# InvoiceFlow: 15 demonstration test cases

All 15 passed using live Gemini responses and isolated databases. No invoices were sent.
These are fictional demonstrations, not 15 collected customer cases.

## 1. English: complete prices

Message:
Customer Demo Customer: replaced 2 oil filters at 25 USD each and 1 fuel filter at 30 USD each. Labor 30 USD.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $110 / 9,900,000 LBP. PASS.

## 2. Arabic: oil service

Message:
الزبون زبون تجريبي. غيرنا عبوة زيت موتور 20 ليتر عدد واحد بسعر 140 دولار للعبوة، وفلتر هوا عدد واحد بسعر 35 دولار. أجرة اليد 45 دولار.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $220 / 19,800,000 LBP. PASS.

## 3. Missing part prices

Message:
Customer Demo Customer: replaced 2 oil filters and 1 fuel filter. Labor 30 USD.

Test amounts entered: Oil Filter = $25, Fuel Filter = $30

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Missing amounts stayed null; filled test amounts and checked recalculated totals
- Test employee approval and final PDF succeeded; nothing sent

Final result: $110 / 9,900,000 LBP. PASS.

## 4. Arabic: missing labor

Message:
الزبون زبون تجريبي. غيرنا فلتر زيت عدد اتنين، سعر الواحد 25 دولار، وفلتر مازوت عدد واحد، سعره 30 دولار.

Test amounts entered: Labor = $30

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Missing amounts stayed null; filled test amounts and checked recalculated totals
- Test employee approval and final PDF succeeded; nothing sent

Final result: $110 / 9,900,000 LBP. PASS.

## 5. Explicit zero: free work

Message:
Customer Demo Customer: replaced 1 oil filter at 0 USD per filter. Labor 0 USD. The part and labor are free.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $0 / 0 LBP. PASS.

## 6. Arabic: Lebanese-pound prices

Message:
الزبون زبون تجريبي. غيرنا فلتر زيت عدد اتنين سعر الواحد 2340000 ليرة لبنانية وفلتر مازوت واحد سعره 2700000 ليرة لبنانية. أجرة اليد 900000 ليرة لبنانية.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $92 / 8,280,000 LBP. PASS.

## 7. Quoted battery price, not catalog price

Message:
Customer Demo Customer: replaced 1 truck battery at 175 USD. Labor 20 USD.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $195 / 17,550,000 LBP. PASS.

## 8. Several brake parts and quantities

Message:
Customer Demo Customer: replaced 2 brake discs at 160 USD each and 1 brake pads set at 120 USD per set. Labor 60 USD.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $500 / 45,000,000 LBP. PASS.

## 9. Arabic: water pump and coolant

Message:
الزبون زبون تجريبي. غيرنا طرمبة مي عدد واحد بسعر 140 دولار، وعبوتين ماء رادياتور حجم العبوة 5 ليتر بسعر 25 دولار للعبوة. أجرة اليد 40 دولار.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $230 / 20,700,000 LBP. PASS.

## 10. Mixed Arabic and English

Message:
Customer Demo Customer: غيرنا 1 air filter بسعر 35 USD و1 drive belt بسعر 45 USD. أجرة اليد 20 USD.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $100 / 9,000,000 LBP. PASS.

## 11. Decimal prices and labor

Message:
Customer Demo Customer: used 3 bottles of brake fluid 1L at 12.50 USD per bottle. Labor 7.25 USD.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $44.75 / 4,027,500 LBP. PASS.

## 12. USD parts with LBP labor

Message:
Customer Demo Customer: replaced 2 oil filters at 25 USD each. Labor 900000 LBP.

Checks:
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $60 / 5,400,000 LBP. PASS.

## 13. Unknown product: ask before invoicing

Message:
Customer Demo Customer: replaced 1 flux capacitor at 50 USD. Labor 30 USD.

Clarification supplied:
Correction: the part was actually 1 truck battery at 180 USD. No flux capacitor was fitted. Labor 30 USD.

Checks:
- Correctly asked for clarification before producing an invoice
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $210 / 18,900,000 LBP. PASS.

## 14. Ambiguous oil size: ask 5L or 20L

Message:
Customer Demo Customer: used 1 container of engine oil at 40 USD. Labor 10 USD.

Clarification supplied:
Correction: it was 1 container of Engine Oil 20L at 140 USD, not 40 USD. Labor 10 USD.

Checks:
- Correctly asked for clarification before producing an invoice
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $150 / 13,500,000 LBP. PASS.

## 15. Missing quantity: ask how many

Message:
Customer Demo Customer: replaced oil filters at 25 USD each. Labor 30 USD.

Clarification supplied:
There were exactly 2 oil filters, at 25 USD each. Labor remains 30 USD.

Checks:
- Correctly asked for clarification before producing an invoice
- Live Gemini rows, quantities, prices, USD total and LBP total matched expectations
- Saved draft verified; premature approval and final PDF blocked
- Test employee approval and final PDF succeeded; nothing sent

Final result: $80 / 7,200,000 LBP. PASS.
