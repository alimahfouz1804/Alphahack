# InvoiceFlow AI: technical documentation

Flask + SQLite backend, vanilla HTML/CSS/JS frontend, Gemini for understanding and speech-to-text,
ReportLab for PDFs. One process serves both the API and the pages (`python start_local.py` or
`start-invoiceflow.bat`, then http://localhost:5000).

## 1. Architecture

```
Browser (frontend/)                       Flask (app.py)
 index.html  app.js  api.js  auth.js       ├─ web_api.py          accounts, invoices, MA chat endpoint, PDF, review
 print.html  print.js                      ├─ invoice_services.py customers, stored PDFs, delivery attempts, print events
        │  fetch + session cookie + CSRF   ├─ workflow_routes.py  voice upload (/api/transcribe), legacy terminal API
        └────────────────────────────────► ├─ ai_agent.py         Gemini: intent router + structured extraction (MA)
                                           ├─ invoice_engine.py   catalog matching, quantity/price rules
                                           ├─ part_lookup.py      out-of-scope filter, optional web name lookup
                                           ├─ voice_agent.py      Gemini speech-to-text
                                           ├─ pdf_invoice.py      invoice PDF layout
                                           ├─ delivery_providers.py SMTP + WhatsApp Cloud API adapters
                                           └─ garage.db (SQLite)  products.json (catalog, read-only)
```

Rule of authority: **the AI proposes, the server decides.** Gemini only turns words into structured data.
Catalog identity, totals, LBP conversion, validation, approval, PDF and delivery are all computed on the server.

## 2. Frontend (frontend/)

- `index.html`: chat panel (MA) on the left, invoice preview on the right (stacked on phones).
  Voice bar (listening / paused / thinking / speaking, Pause, Resume, Stop), recording preview (listen, Delete, Send),
  parts picker, invoice editor (saved-customer dropdown), review checklist, Pending/Approve switch,
  Edit / Save / Download PDF / Print / Send via WhatsApp / Send via Email, delivery activity.
- `js/app.js`: all workspace behaviour. `js/api.js`: every API call. `js/auth.js`: session + CSRF.
- History page: search by number/customer/plate, status and date filters, Delivery column, Open / PDF / Print.
- `print.html` + `js/print.js`: shows the stored approved PDF and opens the browser print dialog.

## 3. API

| Method | Path | Purpose |
|---|---|---|
| POST | /api/invoices/generate | **MA chat**: understands the message (router) then drafts, asks, answers or prepares sending |
| POST | /api/invoices/confirm-parts | Employee confirms suggested catalog parts or names a custom line |
| POST | /api/transcribe | Voice upload → transcript (signed-in only, 10 MB max) |
| GET/POST | /api/invoices | List (with `delivery` status per method) / create (idempotent with `client_request_id`) |
| GET/PUT | /api/invoices/{id} | Read (with `review`) / edit (not when approved) |
| POST | /api/invoices/{id}/pending | Pending button (approved → pending needs approval rights) |
| POST | /api/invoices/{id}/submit | Strict submit (complete invoice + identity required) |
| POST | /api/invoices/{id}/approve | Explicit approval: `confirm:true` + current `review_digest`; stores the final PDF in the same transaction |
| POST | /api/invoices/{id}/reject | Reject (owner) |
| GET | /api/invoices/{id}/pdf | Approved: the stored PDF (`?inline=1` for printing). Pending: `?preview=1` stamped PENDING-PREVIEW, never stored |
| POST | /api/invoices/{id}/print | Records that printing was started (`physical_print_confirmed:false`) |
| POST | /api/invoices/{id}/email | Send stored PDF by SMTP (`confirm`, `request_key`, optional `subject`/`message`, `resend`) |
| POST | /api/invoices/{id}/whatsapp | Send stored PDF by WhatsApp Cloud API (same contract) |
| POST | /api/invoices/{id}/handoff | Records that wa.me or the email app was opened (status `opened`, never `sent`) |
| GET | /api/invoices/{id}/activity | Delivery attempts + print events |
| GET | /api/delivery/config | Which providers are configured (no secrets) |
| GET/POST | /api/customers | Saved customers / create (duplicate-safe) |
| GET | /api/catalog, /api/products | Catalog (read-only) |
| … | /api/auth/*, /api/company | Accounts, sessions, company profile and logo |

All state-changing calls need the session cookie and the `X-CSRF-Token` header. Roles: employees see their own
invoices; owners see the company's and can approve, reject and move approved invoices back to Pending.

## 4. Database (garage.db, SQLite)

Created/migrated automatically with `CREATE TABLE IF NOT EXISTS` (additive only; existing data kept).

| Table | Purpose |
|---|---|
| companies, users, web_sessions, reset_codes | Accounts, company profile, sessions |
| web_invoices | Invoice number, status (`pending`/`approved`/legacy `draft`/`rejected`), JSON payload (customer, truck, items with `catalog_id`/`is_custom`, totals), created/approved timestamps, approver |
| invoice_files | The approved PDF bytes + SHA-256 (one per invoice, immutable) |
| invoice_create_requests | Idempotency keys: a repeated save returns the same invoice |
| web_customers, invoice_customers | Saved customers (company-scoped, duplicate-safe) and the link to approved invoices |
| delivery_attempts | Every email/WhatsApp attempt: `sending` / `sent` / `failed` / `opened`, recipient, provider id, error, PDF hash |
| print_events | Print started (never "printed") |
| audit | Approvals, PDF releases, emails |
| employees, sessions, login_limits, invoices | Legacy terminal workflow (unchanged) |

## 5. MA (AI agent)

**Name and persona:** MA, the InvoiceFlow AI assistant (Lebanese Arabic, Arabic, English, mixed, Arabizi).

**Two Gemini calls per message**, both with structured JSON output (`response_schema`), primary model then backup model:

1. **Router** (`ai_agent.route_message`, schema `Route`): decides `intent` =
   `invoice` | `invoice_query` | `open_invoice` | `send_whatsapp` | `send_email` | `help` | `chat`, plus `language`,
   `understood` (one-line restatement), filters (dates, status, customer, plate, invoice number),
   contact (`phone`/`email` exactly as said), and `new_invoice`. Clear commands ("send to WhatsApp 03 123 456",
   answers to "what's the number?") are recognised by `web_api.quick_route` **without** calling Gemini.
2. **Extractor** (`ai_agent.understand_message`, schema `RepairOrder`): customer, phone/email (only if stated), parts
   (`name`, `original_name`, `quantity`, `quantity_evidence`, `unit_price`, `line_price`, `price_currency`,
   `match_type` named/description, `candidate_ids`, `scope`, `clarification`), labor amount/currency, truck plate/model, notes.

**Rules in the prompts and enforced on the server:** never invent prices, quantities, customers, contacts or catalog
IDs; a quantity counts only if the quoted `quantity_evidence` really appears in what was said; sizes (5L, 20L, 2 m) are
not quantities; prices are never taken from the catalog; corrections in later messages win; functional descriptions
must be confirmed by the employee; out-of-scope items (food etc.) are refused.

**Conversation state:** every message sends the conversation since the current invoice started. A new invoice
starts after an answered question or when the message says "new invoice / another customer / فاتورة جديدة"
(then `new_invoice:true` and the frontend never overwrites the previous invoice).

**Structured draft returned to the frontend** (and stored when saved): `cust`, `truck`, `items[]` (`d`, `q`, `p`,
`total_usd`, `catalog_id`, `is_custom`), `totals` (subtotal, VAT, total USD, total LBP, exchange rate 89,500,
`incomplete`), `warnings[]`, and the server-computed **`review`**: `ready`, `missing[]` (field, item, message),
`duplicates[]`, `custom_items[]`, `approval_required:true`. Clarifications come back as `question`
(+ `suggestions` and a signed `confirmation_token` when parts must be confirmed).

## 6. Catalog matching

`database.search_products` normalises Arabic/English (diacritics, alef forms, Arabic digits, "ال", plurals, packaging
words, litre sizes) and matches against `name_en`, `name_ar` and `aliases` in `products.json`.

| Situation | Behaviour |
|---|---|
| Exactly one match | Catalog line (`catalog_id`), name from the catalog |
| Several matches (e.g. engine oil 5L / 20L) | Suggestions; the employee picks one (signed token, 15 min) |
| Described by function | Up to 3 candidates from the model, validated against the catalog; employee confirms |
| No match | MA asks "What name would you like to display on the invoice for this item?"; the employee types the name, quantity, unit price and currency; a web-sourced name may be pre-filled as a suggestion |
| Out of garage scope | Refused |

Custom lines are saved **in the invoice only** (`is_custom:true`, `catalog_id:null`). `products.json` is never written.

## 7. Voice workflow

Mic → MediaRecorder in the browser (Pause/Resume supported) → Stop → **local preview** (listen, duration) →
Delete (clears blob, URL, timer, releases the mic) or Send → `POST /api/transcribe` (signed-in, ≤10 MB) →
Gemini speech-to-text → the transcript is shown as the employee's message → same path as typed text.
When the employee spoke, MA reads its answer aloud (browser voice); Stop silences it.

## 8. Invoice approval workflow

New invoices are **Pending** (they may still be incomplete). Approval requires: at least one item, every item with a
name, a quantity > 0 and a price (0 only if stated as free), a customer name or truck plate, `confirm:true`, and the
current `review_digest` (so the employee approves exactly what they reviewed). Approval stores the final PDF and the
customer in the same transaction; if the PDF fails, the approval is rolled back. Approved invoices cannot be edited;
an owner can move one back to Pending, then it must be approved again.

## 9. PDF

`pdf_invoice.web_invoice_pdf`: company name, phone and logo; invoice number; date; status; customer and contacts;
truck; items with quantity, unit price, line total USD and LBP; VAT when configured; totals USD and LBP; exchange rate;
notes; approver. Pending previews carry a diagonal "PENDING - PREVIEW" stamp. The approved PDF is generated **once**
and stored in `invoice_files`; download, print, email and WhatsApp API all use those same bytes.
Font: Windows Arial by default (`INVOICE_FONT_PATH` to change).

## 10. WhatsApp and email configuration

Copy the needed lines into `.env` (never commit `.env`), then restart the server. See `delivery.env.example`.

| Channel | How it works | Needs |
|---|---|---|
| WhatsApp — Method A, open chat (always available) | Opens `https://wa.me/<number>?text=<garage, invoice no., summary>` after the employee confirms. A link cannot attach files: the dialog offers Download PDF and says the PDF must be attached in the chat. Recorded as `opened`, never `sent` | Nothing |
| WhatsApp — Method B, send directly | Shown as a choice when configured (MA asks "open the WhatsApp chat or send it directly?"). Uploads the stored PDF and sends it as a document (or as an approved template with a document header when `WHATSAPP_TEMPLATE_NAME` is set); recorded `sent`/`failed` | `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_API_VERSION` (Meta Cloud API account; a normal WhatsApp account has no API). Without a template, document messages need an open 24-hour customer-service window |
| Email (configured) | SMTP with TLS; stored PDF attached; subject/message editable in the popup | `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURITY` (starttls/ssl), `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` |
| Email (not configured) | Opens the employee's email app with the message; the employee attaches the PDF; recorded as `opened` | Nothing |

"Sent" always means **accepted by the provider**; delivery is never claimed (no delivery-receipt webhooks).
Every send needs explicit confirmation, a request key (duplicate-safe), and `resend:true` to send the same recipient again.

## 10b. MA upgrades (Nov 2026)

- **Required identity** (`invoice_validation.py`, mirrored in `frontend/js/validation.js`): customer **full name**
  (first + last, Arabic or English) and **truck number** `^[A-Za-z][0-9]{4}$` (stored uppercase, e.g. `A1234`).
  Checked in MA drafts, the review list, Submit and Approve. MA asks only for what is missing/invalid, with the exact
  reason ("Please provide Ahmad's last name.", "Invalid truck number. Only one letter is allowed…"). Old approved
  invoices are not re-validated.
- **Conversation state**: each MA question returns a signed `state` (what was understood + what was asked, bound to
  the user's session, 30 min). A short answer ("Haddad, A1234") is applied **without another AI call**; valid values
  already collected are never asked again. Pause ("hold on", "استنى") keeps everything; cancel discards the draft.
- **Speed**: the router is skipped while MA waits for an invoice answer; otherwise routing and extraction run in
  parallel; Gemini thinking is kept low; voice turns go in **one request** (multipart `audio` + `payload` to
  `/api/invoices/generate?progress=1`, a `transcript` event arrives first).
- **Language**: detected per message (Arabic/Lebanese/Arabizi/English/mixed); answers carry `language`, which picks
  the speech voice. Live Voice uses voice-activity detection in the browser + server transcription, so there is no
  language button. "MA" is always written MA and spoken "Em Ay" / «إم إيه».
- **Greeting**: once per AI session, with the signed-in employee's first name, in their last-used language.
- **Activity panel** (button right of the chat input): NDJSON `{"type":"activity","key","status"}` events from the
  server (understand → extract → validate name → check truck → check items → totals), plus the real client calls
  (preview shown, approval, PDF, WhatsApp/email sending). Statuses: pending / processing / completed / failed.
- **Sending**: WhatsApp and email are sent by the server only (no share sheet, no wa.me). Success is shown only when
  the provider accepted the message; missing configuration is explained and nothing is sent.

## 11. Tests and evaluation

`TEST_CASES.md` (software tests), `AI_SCENARIOS.md` + `ai_eval/` (60 AI scenarios, live model),
`REAL_WORKSHOP_CASES.md` (real garage validation), `FINAL_REPORT.md` (summary of this work).
