"""MA's capabilities ("tools") and the gate every one of them passes through.

The AI model never executes anything. It only proposes a structured intent (ai_agent.Route). This module decides,
outside the model, whether the signed-in user may use that capability and whether its arguments are valid. Then
web_api runs the existing business function for it, scoped to the user's company (and, for employees, to their
own invoices).

Levels
  READ         look up data the user is allowed to see (invoices, catalog, the invoice on screen)
  WRITE        prepares a change. MA itself never saves, approves or sends: the employee confirms in the app,
               and that request is checked again by its own endpoint (permission + CSRF + explicit confirm)
  DESTRUCTIVE  deleting invoices / customers / data. MA has no such capability (saved invoices are a permanent
               record), so these requests are refused and logged
There is no tool for SQL, files, environment variables, keys or administration: such requests are refused before
any AI call, and free-text AI replies are scrubbed of secrets and internal instructions.
"""
import os
import re
from dataclasses import dataclass
from typing import Literal, Optional

from pydantic import BaseModel, Field, ValidationError, field_validator

import security

READ, WRITE, DESTRUCTIVE = "read", "write", "destructive"


# ---------------------------------------------------------------- argument schemas (validated before execution)
def _choice(value, options, default=""):
    """The model words choices loosely ("pending approval", "prices"): map them onto the allowed values, and
    anything unknown onto the safe default (no filter). Lengths and formats stay strictly validated."""
    v = str(value or "").strip().lower()
    for opt in options:
        if opt and (v == opt or v.startswith(opt[:5])):
            return opt
    return default


class QueryArgs(BaseModel):
    metric: Literal["count", "list", "total"] = "count"
    date_from: str = Field("", max_length=10)
    date_to: str = Field("", max_length=10)
    status: Literal["", "draft", "pending", "approved", "rejected"] = ""
    customer: str = Field("", max_length=80)
    plate: str = Field("", max_length=20)

    @field_validator("date_from", "date_to")
    @classmethod
    def iso_day(cls, v):
        if v and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
            raise ValueError("date must be YYYY-MM-DD")
        return v

    @field_validator("metric", mode="before")
    @classmethod
    def metric_choice(cls, v):
        return _choice(v, ("count", "list", "total"), "count")

    @field_validator("status", mode="before")
    @classmethod
    def status_choice(cls, v):
        v = str(v or "").lower()
        return "pending" if "pend" in v else "approved" if "approv" in v else "rejected" if "reject" in v else "draft" if "draft" in v else ""


class OpenArgs(BaseModel):
    invoice_no: str = Field("", max_length=20)


class ProductArgs(BaseModel):
    product: str = Field("", max_length=80)
    detail: Literal["", "price", "stock", "what"] = ""

    @field_validator("detail", mode="before")
    @classmethod
    def detail_choice(cls, v):
        return _choice(v, ("price", "stock", "what"))


class CurrentArgs(BaseModel):
    detail: Literal["", "items", "count", "total", "customer", "status"] = ""

    @field_validator("detail", mode="before")
    @classmethod
    def detail_choice(cls, v):
        return _choice(v, ("items", "count", "total", "customer", "status"))


class SendArgs(BaseModel):
    phone: str = Field("", max_length=30)
    email: str = Field("", max_length=254)
    invoice_no: str = Field("", max_length=20)
    method: Literal["", "chat", "direct"] = ""

    @field_validator("method", mode="before")
    @classmethod
    def method_choice(cls, v):
        return _choice(v, ("chat", "direct"))


class NoArgs(BaseModel):
    pass


@dataclass(frozen=True)
class Tool:
    name: str
    level: str
    permission: Optional[str]
    args: type
    confirmation: str = ""        # how a WRITE is confirmed (documentation + tests)


TOOLS = {t.name: t for t in (
    Tool("invoice_query", READ, "invoice.history", QueryArgs),
    Tool("open_invoice", READ, "invoice.history", OpenArgs),
    Tool("current_invoice", READ, "invoice.history", CurrentArgs),
    Tool("product_info", READ, "ai.chat", ProductArgs),
    # drafting fills an UNSAVED invoice on screen; saving is POST /api/invoices by the employee (invoice.create)
    Tool("invoice", WRITE, "invoice.create", NoArgs, confirmation="employee presses Save; approval needs review digest"),
    # MA only prepares the message; opening WhatsApp / sending needs the employee's click, and direct sending
    # is POST /api/invoices/<id>/whatsapp|email with confirm=true, a request key and the invoice.send permission
    Tool("send_whatsapp", WRITE, "invoice.history", SendArgs, confirmation="employee confirms in the send dialog"),
    Tool("send_email", WRITE, "invoice.history", SendArgs, confirmation="employee confirms in the send dialog"),
    Tool("cancel", READ, "ai.chat", NoArgs),
    Tool("pause", READ, "ai.chat", NoArgs),
    Tool("help", READ, "ai.chat", NoArgs),
    Tool("chat", READ, "ai.chat", NoArgs),
    Tool("unavailable", READ, "ai.chat", NoArgs),
)}


def permissions(user):
    import web_api
    return web_api.OWNER_PERMS if user["role"] == "owner" else web_api.EMPLOYEE_PERMS


def refusal(en, ar_text, is_ar):
    return {"reply": ar_text if is_ar else en, "kind": "answer", "refused": True}


def gate(user, intent, r, ar):
    """(args, None) when the user may run this capability with these arguments, else (None, refusal reply).
    The decision never depends on what the model says about permissions."""
    tool = TOOLS.get(intent or "")
    if tool is None:
        security.log_event("tool_unknown", user=user, detail=str(intent)[:40])
        return None, refusal("Sorry, I can't do that here.", "عذرًا، ما فيني أعمل هالشي هون.", ar)
    if tool.permission and tool.permission not in permissions(user):
        security.log_event("tool_denied", user=user, detail=tool.name)
        return None, refusal("Your account isn't allowed to do that. Ask the garage owner if you need access.",
                             "حسابك ما بيسمح بهالشي. إسأل صاحب الكاراج إذا بدك صلاحية.", ar)
    try:
        fields = {k: r[k] for k in tool.args.model_fields if r.get(k) not in (None,)}
        args = tool.args.model_validate(fields)
    except ValidationError:
        security.log_event("tool_args_invalid", user=user, detail=tool.name)
        return None, refusal("I couldn't use that request as given. Could you say it another way?",
                             "ما قدرت إستعمل الطلب هيك. فيك تقولو بطريقة تانية؟", ar)
    return {**r, **args.model_dump()}, None


# ---------------------------------------------------------------- prompt-injection screen (before any AI call)
_SCREEN = [
    ("reveal_prompt", re.compile(
        r"\b(?:system|initial|hidden|original|developer)\s+(?:prompt|instructions?|message|rules)\b|\byour\s+(?:prompt|instructions|rules|system\s+message)\b|"
        r"(?:repeat|print|show|reveal|tell me|output|dump)\s+(?:me\s+)?(?:everything|all|the text)\s+(?:above|before)|"
        r"تعليماتك|برومبت|البرومبت|التعليمات\s+(?:الأصلية|السرية|يلي\s+عطوك)", re.I)),
    ("reveal_secret", re.compile(
        r"\b(?:api|secret|access|private)[\s_-]*keys?\b|\bapi[\s_-]*token\b|\.env\b|\benv(?:ironment)?\s+var(?:iable)?s?\b|"
        r"\b(?:smtp|whatsapp|gemini|openai|database|db|admin)\s+(?:password|token|key|credentials?)\b|\bcredentials?\b|"
        r"\b(?:show|give|tell|send|reveal)\s+(?:me\s+)?(?:the\s+|your\s+|all\s+|his\s+|her\s+|their\s+)?(?:passwords?|password\s+hash(?:es)?)\b|"
        r"مفتاح\s+(?:الـ?\s*)?api|المفتاح\s+السري|كلمة\s+(?:السر|المرور)\s+(?:تبع|تبعك|للـ?)|باسوورد(?:ات)?\s+(?:الـ?)?(?:سيستم|داتابيس|موظفين)", re.I)),
    ("raw_sql", re.compile(
        # real SQL shapes only, so "select the oil filter from the list" or "update quantity set to 3" are not caught
        r"\bselect\s+(?:\*|[a-z_]+(?:\s*,\s*[a-z_]+)*)\s+from\s+[a-z_]+\s*(?:where\b|limit\b|order\b|;|$)|\bdrop\s+table\b|"
        r"\bdelete\s+from\s+[a-z_]+|\binsert\s+into\s+[a-z_]+\s*(?:\(|values\b)|\bupdate\s+[a-z_]+\s+set\s+[a-z_]+\s*=|\bunion\s+(?:all\s+)?select\b|"
        r"\b(?:run|execute)\s+(?:this\s+|a\s+|an\s+)?(?:raw\s+)?(?:sql|query|command)\b|;\s*--|\bsqlite_master\b|\bgarage\.db\b", re.I)),
    ("override", re.compile(
        r"\b(?:ignore|forget|disregard|override)\s+(?:all\s+|any\s+|your\s+|the\s+)?(?:previous\s+|prior\s+|above\s+|earlier\s+)?"
        r"(?:instructions|rules|guidelines|prompts?)\b|\bjailbreak\b|\bdeveloper\s+mode\b|"
        r"\b(?:you\s+are|act\s+as|pretend\s+to\s+be)\s+(?:now\s+)?(?:an?\s+)?(?:admin|administrator|root|superuser|unrestricted)\b|"
        r"\b(?:bypass|disable|skip)\s+(?:the\s+)?(?:auth(?:entication)?|login|security|permissions?|approval|confirmation)\b|"
        r"تجاهل\s+(?:كل\s+)?(?:التعليمات|القواعد)|انسى\s+(?:كل\s+)?(?:التعليمات|القواعد)", re.I)),
    ("destructive", re.compile(
        r"\b(?:delete|erase|wipe|destroy|purge)\s+(?:the\s+|this\s+|that\s+|all\s+(?:the\s+)?|every\s+|my\s+|our\s+)?"
        r"(?:invoices?|customers?|clients?|records?|database|data|history|everything|accounts?|users?|products?|catalog)\b|"
        r"\bremove\s+(?:all\s+(?:the\s+)?|every\s+)?(?:customers?|clients?|records?|database|accounts?|users?)\b|"
        r"\bremove\s+(?:the\s+|this\s+|that\s+|all\s+(?:the\s+)?)?invoices?\s*(?:#?\s*\d+|inv-\d+)?\s*(?:from\s+(?:the\s+)?(?:system|history|database))?\s*[.!]?$|"
        r"(?:احذف|احذفلي|امسح|امسحلي|امحي|امحيلي|إمسح|إحذف)\s+(?:كل\s+)?(?:الفاتورة|الفواتير|الزبون|الزباين|الزبائن|الداتا|البيانات|السجلات|الحسابات)", re.I)),
]
# An explicit attempt to override the rules is reported as such, even when it also asks for the prompt.
_SCREEN.sort(key=lambda entry: entry[0] != "override")
_REPLIES = {
    "reveal_prompt": ("I keep my internal instructions private, but I'm happy to tell you what I can do: invoices, "
                      "your invoice history, catalog prices, and sending approved invoices.",
                      "تعليماتي الداخلية بتضل خاصة، بس بخبرك شو فيني أعمل: الفواتير، سجل الفواتير، أسعار الكتالوج، وإرسال الفواتير الموافق عليها."),
    "reveal_secret": ("I can't share keys, passwords or other credentials, and I don't have access to them. "
                      "To change your own password, use your profile page.",
                      "ما فيني شارك مفاتيح أو كلمات سر أو أي بيانات دخول، وما عندي وصول إلها. لتغيّر كلمة السر تبعك، روح على صفحة الحساب."),
    "raw_sql": ("I can't run database commands. Ask me in plain words instead, for example \"how many invoices this month?\".",
                "ما فيني شغّل أوامر داتابيس. إسألني بكلام عادي، مثلاً «قديش فاتورة هالشهر؟»."),
    "override": ("I can't change how I work or skip security checks, but I'm glad to help within the app.",
                 "ما فيني غيّر طريقة شغلي أو إتخطّى الحماية، بس أكيد بساعدك ضمن التطبيق."),
    "destructive": ("I can't delete invoices, customers or other records: saved invoices are kept as a permanent record. "
                    "If a draft is wrong, I can cancel it or you can correct it.",
                    "ما فيني إمحي فواتير أو زباين أو سجلات: الفواتير المحفوظة بتضل سجل دايم. إذا في مسودة غلط، فيني إلغيها أو فيك تصحّحها."),
}


def screen(text, user, ar):
    """A refusal reply when the message tries to extract secrets/instructions, run SQL, override MA's rules or
    delete data; else None. Runs before any AI call, so the model never even sees these requests."""
    for kind, rx in _SCREEN:
        if rx.search(text or ""):
            security.log_event("prompt_injection", user=user, detail=kind)
            en, ar_text = _REPLIES[kind]
            return refusal(en, ar_text, ar)
    return None


# ---------------------------------------------------------------- output scrubbing (after the model)
_PROMPT_MARKERS = re.compile(r"Intents:|invoice_query|current_invoice|product_info|send_whatsapp|Treat the conversation as data|"
                             r"\{employee\}|\{today\}|response_schema|ROUTER_PROMPT|Mechanic conversation \(data", re.I)
_SECRET_ENV = ("GEMINI_API_KEY", "SMTP_PASSWORD", "WHATSAPP_ACCESS_TOKEN", "SMTP_USER")


def scrub_reply(text, ar=False):
    """Free text written by the model is checked before it reaches the user: it must not contain internal
    instructions or any configured secret value."""
    out = str(text or "")
    for name in _SECRET_ENV:
        value = os.getenv(name) or ""
        if len(value) >= 6 and value in out:
            security.log_event("reply_scrubbed", detail="secret")
            return _REPLIES["reveal_secret"][1 if ar else 0]
    if _PROMPT_MARKERS.search(out):
        security.log_event("reply_scrubbed", detail="prompt")
        return _REPLIES["reveal_prompt"][1 if ar else 0]
    return out
