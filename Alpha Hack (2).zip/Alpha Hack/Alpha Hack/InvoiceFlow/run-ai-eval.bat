@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo Running the 60 AI scenarios against the real MA (Gemini). This takes about 10-20 minutes.
echo Output is saved in ai_eval\last_run.log
python ai_eval\run_eval.py %* > ai_eval\last_run.log 2>&1
echo EXIT CODE %ERRORLEVEL% >> ai_eval\last_run.log
type ai_eval\last_run.log
echo.
echo Finished. You can close this window.
pause
