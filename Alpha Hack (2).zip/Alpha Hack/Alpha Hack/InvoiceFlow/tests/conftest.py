"""Shared fixtures for the security tests: a fresh temporary database per test, synthetic users and companies,
and the AI replaced by stand-ins (the tests never call Gemini and never touch garage.db or real customer data)."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("GEMINI_API_KEY", "test-only")

import pytest
from unittest.mock import patch

from app import app as flask_app
import web_api

PASSWORD = "Garage2026x"
GOOD_INVOICE = {"cust": {"name": "Rami Khoury"}, "truck": {"plate": "A1234"}, "items": [{"d": "Oil Filter", "q": 1, "p": 25}]}


@pytest.fixture
def app(tmp_path):
    old = flask_app.config["INVOICE_DB"]
    flask_app.config["INVOICE_DB"] = str(tmp_path / "security.db")
    # MA's intent router answers "chat" unless a test says otherwise: no live AI call is ever made
    with patch("ai_agent.route_message", return_value={"intent": "chat", "reply": "Sure."}) as router:
        flask_app.router_mock = router
        yield flask_app
    flask_app.config["INVOICE_DB"] = old


class Account:
    """A signed-in browser: test client + CSRF header + who it is."""
    def __init__(self, client, username, user):
        self.c, self.username, self.user = client, username, user

    @property
    def h(self):
        return {"X-CSRF-Token": self.c.get_cookie("if_csrf").value}

    def get(self, url, **kw):
        return self.c.get(url, **kw)

    def post(self, url, **kw):
        return self.c.post(url, headers={**self.h, **kw.pop("headers", {})}, **kw)

    def put(self, url, **kw):
        return self.c.put(url, headers={**self.h, **kw.pop("headers", {})}, **kw)

    def say(self, text, **kw):
        return self.post("/api/invoices/generate", json={"text": text, "history": kw.pop("history", []), **kw})

    def invoice(self, data=None):
        r = self.post("/api/invoices", json=data or GOOD_INVOICE)
        assert r.status_code == 201, r.json
        return r.json


@pytest.fixture
def owner(app):
    return register(app, "owner_a", "Cedar Trucks")


@pytest.fixture
def other_owner(app):
    return register(app, "owner_b", "Other Garage")


@pytest.fixture
def employee(app, owner):
    web_api.create_user("emp_a", PASSWORD, "Sami", "Test", "", role="employee",
                        company_id=owner.user["company"]["id"], path=app.config["INVOICE_DB"])
    return login(app, "emp_a")


def register(app, username, company):
    c = app.test_client()
    r = c.post("/api/auth/register", json=dict(first_name="Test", last_name="Owner", username=username, password=PASSWORD,
                                               phone="+96171123456", company_name=company))
    assert r.status_code == 201, r.json
    return Account(c, username, r.json["user"])


def login(app, username, password=PASSWORD, client=None):
    c = client or app.test_client()
    r = c.post("/api/auth/login", json={"username": username, "password": password}, headers={"X-Requested-With": "InvoiceFlow"})
    assert r.status_code == 200, r.json
    return Account(c, username, r.json["user"])
