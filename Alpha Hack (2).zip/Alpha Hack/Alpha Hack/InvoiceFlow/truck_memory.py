"""Customer memory, keyed by the truck's plate number (the truck's ID).

Every saved / approved / sent invoice teaches InvoiceFlow who drives which truck: the plate number, the
customer's name, phone, email and truck model. Next time MA hears only the name, plate or phone, it
fills in the rest, and it knows whether this is a new, returning or loyal customer from the real invoice
history. Nothing is guessed: values only come from earlier invoices of the same company.
"""
import json
import re
import time
import unicodedata

SCHEMA = """
CREATE TABLE IF NOT EXISTS truck_customers(
 company_id INTEGER NOT NULL, plate_key TEXT NOT NULL, plate TEXT NOT NULL,
 name TEXT NOT NULL DEFAULT '', tel TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
 model TEXT NOT NULL DEFAULT '', first_seen REAL NOT NULL, last_seen REAL NOT NULL,
 PRIMARY KEY(company_id, plate_key));
CREATE INDEX IF NOT EXISTS truck_customers_tel ON truck_customers(company_id, tel);
"""

LOYAL_AFTER = 3          # approved invoices before a customer counts as loyal
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def plate_key(plate):
    """'b 99-881', 'B99881' and 'ب ٩٩٨٨١' style spellings of the same plate compare equal."""
    return re.sub(r"[\s\-_./]", "", str(plate or "").translate(AR_DIGITS)).upper()


def _clean(v):
    return str(v or "").strip()


def remember(db, company_id, cust, truck):
    """Save/refresh what this invoice says about the truck's customer. Empty values never erase saved ones."""
    plate = _clean((truck or {}).get("plate"))
    key = plate_key(plate)
    if not key:
        return None
    cust = cust or {}
    new = {"name": _clean(cust.get("name")), "tel": _clean(cust.get("tel")), "email": _clean(cust.get("email")),
           "model": _clean((truck or {}).get("model"))}
    now = time.time()
    row = db.execute("SELECT * FROM truck_customers WHERE company_id=? AND plate_key=?", (company_id, key)).fetchone()
    if row:
        merged = {k: new[k] or row[k] for k in new}
        db.execute("UPDATE truck_customers SET plate=?, name=?, tel=?, email=?, model=?, last_seen=? WHERE company_id=? AND plate_key=?",
                   (plate, merged["name"], merged["tel"], merged["email"], merged["model"], now, company_id, key))
    else:
        db.execute("INSERT INTO truck_customers(company_id, plate_key, plate, name, tel, email, model, first_seen, last_seen) VALUES (?,?,?,?,?,?,?,?,?)",
                   (company_id, key, plate, new["name"], new["tel"], new["email"], new["model"], now, now))
    return key


def remember_contact(db, company_id, plate, method, recipient):
    """A number/email the invoice was actually sent to becomes the truck customer's saved contact."""
    key = plate_key(plate)
    if not key or not recipient:
        return
    field = "email" if method == "email" else "tel"
    db.execute("UPDATE truck_customers SET %s=?, last_seen=? WHERE company_id=? AND plate_key=?" % field,
               (recipient, time.time(), company_id, key))


def name_key(name):
    """Compare full names without case, spacing or Arabic vocalization differences."""
    name = unicodedata.normalize("NFC", _clean(name)).casefold().replace("’", "'")
    return " ".join(re.sub(r"[\u064b-\u065f\u0670\u0640]", "", name).split())


def named_trucks(db, company_id, name):
    """Exact normalized full-name matches, including records saved before name lookup existed."""
    key = name_key(name)
    if not key:
        return []
    return [row for row in db.execute(
        "SELECT * FROM truck_customers WHERE company_id=? ORDER BY plate_key", (company_id,))
        if name_key(row["name"]) == key]


def find(db, company_id, plate=None, tel=None, name=None):
    key = plate_key(plate)
    if key:
        row = db.execute("SELECT * FROM truck_customers WHERE company_id=? AND plate_key=?", (company_id, key)).fetchone()
        if row:
            return row
    if _clean(tel):
        row = db.execute("SELECT * FROM truck_customers WHERE company_id=? AND tel=? ORDER BY last_seen DESC LIMIT 1",
                         (company_id, _clean(tel))).fetchone()
        if row:
            return row
    if not key:
        matches = named_trucks(db, company_id, name)
        if len(matches) == 1:
            return matches[0]
    return None


def history(db, company_id, key, exclude=None):
    """Real numbers from this company's invoices for this plate."""
    count = approved = 0
    total, first, last = 0.0, None, None
    for r in db.execute("SELECT id, status, payload, created_at FROM web_invoices WHERE company_id=?", (company_id,)):
        if r["id"] == exclude:
            continue
        try:
            p = json.loads(r["payload"])
        except ValueError:
            continue
        if plate_key((p.get("truck") or {}).get("plate")) != key:
            continue
        count += 1
        first = r["created_at"] if first is None else min(first, r["created_at"])
        last = r["created_at"] if last is None else max(last, r["created_at"])
        if r["status"] == "approved":
            approved += 1
            total += float((p.get("totals") or {}).get("total_usd") or 0)
    return {"invoices": count, "approved": approved, "total_usd": round(total, 2), "first": first, "last": last}


def profile(db, company_id, plate=None, tel=None, exclude=None, name=None):
    """Who this truck's customer is and how loyal: new / returning / loyal. None when nothing is known."""
    row = find(db, company_id, plate, tel, name)
    key = row["plate_key"] if row else plate_key(plate)
    if not key:
        return None
    h = history(db, company_id, key, exclude)
    if not row and not h["invoices"]:
        return None
    status = "loyal" if h["approved"] >= LOYAL_AFTER else "returning" if h["invoices"] else "new"
    out = {"plate": row["plate"] if row else plate, "status": status, **h}
    if row:
        out.update(name=row["name"], tel=row["tel"], email=row["email"], model=row["model"])
    return out


def fill_order(db, company_id, result):
    """Complete an AI draft from memory: plate from a unique name or phone, other details from the plate.
    Only empty fields are filled; whatever the mechanic said always wins. Returns (profile, filled fields)."""
    row = find(db, company_id, result.get("truck_plate"), result.get("customer_phone"), result.get("customer"))
    if not row:
        return None, []
    said = plate_key(result.get("truck_plate"))
    other_truck = bool(said) and said != row["plate_key"]   # known phone, new plate: same owner, another truck
    fields = (("customer", "name"), ("customer_email", "email")) if other_truck else \
             (("truck_plate", "plate"), ("customer", "name"), ("customer_phone", "tel"), ("customer_email", "email"), ("truck_model", "model"))
    filled = []
    for field, col in fields:
        if not _clean(result.get(field)) and row[col]:
            result[field] = row[col]
            filled.append(field)
    return profile(db, company_id, result.get("truck_plate") if other_truck else row["plate"]), filled
