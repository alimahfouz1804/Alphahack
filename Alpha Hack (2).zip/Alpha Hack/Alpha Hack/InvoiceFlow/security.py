"""App-wide security layer for InvoiceFlow / MA (Flask).

  * passwords:      Argon2id (pwdlib); older Werkzeug hashes are verified once and upgraded at the next sign-in
  * rate limiting:  sliding windows stored in SQLite, so limits survive restarts and are shared by all workers
  * audit trail:    security_events (who, what, when) - never message contents, passwords, tokens or keys
  * HTTP layer:     HTTPS redirect + HSTS, security headers + CSP, Origin check, JSON size limit, JSON errors

Security is enforced here and in the route handlers, never by instructions given to the AI model.
"""
import hashlib
import logging
import sqlite3
import time
from contextlib import contextmanager
from functools import lru_cache

from flask import current_app, g, jsonify, redirect, request
from pwdlib import PasswordHash
from pwdlib.hashers.argon2 import Argon2Hasher
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash as legacy_check

from security_config import settings

log = logging.getLogger("invoiceflow.security")

# ---------------------------------------------------------------- passwords
# Argon2id with the library's recommended (OWASP) cost parameters.
_HASHER = PasswordHash((Argon2Hasher(),))
_DUMMY = _HASHER.hash("timing-equaliser-not-a-password")


def hash_password(password):
    return _HASHER.hash(password)


def verify_password(stored, password):
    """(ok, upgraded_hash_or_None). Unknown users should call verify_password(None, pw) so the response takes
    the same time whether or not the account exists (no username enumeration by timing)."""
    if not isinstance(password, str):
        return False, None
    if not stored:
        _HASHER.verify(password, _DUMMY)
        return False, None
    if stored.startswith("$argon2"):
        ok, new = _HASHER.verify_and_update(password, stored)   # new hash when the cost parameters changed
        return ok, new
    ok = legacy_check(stored, password)                          # Werkzeug pbkdf2/scrypt from before the upgrade
    return ok, (hash_password(password) if ok else None)


# ---------------------------------------------------------------- storage
SCHEMA = """
CREATE TABLE IF NOT EXISTS rate_events(bucket TEXT NOT NULL, at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS rate_events_bucket ON rate_events(bucket, at);
CREATE TABLE IF NOT EXISTS security_events(id INTEGER PRIMARY KEY, at REAL NOT NULL, kind TEXT NOT NULL,
  user_id INTEGER, company_id INTEGER, ip_hash TEXT, detail TEXT NOT NULL DEFAULT '');
"""


@contextmanager
def _db():
    """Short-lived connection that is always committed and closed (an open handle would lock the file)."""
    db = sqlite3.connect(current_app.config["INVOICE_DB"], timeout=10)
    try:
        db.executescript(SCHEMA)
        with db:
            yield db
    finally:
        db.close()


def _key(text):
    # buckets and addresses are stored hashed: the table never holds usernames or IP addresses in clear
    return hashlib.sha256(text.encode("utf-8", "ignore")).hexdigest()[:40]


def client_ip():
    return request.remote_addr or "unknown"


# ---------------------------------------------------------------- rate limiting
def _window(name):
    return settings().limit(name)


def rate_count(name, subject):
    """How many events are recorded for this limit + subject in its current window."""
    count, seconds = _window(name)
    with _db() as db:
        return db.execute("SELECT COUNT(*) FROM rate_events WHERE bucket=? AND at>?",
                          (_key(name + ":" + str(subject)), time.time() - seconds)).fetchone()[0]


def rate_limited(name, subject):
    return rate_count(name, subject) >= _window(name)[0]


def rate_record(name, subject):
    count, seconds = _window(name)
    now = time.time()
    with _db() as db:
        db.execute("INSERT INTO rate_events VALUES (?,?)", (_key(name + ":" + str(subject)), now))
        db.execute("DELETE FROM rate_events WHERE at<?", (now - 86400,))   # nothing older than a day is kept


def rate_hit(name, subject):
    """Count one request; False when the limit is already reached (the request must be refused)."""
    if rate_limited(name, subject):
        log_event("rate_limited", detail=name)
        return False
    rate_record(name, subject)
    return True


def rate_clear(name, subject):
    with _db() as db:
        db.execute("DELETE FROM rate_events WHERE bucket=?", (_key(name + ":" + str(subject)),))


def too_many(message="Too many requests. Please wait a moment and try again."):
    resp = jsonify(detail=message)
    resp.status_code = 429
    resp.headers["Retry-After"] = "60"
    return resp


# ---------------------------------------------------------------- security events
def log_event(kind, user=None, detail=""):
    """Record a security-relevant event. `detail` must be a short code or label, never user content or secrets."""
    try:
        u = user if user is not None else getattr(g, "web_user", None)
        with _db() as db:
            db.execute("INSERT INTO security_events(at, kind, user_id, company_id, ip_hash, detail) VALUES (?,?,?,?,?,?)",
                       (time.time(), kind[:40], u["id"] if u else None, u["company_id"] if u else None,
                        _key("ip:" + client_ip()), str(detail)[:120]))
        log.info("security event %s %s", kind, str(detail)[:60])
    except Exception:          # auditing must never break the request
        log.warning("could not record security event %s", kind)


def events(kind=None):
    with _db() as db:
        db.row_factory = sqlite3.Row
        sql = "SELECT * FROM security_events" + (" WHERE kind=?" if kind else "") + " ORDER BY id"
        return [dict(r) for r in db.execute(sql, (kind,) if kind else ())]


# ---------------------------------------------------------------- HTTP layer
GEMINI_LIVE_WS = "wss://generativelanguage.googleapis.com"


@lru_cache
def content_security_policy():
    # No inline scripts exist in the frontend, so scripts are limited to this origin and the pinned icon CDN.
    # Inline *styles* are allowed (style attributes in the HTML; styles cannot execute code).
    return "; ".join([
        "default-src 'self'",
        "script-src 'self' https://cdn.jsdelivr.net",
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: blob:",
        "media-src 'self' blob:",
        "font-src 'self' data:",
        "connect-src 'self' " + GEMINI_LIVE_WS,     # Live Voice talks to Gemini with a short-lived token
        "frame-src 'self'",
        "worker-src 'self' blob:",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
    ])


def _same_origin(origin):
    host = request.host_url.rstrip("/")
    allowed = {host, host.replace("http://", "https://", 1)} | set(settings().origins())
    return origin.rstrip("/") in allowed


def register_security(app):
    s = settings()

    @app.before_request
    def enforce_transport_and_size():
        if s.force_https and not request.is_secure:
            if request.method in ("GET", "HEAD"):
                return redirect(request.url.replace("http://", "https://", 1), code=308)
            resp = jsonify(detail="HTTPS is required.")
            resp.status_code = 403
            return resp
        # Requests that change data must come from this site (or a configured origin). Browsers always send
        # Origin on cross-site POST/PUT/DELETE, so this stops cross-site requests even before the CSRF check.
        if request.method not in ("GET", "HEAD", "OPTIONS") and request.path.startswith("/api/"):
            origin = request.headers.get("Origin")
            if origin and not _same_origin(origin):
                log_event("cross_origin_blocked", detail=origin[:80])
                resp = jsonify(detail="Cross-site request blocked.")
                resp.status_code = 403
                return resp
        # JSON bodies are small; only audio and logo uploads (multipart) may use the larger global limit.
        if (request.mimetype or "").endswith("json"):
            if (request.content_length or 0) > s.max_json_bytes:
                resp = jsonify(detail="Request is too large.")
                resp.status_code = 413
                return resp
            if request.method in ("POST", "PUT", "PATCH") and request.get_data(cache=True) and request.get_json(silent=True) is None:
                resp = jsonify(detail="The request body is not valid JSON.", error="Expected a JSON object")
                resp.status_code = 400
                return resp
        return None

    @app.after_request
    def security_headers(resp):
        h = resp.headers
        h.setdefault("X-Content-Type-Options", "nosniff")
        h.setdefault("X-Frame-Options", "DENY")
        h.setdefault("Referrer-Policy", "same-origin")
        h.setdefault("Permissions-Policy", "microphone=(self), camera=(), geolocation=(), payment=(), usb=()")
        h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        h.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        if resp.mimetype == "text/html":
            h.setdefault("Content-Security-Policy", content_security_policy())
        if request.path.startswith("/api/"):
            h["Cache-Control"] = "no-store"
        if s.force_https and request.is_secure:
            h.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        h.pop("Server", None)
        return resp

    def wants_json():
        return request.path.startswith(("/api/", "/media/"))

    @app.errorhandler(HTTPException)
    def http_error(exc):
        # Generic messages only: no stack traces, file paths, SQL or library names are ever returned.
        if getattr(exc, "response", None) is not None:      # abort(our own JSON response): keep it as is
            return exc.response
        if exc.code == 413:
            resp = jsonify(detail="Upload too large; maximum recording size is 10 MB", error="Upload too large; maximum recording size is 10 MB")
        elif not wants_json():
            return exc
        else:
            resp = jsonify(detail={400: "Bad request.", 401: "Please sign in again.", 403: "Not allowed.", 404: "Not found.",
                                   405: "Method not allowed.", 429: "Too many requests."}.get(exc.code, "Request failed."))
        resp.status_code = exc.code or 500
        return resp

    @app.errorhandler(Exception)
    def unhandled(exc):
        if isinstance(exc, HTTPException):
            return http_error(exc)
        current_app.logger.exception("Unhandled error on %s %s", request.method, request.path)
        resp = jsonify(detail="Something went wrong on the server. Please try again.")
        resp.status_code = 500
        return resp
