# Open InvoiceFlow on this laptop

Double-click start-invoiceflow.bat in this folder, or run `python start_local.py` in VS Code. Open http://localhost:5000/signin.html (not the HTML file directly). No separate frontend server or Node installation is needed.

1. Click Create account. Use a new website username, for example alitaam_web. Your existing AliTaam terminal employee account remains separate and unchanged.
2. Enter your name, garage name, phone, and a private password following the form rules. The website account owns its new garage and can approve its invoices.
3. Select Talk with AI. Type a repair description and press the send arrow, or click the microphone, allow microphone access, speak, and click again to stop. The recording is transcribed and a draft is prepared automatically. Review it, then speak any correction in the same conversation. See VOICE-GUIDE.md.
4. Review the products and totals. Prices must be stated explicitly: "Customer Demo Customer: 2 oil filters at 25 USD each and 1 fuel filter at 30 USD each. Labor 30 USD." gives USD 110 / LBP 9,845,000 (1 USD = 89,500 LBP). No VAT is automatically added. Omitted prices stay blank (shown as a dash), even when the product has a saved catalog price. Missing labor also stays blank. Enter 0 explicitly only for free work or parts.
5. Click Edit Invoice to fill in blank prices, then Save Draft. You can save an incomplete draft, but its final totals remain blank and submission/approval is blocked until the quantities and prices are complete. Click Submit for Approval, open Pending Approvals, review the invoice, and click Approve. Confirm the displayed totals and any warnings.
6. Open the approved invoice from Invoice History and click Download PDF.

Download PDF works for every invoice: pending invoices download a preview stamped PENDING, approved invoices download the final PDF.

WhatsApp and email need an approved invoice and your confirmation (Confirm & Send). Type the number or email in the popup, or tell MA: "MA, send this invoice to WhatsApp 03 123 456" or "MA, email this invoice to customer@gmail.com". WhatsApp opens with the message ready; you press Send inside WhatsApp.

Email: without a mail server, your email app opens with the message ready and you attach the PDF yourself. To let InvoiceFlow send emails with the PDF attached automatically, add these lines to .env and restart the server (Gmail needs an App Password, not your normal password):

    SMTP_HOST=smtp.gmail.com
    SMTP_PORT=587
    SMTP_SECURITY=starttls
    SMTP_USER=yourgarage@gmail.com
    SMTP_PASSWORD=your-16-letter-app-password
    SMTP_FROM=yourgarage@gmail.com

Optional: to send the PDF itself through the paid WhatsApp Business (Meta Cloud) API, fill the WHATSAPP_ lines from delivery.env.example; a "Send PDF via API" button then appears next to Confirm & Send. The free wa.me method works without it.

Approved invoices store their final PDF once; downloads, Print and email always use that same file. Print opens a print page for the approved PDF.

SMS password recovery is not configured. Nothing is sent without your confirmation. Test accounts from the uploaded ZIP were not imported.

Keep the server running while using the website. If a launcher opened a server console, closing that console stops the server. It listens only on this laptop. A friend on a different laptop cannot use your localhost address.

Tests: `python -m unittest test_backend test_workflow test_web -v`

Quick missing-price test: "Customer Demo Customer: replaced 2 oil filters and 1 fuel filter. Labor 30 USD." Both part prices and their line totals must show a dash. Labor remains USD 30 and the final total is blank. Click Edit Invoice, enter 25 and 30 in the two unit-price fields, and Save Draft: the total becomes USD 110 / LBP 9,845,000. Refresh with Ctrl+Shift+R after a code update. Previously saved invoices keep their existing prices; generate a new draft to test the new behavior.

Existing .env, garage.db records and products.json were preserved. Pre-installation backups are in .local-backups. The original terminal APIs and employee approval workflow remain available. Website invoices are stored separately in the same local database and are scoped to the signed-in garage.

