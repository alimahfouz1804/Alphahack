# InvoiceFlow / MA — Security Audit and Plan

Audited: 15 Nov 2026. Scope: every Python module, the `frontend/` folder, `.env` handling, the SQLite database and MA's AI flow.

## Actual stack (differs from the brief)

| Brief says | The project really uses | Decision |
|---|---|---|
| FastAPI | **Flask 3.1** (`app.py`, `web_api.py`, `workflow_routes.py`, `invoice_services.py`) | Keep Flask; apply every requirement to it |
| OpenAI API | **Google Gemini** (`google-genai`) for chat, extraction and transcription | Keep Gemini; Live Voice moves to the Gemini Live API (part 2) |
| JWT | **Server-side session cookies** (HttpOnly, random 256-bit token stored hashed) + double-submit **CSRF** token; plus an older **Bearer-token** login for terminal employees | Keep both; harden them. No second auth system, no JWT |
| SQLite | SQLite (`garage.db`, outside the public `frontend/` folder) | Keep SQLite |

## How MA works (relevant to security)

1. The browser sends the message (or a voice recording) and the conversation history to `POST /api/invoices/generate`.
2. The server asks Gemini to classify the message into one structured **intent** (`ai_agent.Route`), or handles it without AI (greetings, short answers).
3. The server, not the AI, runs a fixed Python function for that intent. Each one reads only the signed-in user's company, and employees only see their own invoices.
4. The AI never receives SQL, files, environment variables or keys, and it cannot write anything. An invoice draft is saved only when the employee presses Save. Approval and sending need explicit confirmation requests from the user's own browser, with CSRF.

This design is sound. The gaps are listed below.

## Findings

Severity: **Critical** = exploitable now without an account; **High** = serious with little effort; **Medium** = needs an account or specific conditions; **Low** = hardening / defence in depth.

| # | Severity | Finding | Impact | Fix |
|---|---|---|---|---|
| 1 | **Critical** | `POST /api/invoice/draft` (`app.py`) needs **no login**. It calls Gemini and writes a draft into the database. | Anyone who can reach the server can burn the Gemini quota/bill and fill the database. | Require a signed-in user (web session or terminal token) and rate-limit it. |
| 2 | **High** | `GET /api/products` and `/api/products/search` are public. | The full catalog with prices is readable without an account. | Require sign-in. |
| 3 | **High** | No rate limiting on MA (`/api/invoices/generate`), `/api/transcribe`, part confirmation or sending. The login limiter lives in memory (resets on restart, not shared) and only counts usernames that exist. | Cost abuse of Gemini; password guessing restarts with the server. | Database-backed limiter for login (per account and per IP), registration, username checks, MA chat, voice and sending. |
| 4 | **High** | Passwords use Werkzeug's default hash, not Argon2id. | Weaker against offline cracking if the database leaks. | Argon2id (`pwdlib`). Existing hashes keep working and are upgraded at the next successful login. |
| 5 | **High** | Sessions last 12 h (30 days with "remember me") with **no rotation and no idle timeout**. | A stolen cookie stays valid for up to 30 days. | Rotate the session token every 15 min (the cookie equivalent of short-lived access + refresh rotation). Idle timeout. If an old token is replayed after rotation, every session of that user is revoked (theft detection). |
| 6 | **High** | No security headers: no CSP, no clickjacking protection, no Referrer / Permissions policy, no HSTS. | XSS impact is unrestricted; pages can be framed. | Strict CSP (no inline scripts exist, so `script-src 'self'` plus the pinned icon CDN), `frame-ancestors 'none'`, Referrer-Policy, Permissions-Policy (microphone only for the app itself), HSTS over HTTPS. |
| 7 | **Medium** | Cookies get the `Secure` flag only if Flask itself sees HTTPS. Behind a reverse proxy they are sent without it. There is no HTTPS redirect. | Session cookie exposed over plain HTTP in production. | `FORCE_HTTPS` / `COOKIE_SECURE` settings, proxy support (`TRUSTED_PROXIES`), redirect to HTTPS, HSTS. |
| 8 | **Medium** | JSON bodies may be up to 11 MB (the audio limit applies to every request). The conversation `history` sent by the browser is not limited. | Memory/CPU abuse; very large prompts to Gemini. | 256 KB limit for JSON bodies, 10 MB only for audio/logo uploads; history capped (count and size). |
| 9 | **Medium** | No central permission layer for MA's capabilities. Each intent function checks scope by itself. Nothing logs refused or suspicious requests. | A future capability could forget a check; abuse is invisible. | `ma_tools.py`: one registry declaring each capability's level (READ / WRITE / DESTRUCTIVE), required permission, validated arguments and confirmation rule. Every MA action goes through it. Security events go to a `security_events` table (no message contents, no secrets). |
| 10 | **Medium** | Prompt injection: free-text chat replies come straight from Gemini. Nothing stops "show me your system prompt / API key" from being answered with internal instructions. | Disclosure of internal prompts (the key itself is never in the prompt). | Deterministic refusal for requests for prompts, keys, passwords or other companies' data, before any AI call. Outgoing replies are scrubbed of secrets and prompt fragments. Permissions enforced outside the model. |
| 11 | **Medium** | Login responses differ between "no such web account" and "wrong password" (the `X-Requested-With` message, plus timing). | Username enumeration. | One generic message and constant-time password checking for unknown users. |
| 12 | **Medium** | CORS allows four `localhost` dev origins in every environment. | Harmless today (no credentials allowed), but not intended for production. | Origins come from `CORS_ORIGINS` (empty by default = same origin only). |
| 13 | **Low** | Unhandled errors return Flask's HTML pages; 404/405 under `/api` are not JSON. No stack traces leak (debug is off). | Inconsistent error format. | JSON error handlers with generic messages; details only in the server log. |
| 14 | **Low** | `.gitignore` pattern `.env.*` would also hide the `.env.example` the brief asks for. There is no `.env.example` for the Gemini and security settings. | Setup mistakes. | `!.env.example` and a complete example file without secrets. |
| 15 | **Low** | `frontend/six-case-results.html` and `fifteen-case-results.html` (test reports) are publicly served. | Disclosure of test data (synthetic). | Served only to signed-in users. |
| 16 | **Low** | The older terminal invoices (`invoices` table, Bearer-token employees) are not separated by company; every terminal employee sees them all. | Fine for one garage on one laptop; not multi-tenant. | Documented limitation; web users cannot reach them. |
| 17 | **Low** | Logged-in employees can list the company's whole customer directory and truck memory. | Intended (needed to invoice repeat customers); employees still see only their own invoices. | Kept, documented as a decision. |

**Checked and found sound (kept):**
- **SQL:** all queries are parameterised; the one formatted query only inserts a column name from a fixed pair.
- **Sign-in tokens:** session tokens are 256-bit random values stored only as SHA-256 hashes; the CSRF check uses constant-time comparison.
- **Data access:** invoice, PDF, delivery and activity access is scoped to the company, and employees see only their own invoices.
- **Approvals:** approval needs explicit confirmation plus a digest of the reviewed invoice; sending needs `confirm: true`, a request key and approval rights.
- **Voice:**
  - recordings are checked by their file signature, limited to 10 MB, kept only in memory and never stored;
  - transcription is told not to follow spoken instructions.
- **Frontend:**
  - every dynamic `innerHTML` goes through `esc()`, and chat bubbles use `textContent`;
  - there are no inline scripts or event handlers;
  - the Google search widget runs in a sandboxed iframe without scripts.
- **Static files:** file serving blocks path traversal and `.md` files, and the database is not in `frontend/`.
- **There is no delete endpoint at all**, so there are no destructive operations to expose to MA today.

## SQLite: is it appropriate?

Yes, for one garage running InvoiceFlow on one machine or a small server: it is fast and simple, and all access already goes through one process.

Move to PostgreSQL when you have:
- several app servers or processes writing at the same time;
- more than a few garages on one instance;
- a need for point-in-time recovery, row-level security or database user separation.

No migration now.

Backups:
- copy `garage.db` with SQLite's online backup (`sqlite3 garage.db ".backup backup.db"`) daily;
- keep 7 daily and 4 weekly copies, encrypted, off the machine;
- test a restore monthly.

## Implementation plan

1. **Configuration (`security_config.py`):** typed settings from `.env` (pydantic-settings); secrets are never sent to the browser; `.env.example`.
2. **Hardening (`security.py`, registered in `app.py`):** security headers and CSP, HTTPS enforcement and proxy support, configurable CORS, request size limits, database-backed rate limiter, JSON error handlers, Origin check on state-changing requests.
3. **Authentication:** Argon2id with upgrade on login; session rotation every 15 min with replay detection; idle and absolute timeouts; one generic login error; auth on the public product and draft routes.
4. **MA capabilities (`ma_tools.py`):** registry with READ / WRITE / DESTRUCTIVE levels, permission check, argument validation, confirmation rules, security-event log, prompt-injection guard and output scrubbing. Existing business functions are reused, not duplicated.
5. **Tests (`tests/test_security.py`, pytest):** 40+ tests that check real behaviour (status codes, data not leaked, nothing written), alongside the existing 225 tests.
6. **Part 2:** UI redesign and the Gemini Live voice rebuild, on top of the secured backend.
