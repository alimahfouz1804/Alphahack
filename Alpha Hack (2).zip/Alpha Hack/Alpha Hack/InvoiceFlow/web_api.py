"""Web-app API for the InvoiceFlow AI frontend (frontend/ folder).

Adds, next to the existing Flask routes:
  - username + password accounts with HttpOnly cookie sessions and a CSRF token
  - companies (name, phone, logo, VAT) - each signup creates its own company
  - invoices in the frontend's shape with server-side USD + LBP totals
  - POST /api/invoices/generate: runs the existing Gemini agent (invoice_engine.create_invoice)
  - serves the frontend pages from frontend/ so everything runs on one origin

The existing Bearer-token employee routes (workflow_routes.py) keep working unchanged.
"""
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
import contextvars
import concurrent.futures
import queue
import threading
from contextlib import contextmanager
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path

from flask import request, jsonify, current_app, g, send_from_directory, redirect, Response, abort, send_file, copy_current_request_context
from werkzeug.exceptions import HTTPException
from io import BytesIO
from pdf_invoice import invoice_pdf

import delivery_providers
import invoice_services
import security
from security import hash_password, verify_password
from security_config import settings
import invoice_validation
import ma_tools
import truck_memory
import part_lookup
from ai_agent import GeminiUnavailable
from database import load_products, get_product_by_id
from itsdangerous import URLSafeTimedSerializer, BadSignature
PROPOSALS = URLSafeTimedSerializer(secrets.token_hex(32), salt="invoice-part-confirmation")

BASE = Path(__file__).parent
FRONTEND = BASE / "frontend"

# Fixed project exchange rate (not a market rate). Override with EXCHANGE_RATE_LBP in .env.
EXCHANGE_RATE = Decimal(str(json.loads((BASE / "products.json").read_text(encoding="utf-8"))["currency"]["sample_exchange_rate_lbp_per_usd"]))
DEFAULT_VAT = Decimal("0")

SESSION_COOKIE, CSRF_COOKIE, CSRF_HEADER = "if_session", "if_csrf", "X-CSRF-Token"

USERNAME_RE = re.compile(r"^[a-z](?!.*[_.]{2})[a-z0-9_.]{1,28}[a-z0-9]$")
NAME_RE = re.compile(r"^[^\W\d_]+(?:[ '\-.][^\W\d_]+)*\.?$", re.UNICODE)
LB_PHONE_RE = re.compile(r"^\+961(3\d{6}|(70|71|76|78|79|81)\d{6}|[14-9]\d{6})$")
E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")

OWNER_PERMS = ["ai.chat", "invoice.create", "invoice.edit", "invoice.submit", "invoice.history", "account.edit",
               "invoice.history.all", "invoice.approve", "invoice.reject", "invoice.send", "company.manage"]
EMPLOYEE_PERMS = OWNER_PERMS[:6]
CSRF_EXEMPT = {"/api/auth/login", "/api/auth/register", "/api/auth/password/forgot", "/api/auth/password/reset"}


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS companies(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
  logo BLOB, logo_type TEXT, logo_ver TEXT, vat_rate TEXT NOT NULL DEFAULT '0', created_at REAL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  first_name TEXT NOT NULL, last_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'employee',
  is_active INTEGER NOT NULL DEFAULT 1, created_at REAL);
CREATE TABLE IF NOT EXISTS web_sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires REAL NOT NULL, remember INTEGER NOT NULL DEFAULT 0,
  family TEXT, issued REAL, last_seen REAL, rotated_to TEXT, rotated_at REAL);
CREATE TABLE IF NOT EXISTS reset_codes(
  user_id INTEGER PRIMARY KEY, code_hash TEXT NOT NULL, expires REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS web_invoices(
  id TEXT PRIMARY KEY, company_id INTEGER NOT NULL, seq INTEGER NOT NULL, no TEXT NOT NULL,
  created_by INTEGER NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL,
  created_at REAL NOT NULL, updated_at REAL NOT NULL, approved_by INTEGER, approved_at REAL,
  UNIQUE(company_id, seq));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, invoice_id TEXT, employee TEXT, action TEXT, at REAL);
"""


def db_path():
    return current_app.config["INVOICE_DB"]


_MIGRATED = set()
SESSION_COLUMNS = {"family": "TEXT", "issued": "REAL", "last_seen": "REAL", "rotated_to": "TEXT", "rotated_at": "REAL"}


@contextmanager
def connect(path=None):
    path = path or db_path()
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA + invoice_services.SCHEMA + truck_memory.SCHEMA + security.SCHEMA)
    if path not in _MIGRATED:      # older databases: add the session-rotation columns once
        have = {r[1] for r in db.execute("PRAGMA table_info(web_sessions)")}
        for col, kind in SESSION_COLUMNS.items():
            if col not in have:
                db.execute("ALTER TABLE web_sessions ADD COLUMN %s %s" % (col, kind))   # fixed names, not input
        db.commit()
        _MIGRATED.add(path)
    try:
        with db:
            yield db
    finally:
        db.close()


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


# ---------------------------------------------------------------- helpers
def err(status, message, fields=None, code=None):
    detail = message if not (fields or code) else {"message": message, "fields": fields or {}, "code": code or ""}
    return jsonify(detail=detail), status


def err_response(status, message, code=None):
    response, _ = err(status, message, code=code)
    response.status_code = status
    return response


def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def text(value, limit):
    return value.strip()[:limit] if isinstance(value, str) else ""


def money(value):
    return float(value)


def q2(value):
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def valid_phone(phone):
    return isinstance(phone, str) and (LB_PHONE_RE.match(phone) if phone.startswith("+961") else E164_RE.match(phone))


def check_password_rules(password, username=""):
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        return "Password must be 8-128 characters."
    if not (re.search(r"[A-Z]", password) and re.search(r"[a-z]", password) and re.search(r"\d", password)):
        return "Password needs an uppercase letter, a lowercase letter and a number."
    if username and len(username) >= 3 and username.lower() in password.lower():
        return "Password must not contain the username."
    return ""


def user_json(row, company):
    role = "owner" if row["role"] == "owner" else "employee"
    return {"user": {
        "id": row["id"], "first_name": row["first_name"], "last_name": row["last_name"],
        "username": row["username"], "phone": row["phone"], "role": role,
        "permissions": OWNER_PERMS if role == "owner" else EMPLOYEE_PERMS,
        "company": {"id": company["id"], "name": company["name"]}}}


def company_json(c):
    return {"id": c["id"], "name": c["name"], "phone": c["phone"],
            "logo_url": "/media/logo/%d?v=%s" % (c["id"], c["logo_ver"]) if c["logo"] else "",
            "vat_rate": money(Decimal(c["vat_rate"])), "exchange_rate": int(EXCHANGE_RATE)}


LOGIN_FAILED = "Incorrect username or password."


# ---------------------------------------------------------------- sessions
# Browser sign-in uses an opaque random token in an HttpOnly, SameSite=Lax cookie (stored only as a SHA-256 hash).
# It is the cookie equivalent of short-lived access tokens with refresh rotation:
#   * the token is replaced every SESSION_ROTATE_SECONDS (15 min); the old one stays valid for a short grace period
#     so requests already in flight still work, then it is dead;
#   * using a replaced token after that grace period means it was copied: every session of that user is revoked;
#   * idle sessions expire (2 h, or 7 days with "remember me"), and every session has an absolute lifetime.
# A session "family" id stays the same across rotations; signed conversation state is bound to it.
def _cookie_secure():
    s = settings()
    return s.cookie_secure if s.cookie_secure is not None else (request.is_secure or s.force_https)


def _set_session_cookie(response, token, remember, expires):
    max_age = max(0, int(expires - time.time())) if remember else None
    response.set_cookie(SESSION_COOKIE, token, max_age=max_age, httponly=True, secure=_cookie_secure(), samesite="Lax", path="/")


def session_user():
    """The signed-in web user (sqlite Row) or None. Rotates the session token when it is due."""
    if "web_user" in g:
        return g.web_user
    g.web_user = None
    token = request.cookies.get(SESSION_COOKIE, "")
    if not token or len(token) > 200:
        return None
    s, now = settings(), time.time()
    replayed = None
    with connect() as db:
        row = db.execute(
            "SELECT u.*, s.token_hash, s.expires, s.remember, s.family, s.issued, s.last_seen, s.rotated_to, s.rotated_at "
            "FROM web_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND u.is_active=1", (sha(token),)).fetchone()
        if not row or row["expires"] <= now:
            return None
        if row["rotated_to"]:
            if now - (row["rotated_at"] or 0) <= s.session_rotate_grace_seconds:
                g.web_user, g.session_family = row, row["family"] or row["token_hash"]
                return row                                    # a request that was already on its way
            db.execute("DELETE FROM web_sessions WHERE user_id=?", (row["id"],))   # stolen token replayed
            replayed = row
    if replayed is not None:                                  # logged after the write above is committed
        security.log_event("session_replay_revoked", user=replayed)
        return None
    with connect() as db:
        idle = s.remember_idle_seconds if row["remember"] else s.session_idle_seconds
        if now - (row["last_seen"] or now) > idle:
            db.execute("DELETE FROM web_sessions WHERE token_hash=?", (row["token_hash"],))
            return None
        family = row["family"] or row["token_hash"]
        if now - (row["issued"] or 0) >= s.session_rotate_seconds:
            new = secrets.token_urlsafe(32)
            db.execute("INSERT INTO web_sessions(token_hash,user_id,expires,remember,family,issued,last_seen) VALUES (?,?,?,?,?,?,?)",
                       (sha(new), row["id"], row["expires"], row["remember"], family, now, now))
            db.execute("UPDATE web_sessions SET rotated_to=?, rotated_at=? WHERE token_hash=?", (sha(new), now, row["token_hash"]))
            g.rotated_session = (new, bool(row["remember"]), row["expires"])
        elif now - (row["last_seen"] or 0) > 30:
            db.execute("UPDATE web_sessions SET last_seen=? WHERE token_hash=?", (now, row["token_hash"]))
    g.web_user, g.session_family = row, family
    return row


def session_id():
    """Stable id of the current sign-in (survives token rotation): signed MA state is bound to it."""
    session_user()
    return g.get("session_family") or ""


def company_of(db, user):
    return db.execute("SELECT * FROM companies WHERE id=?", (user["company_id"],)).fetchone()


def start_session(response, user_id, remember):
    """A new sign-in: fresh token + fresh CSRF token (never reuse an earlier session id)."""
    s, now = settings(), time.time()
    token = secrets.token_urlsafe(32)
    expires = now + (s.remember_seconds if remember else s.session_seconds)
    with connect() as db:
        db.execute("DELETE FROM web_sessions WHERE expires<? OR (rotated_at IS NOT NULL AND rotated_at<?)", (now, now - 3600))
        db.execute("INSERT INTO web_sessions(token_hash,user_id,expires,remember,family,issued,last_seen) VALUES (?,?,?,?,?,?,?)",
                   (sha(token), user_id, expires, int(bool(remember)), secrets.token_hex(16), now, now))
    _set_session_cookie(response, token, remember, expires)
    response.set_cookie(CSRF_COOKIE, secrets.token_urlsafe(24), max_age=int(expires - now) if remember else None,
                        httponly=False, secure=_cookie_secure(), samesite="Lax", path="/")
    return response


def clear_session(response):
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")
    return response


def web_login(username, password, remember):
    """Called by the shared /api/auth/login route. Returns a response, or None if the
    username is not a web account (then the older employee-token login is tried).
    Rate limits are per account and per address and live in the database (they survive restarts)."""
    uname = username.strip().lower()
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE username=?", (uname,)).fetchone()
        company = company_of(db, row) if row else None
    if not row:
        return None
    if security.rate_limited("login_account", uname) or security.rate_limited("login_ip", security.client_ip()):
        security.log_event("login_locked", detail="account")
        return err(429, "Too many attempts. Please wait 5 minutes and try again.")
    ok, upgraded = verify_password(row["password_hash"], password)
    if not ok:
        security.rate_record("login_account", uname); security.rate_record("login_ip", security.client_ip())
        security.log_event("login_failed", user=row)
        return err(401, LOGIN_FAILED)
    if not row["is_active"]:
        return err(403, "This account has been disabled. Please contact your garage owner.", code="account_disabled")
    if upgraded:        # an older hash (or weaker parameters): store Argon2id now that the password is known
        with connect() as db:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (upgraded, row["id"]))
    security.rate_clear("login_account", uname)
    return start_session(jsonify(user_json(row, company)), row["id"], remember)


def web_logout():
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as db:
            row = db.execute("SELECT family FROM web_sessions WHERE token_hash=?", (sha(token),)).fetchone()
            db.execute("DELETE FROM web_sessions WHERE token_hash=? OR (family IS NOT NULL AND family=?)",
                       (sha(token), row["family"] if row else ""))
    return clear_session(Response(status=204))


def require_user(perm=None):
    user = session_user()
    if not user:
        abort(err_response(401, "Please sign in again."))
    perms = OWNER_PERMS if user["role"] == "owner" else EMPLOYEE_PERMS
    if perm and perm not in perms:
        abort(err_response(403, "Your account is not allowed to do this. Ask the garage owner if you need access."))
    return user


# ---------------------------------------------------------------- invoices
def compute(payload, vat_rate):
    items, sub = [], Decimal("0")
    incomplete = False
    if not isinstance(payload.get("items", []), list): raise ValueError("Items must be a list")
    for raw in payload.get("items", [])[:100]:
        if isinstance(raw,dict) and part_lookup.obvious_non_part(raw.get('d','')):
            raise ValueError('This item is outside the garage scope. هالبند خارج نطاق الورشة.')
        try:
            qty = None if raw.get("q") in (None, "") else Decimal(str(raw["q"]))
            price = None if raw.get("p") in (None, "") else Decimal(str(raw["p"]))
        except (InvalidOperation, AttributeError):
            raise ValueError("Each item needs a numeric quantity and price.")
        if any(v is not None and (not v.is_finite() or v < 0 or v > limit) for v, limit in ((qty, 10000), (price, 10000000))):
            raise ValueError("Quantities and prices must be positive numbers.")
        line = None if qty is None or price is None else q2(qty * price)
        if line is None:
            incomplete = True
        else:
            sub += qty * price
        catalog_id = raw.get('catalog_id')
        if catalog_id is not None and (not isinstance(catalog_id,str) or not get_product_by_id(catalog_id)):
            raise ValueError('Invalid catalog reference.')
        if catalog_id and text(raw.get('d'),200) != get_product_by_id(catalog_id)['name_en']:
            catalog_id = None  # An edited description becomes a custom line, not a verified identity.
        items.append({'catalog_id':catalog_id, 'is_custom':not bool(catalog_id), "d": text(raw.get("d"), 200), "t": text(raw.get("t"), 40) or "Service",
                      "q": money(qty) if qty is not None else None,
                      "p": money(price) if price is not None else None,
                      "total_usd": money(line) if line is not None else None})
    if incomplete:
        return items, {"subtotal_usd": None, "vat_rate": money(vat_rate), "vat_usd": None,
                       "total_usd": None, "total_lbp": None, "exchange_rate": int(EXCHANGE_RATE), "incomplete": True}
    raw_sub = sub
    sub = q2(sub)
    vat = q2(sub * vat_rate / 100)
    total = sub + vat
    lbp = ((raw_sub + vat) * EXCHANGE_RATE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return items, {"subtotal_usd": money(sub), "vat_rate": money(vat_rate), "vat_usd": money(vat),
                   "total_usd": money(total), "total_lbp": int(lbp), "exchange_rate": int(EXCHANGE_RATE), "incomplete": False}


from invoice_identity import has_identity

def clean_payload(data, company):
    cust = data.get("cust") if isinstance(data.get("cust"), dict) else {}
    truck = data.get("truck") if isinstance(data.get("truck"), dict) else {}
    out = {
        "cust": {k: text(cust.get(k), 200) for k in ("name", "contact", "tel", "email")},
        "truck": {k: text(truck.get(k), 100) for k in ("plate", "model")},
        "notes": text(data.get("notes"), 2000),
        "warnings": [text(w, 500) for w in data.get("warnings", [])[:30] if isinstance(w, str)] if isinstance(data.get("warnings"), list) else [],
        "items": data.get("items") if isinstance(data.get("items"), list) else [],
    }
    # Truck number is stored in its canonical form (A1234) when it is valid; anything else is kept as typed
    # so the review can explain exactly what is wrong with it. Names keep their spelling, extra spaces go.
    out["cust"]["name"] = invoice_validation.clean_name(out["cust"]["name"])
    if invoice_validation.truck_valid(out["truck"]["plate"]):
        out["truck"]["plate"] = invoice_validation.normalize_truck(out["truck"]["plate"])
    cid = cust.get('id')
    if isinstance(cid,int) and not isinstance(cid,bool):
        with sqlite3.connect(db_path()) as customer_db:
            found = customer_db.execute('SELECT id FROM web_customers WHERE id=? AND company_id=?',(cid,company['id'])).fetchone()
        if not found: raise ValueError('Customer not found in this company.')
        out['cust']['id'] = cid
    if out['cust']['tel']:
        tel = re.sub(r'[ ()-]', '', out['cust']['tel'].translate(AR_DIGITS))
        if not tel.startswith('+'):   # local Lebanese form: 71 234 567 / 03 123 456 / 01 234 567 / 00961...
            d = tel[2:] if tel.startswith('00') else tel
            tel = '+' + d if tel.startswith('00') or (d.startswith('961') and len(d) >= 10) else '+961' + d.lstrip('0')
        out['cust']['tel'] = tel
        if not valid_phone(out['cust']['tel']):
            raise ValueError('Customer phone must be a valid international number, e.g. +96171123456.')
    if out["cust"]["email"] and not EMAIL_RE.fullmatch(out["cust"]["email"]):
        raise ValueError("Customer email address is not valid.")
    out["items"], out["totals"] = compute(out, Decimal(company["vat_rate"]))
    out["company"] = company_json(company)
    out["company"].pop("id", None)
    return out


def readiness(inv):
    """Structured, server-computed review of an invoice draft: what is missing before approval.
    The AI never decides this; the frontend shows the same rules while the employee edits."""
    items = inv.get("items") or []
    missing, seen, duplicates = [], {}, []
    if not items:
        missing.append({"field": "items", "message": "Add at least one item."})
    for i, it in enumerate(items):
        name = str(it.get("d") or "").strip()
        if not name:
            missing.append({"item": i, "field": "description", "message": "Item %d needs a description." % (i + 1)})
        if it.get("q") is None or (isinstance(it.get("q"), (int, float)) and it["q"] <= 0):
            missing.append({"item": i, "field": "quantity", "message": "Quantity is missing for %s." % (name or "item %d" % (i + 1))})
        if it.get("p") is None:
            missing.append({"item": i, "field": "unit_price", "message": "Unit price is missing for %s." % (name or "item %d" % (i + 1))})
        key = (it.get("catalog_id") or name.casefold())
        if key and not re.match(r"^labou?r\b", name, re.I):
            if key in seen and seen[key] not in duplicates:
                duplicates.append(seen[key])
            seen.setdefault(key, name)
    # Required identity: customer's full name + truck number (one letter + four digits). Same rules as MA's questions.
    for p in invoice_validation.invoice_problems(inv):
        missing.append({"field": p["field"], "code": p["code"], "message": p["message"]})
    return {"ready": not missing, "missing": missing, "duplicates": duplicates,
            "custom_items": [it.get("d") for it in items if it.get("is_custom") and not re.match(r"^labou?r\b", str(it.get("d") or ""), re.I)],
            "approval_required": True}


def invoice_out(row):
    data = json.loads(row["payload"])
    data.update(approved_at=row["approved_at"], approved_by=row["approved_by"], id=row["id"], no=row["no"], status=row["status"], review_digest=sha(row["payload"]),
                date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(row["created_at"])))
    data["review"] = readiness(data)
    return data


def find_invoice(db, user, ident):
    row = db.execute("SELECT * FROM web_invoices WHERE id=? AND company_id=?", (ident, user["company_id"])).fetchone()
    if row and user["role"] != "owner" and row["created_by"] != user["id"]:
        return None
    return row


def is_web_invoice(ident):
    with connect() as db:
        return db.execute("SELECT 1 FROM web_invoices WHERE id=?", (ident,)).fetchone() is not None


def web_get_invoice(ident):
    user = require_user("invoice.history")
    with connect() as db:
        row = find_invoice(db, user, ident)
    if not row:
        return err(404, "Invoice not found.")
    out = invoice_out(row)
    with connect() as db:
        known = truck_memory.profile(db, user["company_id"], (out.get("truck") or {}).get("plate"), exclude=row["id"])
    if known:
        out["customer_profile"] = known
    return jsonify(out)


def move(ident, allowed_from, to, perm, who_ok=None, strict=False):
    """strict=True (Submit for approval) applies the approval checks to 'pending' too."""
    user = require_user(perm)
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        row = find_invoice(db, user, ident)
        if not row:
            return err(404, "Invoice not found.")
        if to == 'approved' and row['status'] == 'approved':
            if body().get('confirm') is True and body().get('review_digest') == sha(row['payload']):
                return jsonify(invoice_out(row))
        if row["status"] not in allowed_from:
            return err(409, "This invoice is %s and cannot be changed that way." % row["status"])
        payload = json.loads(row["payload"])
        # Pending may be incomplete (it is still being worked on). Approval and Submit need a complete invoice.
        check = to == "approved" or strict
        problems = invoice_validation.invoice_problems(payload) if check else []
        if problems:
            return err(409, " ".join(p["message"] for p in problems), {p["field"]: p["message"] for p in problems}, code="identity_invalid")
        if check and (payload.get("totals", {}).get("incomplete") or
                any(i.get("p") is None or i.get("q") is None for i in payload.get("items", []))):
            return err(409, "Fill in all missing quantities and prices before approving.")
        if check and (not payload.get('items') or any(
                not i.get('d','').strip() or i.get('q',0) <= 0 for i in payload['items'])):
            return err(409,'Each invoice needs at least one named item with a quantity greater than zero.')
        now = time.time()
        if to == "approved":
            approval = body()
            if approval.get("confirm") is not True or approval.get("review_digest") != sha(row["payload"]):
                return err(409, "Review the saved invoice and explicitly confirm approval.")
            if json.loads(row["payload"]).get("warnings") and approval.get("acknowledge_warnings") is not True:
                return err(409, "Acknowledge the invoice warnings before approval.")
            # Render first. Any error rolls back approval and customer changes atomically.
            try:
                invoice_services.store_approved_pdf(db,row,user['username'])
                cid = invoice_services.save_customer(db,user['company_id'],payload['cust'])
                truck_memory.remember(db, user['company_id'], payload['cust'], payload.get('truck'))
                if cid: db.execute('INSERT OR REPLACE INTO invoice_customers VALUES (?,?)',(ident,cid))
            except ValueError as exc:
                raise ValueError('Could not save the approved invoice: '+str(exc)) from None
            db.execute("UPDATE web_invoices SET status=?, updated_at=?, approved_by=?, approved_at=? WHERE id=?",
                       (to, now, user["id"], now, ident))
        else:
            db.execute("UPDATE web_invoices SET status=?, updated_at=?, approved_by=NULL, approved_at=NULL WHERE id=?", (to, now, ident))
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)", (ident, user["username"], to, now))
        row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
    return jsonify(invoice_out(row))


def web_approve_invoice(ident):
    return move(ident, ("pending",), "approved", "invoice.approve")


# ---------------------------------------------------------------- AI draft
# ---- live progress: real steps MA takes, streamed to the invoice screen while it works ----
PROGRESS = contextvars.ContextVar("progress", default=None)


def step(key, en, ar, **extra):
    """Report a step that is actually happening now (no-op when the client did not ask for progress)."""
    emit = PROGRESS.get()
    if emit:
        emit(dict(type="step", key=key, en=en, ar=ar, **extra))


def act(key, status, en="", ar="", **extra):
    """Activity panel event: a real step of this request changed state (processing / completed / failed)."""
    emit = PROGRESS.get()
    if emit:
        emit(dict(type="activity", key=key, status=status, en=en, ar=ar, **extra))


INVOICE_PLAN = [("understand", "Understanding employee request", "عم إفهم طلبك"),
                ("extract", "Extracting customer information", "عم طلّع معلومات الزبون"),
                ("validate_name", "Validating customer full name", "عم إتأكّد من اسم الزبون الكامل"),
                ("validate_truck", "Checking truck number", "عم إتأكّد من رقم الشاحنة"),
                ("check_items", "Checking parts, quantities and prices", "عم إتأكّد من القطع والكميات والأسعار"),
                ("totals", "Calculating invoice totals", "عم إحسب مجموع الفاتورة"),
                ("preview", "Preparing invoice preview", "عم حضّر معاينة الفاتورة"),
                ("approval", "Waiting for employee approval", "ناطر موافقتك"),
                ("pdf", "Generating invoice PDF", "عم إعمل الـ PDF للفاتورة")]


def apply_identity(result, order, slots=None, collected=None):
    """Customer + truck for this draft: what the employee just answered (slots) wins, then what the AI read,
    then values already collected and validated earlier in this conversation. Nothing is invented."""
    for field in ("customer", "truck_plate"):
        said = (slots or {}).get(field)
        if said:
            result[field] = said
        elif not str(result.get(field) or "").strip() and (collected or {}).get(field):
            result[field] = collected[field]
        if order is not None and result.get(field):
            order[field] = result[field]
    result["customer"] = invoice_validation.clean_name(result.get("customer"))
    if invoice_validation.truck_valid(result.get("truck_plate")):
        result["truck_plate"] = invoice_validation.normalize_truck(result["truck_plate"])
        if order is not None:
            order["truck_plate"] = result["truck_plate"]


def ai_draft(message, company, confirmed_order=None, ar=None, precomputed=None, slots=None, collected=None):
    """Turn the repair conversation into a validated draft, or into ONE question listing exactly what is missing.
    Questions carry '_state' (the understood order + what was asked) so the next answer can be applied
    without re-asking, and without another AI call when it is a short answer."""
    from invoice_engine import create_invoice  # the teammate's Gemini pipeline
    if ar is None:
        ar = bool(re.search(r'[؀-ۿ]', message))
    step("extract", "Extracting customer, parts, quantities and prices", "عم طلّع الزبون والقطع والكميات والأسعار")
    act("extract", "processing", *INVOICE_PLAN[1][1:])
    try:
        if confirmed_order is not None:
            result = create_invoice(message, confirmed_order=confirmed_order)
        elif precomputed is not None:
            result = create_invoice(message, precomputed_order=precomputed)
        else:
            result = create_invoice(message)
    except Exception:
        act("extract", "failed", *INVOICE_PLAN[1][1:], error="AI service unavailable" if not ar else "خدمة الذكاء مش متوفرة هلّق")
        raise
    order = result.pop("_order", None)
    apply_identity(result, order, slots, collected)
    act("extract", "completed", *INVOICE_PLAN[1][1:],
        detail=", ".join(x for x in (result.get("customer"), result.get("truck_plate")) if x))
    known, filled, name_matches = None, [], []
    company_id = company["id"] if company is not None and "id" in company.keys() else None
    if company_id is not None:
        act("customer_memory", "processing", "Looking up saved customer details", "عم فتّش عن معلومات الزبون المحفوظة")
        with connect() as db:
            known, filled = truck_memory.fill_order(db, company_id, result)
            if not result.get("truck_plate"):
                name_matches = truck_memory.named_trucks(db, company_id, result.get("customer"))
        apply_identity(result, order)       # memory may have filled the name / truck number: same rules apply
        memory_detail = (("لقيت النمرة المحفوظة: " if ar else "Found saved plate: ") + known["plate"] if known else
                         ("في أكتر من نمرة لهالاسم" if ar else "Multiple plates match this name") if len(name_matches) > 1 else
                         ("ما في معلومات محفوظة مطابقة بعد" if ar else "No matching saved customer details yet"))
        act("customer_memory", "completed", detail=memory_detail)
    # identity is validated below with exact messages; the engine's generic plate warning is not shown
    result["warnings"] = [w for w in result.get("warnings") or [] if w != "Truck plate number is required"]
    step("check", "Checking for anything missing", "عم إتأكّد إذا في شي ناقص")
    # ---- required identity: customer full name + truck number (exact problem, asked only when wrong/missing)
    arabic = ar
    act("validate_name", "processing", *INVOICE_PLAN[2][1:])
    name_problem = invoice_validation.customer_problem(result.get("customer"), arabic)
    # not given yet = still to collect (pending); given but wrong = failed, with the exact reason
    status = lambda p: "completed" if not p else "pending" if p["code"] == "missing" else "failed"
    act("validate_name", status(name_problem), *INVOICE_PLAN[2][1:],
        error=name_problem["message"] if name_problem else "", detail="" if name_problem else result.get("customer", ""))
    act("validate_truck", "processing", *INVOICE_PLAN[3][1:])
    truck_problem = invoice_validation.truck_problem(result.get("truck_plate"), arabic)
    if truck_problem and truck_problem["code"] == "missing" and len(name_matches) > 1:
        plates = ", ".join(row["plate"] for row in name_matches)
        truck_problem["message"] = ("في أكتر من نمرة محفوظة لهالاسم: %s. أي نمرة بدك تستعمل؟" if arabic else
                                    "There are multiple plates saved for this name: %s. Which plate should I use?") % plates
    if company_id is not None and not name_problem and not truck_problem:
        # Remember valid details as soon as they are entered, even before the repair is described.
        with connect() as db:
            truck_memory.remember(db, company_id,
                                  {"name": result.get("customer"), "tel": result.get("customer_phone"),
                                   "email": result.get("customer_email")},
                                  {"plate": result.get("truck_plate"), "model": result.get("truck_model")})
        act("save_customer", "completed", "Saving customer details", "عم إحفظ معلومات الزبون",
            detail=("محفوظ للمرة الجاية: " if ar else "Remembered for next time: ") + result["customer"] + " · " + result["truck_plate"])
    act("validate_truck", status(truck_problem), *INVOICE_PLAN[3][1:],
        error=truck_problem["message"] if truck_problem else "", detail="" if truck_problem else result.get("truck_plate", ""))
    # step by step: the customer's name first, then the truck number, then the repair details (one question at a time)
    problems = [p for p in (name_problem, truck_problem) if p][:1]
    collected = {"customer": result.get("customer") if not name_problem else (collected or {}).get("customer", ""),
                 "truck_plate": result.get("truck_plate") if not truck_problem else (collected or {}).get("truck_plate", "")}
    if name_problem and name_problem["code"] == "last_name_missing":
        collected["first_name"] = name_problem["first"]

    def ask(question, item_questions=False, **extra):
        """A question back to the employee, with the conversation state needed to continue from the answer."""
        out = {"question": question, "missing": [{k: p[k] for k in ("field", "code", "message")} for p in problems], **extra}
        out["_state"] = {"order": order if not item_questions else None, "collected": collected,
                         "asked": {p["field"]: {"code": p["code"], "first": p.get("first", "")} for p in problems}}
        return out

    act("check_items", "processing", *INVOICE_PLAN[4][1:])
    if result.get('blocked_items'):
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error=', '.join(result['blocked_items']))
        return ask('هالبنود خارج نطاق قطع وخدمات الورشة: '+', '.join(result['blocked_items'])+'. صحّح أو احذف هالبنود.' if arabic else
                   'Outside garage scope: '+', '.join(result['blocked_items'])+'. Correct or remove these items.', True,
                   blocked_items=result['blocked_items'])
    if result.get('suggestions') and problems:
        act("check_items", "pending", *INVOICE_PLAN[4][1:])
        return ask(" ".join(p["message"] for p in problems), True)
    if result.get('suggestions'):
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error="Part confirmation needed" if not arabic else "لازم تأكّد القطعة")
        proposal = {'question': 'هيدي اقتراحات حسب وصفك. اختار القطعة الصحيحة لتأكيدها، أو اضغط «مش هيدي» ووضّح أكتر. إذا ما لقيت القطعة، أكّد اسمها وكمّيتها وسعرها كبند مخصّص.' if arabic else 'These are suggestions from your description. Confirm the correct part, or choose Not this part and describe it further. If no match fits, confirm a custom invoice description, quantity and price.',
                'suggestions':result['suggestions'],'_pending_order':result['_pending_order']}
        proposal['question'] += ' '+ ' / '.join(s['description']+' '+ ' / '.join(c['name_ar' if arabic else 'name_en'] for c in s['candidates']) for s in result['suggestions'])
        if any(not s['candidates'] for s in result['suggestions']):
            proposal['question'] += (' ما لقيت هالبند بالكتالوج: شو الاسم يلي بدك يطلع عالفاتورة لهالبند؟ وأكّد الكمية والسعر.' if arabic else
                                     ' Not found in the catalog: what name would you like to display on the invoice for this item? Then confirm its quantity and price.')
        if arabic and any(re.search(r'\d+\s*(?:لتر|ليتر|l\b)',s['description']) for s in result['suggestions']): proposal['question'] += ' وضّح إذا التفصيل حجم القطعة أو سعرها.'
        return proposal
    items = [{"catalog_id":it.get("id"),"is_custom":it.get("is_custom",False), "d": it["name"], "t": "Part", "q": it["quantity"],
              "p": float(it["price_usd"]) if it["price_usd"] is not None else None} for it in result["items"]]
    warnings = list(result.get("warnings", []))
    # Never offer a partial invoice after dropping an unresolved repair item.
    from database import search_products, suggest_products
    def part_label(name):
        found = search_products(name)
        return found[0]['name_ar'] if arabic and len(found) == 1 else name
    questions = []
    for warning in warnings:
        if warning.startswith("Unknown product: "):
            name = warning.split(": ", 1)[1]
            candidates = suggest_products(name)
            options = ' / '.join(p['name_ar' if arabic else 'name_en'] for p in candidates[:4])
            if options:
                questions.append(f'تقصد {options}؟ وضّح التفصيل «{name}»: هو حجم القطعة أو سعرها؟' if arabic else f'Do you mean {options}? Please clarify "{name}": is that a size or a price?')
            else:
                questions.append(f'ما قدرت أحدّد القطعة «{name}». فيك توصف شو هي أو شو بتعمل؟' if arabic else f'I could not identify "{name}". Can you describe the part or what it does?')
        elif warning.startswith("Ambiguous product: "):
            name = warning.split(": ", 1)[1]
            options = " / ".join(p['name_ar' if arabic else 'name_en'] for p in search_products(name))
            questions.append(f'أي نوع تقصد: {options}؟' if arabic else f'Which type do you mean: {options}?')
        elif warning.startswith("Invalid quantity: "):
            name = warning.split(": ", 1)[1]
            questions.append(f'قدّيش عدد {part_label(name)}؟' if arabic else f'How many "{name}" were used?')
        elif warning.startswith('Part detail needs review: '):
            questions.append(warning.split(': ',1)[1])
        elif warning.startswith('Conflicting price: '):
            name = warning.split(': ',1)[1]
            questions.append(f'سعر الوحدة ومجموع {part_label(name)} مش متطابقين. قديش حق الواحد؟' if arabic else f'The unit price and line total for {name} disagree. What is the price per item?')
    if questions:
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error=" ".join(questions))
    elif problems and items:
        act("check_items", "completed", *INVOICE_PLAN[4][1:], detail="%d item%s" % (len(items), "" if len(items) == 1 else "s"))
    if problems:
        # the identity first (one field at a time); the part details are asked once it is complete
        return ask(problems[0]["message"])
    if questions:
        return ask(" ".join(questions), True)
    labor = Decimal(str(result["labor_amount"])) if result.get("labor_amount") is not None else None
    cur = result.get("labor_currency")
    if labor is not None and labor > 0 and cur in ("USD", "LBP"):
        usd = labor if cur == "USD" else labor / EXCHANGE_RATE
        items.append({"d": "Labor" + (" (%s LBP)" % format(int(labor), ",") if cur == "LBP" else ""), "t": "Service", "q": 1, "p": float(usd)})
    if not items:
        unknown = [w.split(": ", 1)[1] for w in warnings if w.startswith(("Unknown product", "Ambiguous product"))]
        if unknown:
            q = ("ما قدرت لاقي %s بكتالوج الكاراج. شو القطع يلي تغيّرت، وقدّيش العدد؟ فيك تزيد أجرة اليد إذا بدك." % "، ".join('«%s»' % u for u in unknown)) if arabic else \
                ("I couldn't match %s to the garage catalog. Which parts were replaced, and how many? You can include labor if you want to charge it." % ", ".join('"%s"' % u for u in unknown))
        else:     # nothing described yet: the natural next step of the conversation
            q = REPAIR_QUESTION[1] if arabic else REPAIR_QUESTION[0]
        act("check_items", "pending" if not unknown else "failed", *INVOICE_PLAN[4][1:], error="" if not unknown else ("ما في قطع بعد" if arabic else "No parts yet"))
        return ask(q, True)
    act("check_items", "completed", *INVOICE_PLAN[4][1:], detail="%d item%s" % (len(items), "" if len(items) == 1 else "s"))
    if any(w in warnings for w in ("Invalid labor amount", "Labor currency is unclear")):
        items.append({"d": "Labor", "t": "Service", "q": 1, "p": None})
    draft = {"status": "draft", "cust": {"name": result.get("customer", ""), "contact": "", "tel": result.get("customer_phone", ""), "email": result.get("customer_email", "")},
             "truck": {"plate": result.get("truck_plate", "") or "", "model": result.get("truck_model", "") or ""},
             "notes": result.get("notes", ""), "items": items}
    # everything required is collected and valid: only now is the invoice preview built (the screen shows it from here)
    step("preview", "Preparing the invoice preview", "عم حضّر معاينة الفاتورة")
    if known:
        label = {"loyal": ("Loyal customer", "زبون دايم"), "returning": ("Returning customer", "زبون راجع"), "new": ("Known truck", "شاحنة معروفة")}[known["status"]]
        step("memory", "%s: %s · plate %s · %d earlier invoice%s" % (label[0], known.get("name") or "-", known["plate"], known["invoices"], "" if known["invoices"] == 1 else "s"),
             "%s: %s · نمرة %s · %d فواتير قبل" % (label[1], known.get("name") or "-", known["plate"], known["invoices"]), profile=known)
    step("customer", "Customer: %s" % result.get("customer"), "الزبون: %s" % result.get("customer"),
         customer=result.get("customer") or "", plate=result.get("truck_plate") or "")
    for it in items:
        step("item", "Added: %s × %s" % (it["d"], it["q"]), "زدت: %s × %s" % (it["d"], it["q"]), item={"d": it["d"], "q": it["q"], "p": it["p"]})
    act("totals", "processing", *INVOICE_PLAN[5][1:])
    try:
        payload = clean_payload(draft, company)
    except ValueError as exc:
        act("totals", "failed", *INVOICE_PLAN[5][1:], error=str(exc))
        return ask(str(exc), True)
    step("totals", "Calculating totals (USD and LBP)", "عم إحسب المجموع بالدولار والليرة")
    t = payload.get("totals") or {}
    act("totals", "completed", *INVOICE_PLAN[5][1:],
        detail="" if t.get("total_usd") is None else "$%s / %s LBP" % (format(Decimal(str(t["total_usd"])), ",.2f"), format(t["total_lbp"], ",")))
    payload.update(status="draft", date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   warnings=[friendly(w) for w in warnings])
    payload["review"] = readiness(payload)
    if known:
        payload["customer_profile"] = known
    if filled:
        payload["filled_from_memory"] = filled
    # the preview keeps what was collected, so a later correction ("make it 3") updates this invoice without re-asking
    payload["_state"] = {"order": order, "asked": {}, "stage": "preview",
                         "collected": {"customer": result.get("customer", ""), "truck_plate": result.get("truck_plate", "")}}
    return payload


def friendly(w):
    return {"Customer name is missing": "Customer name wasn't mentioned - add it before submitting.",
            "Labor amount is missing": "No labour cost was mentioned.",
            "Labor currency is unclear": "Labour currency wasn't clear (USD or LBP?), so its price is blank."}.get(w, w)
CANCEL_RE = re.compile(r"\b(?:cancel|forget (?:it|this)|never ?mind|discard)\b|إلغاء|الغي|الغيها|لغيها|انسى|انساها|بلاها", re.I)


# ---------------------------------------------------------------- routes
# ---------------------------------------------------------------- assistant: understand any request
STATUSES = ("draft", "pending", "approved", "rejected")
STATUS_AR = {"draft": "مسودة", "pending": "بانتظار الموافقة", "approved": "موافق عليها", "rejected": "مرفوضة"}
STATUS_EN = {"draft": "draft", "pending": "pending approval", "approved": "approved", "rejected": "rejected"}
MONTHS_AR = ["كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"]


def visible_rows(user):
    """Invoices this user may see: owners see the whole garage, employees only their own."""
    sql, args = "SELECT * FROM web_invoices WHERE company_id=?", [user["company_id"]]
    if user["role"] != "owner":
        sql += " AND created_by=?"
        args.append(user["id"])
    with connect() as db:
        return db.execute(sql + " ORDER BY seq", args).fetchall()


def local_day(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def nice_day(day, ar):
    y, m, d = (int(x) for x in day.split("-"))
    return "%d %s %d" % (d, MONTHS_AR[m - 1], y) if ar else time.strftime("%d %b %Y", (y, m, d, 0, 0, 0, 0, 1, -1)).lstrip("0")


def valid_day(value):
    try:
        time.strptime(value, "%Y-%m-%d")
        return value
    except (TypeError, ValueError):
        return ""


def loose(value):
    """Lower-case letters/digits only, so 'ABC-123', 'abc 123' and 'Abc123' compare equal."""
    return re.sub(r"[\W_]+", "", str(value or "").casefold())


def similar(wanted, actual):
    """Typo-tolerant match for customer names and plates."""
    from difflib import SequenceMatcher
    a, b = loose(wanted), loose(actual)
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    if SequenceMatcher(None, a, b).ratio() >= 0.75:
        return True
    words = [loose(w) for w in str(actual).split()]
    return any(w and SequenceMatcher(None, a, w).ratio() >= 0.8 for w in words)


def invoice_no_from(text_value):
    digits = re.findall(r"\d+", str(text_value or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")))
    return "INV-%04d" % int(digits[-1]) if digits else ""


def summary(row):
    inv = invoice_out(row)
    return {"id": inv["id"], "no": inv["no"], "status": inv["status"], "date": local_day(row["created_at"]),
            "customer": inv.get("cust", {}).get("name", ""), "plate": inv.get("truck", {}).get("plate", ""),
            "total_usd": inv.get("totals", {}).get("total_usd"), "total_lbp": inv.get("totals", {}).get("total_lbp")}


def describe_filters(r, ar):
    parts = []
    a, b = r.get("date_from"), r.get("date_to")
    if a and b and a == b:
        parts.append(("بتاريخ " if ar else "on ") + nice_day(a, ar))
    elif a and b:
        parts.append(("من %s لـ %s" if ar else "from %s to %s") % (nice_day(a, ar), nice_day(b, ar)))
    elif a:
        parts.append(("من " if ar else "since ") + nice_day(a, ar))
    elif b:
        parts.append(("لغاية " if ar else "up to ") + nice_day(b, ar))
    if r.get("customer"):
        parts.append(("للزبون «%s»" if ar else "for customer \"%s\"") % r["customer"])
    if r.get("plate"):
        parts.append(("للنمرة %s" if ar else "for plate %s") % r["plate"])
    if r.get("status"):
        parts.append(("حالتها: " + STATUS_AR[r["status"]]) if ar else ("that are " + STATUS_EN[r["status"]]))
    return " ".join(parts)


def money_usd(v):
    v = Decimal(str(v))
    return "$" + (format(v, ",.0f") if v == v.to_integral_value() else format(v, ",.2f"))


def answer_query(user, r):
    ar = r.get("language") == "ar"
    r = dict(r)
    r["date_from"], r["date_to"] = valid_day(r.get("date_from")), valid_day(r.get("date_to"))
    if r["date_from"] and r["date_to"] and r["date_from"] > r["date_to"]:
        r["date_from"], r["date_to"] = r["date_to"], r["date_from"]
    r["status"] = r.get("status") if r.get("status") in STATUSES else ""
    metric = r.get("metric") if r.get("metric") in ("count", "list", "total") else "count"

    found = []
    for row in visible_rows(user):
        s = summary(row)
        if r["date_from"] and s["date"] < r["date_from"]: continue
        if r["date_to"] and s["date"] > r["date_to"]: continue
        if r["status"] and s["status"] != r["status"]: continue
        if r.get("customer") and not similar(r["customer"], s["customer"]): continue
        if r.get("plate") and not similar(r["plate"], s["plate"]): continue
        found.append(s)

    where = describe_filters(r, ar)
    n = len(found)
    if ar:
        head = "ما في ولا فاتورة" if n == 0 else ("في فاتورة وحدة" if n == 1 else "في %d فواتير" % n)
    else:
        head = "There are no invoices" if n == 0 else ("There is 1 invoice" if n == 1 else "There are %d invoices" % n)
    text_out = (head + (" " + where if where else "") + ".")
    if n:
        by = {}
        for s in found:
            by[s["status"]] = by.get(s["status"], 0) + 1
        text_out += " (" + "، ".join("%d %s" % (c, STATUS_AR[k]) for k, c in by.items()) + ")" if ar else \
                    " (" + ", ".join("%d %s" % (c, STATUS_EN[k]) for k, c in by.items()) + ")"
    if metric == "total" and n:
        complete = [s for s in found if s["total_usd"] is not None]
        usd = sum((Decimal(str(s["total_usd"])) for s in complete), Decimal("0"))
        lbp = sum(int(s["total_lbp"] or 0) for s in complete)
        text_out += ("\nالمجموع: %s / %s ل.ل." if ar else "\nTotal: %s / %s LBP") % (money_usd(usd), format(lbp, ","))
        missing = n - len(complete)
        if missing:
            text_out += ("\n(%d فاتورة ناقصة أسعار ما انحسبت)" if ar else "\n(%d incomplete invoice(s) without prices are not counted)") % missing
    if user["role"] != "owner":
        text_out += "\n(بس الفواتير يلي إنت عملتها)" if ar else "\n(Only invoices you created.)"
    if n and metric != "list" and n > 10:
        text_out += "\nآخر 10:" if ar else "\nLatest 10:"
    return {"reply": text_out, "understood": r.get("understood", ""), "invoices": list(reversed(found))[:10]}


def open_by_number(user, r):
    ar = r.get("language") == "ar"
    no = invoice_no_from(r.get("invoice_no"))
    if no:
        for row in visible_rows(user):
            if row["no"] == no:
                return {"reply": ("هيدي الفاتورة %s." if ar else "Here is invoice %s.") % no, "open": invoice_out(row)}
    return {"reply": ("ما لقيت الفاتورة %s." if ar else "I couldn't find invoice %s.") % (no or r.get("invoice_no") or "?")
                     + (" جرّب «شو آخر الفواتير؟»" if ar else " Try \"show my latest invoices\".")}


# ---- contacts given to MA: must come from what the user actually typed/said ----
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
LB_MOBILE_RE = re.compile(r"^\+961(3\d{6}|(70|71|76|78|79|81)\d{6})$")
EMAIL_FIND = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}")
PHONE_FIND = re.compile(r"(?:\+|00)?\d[\d\s\-().]{4,18}\d")


def normalize_phone(raw):
    """'03 123 456' -> '+9613123456'. Lebanese numbers must be mobiles (WhatsApp). None if not valid."""
    s = str(raw or "").translate(AR_DIGITS).strip()
    d = re.sub(r"\D", "", s)
    if not d:
        return None
    if s.startswith("00"):
        d, intl = d[2:], True
    else:
        intl = s.startswith("+") or (d.startswith("961") and len(d) >= 10)
    e = "+" + d if intl else "+961" + d.lstrip("0")
    if e.startswith("+961"):
        return e if LB_MOBILE_RE.match(e) else None
    return e if E164_RE.match(e) else None


def phone_from_text(text):
    for m in PHONE_FIND.finditer(str(text or "").translate(AR_DIGITS)):
        e = normalize_phone(m.group(0))
        if e:
            return e
    return None


def phone_in_text(e164, text):
    digits = re.sub(r"\D", "", str(text or "").translate(AR_DIGITS))
    core = e164[4:] if e164.startswith("+961") else e164[1:]
    return bool(core) and (core in digits or core[-8:] in digits)


def email_in_text(email, text):
    t = str(text or "").lower()
    spoken = re.sub(r"\s*(?:\(at\)|\[at\]|\bat\b|@|آت)\s*", "@", t)
    spoken = re.sub(r"\s*(?:\bdot\b|نقطة|دوت)\s*", ".", spoken)
    return email.lower() in t or email.lower() in spoken.replace(" ", "")


def pretty_phone(e164):
    m = re.match(r"^\+961(\d+)$", e164 or "")
    if not m:
        return e164 or ""
    d = m.group(1)
    return "+961 " + (d[:2] + " " + d[2:5] + " " + d[5:] if len(d) == 8 else d[:1] + " " + d[1:4] + " " + d[4:])


def saved_contact(user, kind, opened=None, context=None):
    """The number/email already known for the invoice in question: on the invoice itself, else in the
    customer memory of its plate number (the truck's ID). Never invented."""
    inv = opened
    ctx = context if isinstance(context, dict) else {}
    with connect() as db:
        if inv is None and isinstance(ctx.get("invoice_id"), str):
            row = find_invoice(db, user, ctx["invoice_id"])
            inv = invoice_out(row) if row else None
        if inv is None and isinstance(ctx.get("draft"), dict):
            inv = ctx["draft"]
        if not isinstance(inv, dict):
            return ""
        cust, truck = inv.get("cust") or {}, inv.get("truck") or {}
        value = cust.get("tel" if kind == "whatsapp" else "email") or ""
        if not value:
            known = truck_memory.find(db, user["company_id"], truck.get("plate"))
            value = (known["tel"] if kind == "whatsapp" else known["email"]) if known else ""
    if kind == "whatsapp":
        return normalize_phone(value) or ""
    return value if EMAIL_RE.match(value or "") else ""


def share_request(user, r, turns, context=None):
    """MA was asked to send an invoice by WhatsApp or email. Uses only contact details the user gave."""
    ar = r.get("language") == "ar"
    said = "\n".join(h["text"] for h in turns[-6:] if h["role"] == "user")
    latest = turns[-1]["text"]
    out = {}
    if r.get("invoice_no"):
        opened = open_by_number(user, r)
        if "open" not in opened:
            return opened
        out["open"] = opened["open"]
    if r["intent"] == "send_whatsapp":
        phone = normalize_phone(r.get("phone")) if r.get("phone") else None
        if phone and not r.get("phone_from_ma") and not phone_in_text(phone, said):
            phone = None                      # the AI produced a number the user never said
        phone = phone or phone_from_text(latest)
        saved = False
        if not phone and not (r.get("phone") or re.search(r"\d{3}", latest.translate(AR_DIGITS))):
            phone = saved_contact(user, "whatsapp", out.get("open"), context)
            saved = bool(phone)
        if phone:
            who = pretty_phone(phone)
            out.update(reply=(("سأجهز ملف PDF وأفتح واتساب مع %s بعد التأكيد. أرفق الملف واضغط إرسال بنفسك." if ar else
                               "I'll prepare the PDF and open the WhatsApp chat with %s after confirmation. WhatsApp links can't attach files; attach the downloaded PDF and press Send yourself.") % who),
                       action={"type": "whatsapp", "phone": phone, "saved": saved, "method": "chat"})
        elif r.get("phone") or re.search(r"\d{3}", latest.translate(AR_DIGITS)):
            out.update(reply=("الرقم مش واضح أو مش رقم واتساب صحيح. اكتبو مع رمز البلد، مثلاً 96170123456 أو 03 123 456. شو الرقم الصحيح؟" if ar else
                              "That doesn't look like a valid WhatsApp number. Include the country code, e.g. 96170123456 or 03 123 456. What's the correct number?"),
                       ask="whatsapp", action={"type": "whatsapp"})
        else:
            out.update(reply="أكيد، شو رقم واتساب الزبون؟" if ar else "Sure. What's the customer's WhatsApp number?",
                       ask="whatsapp", action={"type": "whatsapp"})
    else:
        email = (r.get("email") or "").strip().strip(".,;")
        if email and not (EMAIL_RE.match(email) and email_in_text(email, said)):
            email = ""
        if not email:
            m = EMAIL_FIND.search(latest)
            email = m.group(0) if m else ""
        saved = False
        if not email and not (r.get("email") or "@" in latest):
            email = saved_contact(user, "email", out.get("open"), context)
            saved = bool(email)
        if email:
            out.update(reply=(("سأجهز ملف PDF وأفتح Gmail إلى %s بعد التأكيد. أرفق الملف وراجع الرسالة واضغط إرسال بنفسك." if ar else
                               "I'll prepare the PDF and open Gmail to %s after confirmation. Attach the downloaded PDF, review the email and press Send yourself.") % email),
                       action=dict({"type": "email", "email": email}, **({"saved": True} if saved else {})))
        elif r.get("email") or "@" in latest:
            out.update(reply="الإيميل مش صحيح. شو إيميل الزبون؟ مثلاً name@gmail.com" if ar else
                       "That email address doesn't look valid. What's the customer's email? For example name@gmail.com.",
                       ask="email", action={"type": "email"})
        else:
            out.update(reply="أكيد، شو إيميل الزبون؟" if ar else "Sure. What's the customer's email address?", ask="email", action={"type": "email"})
    return out


NEW_INVOICE_RE = re.compile(r"\b(?:new|another|next|second|different)\s+(?:invoice|customer|bill|job)\b|"
                            r"فاتورة\s+(?:جديدة|جديده|تانية|تانيه|ثانية|غير)|زبون\s+(?:جديد|تاني|ثاني)", re.I)


PAUSE_RE = re.compile(r"^\s*(?:ma[\s,]*)?(?:pause|hold on|wait(?: a (?:sec|second|minute|moment))?|one (?:sec|second|minute|moment)|"
                      r"give me a (?:sec|second|minute|moment)|وقّف شوي|وقف شوي|استنى|إستنى|لحظة|دقيقة|ناطر)\b[\s.!]*$", re.I)
# while MA waits for an invoice answer, these mean the employee asks something else (route it normally)
FOLLOWUP_OTHER_RE = re.compile(r"[?؟]|\b(?:how many|how much|how are|what(?:'s| is)|which|show|list|open|send|whats ?app|e-?mail|help|cancel|who|total|"
                               r"hello|hi|hey|thanks|thank you|good (?:morning|evening|afternoon))\b|"
                               r"قدّيش|قديش|كم |شو |افتح|فرجيني|ابعت|إبعت|واتس|ايميل|إيميل|مساعدة|الغي|انسى|مين|كيفك|مرحبا|أهلين|اهلين|شكرا|يسلمو", re.I)
WA_DIRECT_RE = re.compile(r"\b(?:direct(?:ly)?|business|api|automatic(?:ally)?|send it(?: now)?|just send)\b|مباشر|مباشرة|الأعمال|اعمال|ابعتها|إبعتها|بعتها", re.I)
WA_CHAT_RE = re.compile(r"\b(?:open|chat|link|myself|manual(?:ly)?|attach)\b|افتح|إفتح|فتاح|محادثة|المحادثة|الشات|شات|بإيدي|بايدي", re.I)
CHAT_INPUT = contextvars.ContextVar("chat_input", default=None)   # (json body, audio bytes) of this chat request

# ---------------------------------------------------------------- conversation stages
# chat -> collecting (customer name, truck number, repair) -> validating -> preview -> approval -> delivery.
# Talking to MA (or opening Live Voice) never starts an invoice; only an explicit request or a repair description does.
REPAIR_QUESTION = ("Perfect! Now, can you describe the repair? Tell me the parts, quantities and prices.",
                   "ممتاز! هلّق احكيلي شو التصليح؟ القطع، العدد والأسعار.")
START_ACK = ("Sure! Let's start. ", "أكيد! يلّا نبلّش. ")
NEXT_ACK = ("Great! ", "تمام! ")
EMPTY_ORDER = dict(customer="", customer_phone="", customer_email="", parts=[], labor_amount=None, labor_currency=None,
                   notes="", truck_plate="", truck_model="")
MA_WORDS = {"ma", "em", "ay", "إم", "ام", "إيه", "ايه", "اي", "يا", "ya"}
GREET_PHRASES = sorted({"hello", "hi", "hey", "hiya", "hi there", "hello there", "hey there", "good morning", "good afternoon",
                        "good evening", "مرحبا", "مرحبتين", "مرحبًا", "اهلا", "أهلا", "أهلين", "اهلين", "هاي", "هلا", "صباح الخير",
                        "مسا الخير", "مساء الخير", "السلام عليكم", "سلام", "marhaba", "ahla", "ahlan"}, key=len, reverse=True)
HOW_PHRASES = {"how are you", "how are you doing", "how are you today", "how's it going", "hows it going", "how is it going",
               "how are things", "كيفك", "كيف حالك", "كيفك اليوم", "شو اخبارك", "شو أخبارك", "كيف الحال", "kifak", "kifik", "kifak l yom"}
THANKS_PHRASES = {"thanks", "thank you", "thanks a lot", "thank you very much", "thanks ma", "شكرا", "يسلمو", "يسلموا", "تسلم",
                  "merci", "مرسي", "ميرسي", "شكرا كتير", "يعطيك العافية"}
START_RE = re.compile(
    r"^(?:(?:ok(?:ay)?|so|please|hey|hi|hello|yes|yeah)\s+)*"
    r"(?:(?:i\s+(?:want|need|would like|wanna)|i'd like|let's|lets|can (?:you|we)|could you|please)\s+(?:to\s+)?)?"
    r"(?:create|make|start|do|prepare|write|generate|issue|begin)?\s*(?:a\s+|an\s+)?(?:new\s+)?invoice(?:\s+please)?$"
    r"|^(?:بدي|بدنا|بدّي|حابب|ممكن|خلينا|يلا|يلّا)?\s*(?:إعمل|اعمل|أعمل|نعمل|تعمل|عمل|نفتح|افتح|إفتح|حضّر|حضر|نحضّر|اعملي|إعملي|اعملّي|تعملي|تعمللي)?\s*"
    r"(?:لي\s+)?فاتورة(?:\s+(?:جديدة|جديده))?(?:\s+(?:لو سمحت|من فضلك))?$"
    r"|^(?:baddi|bade|badde|badna)\s+(?:a3mel|e3mel|na3mel|a3mol)\s+fat(?:o|ou)ra(?:\s+jdide)?$", re.I)


def plain_words(text_value):
    """Lowercase words of a short message without punctuation and without MA's own name (\"MA, hello\" -> \"hello\")."""
    s = re.sub(r"[ً-ٰٟـ]", "", str(text_value or "").lower().replace("’", "'"))   # Arabic diacritics
    return " ".join(w for w in re.sub(r"[^\w\s']", " ", s).split() if w not in MA_WORDS)


def is_invoice_start(text_value):
    """'I want to create an invoice' / 'new invoice' / «بدي إعمل فاتورة»: a request with no details yet."""
    s = plain_words(text_value)
    return bool(s) and len(s.split()) <= 9 and bool(START_RE.fullmatch(s))


def small_talk(text_value, first_name, ar):
    """Greetings, 'how are you' and thanks are answered at once (no AI call) and never start an invoice."""
    s = plain_words(text_value)
    greet = False
    for g in GREET_PHRASES:
        if s == g or s.startswith(g + " "):
            greet, s = True, s[len(g):].strip()
            break
    first = (" " + first_name) if first_name else ""
    if s in HOW_PHRASES:
        hello = (("أهلين%s! " % first) if ar else ("Hi%s! " % first)) if greet else ""
        return hello + ("منيح الحمدلله! كيف فيني ساعدك؟" if ar else "I'm doing great! How can I assist you?")
    if s in THANKS_PHRASES:
        return "تكرم! في شي تاني بقدر ساعدك فيه؟" if ar else "You're welcome! Anything else I can help with?"
    if greet and not s:
        return ("أهلين%s! كيف فيني ساعدك اليوم؟" % first) if ar else ("Hello%s! How can I help you today?" % first)
    return None


def is_echo(heard, said):
    """Live Voice: the microphone picked up MA's own last sentence (speaker echo), not the employee."""
    a, b = plain_words(heard), plain_words(said)
    if len(a) < 6 or not b:
        return False
    from difflib import SequenceMatcher
    return a in b or SequenceMatcher(None, a, b[:len(a) + 40]).ratio() >= 0.8


def collecting(state):
    """True while MA is in the middle of collecting an invoice (its last question carried a valid state)."""
    return bool(state) and state.get("stage") != "preview" and \
        (state.get("order") is not None or bool(state.get("collected")) or bool(state.get("asked")))


def stage_of(out):
    if out.get("question"):
        return "collecting"
    if out.get("reply") is not None:
        return "collecting" if out.get("kind") == "aside" else "chat"
    if out.get("items") is not None and out.get("totals") is not None:
        return "preview"
    return "chat"
STATES = URLSafeTimedSerializer(secrets.token_hex(32), salt="ma-conversation-state")


def repair_window(turns, new_from_router):
    """The turns that belong to the invoice being prepared, and whether this message starts a new one."""
    start, marked = 0, False
    for i, h in enumerate(turns):
        if h['role'] == 'assistant' and h.get('kind') in ('answer', 'greeting'):
            start, marked = i + 1, False
        elif h['role'] == 'user' and (NEW_INVOICE_RE.search(h['text']) or is_invoice_start(h['text'])):
            start, marked = i, True
    if new_from_router and len(turns) > 1:
        start, marked = len(turns) - 1, True
    # a new request starts a new invoice: never mixed with (or saved over) the invoice shown before it.
    # Once the new invoice has been shown, later turns correct THAT invoice.
    is_draft = lambda t: t['role'] == 'assistant' and t.get('kind') == 'draft'
    new_invoice = marked and any(is_draft(t) for t in turns[:start]) and not any(is_draft(t) for t in turns[start:])
    # small talk in the middle of collecting (MA's 'aside' answers, pauses) is not part of the repair
    window = turns[start:]
    skip = set()
    for i, h in enumerate(window):
        if h['role'] == 'assistant' and h.get('kind') in ('aside', 'pause'):
            skip.add(i)
            if i > 0 and window[i - 1]['role'] == 'user' and i - 1 != len(window) - 1:
                skip.add(i - 1)
    return [h for i, h in enumerate(window) if i not in skip], new_invoice


def quick_route(turns):
    """Clear 'send to WhatsApp 03 123 456' / 'email it to x@y.com' commands (and answers to MA's
    'what's the number/email?') are understood without calling Gemini."""
    latest = turns[-1]["text"]
    if CANCEL_RE.search(latest) and len(latest) < 80 and not re.search(r"\d", latest):
        return {"intent": "cancel"}
    if PAUSE_RE.search(latest):
        return {"intent": "pause"}
    prev0 = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
    if prev0.get("ask") == "wa_method":            # answer to "open the WhatsApp chat or send it directly?"
        direct = WA_DIRECT_RE.search(latest)
        chat = WA_CHAT_RE.search(latest)
        phone = phone_from_text(prev0.get("text", ""))
        if phone and bool(direct) != bool(chat):
            return {"intent": "send_whatsapp", "phone": phone, "method": "direct" if direct else "chat", "phone_from_ma": True}
    prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
    asked = prev.get("ask")
    no = re.search(r"(?:\binv(?:oice)?|فاتورة|الفاتورة)\s*(?:no\.?|number|num|#|رقم)?\s*-?\s*(\d{1,5})\b", latest.translate(AR_DIGITS), re.I)
    extra = {"invoice_no": no.group(1)} if no else {}
    rest = latest.translate(AR_DIGITS).replace(no.group(0), " ") if no else latest
    em = EMAIL_FIND.search(latest)
    if em and (asked == "email" or re.search(r"e-?mail|mail|ايميل|إيميل|ميل|ابعت|إبعت|send", latest, re.I)):
        return dict(intent="send_email", email=em.group(0), **extra)
    ph = phone_from_text(rest)
    if ph and (asked == "whatsapp" or re.search(r"whats|wats|واتس|وتس", latest, re.I)):
        return dict(intent="send_whatsapp", phone=ph, **extra)
    return None


HELP_EN = ("Hi, I'm MA, your AI assistant. I'm here to help you understand, organize, and complete your tasks. Here's what I can do:\n"
           "\u2022 Describe a repair (type or tap the mic, Arabic or English) and I'll prepare a draft invoice.\n"
           "\u2022 Ask about your invoices: \"how many invoices today?\", \"total of approved invoices this month\", \"invoices for plate 123456\".\n"
           "\u2022 Open one: \"open invoice 3\".\n"
           "\u2022 Send an approved invoice: \"send it on WhatsApp to 03 123 456\" or \"email it to name@gmail.com\".")
HELP_AR = ("أهلا، أنا MA، مساعدك الذكي. أنا هون لساعدك تفهم وتنظّم وتخلّص شغلك. هيدا شو فيني أعمل:\n"
           "\u2022 احكيلي شو تصلّح (كتابة أو بالمايك، عربي أو إنكليزي) وبحضّرلك مسودة فاتورة.\n"
           "\u2022 إسألني عن الفواتير: «قديش فاتورة اليوم؟»، «مجموع الفواتير الموافق عليها هالشهر»، «فواتير النمرة 123456».\n"
           "\u2022 إفتح فاتورة: «افتحلي الفاتورة 3».\n"
           "\u2022 ابعت فاتورة موافق عليها: «ابعتها عالواتساب لـ 03 123 456» أو «ابعتها عالإيميل name@gmail.com».")


def current_invoice_answer(user, r, context):
    """Answer about the invoice on screen from real data: a saved invoice is re-read from the database
    (with the same company/ownership check as opening it); an unsaved draft is recomputed by the server."""
    ar = r.get("language") == "ar"
    ctx = context if isinstance(context, dict) else {}
    inv = None
    with connect() as db:
        if isinstance(ctx.get("invoice_id"), str) and ctx["invoice_id"]:
            row = find_invoice(db, user, ctx["invoice_id"])
            inv = invoice_out(row) if row else None
        elif isinstance(ctx.get("draft"), dict):
            try:
                inv = clean_payload(ctx["draft"], company_of(db, user))
            except (ValueError, TypeError):
                inv = None
    if not inv:
        return {"reply": "ما في فاتورة مفتوحة هلّق. احكيلي شو صلّحت لحضّرلك وحدة، أو قول «افتحلي الفاتورة 3»." if ar else
                "There's no invoice open right now. Tell me about a repair and I'll draft one, or say \"open invoice 3\"."}
    items = [i for i in inv.get("items") or [] if i.get("d")]
    tot = (inv.get("totals") or {}).get("total_usd")
    name = (inv.get("cust") or {}).get("name") or ("بلا اسم" if ar else "no name")
    label = inv.get("no") or ("المسودة" if ar else "this draft")
    detail = r.get("detail") or "items"
    def amount():
        if tot is None:
            return "المجموع مش كامل لأن في سعر ناقص." if ar else "The total isn't complete yet because a price is missing."
        return ("المجموع %s دولار." if ar else "The total is $%s.") % format(Decimal(str(tot)), ",.2f")
    if detail == "count":
        reply = ("بـ %s في %d بند." if ar else "There are %d items in %s.") % ((label, len(items)) if ar else (len(items), label))
    elif detail == "total":
        reply = amount()
    elif detail == "customer":
        reply = ("الزبون: %s." if ar else "The customer is %s.") % name
    elif detail == "status":
        reply = ("الحالة: %s." if ar else "The status is %s.") % (inv.get("status") or ("مسودة" if ar else "draft"))
    else:
        lines = ["%s × %s" % (format(Decimal(str(i["q"])).normalize(), "f") if i.get("q") is not None else "?", i["d"]) for i in items[:12]]
        reply = (("بـ %s: " if ar else "%s has: ") % label) + "، ".join(lines) + ". " + amount() if lines else \
                ("ما في بنود بعد." if ar else "It has no items yet.")
    return {"reply": reply, "understood": r.get("understood") or ""}


def product_answer(r):
    """Product questions are answered only from the catalog (products.json): never invented."""
    from database import search_products, suggest_products
    ar = r.get("language") == "ar"
    q = (r.get("product") or "").strip()
    if not q:
        # a question about the whole catalog ("how many products do we have?", "and the prices?")
        products = [p for p in load_products() if p.get("name_en")]
        if not products:
            return {"reply": "الكتالوج فاضي." if ar else "The catalog is empty."}
        detail = r.get("detail") or "what"
        if detail == "price":
            priced = sorted((p for p in products if p.get("price_usd") is not None), key=lambda p: p["price_usd"])
            if not priced:
                return {"reply": "ما في أسعار بالكتالوج." if ar else "The catalog has no prices."}
            lo, hi = priced[0], priced[-1]
            name = (lambda p: p["name_ar"]) if ar else (lambda p: p["name_en"])
            return {"reply": ("الأسعار بالكتالوج من %s دولار (%s) لـ %s دولار (%s). إسألني عن أي قطعة بالتحديد." if ar else
                              "Catalog prices range from $%s (%s) to $%s (%s). Ask me about any part for its exact price.")
                             % (lo["price_usd"], name(lo), hi["price_usd"], name(hi))}
        reply = ("في %d قطعة بالكتالوج." if ar else "There are %d products in the catalog.") % len(products)
        if detail == "stock":
            reply += (" الكتالوج ما فيه كميات المخزون، فما فيني أعرف قديش في من كل قطعة." if ar else
                      " The catalog doesn't track stock quantities, so I can't tell how many of each are in stock.")
        return {"reply": reply}
    found = search_products(q) or suggest_products(q)
    if not found:
        return {"reply": ("ما لقيت «%s» بالكتالوج." if ar else "I couldn't find \"%s\" in the catalog.") % q}
    if len(found) > 1:
        names = "، ".join(p["name_ar"] if ar else p["name_en"] for p in found[:4])
        return {"reply": ("لقيت أكتر من قطعة: %s. أي وحدة بتقصد؟" if ar else "I found a few: %s. Which one do you mean?") % names}
    p = found[0]
    nm = p["name_ar"] if ar else p["name_en"]
    unit = p.get("unit") or "piece"
    if ar:
        unit = {"piece": "قطعة", "set": "طقم", "container": "عبوة", "bottle": "قنينة"}.get(unit, unit)
    price = p.get("price_usd")
    price_txt = (("سعرها بالكتالوج %s دولار للـ%s." if ar else "Its catalog price is $%s per %s.") % (price, unit)) if price is not None else \
                ("ما في سعر إلها بالكتالوج." if ar else "The catalog has no price for it.")
    reply = ("%s (%s): %s" % (nm, p["id"], price_txt))
    if r.get("detail") == "stock":
        reply += (" الكتالوج ما فيه كميات المخزون، فما فيني أعرف قديش في." if ar else
                  " The catalog doesn't track stock, so I can't tell you how many are available.")
    return {"reply": reply, "product": {k: p.get(k) for k in ("id", "name_en", "name_ar", "unit", "price_usd")}}


CAPS_RE = re.compile(r"what can you do|how (?:do|does|to) (?:i|it|this|you)|\bhelp\b|features|شو (?:بتعمل|فيك|بتقدر)|كيف بستعمل|ساعدني|مساعدة", re.I)


def route(conversation, employee=""):
    from ai_agent import route_message
    now = time.localtime()
    return route_message(conversation, time.strftime("%Y-%m-%d", now), time.strftime("%A", now), employee)


def register_web(app):
    app.config.setdefault("INVOICE_DB", str(BASE / "garage.db"))
    invoice_services.register(app)

    @app.before_request
    def csrf_guard():
        if not request.path.startswith("/api/") or request.method in ("GET", "HEAD", "OPTIONS"):
            return None
        if request.path in CSRF_EXEMPT or not request.cookies.get(SESSION_COOKIE):
            return None
        sent, expected = request.headers.get(CSRF_HEADER, ""), request.cookies.get(CSRF_COOKIE, "")
        if not expected or not secrets.compare_digest(sent, expected):
            security.log_event("csrf_failed", detail=request.path[:60])
            return err(403, "Security check failed. Refresh the page and try again.", code="csrf")
        return None

    @app.after_request
    def send_rotated_session(resp):
        """The session token was replaced during this request: the browser gets the new one."""
        rotated = g.get("rotated_session")
        if rotated and not any(c.startswith(SESSION_COOKIE + "=;") or c.startswith(SESSION_COOKIE + '=""')
                               for c in resp.headers.getlist("Set-Cookie")):
            _set_session_cookie(resp, *rotated)
        return resp

    # ---- accounts
    @app.post("/api/auth/register")
    def register():
        d = body()
        f = {k: text(d.get(k), 130) for k in ("first_name", "last_name", "username", "phone", "company_name")}
        f["username"] = f["username"].lower()
        password = d.get("password") if isinstance(d.get("password"), str) else ""
        errors = {}
        for k in ("first_name", "last_name"):
            if not f[k] or len(f[k]) > 50 or not NAME_RE.match(f[k]):
                errors[k] = "Use letters only (1-50 characters)."
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "3-30 characters: letters, numbers, '_' or '.'; start with a letter."
        msg = check_password_rules(password, f["username"])
        if msg:
            errors["password"] = msg
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        company_name = re.sub(r"\s+", " ", f["company_name"])
        if not 2 <= len(company_name) <= 120:
            errors["company_name"] = "Company name must be 2-120 characters."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        if not security.rate_hit("register_ip", security.client_ip()):
            return err(429, "Too many attempts. Please wait a few minutes.")
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to an existing terminal account. Choose a different web username.")
        try:
            with connect() as db:
                now = time.time()
                cid = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                 (company_name, f["phone"], str(DEFAULT_VAT), now)).lastrowid
                # The person who registers a new company is its owner. Nobody can join an existing company this way.
                uid = db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                                 "VALUES (?,?,?,?,?,?,?,?)", (cid, f["first_name"], f["last_name"], f["username"],
                                                              hash_password(password), f["phone"], "owner", now)).lastrowid
                row = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
                company = company_of(db, row)
        except sqlite3.IntegrityError:
            return err(409, "Username is already taken.")
        resp = jsonify(user_json(row, company))
        resp.status_code = 201
        return start_session(resp, uid, True)

    @app.get("/api/auth/check-username")
    def check_username():
        if not security.rate_hit("username_check_ip", security.client_ip()):
            return security.too_many()
        name = text(request.args.get("username"), 40).lower()
        if not USERNAME_RE.match(name):
            return jsonify(available=False, suggestions=[], message="Invalid username format.")
        with connect() as db:
            taken = lambda n: db.execute("SELECT 1 FROM users WHERE username=?", (n,)).fetchone() is not None
            if not taken(name):
                return jsonify(available=True, suggestions=[])
            base = re.sub(r"[^a-z0-9]", "", name)[:20] or "user"
            cands = [base + "_garage", base + time.strftime("%Y"), base + "_trucks", base + "_auto", "%s.%d" % (base, secrets.randbelow(90) + 10)]
            free = [c for c in cands if USERNAME_RE.match(c) and not taken(c)][:3]
        return jsonify(available=False, suggestions=free)

    @app.get("/api/auth/me")
    def me():
        user = require_user()
        with connect() as db:
            return jsonify(user_json(user, company_of(db, user)))

    @app.put("/api/auth/me")
    def update_me():
        user = require_user("account.edit")
        d = body()
        f = {k: text(d.get(k), 60) for k in ("first_name", "last_name", "username", "phone")}
        f["username"] = f["username"].lower()
        errors = {k: "Use letters only." for k in ("first_name", "last_name") if not f[k] or not NAME_RE.match(f[k])}
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "Invalid username."
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to a terminal employee account. Choose a different website username.")
        try:
            with connect() as db:
                db.execute("UPDATE users SET first_name=?, last_name=?, username=?, phone=? WHERE id=?",
                           (f["first_name"], f["last_name"], f["username"], f["phone"], user["id"]))
                row = db.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
                return jsonify(user_json(row, company_of(db, row)))
        except sqlite3.IntegrityError:
            return err(409, "Username is already taken.")

    @app.post("/api/auth/password/change")
    def change_password():
        user = require_user("account.edit")
        d = body()
        if security.rate_limited("login_account", user["username"]):
            return err(429, "Too many attempts. Please wait 5 minutes and try again.")
        if not verify_password(user["password_hash"], str(d.get("current_password", "")))[0]:
            security.rate_record("login_account", user["username"])
            return err(400, "Current password is incorrect.", {"current_password": "Current password is incorrect."})
        msg = check_password_rules(d.get("new_password"), user["username"])
        if msg:
            return err(422, msg, {"new_password": msg})
        with connect() as db:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(d["new_password"]), user["id"]))
            # every other device is signed out; this browser keeps its session
            db.execute("DELETE FROM web_sessions WHERE user_id=? AND COALESCE(family, token_hash)<>?", (user["id"], session_id()))
        security.log_event("password_changed", user=user)
        return Response(status=204)

    @app.post("/api/auth/password/forgot")
    def forgot():
        return err(501, "SMS password recovery is not configured. Contact the laptop administrator.")

    @app.post("/api/auth/password/reset")
    def reset():
        d = body()
        name = text(d.get("username"), 40).lower()
        code = text(d.get("code"), 10)
        with connect() as db:
            row = db.execute("SELECT u.*, r.code_hash, r.expires AS r_exp, r.attempts FROM users u JOIN reset_codes r ON r.user_id=u.id "
                             "WHERE u.username=?", (name,)).fetchone()
            if not row or row["r_exp"] < time.time() or row["attempts"] >= 5:
                return err(400, "This code is wrong or has expired.")
            if not secrets.compare_digest(row["code_hash"], sha(code)):
                db.execute("UPDATE reset_codes SET attempts=attempts+1 WHERE user_id=?", (row["id"],))
                return err(400, "This code is wrong or has expired.")
            msg = check_password_rules(d.get("password"), name)
            if msg:
                return err(422, msg, {"password": msg})
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(d["password"]), row["id"]))
            db.execute("DELETE FROM reset_codes WHERE user_id=?", (row["id"],))
            db.execute("DELETE FROM web_sessions WHERE user_id=?", (row["id"],))
        return jsonify(message="Password updated.")

    # ---- company
    @app.get("/api/company")
    def get_company():
        user = require_user()
        with connect() as db:
            return jsonify(company_json(company_of(db, user)))

    @app.put("/api/company")
    def put_company():
        user = require_user("company.manage")
        name = re.sub(r"\s+", " ", text(request.form.get("name"), 130))
        phone = text(request.form.get("phone"), 20)
        errors = {}
        if not 2 <= len(name) <= 120:
            errors["name"] = "Company name must be 2-120 characters."
        if not valid_phone(phone):
            errors["phone"] = "Enter a valid phone number."
        logo = request.files.get("logo")
        data = ctype = None
        if logo:
            data = logo.read(2 * 1024 * 1024 + 1)
            if len(data) > 2 * 1024 * 1024:
                errors["logo"] = "The logo must be 2 MB or smaller."
            elif data[:8] == b"\x89PNG\r\n\x1a\n":
                ctype = "image/png"
            elif data[:3] == b"\xff\xd8\xff":
                ctype = "image/jpeg"
            elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
                ctype = "image/webp"
            else:
                errors["logo"] = "Please upload a PNG, JPG or WebP image."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        with connect() as db:
            db.execute("UPDATE companies SET name=?, phone=? WHERE id=?", (name, phone, user["company_id"]))
            if data:
                db.execute("UPDATE companies SET logo=?, logo_type=?, logo_ver=? WHERE id=?",
                           (data, ctype, secrets.token_hex(4), user["company_id"]))
            elif request.form.get("remove_logo") == "1":
                db.execute("UPDATE companies SET logo=NULL, logo_type=NULL, logo_ver=NULL WHERE id=?", (user["company_id"],))
            return jsonify(company_json(company_of(db, user)))

    @app.get("/media/logo/<int:cid>")
    def logo(cid):
        user = require_user()
        if user["company_id"] != cid:
            return err(404, "Not found.")
        with connect() as db:
            c = db.execute("SELECT logo, logo_type FROM companies WHERE id=?", (cid,)).fetchone()
        if not c or not c["logo"]:
            return err(404, "No logo.")
        resp = Response(c["logo"], mimetype=c["logo_type"])
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "private, max-age=86400"
        return resp

    # ---- catalog & customers
    @app.get("/api/catalog")
    def catalog():
        require_user()
        return jsonify([[p["name_en"], "Part", p["price_usd"]] for p in load_products()])

    @app.get("/api/trucks/lookup")
    def truck_lookup():
        """Customer memory for the invoice editor: by plate, phone or a unique full name."""
        user = require_user("ai.chat")
        with connect() as db:
            known = truck_memory.profile(db, user["company_id"], request.args.get("plate"), request.args.get("tel"),
                                         exclude=request.args.get("exclude"), name=request.args.get("name"))
        return jsonify(known or {})

    @app.get("/api/customers")
    def customers():
        user = require_user("invoice.history")
        with connect() as db:
            out = [invoice_services.customer_out(r) for r in db.execute('SELECT * FROM web_customers WHERE company_id=? ORDER BY name',(user['company_id'],)).fetchall()]
        seen = {(c['name'].casefold(),c.get('tel',''),c.get('email','')) for c in out}
        for inv in _list(user):
            c = inv.get("cust", {})
            key = (c.get("name","").casefold(),c.get("tel",""),c.get("email",""))
            if c.get("name") and key not in seen:
                seen.add(key)
                out.append(c)
        return jsonify(out)

    def _list(user):
        sql, args = "SELECT * FROM web_invoices WHERE company_id=?", [user["company_id"]]
        if user["role"] != "owner":
            sql += " AND created_by=?"
            args.append(user["id"])
        with connect() as db:
            rows = db.execute(sql + " ORDER BY seq", args).fetchall()
            # latest delivery status per method, shown in Invoice History (Not Sent / Sending / Sent / Failed)
            last = {}
            for d in db.execute("SELECT invoice_id, method, status FROM delivery_attempts WHERE invoice_id IN (SELECT id FROM web_invoices WHERE company_id=?) "
                                "ORDER BY attempted_at", (user["company_id"],)).fetchall():
                last.setdefault(d["invoice_id"], {})[d["method"]] = d["status"]
            out = []
            for r in rows:
                inv = invoice_out(r)
                inv["delivery"] = {m: last.get(r["id"], {}).get(m, "not_sent") for m in ("email", "whatsapp")}
                out.append(inv)
            return out

    # ---- invoices
    @app.get("/api/invoices")
    def list_invoices():
        return jsonify(_list(require_user("invoice.history")))

    @app.post("/api/invoices/generate")
    def generate():
        """One chat endpoint. With ?progress=1 the answer is streamed as NDJSON: {"type":"step"|"activity",...} lines
        for each real step MA takes, then one {"type":"result","status":...,"body":...} line.
        Voice turns: multipart with an "audio" file and a "payload" JSON field. The recording is transcribed and
        answered in the same request (one round trip); a {"type":"transcript"} line arrives as soon as it is heard."""
        user = require_user("ai.chat")       # auth/CSRF problems are answered normally, before streaming
        if not security.rate_hit("ai_user", "web:%d" % user["id"]):   # every MA turn costs AI quota
            return security.too_many("You're sending messages very fast. Please wait a moment.")
        audio = None
        if request.files.get("audio") is not None:
            from voice_agent import MAX_AUDIO_BYTES
            audio = request.files["audio"].read(MAX_AUDIO_BYTES + 1)
            if len(audio) > MAX_AUDIO_BYTES:
                return err(413, "Recording exceeds 10 MB.")
            try:
                data = json.loads(request.form.get("payload") or "{}")
            except ValueError:
                return err(400, "Invalid voice request.")
        else:
            data = body()
        data = data if isinstance(data, dict) else {}
        if request.args.get("progress") != "1":
            CHAT_INPUT.set((data, audio))
            return generate_once()
        events = queue.Queue()

        @copy_current_request_context
        def work():
            PROGRESS.set(events.put)
            CHAT_INPUT.set((data, audio))
            try:
                resp = current_app.make_response(generate_once())
                events.put({"type": "result", "status": resp.status_code, "body": resp.get_json(silent=True)})
            except HTTPException as exc:
                events.put({"type": "result", "status": exc.code or 500, "body": {"detail": exc.description}})
            except Exception:
                current_app.logger.error("AI generation failed")
                events.put({"type": "result", "status": 500, "body": {"detail": "MA couldn't finish this. Please try again."}})
            finally:
                events.put(None)

        threading.Thread(target=work, daemon=True).start()

        def lines():
            while True:
                item = events.get()
                if item is None:
                    return
                yield json.dumps(item, ensure_ascii=False) + "\n"
        return Response(lines(), mimetype="application/x-ndjson", headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    def generate_once():
        """Understands what the employee wants, then drafts, answers or opens. Every answer carries `language`
        (the language MA replied in, so the right voice reads it)."""
        user = require_user("ai.chat")
        d, audio = CHAT_INPUT.get() or (body(), None)
        history = d.get("history") if isinstance(d.get("history"), list) else []
        # The history comes from the browser: untrusted. Only the recent turns are used, each of bounded size, and
        # only role/text/kind/ask/state are read (state tokens are signed and re-verified, never trusted as is).
        turns = [{k: (h[k][:5000] if k == "text" else h[k]) for k in ("role", "text", "kind", "ask", "state") if isinstance(h.get(k), str)}
                 for h in history[-settings().max_history_turns:]
                 if isinstance(h, dict) and h.get('role') in ('user','assistant') and isinstance(h.get('text'),str) and h['text'].strip()]
        latest = text(d.get('text'),5000)
        if audio is not None:
            from voice_agent import transcribe_audio
            act("transcribe", "processing", "Listening to your voice message", "عم إسمع رسالتك الصوتية")
            try:
                latest = transcribe_audio(audio)
            except ValueError as exc:
                act("transcribe", "failed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", error=str(exc))
                return err(400, "I couldn't hear anything clear. Please try again. ما سمعت شي واضح، جرّب كمان مرّة.")
            except GeminiUnavailable:
                act("transcribe", "failed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", error="AI service busy")
                return err(503, "MA is busy right now. Please say it again in a moment.")
            lang = "ar" if re.search(r'[؀-ۿ]', latest) else "en"
            said = next((h["text"] for h in reversed(turns) if h["role"] == "assistant"), "")
            if d.get("live") and is_echo(latest, said):
                # Live Voice heard MA's own voice from the speaker: nothing is added to the conversation
                act("transcribe", "completed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", detail="(MA's own voice: ignored)")
                return jsonify({"ignored": True, "language": lang})
            act("transcribe", "completed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", detail=latest[:120])
            emit = PROGRESS.get()
            if emit:
                emit({"type": "transcript", "text": latest, "language": lang})
        if latest and (not turns or turns[-1]['role'] != 'user' or turns[-1]['text'].strip() != latest):
            turns.append({'role':'user','text':latest})
        if not turns or turns[-1]['role'] != 'user':
            return err(400, "Type or say something to MA first.")
        out = converse(user, d, turns)
        if isinstance(out, tuple):
            return out
        if audio is not None:
            out["transcript"] = latest
        return jsonify(out)

    def load_state(turns):
        """The signed state of MA's last invoice question (what it understood + what it asked), if still valid."""
        prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), None)
        token = prev.get("state") if prev else None
        if not isinstance(token, str) or not token:
            return None
        try:
            st = STATES.loads(token, max_age=1800)
        except (BadSignature, TypeError):
            return None
        user = session_user()
        if not user or st.get("user") != user["id"] or st.get("session") != session_id():
            return None
        return st

    def sign_state(user, result, ar):
        st = result.pop("_state", None)
        if st is not None:
            result["state"] = STATES.dumps({**st, "ar": ar, "user": user["id"], "session": session_id()})
        return result

    def converse(user, d, turns):
        label = lambda h: ('Mechanic: ' if h['role']=='user' else 'Assistant: ')+h['text'].strip()
        latest = turns[-1]["text"]
        step("start", "Reading your message", "عم إقرا رسالتك")
        act("understand", "processing", *INVOICE_PLAN[0][1:])
        prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
        state = load_state(turns)
        has_ar = bool(re.search(r'[؀-ۿ]', latest))
        has_en = bool(re.search(r'[A-Za-z]{3,}', re.sub(r'(?<![A-Za-z])[A-Za-z]{1,3}\s?-?\d{2,6}', ' ', latest)))
        # language of THIS message; a bare answer ("A1234", "Haddad") keeps the conversation's language
        ar_now = has_ar or (not has_en and bool(state and state.get("ar")))
        # 0) Requests for secrets, internal instructions, raw SQL, rule overrides or deleting data are refused here,
        #    before any AI call. What MA is allowed to do is decided by the server, never by the model.
        refused = ma_tools.screen(latest, user, ar_now)
        if refused:
            act("understand", "completed", *INVOICE_PLAN[0][1:], detail="Refused" if not ar_now else "مرفوض")
            out = {**refused, "language": "ar" if ar_now else "en", "stage": "chat"}
            if state and prev.get("state"):          # an invoice being collected is kept
                out.update(kind="aside", state=prev["state"], stage="collecting" if collecting(state) else "preview")
            return out
        # 1) Understand the request. Fast paths first (no AI call), then the router.
        r, speculative = quick_route(turns), None
        if not r:
            chat = small_talk(latest, user["first_name"], has_ar)
            if chat:                             # "Hello MA" / "how are you?" / "thanks": a conversation, never an invoice
                r = {"intent": "chat", "reply": chat, "language": "ar" if has_ar else "en"}
            elif is_invoice_start(latest):       # "I want to create an invoice": collection starts with the customer
                r = {"intent": "invoice", "start": True}
        slots = {}
        if not r and state and state.get("asked"):
            slots = invoice_validation.answer_slots(latest, state["asked"])
            leftover = re.sub(r"(?<![A-Za-z0-9])[A-Za-z]{0,3}[\s\-]?\d{2,6}(?![A-Za-z0-9])", " ", latest)
            short = len(latest.split()) <= 6 and not re.search(r"\d", leftover.translate(AR_DIGITS))
            if slots and short:
                r = {"intent": "invoice", "fast": True}
        if not r and prev.get("kind") == "question" and not FOLLOWUP_OTHER_RE.search(latest):
            r = {"intent": "invoice"}            # answering MA's invoice question: no need to re-route
        if not r:
            convo = '\n\n'.join(label(h) for h in turns[-12:])[-5000:]
            likely_repair = len(latest) > 25 and not FOLLOWUP_OTHER_RE.search(latest)
            pool = concurrent.futures.ThreadPoolExecutor(max_workers=2) if likely_repair else None
            if pool:   # start reading the repair while the intent is decided: saves one full AI round trip
                window = '\n\n'.join(('Mechanic: ' if h['role']=='user' else 'Assistant question: ')+h['text'].strip() for h in repair_window(turns, False)[0])
                import invoice_engine
                speculative = (window, pool.submit(invoice_engine.understand_message, window))
            # if the intent cannot be read, only a repair description (or an answer while collecting) goes on to an invoice
            fallback = {"intent": "invoice"} if likely_repair or collecting(state) else {"intent": "unavailable"}
            try:
                r = route(convo, user["first_name"])
            except GeminiUnavailable:
                r = fallback
            except Exception:
                current_app.logger.warning("Intent detection failed")
                r = fallback
            finally:
                if pool:
                    pool.shutdown(wait=False)
        r = dict(r)                              # never modify the router's own result
        intent = r.get("intent")
        ar = (r.get("language") == "ar") if r.get("language") in ("ar", "en") and not has_ar else ar_now
        lang = "ar" if ar else "en"
        step("intent", *{"invoice": ("Preparing an invoice", "عم حضّر فاتورة"), "invoice_query": ("Looking up your invoices", "عم دوّر بفواتيرك"),
                         "current_invoice": ("Reading the invoice on screen", "عم إقرا الفاتورة المفتوحة"), "product_info": ("Checking the catalog", "عم شوف الكتالوج"),
                         "open_invoice": ("Opening the invoice", "عم إفتح الفاتورة"), "send_whatsapp": ("Preparing to send", "عم حضّر للإرسال"),
                         "send_email": ("Preparing to send", "عم حضّر للإرسال")}.get(intent, ("Answering in the chat", "عم جاوبك بالمحادثة")), intent=intent or "")
        act("understand", "completed", *INVOICE_PLAN[0][1:], intent=intent or "",
            plan=[{"key": k, "en": en, "ar": a} for k, en, a in INVOICE_PLAN] if intent == "invoice" else None,
            detail={"invoice": ("Invoice", "فاتورة"), "invoice_query": ("Question about invoices", "سؤال عن الفواتير"),
                    "send_whatsapp": ("Send by WhatsApp", "إرسال عالواتساب"), "send_email": ("Send by email", "إرسال عالإيميل"),
                    "cancel": ("Cancel", "إلغاء"), "pause": ("Pause", "توقيف مؤقت")}.get(intent, ("Conversation", "محادثة"))[1 if ar else 0])
        r["language"] = lang
        done = lambda o: {**o, "language": lang, "stage": stage_of(o)}
        # The capability gate: permission for this capability + validated arguments, checked outside the model.
        r, denied = ma_tools.gate(user, intent, r, ar)
        if denied:
            return done(denied)

        def aside(o, remind=False):
            """An answer given while MA is collecting an invoice: the collected details (signed state) are kept,
            so the next reply continues the same invoice instead of starting over."""
            if state and prev.get("state"):
                o = {**o, "kind": "aside", "state": prev["state"]}
                if remind and collecting(state) and o.get("reply"):
                    o["reply"] += ("\n\nلما تكون جاهز، منكمّل الفاتورة." if ar else "\n\nWhenever you're ready, we'll continue the invoice.")
                return {**done(o), "stage": "collecting" if collecting(state) else "preview"}
            return done(o)
        if intent == "invoice_query":
            return aside(answer_query(user, r))
        if intent == "open_invoice":
            return done(open_by_number(user, r))
        if intent in ("send_whatsapp", "send_email"):
            return done(share_request(user, r, turns, d.get("context")))
        if intent == "current_invoice":
            return aside(current_invoice_answer(user, r, d.get("context")))
        if intent == "product_info":
            return aside(product_answer(r))
        if intent == "unavailable":
            return aside({"reply": "عذرًا، ما قدرت إفهم هلّق. فيك تعيدها؟" if ar else "Sorry, I didn't quite catch that. Could you say it again?"})
        if intent == "cancel":
            return done({"reply": "تمام، لغيت المسودة. ما انحفظ شي، والفواتير المحفوظة ما بتنمحى." if ar else
                         "OK, I cancelled this draft. Nothing new was saved, and saved invoices are never deleted.",
                         "action": {"type": "cancel"}})
        if intent == "pause":
            # nothing is lost: the next message continues the same invoice (the question's state is kept)
            out = {"reply": "تمام، وقّفنا شوي. كل المعلومات محفوظة، قلّي «كمّل» لما تكون جاهز." if ar else
                   "Sure, paused. Everything so far is kept. Say \"continue\" when you're ready.",
                   "action": {"type": "pause"}, "kind": "pause"}
            if prev.get("state"):
                out["state"] = prev["state"]
            return done(out)
        if intent in ("help", "chat"):
            # free text written by the model: checked for secrets / internal instructions before it is shown
            reply = ma_tools.scrub_reply((r.get("reply") or "").strip()[:1500], ar) or (HELP_AR if ar else HELP_EN)
            if intent == "help" and len(reply) < 60 and CAPS_RE.search(latest):
                reply += "\n\n" + (HELP_AR if ar else HELP_EN)
            return aside({"reply": reply}, remind=True)
        # 2) A repair: only the turns since the last non-repair answer belong to this invoice,
        #    and "new invoice / another customer" starts a fresh one (never mixed with the previous draft).
        repair, new_invoice = repair_window(turns, bool(r.get("new_invoice")))
        message = '\n\n'.join(('Mechanic: ' if h['role']=='user' else 'Assistant question: ')+h['text'].strip() for h in repair)
        if len(message) > 5000:
            return err(400, "That description is too long. Please keep it under 5000 characters.")
        # this very message starts a new invoice: nothing collected for an earlier one carries over
        if r.get("start") or (new_invoice and (r.get("new_invoice") or NEW_INVOICE_RE.search(latest))):
            state, slots = None, {}
        try:
            with connect() as db:
                company = company_of(db, user)
            collected = (state or {}).get("collected")
            if r.get("start"):
                # nothing to read yet: the same validation asks for the first missing detail (the customer), no AI call
                step("extract", "Starting a new invoice", "عم بلّش فاتورة جديدة")
                result = ai_draft(message, company, confirmed_order=json.loads(json.dumps(EMPTY_ORDER)), ar=ar)
                if result.get("question"):
                    result["question"] = START_ACK[1 if ar else 0] + result["question"]
            elif r.get("fast") and state and state.get("order"):
                step("extract", "Using your answer", "عم إستعمل جوابك")
                result = ai_draft(message, company, confirmed_order=state["order"], ar=ar, slots=slots, collected=collected)
                answered = set(state.get("asked") or {})
                still = result.get("missing") or []
                if result.get("question") and answered and not (answered & {m["field"] for m in still}) and not result["question"].startswith(REPAIR_QUESTION):
                    # the answer was accepted: acknowledge it, then the next detail (a wrong one is explained as is)
                    if not still or still[0]["code"] == "missing":
                        result["question"] = NEXT_ACK[1 if ar else 0] + result["question"]
            else:
                pre = None
                if speculative and speculative[0] == message:
                    try:
                        pre = speculative[1].result(timeout=25)
                    except Exception:
                        pre = None
                # a short answer the AI might read differently: what the employee clearly answered still wins
                result = ai_draft(message, company, ar=ar, precomputed=pre, slots=slots, collected=collected)
            if new_invoice:
                result['new_invoice'] = True     # the frontend must not overwrite the previous invoice
            if '_pending_order' in result:
                result = part_lookup.enrich_proposal(result)
                result['confirmation_token'] = PROPOSALS.dumps({'user':user['id'], 'company':user['company_id'],
                    'session':session_id(), 'message':message,
                    'order':result.pop('_pending_order'), 'suggestions':result['suggestions']})
            return done(sign_state(user, result, ar))
        except GeminiUnavailable:
            act("extract", "failed", *INVOICE_PLAN[1][1:], error="AI service busy")
            return err(503, "The AI service is busy right now. Please try again in a moment.")
        except Exception:
            current_app.logger.exception("AI invoice generation failed")
            return err(500, "The AI couldn't prepare this invoice. Please try again or rephrase the repair.")

    @app.post('/api/invoices/confirm-parts')
    def confirm_parts():
        user = require_user('ai.chat')
        if not security.rate_hit("ai_user", "web:%d" % user["id"]):
            return security.too_many()
        data = body()
        try:
            proposal = PROPOSALS.loads(data.get('confirmation_token',''), max_age=900)
        except (BadSignature, TypeError):
            return err(409, 'This suggestion expired. Describe the part again.')
        if proposal['user'] != user['id'] or proposal['company'] != user['company_id'] or proposal['session'] != session_id():
            return err(403, 'This suggestion belongs to another session.')
        selections = data.get('selections')
        if data.get('confirm') is not True or not isinstance(selections,dict):
            return err(409, 'Explicitly select and confirm each suggested part.')
        order = proposal['order']
        for suggestion in proposal['suggestions']:
            selected = selections.get(str(suggestion['index']))
            if isinstance(selected,dict) and selected.get('custom') is True:
                name = text(selected.get('name'),120)
                if not suggestion.get('custom_allowed'):
                    return err(422,'This item cannot be added as a custom line. Describe it again.')
                if not name:
                    return err(422,'Enter the name to display on the invoice for this item.')
                if part_lookup.obvious_non_part(name):
                    return err(422,'This item is outside the garage scope.')
                try:
                    qty = Decimal(str(selected.get('quantity')))
                    price = Decimal(str(selected.get('unit_price')))
                    if not name or not qty.is_finite() or qty != qty.to_integral() or not 0 < qty <= 10000:
                        raise ValueError()
                    if not price.is_finite() or not 0 <= price <= 10000000: raise ValueError()
                    currency = selected.get('currency')
                    if currency not in ('USD','LBP'): raise ValueError()
                except (ValueError,InvalidOperation,TypeError):
                    return err(422,'Custom items require a description, positive whole quantity, nonnegative unit price and USD/LBP currency.')
                order['parts'][suggestion['index']].update(name=name,quantity=int(qty),unit_price=float(price),
                    line_price=None,price_currency=currency,match_type='named',scope='automotive',clarification='',_custom_confirmed=True)
                continue
            if selected not in [x['id'] for x in suggestion['candidates']]:
                return err(422, 'Choose one of the suggested catalog parts for each description.')
            product = get_product_by_id(selected)
            if not product: return err(409, 'The product is no longer available.')
            part = order['parts'][suggestion['index']]
            part.update(name=product['name_en'],match_type='named',clarification='')
        with connect() as db:
            company = company_of(db,user)
        ar = bool(re.search(r'[؀-ۿ]', proposal['message']))
        return jsonify(sign_state(user, ai_draft(proposal['message'],company,confirmed_order=order,ar=ar), ar))

    @app.post("/api/invoices")
    def create():
        user = require_user("invoice.create")
        try:
            with connect() as db:
                company = company_of(db, user)
                payload = clean_payload(body(), company)
                request_key = text(request.headers.get('Idempotency-Key') or body().get('client_request_id'),100)
                digest = sha(json.dumps(payload,sort_keys=True,ensure_ascii=False))
                db.execute("BEGIN IMMEDIATE")
                if request_key:
                    prior = db.execute('SELECT * FROM invoice_create_requests WHERE company_id=? AND user_id=? AND request_key=?',
                                       (user['company_id'],user['id'],request_key)).fetchone()
                    if prior:
                        if prior['digest'] != digest: return err(409,'This save request was already used for different invoice data.')
                        return jsonify(invoice_out(find_invoice(db,user,prior['invoice_id'])))
                seq = db.execute("SELECT COALESCE(MAX(seq),0)+1 FROM web_invoices WHERE company_id=?", (user["company_id"],)).fetchone()[0]
                ident, now = uuid.uuid4().hex, time.time()
                db.execute("INSERT INTO web_invoices(id, company_id, seq, no, created_by, status, payload, created_at, updated_at) "
                           "VALUES (?,?,?,?,?,?,?,?,?)", (ident, user["company_id"], seq, "INV-%04d" % seq, user["id"], "pending",
                                                          json.dumps(payload, ensure_ascii=False), now, now))
                truck_memory.remember(db, user["company_id"], payload["cust"], payload["truck"])
                if request_key:
                    db.execute('INSERT INTO invoice_create_requests VALUES (?,?,?,?,?)',
                               (user['company_id'],user['id'],request_key,digest,ident))
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row)), 201

    @app.put("/api/invoices/<ident>")
    def update(ident):
        user = require_user("invoice.edit")
        try:
            with connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row = find_invoice(db, user, ident)
                if not row:
                    return err(404, "Invoice not found.")
                if row["status"] not in ("draft", "rejected", "pending"):
                    return err(409, "Approved invoices can't be edited. Move the invoice back to Pending first.")
                payload = clean_payload(body(), company_of(db, user))
                db.execute("UPDATE web_invoices SET payload=?, status='pending', updated_at=? WHERE id=?",
                           (json.dumps(payload, ensure_ascii=False), time.time(), ident))
                truck_memory.remember(db, user["company_id"], payload["cust"], payload["truck"])
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row))

    @app.post("/api/invoices/<ident>/submit")
    def submit(ident):
        return move(ident, ("draft", "rejected", "pending"), "pending", "invoice.submit", strict=True)

    @app.post("/api/invoices/<ident>/pending")
    def mark_pending(ident):
        """The employee's Pending button. Moving an approved invoice back needs approval rights."""
        user = require_user("invoice.submit")
        with connect() as db:
            row = find_invoice(db, user, ident)
        if row and row["status"] == "approved":
            return move(ident, ("approved",), "pending", "invoice.approve")
        return move(ident, ("draft", "rejected", "pending"), "pending", "invoice.submit")

    @app.post("/api/invoices/<ident>/reject")
    def reject(ident):
        return move(ident, ("pending",), "rejected", "invoice.reject")

    @app.post("/api/invoices/<ident>/email")
    def email(ident):
        """Sends the approved invoice PDF through the SMTP settings in .env (delivery_providers)."""
        return invoice_services.deliver(ident,'email')

    # ---- frontend pages (same origin as the API)
    @app.get("/")
    def home():
        return redirect("/signin.html")

    @app.get("/<path:filename>")
    def frontend(filename):
        if filename.startswith(("api/", "media/")):
            return err(404, "Not found.")
        target = (FRONTEND / filename).resolve()
        if FRONTEND.resolve() not in target.parents or not target.is_file() or target.suffix == ".md":
            abort(404)
        if target.name.endswith("-results.html") and not session_user():   # internal test reports: staff only
            abort(404)
        resp = send_from_directory(FRONTEND, filename)
        resp.headers["Cache-Control"] = "no-cache"
        return resp


def create_user(username, password, first, last, company_name, phone="+96171123456", role="owner", company_id=None, path=None):
    """Helper for scripts: create a web account (and a company if company_id is None)."""
    with connect(path) as db:
        now = time.time()
        if company_id is None:
            company_id = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                    (company_name, phone, str(DEFAULT_VAT), now)).lastrowid
        db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                   "VALUES (?,?,?,?,?,?,?,?)", (company_id, first, last, username.lower(), hash_password(password), phone, role, now))
        return company_id


def web_pdf(ident):
    """Approved invoice -> final PDF. Pending invoice -> PDF stamped PREVIEW (only with ?preview=1)."""
    user = require_user("invoice.history")
    preview = request.args.get("preview") in ("1", "true")
    with connect() as db:
        row = find_invoice(db, user, ident)
        if not row: return err(404, "Invoice not found.")
        approved = row["status"] == "approved"
        if not approved and not preview:
            return err(409, "Approve this invoice before downloading its final PDF.")
        payload = json.loads(row["payload"])
        if approved:
            # The approved PDF is stored once at approval; every download/print/send uses the same bytes.
            if not has_identity(payload):
                return err(409, "The truck plate number is required before releasing an invoice.")
            approver = db.execute("SELECT username FROM users WHERE id=?",(row['approved_by'],)).fetchone()
            content = invoice_services.store_approved_pdf(db,row,approver['username'] if approver else 'Owner')
        else:
            # Pending: a fresh preview stamped PENDING - PREVIEW (never stored, never sent).
            content = invoice_services.render_pdf(db, row)
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)",
                   (ident, user["username"], "pdf_released" if approved else "pdf_preview", time.time()))
    return send_file(BytesIO(content), mimetype="application/pdf", as_attachment=request.args.get('inline')!='1',
                     download_name=row["no"] + ("" if approved else "-PREVIEW") + ".pdf")
