
from flask import Flask, request, jsonify, current_app, abort
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

from ai_agent import GeminiUnavailable
from invoice_engine import create_invoice
from database import search_products, load_products
import approval_store
from approval_store import save_draft
from workflow_routes import register_workflow
from web_api import register_web, session_user, err_response
import security
from security_config import settings

app = Flask(__name__)
app.json.ensure_ascii = False

# Behind a reverse proxy (TRUSTED_PROXIES=1), trust its X-Forwarded-* headers so HTTPS and client addresses
# are seen correctly. Never enabled by default: anybody could fake those headers.
if settings().trusted_proxies:
    n = settings().trusted_proxies
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=n, x_proto=n, x_host=n)

# Security first: its checks run before every other handler (HTTPS, Origin, size limits, headers, JSON errors).
security.register_security(app)

# The frontend is served by this server (same origin), so no cross-origin access is needed. Extra origins
# (e.g. a separate dev server) can be allowed with CORS_ORIGINS; credentials are never allowed cross-origin.
if settings().origins():
    CORS(app, resources={r"/api/*": {"origins": settings().origins()}}, supports_credentials=False)


def require_login():
    """Who is calling: 'web:<user id>' (cookie session) or 'terminal:<username>' (Bearer token); otherwise 401.
    The identity always comes from the verified session or token, never from the request body."""
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        employee = approval_store.employee(header[7:], current_app.config["INVOICE_DB"])
        if employee:
            return "terminal:" + employee
    user = session_user()
    if not user:
        abort(err_response(401, "Please sign in again."))
    return "web:%d" % user["id"]


# Test whether backend is running
@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "message": "InvoiceFlow AI backend is running"
    })


# Return all garage products (signed-in users only: the catalog includes prices)
@app.get("/api/products")
def get_products():
    require_login()
    return jsonify({
        "products": load_products()
    })


# Search garage products
@app.get("/api/products/search")
def search():
    require_login()
    query = request.args.get("q", "").strip()[:100]

    if not query:
        return jsonify({"products": []})

    return jsonify({
        "products": search_products(query)
    })


# Generate invoice draft with Gemini AI (signed-in users only: it costs AI quota and writes a draft)
@app.post("/api/invoice/draft")
def generate_invoice():
    if not security.rate_hit("ai_user", require_login()):
        return security.too_many()
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Expected a JSON object"
        }), 400

    message = data.get("message")

    if not isinstance(message, str) or not message.strip():
        return jsonify({
            "error": "Message is required"
        }), 400

    if len(message) > 5000:
        return jsonify({
            "error": "Message is too long"
        }), 400

    try:
        invoice = create_invoice(message); invoice.pop("_order", None)
        return jsonify(save_draft(invoice, current_app.config["INVOICE_DB"]))

    except GeminiUnavailable:
        return jsonify({"error": "AI service is temporarily unavailable. Please try again."}), 503

    except Exception:
        app.logger.error("Invoice generation failed")
        return jsonify({
            "error": "Unable to generate invoice draft"
        }), 500


register_workflow(app)
register_web(app)  # web app: accounts, company, invoices, frontend pages
import live_voice
live_voice.register(app)  # Live Voice: short-lived Gemini Live tokens with MA's settings locked in

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False
    )
