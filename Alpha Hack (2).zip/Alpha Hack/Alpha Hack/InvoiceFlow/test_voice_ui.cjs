// Voice recording UI test (mock browser media): WhatsApp-style tap to record, tap to stop, preview, delete or send.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('frontend/js/app.js','utf8');
const html=fs.readFileSync('frontend/index.html','utf8');
const elements={};
const elem=id=>elements[id]||(elements[id]={id,hidden:false,disabled:false,textContent:'',value:'',innerHTML:'',style:{},dataset:{},paused:true,
  classList:{_s:new Set(),add(c){this._s.add(c)},remove(c){this._s.delete(c)},toggle(c,on){on?this._s.add(c):this._s.delete(c)},contains(c){return this._s.has(c)}},
  setAttribute(k,v){this[k]=v},removeAttribute(){},pause(){this.paused=true},load(){},addEventListener(){},getContext(){return {clearRect(){},fillRect(){}}}});
let sent=0,stopped=0,revoked=0,closed=0,clock=0,chunkSize=5,denied=false;
class FakeDate extends Date{static now(){return clock}}
const context={$:elem,window:{addEventListener(){},AudioContext:class {createAnalyser(){return {fftSize:256,frequencyBinCount:8,getByteFrequencyData(){}}}createMediaStreamSource(){return {connect(){}}}close(){closed++}}},
  navigator:{mediaDevices:{async getUserMedia(){if(denied){const e=new Error('no');e.name='NotAllowedError';throw e}return {getTracks(){return [{stop(){stopped++}}]}}}}},
  MediaRecorder:class {constructor(){this.state='inactive'} start(){this.state='recording'}stop(){this.state='inactive';this.ondataavailable({data:new Blob(['v'.repeat(chunkSize)],{type:'audio/webm'})});this.onstop()}},
  Blob,URL:{createObjectURL(){return 'blob:sample'},revokeObjectURL(){revoked++}},Date:FakeDate,setInterval(){return 1},clearInterval(){},requestAnimationFrame(){return 1},Uint8Array,busy:false,transcribe:async()=>sent++,convo:[],lockInput(){}};
vm.createContext(context);
vm.runInContext(src.slice(src.indexOf('/* recording'),src.indexOf('/* ---- app state:')),context);
const rec=async secs=>{await vm.runInContext('start()',context);clock+=secs*1000;vm.runInContext('stop()',context)};
(async()=>{
 // simple controls only: no Pause / Resume buttons anywhere
 assert(!/id="vPause"|id="vResume"/.test(html),'no pause/resume buttons');
 assert(!/pauseVoice|resumeVoice/.test(src),'no pause/resume code');
 // tap -> recording state, mic becomes the stop button
 await vm.runInContext('start()',context);
 assert.equal(elements.vbar.dataset.s,'listening');assert(elements.mic.classList.contains('rec'));assert.equal(elements.mic['aria-label'],'Stop recording');
 clock+=3000;vm.runInContext('stop()',context);
 // stop -> preview, nothing sent
 assert.equal(sent,0);assert.equal(elements.recordingPreview.hidden,false);assert(vm.runInContext('recordedBlob.size>0',context));
 assert.equal(elements.recordingDuration.textContent,'00:03');assert(!elements.mic.classList.contains('rec'));
 // delete -> gone, cannot be sent
 elements.deleteRecording.onclick();await elements.sendRecording.onclick();
 assert.equal(sent,0);assert.equal(elements.recordingPreview.hidden,true);assert.equal(elements.timer.textContent,'00:00');
 assert.equal(revoked,1);assert.equal(stopped,1);assert.equal(closed,1);
 // record again and send explicitly
 await rec(2);assert.equal(sent,0);await elements.sendRecording.onclick();assert.equal(sent,1);
 // too short (<1s) -> no preview
 await rec(0.4);assert.equal(elements.recordingPreview.hidden,true);assert.match(elements.status.textContent,/too short/);
 // empty recording -> no preview
 chunkSize=0;await rec(2);assert.equal(elements.recordingPreview.hidden,true);assert.match(elements.status.textContent,/Nothing was recorded/);chunkSize=5;
 // microphone permission denied -> clear message, no recording
 denied=true;await vm.runInContext('start()',context);assert.match(elements.status.textContent,/permission was denied/);assert.equal(vm.runInContext('rec',context),null);denied=false;
 console.log('PASS: tap to record / tap to stop, preview, no auto-send, delete, explicit send, too-short, empty, mic denied, no pause/resume (mock media).')
})().catch(e=>{console.error(e);process.exitCode=1});
