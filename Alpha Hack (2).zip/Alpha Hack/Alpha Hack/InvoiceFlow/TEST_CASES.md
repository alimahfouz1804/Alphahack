# Software test cases: InvoiceFlow AI

Statuses are real results from the run below. Nothing NOT EXECUTED or BLOCKED is counted as passed.

**Last automated run:** 2026-11-15 01:19 (Asia/Beirut). Environment: Linux test machine, Python 3.13, Node 22; Gemini, speech-to-text, SMTP and WhatsApp mocked; DejaVu font instead of Windows Arial.

## How to run

```
python -m unittest test_cases -v            # TC-01 … TC-30 (TC-01–03 need Node.js)
python -m unittest test_cases test_assistant test_web test_backend test_workflow test_master test_delivery_providers test_suggestions test_invoice_identity test_part_lookup
node test_voice_ui.cjs
python ai_eval/selfcheck.py                  # pipeline self-check (scripted model, NOT an AI result)
python ai_eval/run_eval.py                   # the 60 AI scenarios against the REAL model -> AI_SCENARIOS.md
```

## Summary

| Group | Tests | Passed | Failed | Not executed / blocked |
|---|---|---|---|---|
| TC-01 … TC-30 (+TC-22b) | 31 | 31 | 0 | 0 |
| Other automated suites (17+22+19+13+9+2+4+46+5) | 137 | 137 | 0 | 0 |
| Node voice test | 1 | 1 | 0 | 0 |
| Browser runs (B-01, B-02) | 2 | 2 | 0 | 0 |
| Manual / real external services (M-01 … M-06) | 6 | 0 | 0 | 6 |

Types: **Automated** = runs the real Flask app, SQLite database, PDF and delivery code with the AI model, speech-to-text and providers **mocked**; **Node** = app.js voice logic with a mocked microphone; **Browser** = real Chrome with a synthetic microphone; **Manual / real service** = needs a person, real hardware or real credentials.

## TC-01 … TC-30

| ID | Name | Type | Status |
|---|---|---|---|
| TC-01 | Start and stop voice recording | Automated (Node, app.js with mocked microphone/MediaRecorder) | **PASS** |
| TC-02 | Preview a recorded voice note | Automated (Node, app.js with mocked microphone/MediaRecorder) | **PASS** |
| TC-03 | Delete a recording and record again | Automated (Node, app.js with mocked microphone/MediaRecorder) | **PASS** |
| TC-04 | Submit a valid voice recording to the backend | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-05 | Submit a written request | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-06 | AI agent receives and processes a request | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-07 | Exact catalog item matching | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-08 | Multiple possible catalog matches | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-09 | Unknown item and custom description | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-10 | Custom item not added to the catalog | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-11 | Conversation context across messages | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-12 | Clarification for ambiguous information | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-13 | Missing quantity validation | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-14 | Missing unit price validation | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-15 | Correct line total | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-16 | Correct subtotal and final total | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-17 | Duplicate item handling | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-18 | Employee edits and removes items | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-19 | Invoice cannot be approved while incomplete | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-20 | Explicit employee approval required | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-21 | Existing customer lookup | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-22 | New customer creation | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-23 | Duplicate customer prevention | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-24 | Approved invoice persists after restart | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-25 | Correct PDF generation | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-26 | Invoice appears in Invoice History | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-27 | PDF download is the approved PDF | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-28 | Invoice printing | Automated (unittest, real app + DB, AI mocked) | **PASS** |
| TC-29 | WhatsApp and email delivery: success, failure, retry | Automated (unittest, real app + DB, AI mocked) + mocked SMTP | **PASS** |
| TC-30 | End-to-end workflow | Automated (unittest, real app + DB, AI mocked) | **PASS** |

### TC-01: Start and stop voice recording

| Field | Value |
|---|---|
| Test ID | TC-01 |
| Test name | Start and stop voice recording |
| Type | Automated (Node, app.js with mocked microphone/MediaRecorder) |
| Objective | Recording starts, timer runs, stopping releases the microphone. |
| Preconditions | app.js loaded; microphone mocked. |
| Input / scenario | Mocked MediaRecorder audio. |
| Execution steps | 1. start() 2. stop() |
| Expected result | Recording state set; on stop: mic tracks stopped, AudioContext closed, preview shown. |
| Actual result | Recording started and stopped; tracks/AudioContext released. |
| Status | PASS |
| Notes | test_voice_ui.cjs via test_cases.test_tc01. Real microphone: see M-01. |

### TC-02: Preview a recorded voice note

| Field | Value |
|---|---|
| Test ID | TC-02 |
| Test name | Preview a recorded voice note |
| Type | Automated (Node, app.js with mocked microphone/MediaRecorder) |
| Objective | The employee can listen before sending; nothing is sent automatically. |
| Preconditions | As TC-01. |
| Input / scenario | Mocked recording. |
| Execution steps | 1. Record 2. Stop |
| Expected result | Preview panel visible with duration; transcription NOT called. |
| Actual result | Preview shown; upload count 0. |
| Status | PASS |
| Notes | Also seen in a Chrome run with a synthetic microphone (B-01). |

### TC-03: Delete a recording and record again

| Field | Value |
|---|---|
| Test ID | TC-03 |
| Test name | Delete a recording and record again |
| Type | Automated (Node, app.js with mocked microphone/MediaRecorder) |
| Objective | Delete clears everything; a deleted recording cannot be sent; re-recording works. |
| Preconditions | As TC-01. |
| Input / scenario | Mocked recording. |
| Execution steps | 1. Record, stop 2. Delete 3. Send 4. Record again, Send |
| Expected result | Blob/URL/duration cleared, URL revoked, send after delete does nothing, second recording sent once. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-04: Submit a valid voice recording to the backend

| Field | Value |
|---|---|
| Test ID | TC-04 |
| Test name | Submit a valid voice recording to the backend |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Audio reaches /api/transcribe and the transcript comes back; bad uploads rejected; login required. |
| Preconditions | Signed-in employee. |
| Input / scenario | webm bytes; empty form; 10 MB+1 file; anonymous upload. |
| Execution steps | POST /api/transcribe for each |
| Expected result | 200 + transcript; 400; 413; 401. |
| Actual result | 200 transcript; 400; 413; 401. |
| Status | PASS |
| Notes | Speech-to-text mocked. Found and fixed: upload worked WITHOUT login before (security gap). |

### TC-05: Submit a written request

| Field | Value |
|---|---|
| Test ID | TC-05 |
| Test name | Submit a written request |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Typed text reaches MA unchanged. |
| Preconditions | Signed in. |
| Input / scenario | "Ahmad: 2 oil filters at 25 USD" |
| Execution steps | POST /api/invoices/generate |
| Expected result | Text passed to the extractor; Oil Filter draft returned. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-06: AI agent receives and processes a request

| Field | Value |
|---|---|
| Test ID | TC-06 |
| Test name | AI agent receives and processes a request |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Chat endpoint returns a structured draft with review info. |
| Preconditions | Signed in; model mocked. |
| Input / scenario | Fuel filter + labor. |
| Execution steps | POST /api/invoices/generate |
| Expected result | status draft, lines Fuel Filter + Labor, review object. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-07: Exact catalog item matching

| Field | Value |
|---|---|
| Test ID | TC-07 |
| Test name | Exact catalog item matching |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Arabic name maps to the catalog ID. |
| Preconditions | Catalog products.json. |
| Input / scenario | "فلتر زيت" |
| Execution steps | generate |
| Expected result | catalog_id P003, not custom. |
| Actual result | P003. |
| Status | PASS |
| Notes |  |

### TC-08: Multiple possible catalog matches

| Field | Value |
|---|---|
| Test ID | TC-08 |
| Test name | Multiple possible catalog matches |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Functional description → suggestions to confirm, no invoice yet. |
| Preconditions | Model returns description match. |
| Input / scenario | "makes the truck start" → P008/P010 |
| Execution steps | generate |
| Expected result | No items; candidates P008, P010; confirmation token. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-09: Unknown item and custom description

| Field | Value |
|---|---|
| Test ID | TC-09 |
| Test name | Unknown item and custom description |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | MA asks the display name; employee's name, qty, price become a custom line. |
| Preconditions | Unknown part. |
| Input / scenario | "hose coupling thing", 2 × $8 |
| Execution steps | generate, then confirm-parts with custom name |
| Expected result | Question asks display name; custom line "Hose coupling" $16. |
| Actual result | As expected. |
| Status | PASS |
| Notes | Changed during this work: the employee's own name is accepted (previously only web-search names). |

### TC-10: Custom item not added to the catalog

| Field | Value |
|---|---|
| Test ID | TC-10 |
| Test name | Custom item not added to the catalog |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | products.json unchanged after a custom line is approved. |
| Preconditions | As TC-09. |
| Input / scenario | Custom line approved. |
| Execution steps | Hash catalog before/after approval |
| Expected result | Same hash; not in /api/catalog. |
| Actual result | Same hash. |
| Status | PASS |
| Notes |  |

### TC-11: Conversation context across messages

| Field | Value |
|---|---|
| Test ID | TC-11 |
| Test name | Conversation context across messages |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | All earlier messages reach the model; a new invoice does not inherit the old one. |
| Preconditions | Model mocked. |
| Input / scenario | Brief example: Ahmad / Mercedes brake pad / qty 2 / $35; then "New invoice: customer Samir…" |
| Execution steps | generate with full history |
| Expected result | All 4 messages sent; total $70; new invoice: old customer absent, new_invoice flag. |
| Actual result | As expected. |
| Status | PASS |
| Notes | Found and fixed: a new invoice in the same chat could mix with (and overwrite) the previous one. |

### TC-12: Clarification for ambiguous information

| Field | Value |
|---|---|
| Test ID | TC-12 |
| Test name | Clarification for ambiguous information |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Ambiguous item (engine oil 5L/20L) → question, no draft. |
| Preconditions | Model returns "engine oil". |
| Input / scenario | "engine oil" |
| Execution steps | generate |
| Expected result | No items; a question. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-13: Missing quantity validation

| Field | Value |
|---|---|
| Test ID | TC-13 |
| Test name | Missing quantity validation |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | No count → MA asks how many. |
| Preconditions | Model returns quantity 0. |
| Input / scenario | oil filter, qty missing |
| Execution steps | generate |
| Expected result | No draft; question contains "how many". |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-14: Missing unit price validation

| Field | Value |
|---|---|
| Test ID | TC-14 |
| Test name | Missing unit price validation |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Missing price stays empty (never 0, never catalog price); not ready. |
| Preconditions | Model returns no price. |
| Input / scenario | 2 oil filters, no price |
| Execution steps | generate |
| Expected result | p null, total null, review.missing has unit_price, ready false. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-15: Correct line total

| Field | Value |
|---|---|
| Test ID | TC-15 |
| Test name | Correct line total |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Server line total = q × p with decimals. |
| Preconditions | — |
| Input / scenario | 3 × $12.50 |
| Execution steps | web_api.compute |
| Expected result | $37.50 |
| Actual result | $37.50 |
| Status | PASS |
| Notes |  |

### TC-16: Correct subtotal and final total

| Field | Value |
|---|---|
| Test ID | TC-16 |
| Test name | Correct subtotal and final total |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Total = sum of lines; LBP at 89,500. |
| Preconditions | Saved invoice. |
| Input / scenario | 2×$25 + 1×$35 + labor $30 |
| Execution steps | Save invoice |
| Expected result | $115 / 10,292,500 LBP, rate 89,500. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-17: Duplicate item handling

| Field | Value |
|---|---|
| Test ID | TC-17 |
| Test name | Duplicate item handling |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Same item twice is flagged for review (not silently merged). |
| Preconditions | Model returns two oil filter lines. |
| Input / scenario | 2 lines Oil Filter |
| Execution steps | generate |
| Expected result | review.duplicates = [Oil Filter] |
| Actual result | As expected. |
| Status | PASS |
| Notes | New server-side review check. |

### TC-18: Employee edits and removes items

| Field | Value |
|---|---|
| Test ID | TC-18 |
| Test name | Employee edits and removes items |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Removing a line and changing a quantity recalculates on the server. |
| Preconditions | Saved invoice. |
| Input / scenario | Remove Air Filter; oil filter qty 4 |
| Execution steps | PUT /api/invoices/{id} |
| Expected result | Lines Oil Filter + Labor; total $130. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-19: Invoice cannot be approved while incomplete

| Field | Value |
|---|---|
| Test ID | TC-19 |
| Test name | Invoice cannot be approved while incomplete |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Missing price, or no customer and no truck → approval refused. |
| Preconditions | Saved pending invoices. |
| Input / scenario | p null; empty identity |
| Execution steps | POST approve |
| Expected result | 409 both. |
| Actual result | 409 both. |
| Status | PASS |
| Notes |  |

### TC-20: Explicit employee approval required

| Field | Value |
|---|---|
| Test ID | TC-20 |
| Test name | Explicit employee approval required |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | New invoices are pending; approval needs confirm + current review digest. |
| Preconditions | Saved invoice. |
| Input / scenario | No confirm; stale digest; correct |
| Execution steps | POST approve |
| Expected result | 409, 409, then approved. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-21: Existing customer lookup

| Field | Value |
|---|---|
| Test ID | TC-21 |
| Test name | Existing customer lookup |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Saved customers are returned for selection. |
| Preconditions | Customer saved. |
| Input / scenario | Ahmad Khalil |
| Execution steps | GET /api/customers |
| Expected result | Contains Ahmad Khalil. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-22: New customer creation

| Field | Value |
|---|---|
| Test ID | TC-22 |
| Test name | New customer creation |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Customer with phone/email saved; name required. |
| Preconditions | Signed in. |
| Input / scenario | Samir Haddad +961…; empty name |
| Execution steps | POST /api/customers |
| Expected result | 200 with email; 422 without name. |
| Actual result | As expected. |
| Status | PASS |
| Notes | TC-22b: local numbers (71 234 567, 03 123 456) become +961…: PASS (fixed during this work). |

### TC-23: Duplicate customer prevention

| Field | Value |
|---|---|
| Test ID | TC-23 |
| Test name | Duplicate customer prevention |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Same name (any case/spaces) + same phone = same record; namesakes with other phone stay separate. |
| Preconditions | Signed in. |
| Input / scenario | Ahmad / ' ahmad ' / Ahmad other phone |
| Execution steps | POST /api/customers ×3 |
| Expected result | Same id, same id, different id. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-24: Approved invoice persists after restart

| Field | Value |
|---|---|
| Test ID | TC-24 |
| Test name | Approved invoice persists after restart |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | A separate Python process reads the approved invoice and stored PDF from the DB file. |
| Preconditions | Approved invoice. |
| Input / scenario | — |
| Execution steps | Approve, then read garage DB from a new process |
| Expected result | Same number, status approved, total, PDF sha256. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-25: Correct PDF generation

| Field | Value |
|---|---|
| Test ID | TC-25 |
| Test name | Correct PDF generation |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Pending → preview PDF only; approval stores the final PDF. |
| Preconditions | Saved invoice. |
| Input / scenario | — |
| Execution steps | GET pdf?preview=1; GET pdf; approve |
| Expected result | Preview %PDF; final 409 before approval; stored PDF after. |
| Actual result | As expected. |
| Status | PASS |
| Notes | Visual check of the layout done earlier (rendered PNG). Arabic shaping needs the Windows libraries: M-06. |

### TC-26: Invoice appears in Invoice History

| Field | Value |
|---|---|
| Test ID | TC-26 |
| Test name | Invoice appears in Invoice History |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Approved invoice listed with delivery status. |
| Preconditions | Approved invoice. |
| Input / scenario | — |
| Execution steps | GET /api/invoices |
| Expected result | status approved, delivery {email: not_sent, whatsapp: not_sent}. |
| Actual result | As expected. |
| Status | PASS |
| Notes | Delivery column added to the History page. |

### TC-27: PDF download is the approved PDF

| Field | Value |
|---|---|
| Test ID | TC-27 |
| Test name | PDF download is the approved PDF |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Same bytes every time; other companies and logged-out users cannot download. |
| Preconditions | Approved invoice. |
| Input / scenario | — |
| Execution steps | Download twice; anonymous; other company |
| Expected result | Identical bytes; 401; 404. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

### TC-28: Invoice printing

| Field | Value |
|---|---|
| Test ID | TC-28 |
| Test name | Invoice printing |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Print allowed only after approval; inline PDF; print event recorded honestly. |
| Preconditions | Approved invoice. |
| Input / scenario | — |
| Execution steps | POST print (pending), GET pdf?inline=1, POST print, GET print.html |
| Expected result | 409; inline; {initiated, physical_print_confirmed:false}; page 200. |
| Actual result | As expected. |
| Status | PASS |
| Notes | Real printer dialog: M-03 (NOT EXECUTED). |

### TC-29: WhatsApp and email delivery: success, failure, retry

| Field | Value |
|---|---|
| Test ID | TC-29 |
| Test name | WhatsApp and email delivery: success, failure, retry |
| Type | Automated (unittest, real app + DB, AI mocked) + mocked SMTP |
| Objective | Not configured → failed; provider failure → failed; retry → sent (not 'delivered'); resend must be explicit; same PDF attached; wa.me hand-off recorded as 'opened'. |
| Preconditions | Approved invoice. |
| Input / scenario | — |
| Execution steps | Email/WhatsApp attempts as listed |
| Expected result | failed, failed, failed, sent (delivery_confirmed false), 409 on silent resend, attachment = stored PDF, handoff 'opened'. |
| Actual result | As expected. |
| Status | PASS |
| Notes | No real email/WhatsApp sent: M-04, M-05. |

### TC-30: End-to-end workflow

| Field | Value |
|---|---|
| Test ID | TC-30 |
| Test name | End-to-end workflow |
| Type | Automated (unittest, real app + DB, AI mocked) |
| Objective | Voice → transcript → MA draft → save (double-click safe) → approve → PDF → history → email. |
| Preconditions | Signed in; STT/model/SMTP mocked. |
| Input / scenario | "Ahmad 2 oil filters 25 dollars each, labor 30" |
| Execution steps | Full API sequence |
| Expected result | Ready draft; same invoice on repeated save; approved; PDF; in history; email sent. |
| Actual result | As expected. |
| Status | PASS |
| Notes |  |

## Browser, manual and real-service tests

| ID | Name | Type | Steps | Actual result | Status | Notes |
|---|---|---|---|---|---|---|
| B-01 | Browser run, merged app (Chrome, synthetic microphone) | Automated browser (Playwright + Chrome fake media device), fake AI and fake SMTP | Voice record → pause/resume → stop → preview (not sent) → delete → record → send → draft; pending preview PDF; approve; final PDF downloaded twice (identical); print endpoints; WhatsApp via MA (wa.me link); email via MA with fake SMTP + resend prompt; history date filters; saved customer offered in editor. | All steps behaved as expected; no page errors. | **PASS** | Run 2026-11-15 ~01:02 on the merged app, before the final review-list/history-column/hand-off changes; re-run after those changes listed in B-02. The automatic print dialog crashed the HEADLESS test browser (environment limitation), so print was verified through its endpoints. |
| B-02 | Browser re-run on the final code | Automated browser (as B-01) | Everything in B-01 plus: wa.me hand-off recorded as "opened", History Delivery column (✉ Sent / WA Opened in app), PDF download and Print from History, review checklist ("Oil Filter: unit price missing"). | All steps behaved as expected; no page errors. | **PASS** | Run 2026-11-15 01:22 (Asia/Beirut). Same headless print-dialog limitation as B-01. |
| M-01 | Real microphone in Chrome/Edge | Manual (real device) | On the laptop: allow the mic, record ~5 s in Arabic, stop, listen, delete, record, send. | — | **NOT EXECUTED** | Needs a person at the laptop. Expected: preview plays your voice; after Send the transcript appears as your message. |
| M-02 | Real speech-to-text (Gemini) | Manual / real external service | Record a Lebanese Arabic request and compare the transcript with what was said. | — | **NOT EXECUTED** | Also covered by putting recordings in ai_eval/audio/ and running ai_eval/run_eval.py. |
| M-03 | Real printer | Manual (real device) | Approve an invoice → Print → choose printer, A4, copies → check the paper for clipping/headers. | — | **NOT EXECUTED** | The app can only confirm that printing was started, never the paper. |
| M-04 | Real email (SMTP) | Real external service | Put SMTP settings in .env, send an approved invoice to your own address, open the PDF attachment. | — | **BLOCKED** | No SMTP credentials configured. |
| M-05 | Real WhatsApp | Real external service | (a) Free wa.me: send to your own phone and check the message text. (b) Business API: needs Meta WhatsApp Cloud API credentials. | — | **(a) NOT EXECUTED, (b) BLOCKED** | (b) has no credentials; a normal WhatsApp account has no API access. |
| M-06 | Arabic text in the PDF on Windows | Manual | Approve an invoice with an Arabic item name and open the PDF. | — | **NOT EXECUTED** | The Linux test machine lacks the Arabic shaping library, so Arabic could not be checked visually here. |

## Other existing automated suites (kept, all passing)

| File | Tests | What it covers |
|---|---|---|
| test_assistant.py | 17 | MA intents: invoice questions, open by number, WhatsApp/email commands, never-invented contacts, email + PDF endpoints |
| test_web.py | 22 | Accounts, sessions, CSRF, invoice API, statuses, totals, LBP |
| test_backend.py | 19 | Extraction rules, quantity evidence, LBP conversion, Gemini fallback/retry |
| test_workflow.py | 13 | Legacy terminal workflow, voice upload, approval/PDF |
| test_master.py | 9 | Idempotent save, immutable PDF, customers, rollback on PDF failure, delivery retry |
| test_delivery_providers.py | 2 | SMTP and WhatsApp Cloud API adapters (mocked) |
| test_suggestions.py | 4 | Functional-description suggestions and confirmation guards |
| test_invoice_identity.py | 46 | Customer-or-truck identity rule across the app |
| test_part_lookup.py | 5 | Out-of-scope items, web lookup parsing, custom line rules |
