# Real workshop validation: InvoiceFlow AI (MA)

**Status: 0 of 20 real cases completed. All 20 are PENDING.**

This file is only for **genuine** requests from a real worker doing their real job in the garage.
The 60 scenarios in `AI_SCENARIOS.md` are synthetic test scenarios. They are **not** workshop cases and must never be
copied here or relabelled as real. No case below may be marked completed until it has actually happened and the
worker has reviewed MA's result.

## Why this is separate

- **Software tests** (`TEST_CASES.md`) prove the application works.
- **AI scenarios** (`AI_SCENARIOS.md`) measure MA on requests we wrote ourselves.
- **Real workshop cases** (this file) show whether MA helps a real mechanic with requests nobody prepared in advance.
  This is also the right preparation for judges bringing new, unseen requests: MA has no memorized answers,
  it uses the same rules and catalog for every request.

## Privacy rules

- Use the customer's **first name or initials only** (e.g. "Customer A.K."). Never write full names, phone numbers,
  emails or full plates here. Shorten a plate to its last 2 digits (e.g. "…87").
- Voice notes stay on the garage laptop (do not commit them). Write a short neutral summary of what was said.
- Get the worker's agreement before recording them. Do not record customers.

## How to collect one case (about 5 minutes)

1. When a real job is finished, the worker tells MA what was done, by voice or text, **in their own words**.
   Do not rephrase the request for them and do not coach them.
2. Write the original request below exactly as said or typed (the transcript for voice).
3. Let MA answer. Write down what MA understood, the catalog matches it proposed and every question it asked.
4. The worker answers MA's questions and corrects the draft in the app. Write each correction.
5. The worker reviews the final draft and says whether it is right. Approve only if the worker agrees.
6. Ask the worker for one sentence of feedback ("was it faster than writing it by hand?", "what was wrong?").
7. Fill in every field. Mark **Completed: Yes** only if the final invoice was correct after the worker's review.
   If MA got something wrong, still record the case: failures are the most useful data.

## Mix to aim for across the 20 cases

| Situation | Target | Done |
|---|---|---|
| Real voice notes | at least 6 | 0 |
| Real written descriptions | at least 6 | 0 |
| Spare-parts requests | at least 8 | 0 |
| Repair-service (labor) requests | at least 5 | 0 |
| Unclear or incomplete descriptions / needed clarification | at least 4 | 0 |
| Existing catalog matches | at least 8 | 0 |
| Custom invoice items (not in catalog) | at least 3 | 0 |
| Several items in one invoice | at least 5 | 0 |
| Customer information + invoice prepared to approval | at least 10 | 0 |

## Summary

| Case | Date | Input | Completed | Short note |
|---|---|---|---|---|
| RW-01 | — | — | PENDING | — |
| RW-02 | — | — | PENDING | — |
| RW-03 | — | — | PENDING | — |
| RW-04 | — | — | PENDING | — |
| RW-05 | — | — | PENDING | — |
| RW-06 | — | — | PENDING | — |
| RW-07 | — | — | PENDING | — |
| RW-08 | — | — | PENDING | — |
| RW-09 | — | — | PENDING | — |
| RW-10 | — | — | PENDING | — |
| RW-11 | — | — | PENDING | — |
| RW-12 | — | — | PENDING | — |
| RW-13 | — | — | PENDING | — |
| RW-14 | — | — | PENDING | — |
| RW-15 | — | — | PENDING | — |
| RW-16 | — | — | PENDING | — |
| RW-17 | — | — | PENDING | — |
| RW-18 | — | — | PENDING | — |
| RW-19 | — | — | PENDING | — |
| RW-20 | — | — | PENDING | — |

## Case record template (copy for each case)

### RW-01

| Field | Value |
|---|---|
| Case ID | RW-01 |
| Date | PENDING |
| Worker role | PENDING (e.g. mechanic, workshop owner, front desk) |
| Original request (exact words / transcript) | PENDING |
| Input type | PENDING (Voice / Text / Mixed) |
| AI interpretation (what MA understood) | PENDING |
| Catalog matches proposed | PENDING |
| Clarification questions MA asked | PENDING |
| Employee corrections | PENDING |
| Final invoice draft (items, quantities, prices, total) | PENDING |
| Final result (approved? PDF? sent how?) | PENDING |
| Worker feedback | PENDING |
| Errors or limitations observed | PENDING |
| Completed successfully | PENDING |

RW-02 to RW-20: same table, all PENDING.
