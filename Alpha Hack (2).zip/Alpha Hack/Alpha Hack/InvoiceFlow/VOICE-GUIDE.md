# InvoiceFlow: voice requests / الطلبات الصوتية

Open http://localhost:5000/index.html and refresh with Ctrl+Shift+R after this update.

## الطريقة

1. اضغط New Conversation لما تبدأ فاتورة لزبون جديد.
2. اضغط المايك واحكي بالعربي، بالإنجليزي، أو باللغتين. فيك تذكر اسم الزبون، نمرة الشاحنة، القطع، الكميات، الأسعار، أجرة اليد والملاحظات بنفس التسجيل.
3. اضغط المايك مرة ثانية. التسجيل بيتحوّل لنص، وبعدها التطبيق بيحضّر مسودة تلقائيًا. ما في داعي تضغط Send للصوت. الكتابة بعدها بتستخدم Send.
4. راجع النص والمسودة. إذا بدك تغيّر تفصيل، سجّل التصحيح بنفس المحادثة: «لا، فلتر المازوت واحد بس، والباقي متل ما هو».
5. إذا في تفصيل غير واضح، جاوب على السؤال بنفس المحادثة. ما لازم تعرف الاسم المكتوب بالكاتالوج.
6. راجع الفاتورة واحفظها، ثم ابعتها لموافقة الموظف. لا موافقة ولا إرسال تلقائي.

مثال:

> بدي فاتورة للزبون التجريبي، نمرة الشاحنة DEMO001. غيرنا فلتر الهواء عدد اتنين، حق الواحد خمسة وثلاثين دولار، وفلتر مازوت واحد حقه تلاتين دولار. أجرة الإيد تلاتين دولار. وحط ملاحظة نفحص إذا في تهريب الأسبوع الجاي.

المتوقّع: 2 × 35 + 1 × 30 + 30 = **130 USD / 11,700,000 LBP**.

السعر اللي ما ذكرته بيضل فارغ (—). إذا قلت «التنين سوا حقن 70 دولار»، التطبيق بيحسب سعر الوحدة من المجموع المذكور، مش من سعر الكاتالوج. عبارة «حق الواحد» تعني سعر الوحدة.

## English

Tap the microphone, describe the complete repair, then tap again to stop. The app transcribes the recording and automatically prepares a draft. Review the transcript and invoice. Speak a correction in the same conversation to update the order while retaining the other details. Start a New Conversation for a different customer/order.

The catalog supplies product identities and spelling context, not automatic prices. Missing prices remain blank. Unclear products or variants prompt a focused question. For a stated combined line price, the server derives the unit price from the stated quantity. Employee approval remains required before releasing the final invoice.

## Verification

- 52 backend/workflow/web regression tests passed.
- Live Gemini checks passed for a long Lebanese-Arabic description, follow-up correction, combined line price, unclear size clarification and its correction.
- A synthetic English WAV was successfully transcribed and converted to a USD 110 invoice.
- Browser checks verified the Arabic draft, preserved customer/plate/notes, and a correction changing USD 160 to USD 130.
- JavaScript checks verified automatic draft generation after transcription, disabled input while processing, retained correction history, and recovery after an AI error.

Arabic interpretation was tested using conversational text, not the user's original audio (which was not attached). The original recording should still be tried through the updated microphone flow.

Changed application files: ai_agent.py, voice_agent.py, database.py, invoice_engine.py, web_api.py, frontend/js/app.js and frontend/index.html. Added regression coverage in test_backend.py and test_web.py. Existing catalog data, API key, accounts and production invoices were preserved.
