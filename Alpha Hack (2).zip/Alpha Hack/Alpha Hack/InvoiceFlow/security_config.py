"""Typed security settings read from the environment / .env (never sent to the browser).

Every value has a safe default for running InvoiceFlow on one laptop. For an online deployment set at least
FORCE_HTTPS=true and, when a reverse proxy terminates TLS, TRUSTED_PROXIES=1. See .env.example.
"""
from functools import lru_cache
from pathlib import Path

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class SecuritySettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=Path(__file__).parent / ".env", env_file_encoding="utf-8", extra="ignore")

    # ---- secrets (SecretStr: never printed in logs or reprs)
    gemini_api_key: SecretStr = SecretStr("")

    # ---- transport
    force_https: bool = False          # redirect http -> https, HSTS, Secure cookies
    cookie_secure: bool | None = None  # None = Secure whenever the request arrived over HTTPS
    trusted_proxies: int = Field(0, ge=0, le=5)   # how many reverse proxies set X-Forwarded-* (0 = none)
    cors_origins: str = ""             # comma-separated extra origins; empty = same origin only

    # ---- sessions (cookie equivalent of short-lived access tokens + refresh rotation)
    session_rotate_seconds: int = Field(15 * 60, ge=60, le=3600)       # token is replaced at least this often
    session_rotate_grace_seconds: int = Field(60, ge=5, le=300)         # parallel requests may still use the old one
    session_idle_seconds: int = Field(2 * 3600, ge=300)                 # signed out after this much inactivity
    session_seconds: int = Field(12 * 3600, ge=600)                     # absolute lifetime (browser session)
    remember_seconds: int = Field(30 * 24 * 3600, ge=3600)              # absolute lifetime with "remember me"
    remember_idle_seconds: int = Field(7 * 24 * 3600, ge=3600)

    # ---- request limits
    max_json_bytes: int = Field(256 * 1024, ge=1024)
    max_history_turns: int = Field(40, ge=2, le=200)

    # ---- rate limits: "count/seconds"
    rate_login_account: str = "5/300"       # failed sign-ins per username
    rate_login_ip: str = "20/300"           # failed sign-ins per address
    rate_register_ip: str = "10/3600"
    rate_username_check_ip: str = "60/60"
    rate_ai_user: str = "40/60"             # MA messages / voice turns per user
    rate_voice_token_user: str = "20/600"   # Live Voice sessions started per user
    rate_send_user: str = "20/600"          # e-mail / WhatsApp deliveries per user

    def limit(self, name):
        count, seconds = getattr(self, "rate_" + name).split("/")
        return int(count), int(seconds)

    def origins(self):
        return [o.strip().rstrip("/") for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def settings() -> SecuritySettings:
    return SecuritySettings()
