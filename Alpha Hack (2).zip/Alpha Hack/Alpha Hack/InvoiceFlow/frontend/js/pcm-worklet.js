/* Microphone -> 16 kHz, 16-bit little-endian PCM in ~40 ms chunks (the Gemini Live input format).
   Runs in the audio thread; the input arrives at the device rate (usually 44.1 or 48 kHz) and is downsampled here,
   which works in every browser (some refuse to mix AudioContexts with different sample rates). */
class PcmRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / 16000;
    this.pos = 0;
    this.out = new Int16Array(640);
    this.n = 0;
    this.muted = false;
    this.port.onmessage = (e) => { if (e.data && 'muted' in e.data) this.muted = !!e.data.muted; };
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch || this.muted) return true;
    // decimate to 16 kHz; each finished 40 ms chunk is posted with its RMS level (used for barge-in and the orb)
    for (let i = 0; i < ch.length; i++) {
      this.pos += 1;
      if (this.pos >= this.ratio) {
        this.pos -= this.ratio;
        const s = Math.max(-1, Math.min(1, ch[i]));
        this.out[this.n++] = s < 0 ? s * 0x8000 : s * 0x7fff;
        if (this.n === this.out.length) {
          let sum = 0;
          for (let k = 0; k < this.out.length; k++) { const v = this.out[k] / 32768; sum += v * v; }
          this.port.postMessage({ pcm: this.out.buffer.slice(0), level: Math.sqrt(sum / this.out.length) });
          this.n = 0;
        }
      }
    }
    return true;
  }
}
registerProcessor('pcm-recorder', PcmRecorder);
