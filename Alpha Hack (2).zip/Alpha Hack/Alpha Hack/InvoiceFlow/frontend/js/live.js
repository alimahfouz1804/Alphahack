/* MA Live Voice: a real-time spoken conversation through the Gemini Live API (browser side).

   The server issues a short-lived, single-use token with MA's instructions and tool locked in (POST /api/live/token);
   the Gemini API key never reaches the browser. This file only moves audio and events:
     microphone -> 16 kHz PCM -> WebSocket            (Gemini decides when the employee has finished speaking)
     WebSocket  -> 24 kHz PCM -> speakers              (stopped at once when the employee interrupts)
     toolCall   -> opts.onTool(name, args)             (the app runs it through the normal, authorised MA pipeline)
   States reported through opts.onState: connecting, listening, hearing, thinking, speaking, reconnecting, muted. */
(function () {
  'use strict';
  var IN_MIME = 'audio/pcm;rate=16000', OUT_RATE = 24000;
  var BARGE_LEVEL = 0.06, BARGE_CHUNKS = 4;          // ~160 ms of clear speech over MA's voice interrupts it
  var MAX_RETRIES = 5, PREROLL_CHUNKS = 8;
  var ANSWER_WAIT_MS = 12000;                         // after a tool result, "Thinking" until MA starts answering

  function toB64(buf) {
    var bytes = new Uint8Array(buf), s = '', step = 0x8000;
    for (var i = 0; i < bytes.length; i += step) s += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
    return btoa(s);
  }
  function fromB64(b64) {
    var s = atob(b64), out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out.buffer;
  }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function LiveSession(opts) {
    this.o = opts; this.ws = null; this.ready = false; this.ended = false; this.handle = null; this.retries = 0;
    this.muted = false; this.state = ''; this.sources = []; this.nextTime = 0; this.turnDone = true;
    this.userText = ''; this.modelText = ''; this.calls = {}; this.cancelled = {}; this.loud = 0; this.barge = false;
  }

  LiveSession.prototype.setState = function (s) {
    if (this.muted && (s === 'listening' || s === 'hearing')) s = 'muted';
    if (s === this.state) return;
    this.state = s; if (this.o.onState) this.o.onState(s);
  };

  /* microphone + audio contexts, then the first connection. Throws {kind:'mic'|'unsupported'|'unavailable', message}. */
  LiveSession.prototype.start = async function () {
    if (!LiveSession.supported()) throw { kind: 'unsupported', message: 'This browser does not support Live Voice.' };
    this.setState('connecting');
    var self = this;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
    } catch (e) {
      throw { kind: 'mic', name: e && e.name, message: e && e.name === 'NotAllowedError' ? 'Microphone permission was denied.' : 'No microphone is available.' };
    }
    try {
      this.inCtx = new (window.AudioContext || window.webkitAudioContext)();
      await this.inCtx.audioWorklet.addModule('js/pcm-worklet.js');
      this.src = this.inCtx.createMediaStreamSource(this.stream);
      this.node = new AudioWorkletNode(this.inCtx, 'pcm-recorder');
      this.sink = this.inCtx.createGain(); this.sink.gain.value = 0;      // keeps the worklet running, plays nothing
      this.src.connect(this.node); this.node.connect(this.sink); this.sink.connect(this.inCtx.destination);
      this.node.port.onmessage = function (e) { if (e.data && e.data.pcm) self.onMic(e.data.pcm, e.data.level || 0); };
      this.outCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: OUT_RATE });
    } catch (e) {
      this.release();
      throw { kind: 'unsupported', message: 'Audio could not be started in this browser.' };
    }
    try { await this.connect(); }
    catch (e) { this.release(); throw e; }
  };

  LiveSession.prototype.connect = async function () {
    var self = this, t = await this.o.getToken();      // throws {kind:'unavailable'} when the server has no Live Voice
    if (this.ended) return;
    this.ready = false;
    var ws = new WebSocket(t.url + '?access_token=' + encodeURIComponent(t.token));
    this.ws = ws;
    await new Promise(function (resolve, reject) {
      var opened = false, timer = setTimeout(function () { if (!opened) { try { ws.close(); } catch (e) {} reject({ kind: 'network', message: 'Could not reach the voice service.' }); } }, 10000);
      ws.onopen = function () {
        opened = true; clearTimeout(timer);
        var setup = Object.assign({}, t.setup, { sessionResumption: self.handle ? { handle: self.handle } : {} });
        ws.send(JSON.stringify({ setup: setup }));
        resolve();
      };
      ws.onerror = function () { if (!opened) { clearTimeout(timer); reject({ kind: 'network', message: 'Could not reach the voice service.' }); } };
    });
    ws.onmessage = function (e) { self.receive(e.data); };
    ws.onclose = function (e) { if (self.ws === ws && !self.ended) self.reconnect(e && e.code === 1008 ? 'policy' : 'closed'); };
  };

  LiveSession.prototype.reconnect = async function (why) {
    if (this.ended || this.reconnecting) return;
    this.reconnecting = true; this.ready = false;
    var old = this.ws; this.ws = null;
    if (old) { old.onclose = old.onmessage = old.onerror = null; try { old.close(); } catch (e) {} }
    this.stopPlayback(); this.flushUser(); this.flushModel();
    while (!this.ended && this.retries < MAX_RETRIES) {
      this.retries++; this.setState('reconnecting');
      await wait(Math.min(5000, 600 * this.retries));
      if (!navigator.onLine) continue;
      try { await this.connect(); this.reconnecting = false; return; }
      catch (e) { if (e && e.kind === 'unavailable') break; }
    }
    this.reconnecting = false;
    if (!this.ended) { if (this.o.onError) this.o.onError('network', 'The connection to MA was lost.'); this.end('network'); }
  };

  LiveSession.prototype.send = function (msg) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(msg));
  };

  /* microphone chunk. While MA is speaking, the speaker's sound must not interrupt it: chunks are held back unless
     the employee clearly talks over MA (barge-in), which stops MA's voice at once. */
  LiveSession.prototype.onMic = function (pcm, level) {
    if (this.o.onLevel) this.o.onLevel(level);
    if (!this.ready || this.muted) return;
    if (this.state === 'speaking' && !this.barge) {
      // keep the last ~320 ms, so the first word of an interruption is not lost when it is finally sent
      this.preroll = (this.preroll || []).concat([pcm]).slice(-PREROLL_CHUNKS);
      this.loud = level > BARGE_LEVEL ? this.loud + 1 : 0;
      if (this.loud < BARGE_CHUNKS) return;
      this.barge = true; this.stopPlayback(); this.setState('hearing');
      var held = this.preroll; this.preroll = [];
      held.forEach(function (c) { this.send({ realtimeInput: { audio: { data: toB64(c), mimeType: IN_MIME } } }); }, this);
      return;
    }
    this.preroll = [];
    this.send({ realtimeInput: { audio: { data: toB64(pcm), mimeType: IN_MIME } } });
  };

  LiveSession.prototype.receive = async function (data) {
    var m;
    try { m = JSON.parse(typeof data === 'string' ? data : await data.text()); } catch (e) { return; }
    if (m.setupComplete) { this.ready = true; this.retries = 0; this.setState('listening'); if (this.o.onReady) this.o.onReady(); }
    if (m.sessionResumptionUpdate && m.sessionResumptionUpdate.resumable && m.sessionResumptionUpdate.newHandle) this.handle = m.sessionResumptionUpdate.newHandle;
    if (m.goAway) { this.reconnect('goaway'); return; }                          // the server will close soon: move now
    if (m.toolCallCancellation && m.toolCallCancellation.ids) m.toolCallCancellation.ids.forEach(function (id) { this.cancelled[id] = true; }, this);
    if (m.toolCall) this.toolCall(m.toolCall);
    var sc = m.serverContent;
    if (!sc) return;
    if (sc.interrupted) { this.stopPlayback(); this.flushModel(); this.setState('hearing'); }
    if (sc.inputTranscription && sc.inputTranscription.text) {
      this.userText += sc.inputTranscription.text;
      if (this.o.onUser) this.o.onUser(this.userText.trim(), false);
      if (this.state !== 'speaking') this.setState('hearing');
    }
    if (sc.outputTranscription && sc.outputTranscription.text) {
      this.flushUser();
      this.modelText += sc.outputTranscription.text;
      if (this.o.onModel) this.o.onModel(this.modelText.trim(), false);
    }
    if (sc.modelTurn && sc.modelTurn.parts) {
      this.flushUser(); this.turnDone = false;
      sc.modelTurn.parts.forEach(function (p) { if (p.inlineData && /^audio\//.test(p.inlineData.mimeType || '')) this.play(p.inlineData.data); }, this);
    }
    if (sc.turnComplete) {
      this.flushUser(); this.flushModel(); this.turnDone = true; this.barge = false;
      // the turn that only carried a tool call ends before the spoken answer: keep showing "Thinking" until it starts
      if (!this.sources.length && !(this.awaiting && Date.now() - this.awaiting < ANSWER_WAIT_MS)) this.setState('listening');
    }
  };

  /* each call id is answered exactly once, even if the server repeats it after a reconnect */
  LiveSession.prototype.toolCall = async function (tc) {
    this.flushUser(); this.setState('thinking');
    var self = this, mark = this.awaiting = Date.now();
    setTimeout(function () { if (self.awaiting === mark && !self.ended) { self.awaiting = 0; if (self.state === 'thinking' && !self.sources.length) self.setState('listening'); } }, ANSWER_WAIT_MS);
    var calls = (tc.functionCalls || []).filter(function (fc) { return fc.id && !this.calls[fc.id]; }, this);
    for (var i = 0; i < calls.length; i++) {
      var fc = calls[i]; this.calls[fc.id] = true;
      var result;
      try { result = await this.o.onTool(fc.name, fc.args || {}); }
      catch (e) { result = { error: (e && e.message) || 'The request failed.' }; }
      if (this.cancelled[fc.id] || this.ended) continue;
      this.send({ toolResponse: { functionResponses: [{ id: fc.id, name: fc.name, response: result }] } });
    }
  };

  LiveSession.prototype.flushUser = function () {
    var t = this.userText.trim(); this.userText = '';
    if (t && this.o.onUser) this.o.onUser(t, true);
  };
  LiveSession.prototype.flushModel = function () {
    var t = this.modelText.trim(); this.modelText = '';
    if (t && this.o.onModel) this.o.onModel(t, true);
  };

  LiveSession.prototype.play = function (b64) {
    var ctx = this.outCtx; if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();
    var pcm = new Int16Array(fromB64(b64)), f = new Float32Array(pcm.length);
    for (var i = 0; i < pcm.length; i++) f[i] = pcm[i] / 32768;
    var buf = ctx.createBuffer(1, f.length, OUT_RATE); buf.copyToChannel(f, 0);
    var src = ctx.createBufferSource(), self = this; src.buffer = buf; src.connect(ctx.destination);
    var at = Math.max(ctx.currentTime + 0.02, this.nextTime);
    src.start(at); this.nextTime = at + buf.duration; this.sources.push(src); this.awaiting = 0;
    this.setState('speaking');
    src.onended = function () {
      self.sources = self.sources.filter(function (s) { return s !== src; });
      if (!self.sources.length && self.turnDone && self.state === 'speaking') { self.barge = false; self.setState('listening'); }
    };
  };

  LiveSession.prototype.stopPlayback = function () {
    this.sources.forEach(function (s) { s.onended = null; try { s.stop(); } catch (e) {} });
    this.sources = []; this.nextTime = 0;
  };

  LiveSession.prototype.setMuted = function (on) {
    this.muted = !!on;
    if (this.node) this.node.port.postMessage({ muted: this.muted });
    if (this.muted) { this.send({ realtimeInput: { audioStreamEnd: true } }); this.setState('muted'); }
    else this.setState(this.sources.length ? 'speaking' : 'listening');
  };

  /* stop everything and release the microphone, audio devices and the connection */
  LiveSession.prototype.release = function () {
    this.stopPlayback();
    if (this.node) { this.node.port.onmessage = null; try { this.node.disconnect(); } catch (e) {} }
    if (this.src) { try { this.src.disconnect(); } catch (e) {} }
    if (this.stream) this.stream.getTracks().forEach(function (t) { t.stop(); });
    [this.inCtx, this.outCtx].forEach(function (c) { if (c && c.state !== 'closed') { try { c.close(); } catch (e) {} } });
    this.node = this.src = this.stream = this.inCtx = this.outCtx = this.sink = null;
  };

  LiveSession.prototype.end = function (why) {
    if (this.ended) return;
    this.ended = true; this.flushUser(); this.flushModel();
    var ws = this.ws; this.ws = null;
    if (ws) { ws.onclose = ws.onmessage = ws.onerror = null; try { ws.close(1000); } catch (e) {} }
    this.release(); this.setState('ended');
    if (this.o.onClose) this.o.onClose(why || 'user');
  };

  /* is everything released? (used by the tests) */
  LiveSession.prototype.released = function () {
    return !this.stream && !this.inCtx && !this.outCtx && !this.ws;
  };

  LiveSession.supported = function () {
    return !!(window.WebSocket && window.AudioWorkletNode && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  };

  window.MALive = { LiveSession: LiveSession };
})();
