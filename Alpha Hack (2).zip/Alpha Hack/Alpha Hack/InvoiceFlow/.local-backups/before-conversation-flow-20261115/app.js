
/* The workspace only starts after the backend confirms the session (GET /api/auth/me).
   No session -> Auth.requireUser() sends the visitor to signin.html. */
Auth.requireUser().then(function(USER){
document.body.classList.remove('auth-pending');
var $=function(i){return document.getElementById(i)};
/* clock */
function tick(){var d=new Date();$('clock').textContent=d.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'})+' · '+d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}
tick();setInterval(tick,30000);
/* mobile menu */
function setMenu(o){document.body.classList.toggle('menu',o);$('menuBtn').setAttribute('aria-expanded',o)}
$('menuBtn').setAttribute('aria-expanded','false');
$('menuBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('scrim').onclick=function(){setMenu(false)};
document.addEventListener('click',function(e){if(document.body.classList.contains('menu')&&!e.target.closest('nav'))setMenu(false)});
document.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});
/* intro: once per session, skippable, reduced-motion aware */
var intro=$('intro'),seen=false;
try{seen=sessionStorage.getItem('ifIntro')==='1'}catch(e){}
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function finish(){document.body.classList.add('ready');intro.classList.add('done');try{sessionStorage.setItem('ifIntro','1')}catch(e){}setTimeout(function(){intro.style.display='none'},700)}
if(seen||reduce){intro.style.display='none';document.body.classList.add('ready')}
else{var t1=setTimeout(function(){intro.classList.add('open')},500),t2=setTimeout(finish,2500);
$('skip').onclick=function(){clearTimeout(t1);clearTimeout(t2);intro.style.display='none';document.body.classList.add('ready');try{sessionStorage.setItem('ifIntro','1')}catch(e){}}}
/* recording: WhatsApp-style. Tap the mic to record, tap it again to stop. The recording then waits in a
   preview where you can listen, delete it, or send it. Nothing is sent until you press Send. */
var mic=$('mic'),st=$('status'),rec=null,chunks=[],stream=null,ac=null,an=null,raf=0,t0=0,ti=0,url=null;
var cv=$('wave'),cx=cv.getContext('2d');
function say(m){st.textContent=m}
function fmt(s){s=Math.max(0,Math.floor(s));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function draw(){
 var w=cv.width,h=cv.height;cx.clearRect(0,0,w,h);
 if(an){var d=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(d);var n=40,bw=w/n;
  for(var i=0;i<n;i++){var v=d[Math.floor(i*d.length/n/2)]/255,bh=Math.max(3,v*h);cx.fillStyle='#f87171';cx.fillRect(i*bw+1,(h-bh)/2,bw-3,bh)}
  raf=requestAnimationFrame(draw)}
 else raf=0}
var discard=false,runId=0,voiceTurn=false,speaking=false,inflight=null,lastArabic=false,recFailed=false;
var recordedBlob=null,startingRecording=false,recDur=0;
function rid(){try{return crypto.randomUUID()}catch(e){return Date.now().toString(36)+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)}}
function refreshIcons(){if(window.lucide)lucide.createIcons()}
var VL={listening:['Recording','عم سجّل'],thinking:['MA is thinking…','MA عم يفكّر…'],speaking:['MA is speaking…','MA عم يحكي…']};
function vstate(s){var vb=$('vbar');vb.hidden=!s;vb.dataset.s=s||'';
 $('vText').textContent=s?VL[s][0]+' / '+VL[s][1]:'';
 var stopBtn=$('vStop');stopBtn.hidden=!(s==='thinking'||s==='speaking');
 $('vStopLabel').textContent=s==='speaking'?'Stop voice / وقّف الصوت':'Cancel / إلغاء';
 $('timer').hidden=$('wave').hidden=s!=='listening';
 $('aiState').textContent=s?VL[s][0]:'Ready'}
function setMic(on){mic.classList.toggle('rec',on);mic.setAttribute('aria-label',on?'Stop recording':'Start recording');mic.title=on?'Tap to stop recording':'Tap to record';
 mic.innerHTML='<i data-lucide="'+(on?'square':'mic')+'"></i>';refreshIcons()}
async function start(){
 if(rec||busy||startingRecording)return;
 stopSpeaking();clearRecording();startingRecording=true;mic.disabled=true;say('Allow microphone access to start recording. اسمح باستعمال المايك لبدء التسجيل.');
 try{stream=await navigator.mediaDevices.getUserMedia({audio:true})}
 catch(e){startingRecording=false;mic.disabled=false;say(e&&e.name==='NotAllowedError'?'Microphone permission was denied. Allow it in the browser, or type instead. المايك مش مسموح.':'Microphone not available. You can type the repair details instead. المايك مش متوفر، فيك تكتب.');return}
 startingRecording=false;mic.disabled=false;
 try{ac=new (window.AudioContext||window.webkitAudioContext)();an=ac.createAnalyser();an.fftSize=256;ac.createMediaStreamSource(stream).connect(an);
  rec=new MediaRecorder(stream);chunks=[];recFailed=false;
  rec.ondataavailable=function(e){if(e.data&&e.data.size)chunks.push(e.data)};rec.onstop=onStop;
  rec.onerror=function(){recFailed=true;if(rec&&rec.state!=='inactive')rec.stop()};
  stream.getTracks().forEach(function(t){t.onended=function(){if(rec&&rec.state!=='inactive'){recFailed=true;rec.stop()}}});
  rec.start()}
 catch(e){say('Recording is not supported in this browser. Please type instead.');cleanup();rec=null;return}
 discard=false;voiceTurn=true;recDur=0;setMic(true);$('gen').disabled=true;
 t0=Date.now();$('timer').textContent='00:00';ti=setInterval(function(){$('timer').textContent=fmt((Date.now()-t0)/1000)},250);
 vstate('listening');if(!raf)draw();say('Speak now. Tap the mic again to stop. احكي هلّق، واضغط المايك لتوقّف.')}
function cleanup(){clearInterval(ti);if(stream)stream.getTracks().forEach(function(t){t.onended=null;t.stop()});if(ac)ac.close();an=null;ac=null;stream=null}
function stop(){if(rec&&rec.state!=='inactive'){recDur=(Date.now()-t0)/1000;rec.stop()}}
function onStop(){
 cleanup();rec=null;setMic(false);$('gen').disabled=busy;vstate('');
 if(discard){discard=false;chunks=[];return}
 var blob=new Blob(chunks,{type:chunks[0]&&chunks[0].type||'audio/webm'});chunks=[];
 if(recFailed){recFailed=false;say('Recording stopped because of a microphone problem. Please try again. صار مشكلة بالمايك، جرّب مرة تانية.');return}
 if(!blob.size){say('Nothing was recorded. Check your microphone and try again. ما انسجل شي.');return}
 if(recDur<1){say('That recording was too short. Tap the mic and speak a little longer. التسجيل قصير كتير.');return}
 recordedBlob=blob;if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(blob);
 $('play').src=url;$('recordingDuration').textContent=fmt(recDur);$('rpPos').textContent='00:00';$('rpSeek').value=0;$('recordingPreview').hidden=false;
 say('Listen if you like, then send it or delete it. فيك تسمعو، وبعدين تبعتو أو تحذفو.')}
/* preview player: play/pause, position, seek (duration comes from the recording time, which is reliable) */
function setPlayIcon(playing){var b=$('playRecording');b.innerHTML='<i data-lucide="'+(playing?'pause':'play')+'"></i>';b.setAttribute('aria-label',playing?'Pause recording':'Play recording');refreshIcons()}
$('playRecording').onclick=function(){var a=$('play');if(!recordedBlob)return;stopSpeaking();if(a.paused){var p=a.play();if(p&&p.catch)p.catch(function(){say('This browser cannot play the recording, but you can still send it.')})}else a.pause()};
$('play').onplay=function(){setPlayIcon(true)};$('play').onpause=function(){setPlayIcon(false)};
$('play').onended=function(){setPlayIcon(false);$('rpSeek').value=0;$('rpPos').textContent='00:00'};
$('play').ontimeupdate=function(){var a=$('play');if(recDur>0){$('rpSeek').value=Math.min(1000,Math.round(a.currentTime/recDur*1000));$('rpPos').textContent=fmt(a.currentTime)}};
$('rpSeek').oninput=function(){var a=$('play');if(recDur>0){try{a.currentTime=$('rpSeek').value/1000*recDur}catch(e){}}};
function clearRecording(){var a=$('play');a.pause();a.removeAttribute('src');a.load();if(url)URL.revokeObjectURL(url);url=null;recordedBlob=null;chunks=[];$('timer').textContent='00:00';$('recordingDuration').textContent='';$('recordingPreview').hidden=true}
$('deleteRecording').onclick=function(){if(!busy){clearRecording();say('Recording deleted. التسجيل انحذف.')}};
$('sendRecording').onclick=async function(){if(!busy&&recordedBlob){$('play').pause();await transcribe(recordedBlob)}};
window.addEventListener('beforeunload',function(){cleanup();if(url)URL.revokeObjectURL(url)});

/* MA's voice: one fixed voice, chosen once and remembered on this device (browser speech, no extra cost).
   A multilingual voice (e.g. Microsoft "…Multilingual (Natural)" in Edge) is used for both English and
   Arabic so MA always sounds the same; otherwise the most natural voice for each language is kept. */
var voiceOn=true;try{voiceOn=localStorage.getItem('ma-voice-on')!=='0'}catch(e){}
var speakQueue=[],voicesReady=false,afterSpeech=null,spokenNow='';
function savedVoice(key,v){try{if(v)localStorage.setItem('ma-voice-'+key,v.name);return localStorage.getItem('ma-voice-'+key)}catch(e){return null}}
function rankVoice(v,ar){var n=v.name+' '+v.lang,s=0;
 if(/natural|neural/i.test(n))s+=50;if(/online/i.test(n))s+=10;if(/google/i.test(n))s+=8;
 if(ar){if(/ar-LB/i.test(v.lang))s+=30;else if(/ar-(SY|JO|PS)/i.test(v.lang))s+=15}else{if(/en-US/i.test(v.lang))s+=12;if(/aria|jenny|ava|emma|andrew|samantha/i.test(n))s+=6}
 return s}
function pickVoice(ar){
 if(!window.speechSynthesis)return null;var all=speechSynthesis.getVoices()||[];if(!all.length)return null;
 var key=ar?'ar':'en',name=savedVoice(key),keep=name&&all.find(function(v){return v.name===name});if(keep)return keep;
 var multi=all.filter(function(v){return /multilingual/i.test(v.name)}).sort(function(a,b){return rankVoice(b,false)-rankVoice(a,false)})[0];
 var own=all.filter(function(v){return (ar?/^ar/i:/^en/i).test(v.lang)}).sort(function(a,b){return rankVoice(b,ar)-rankVoice(a,ar)});
 var chosen=multi||own[0]||null;if(voicesReady)savedVoice(key,chosen);return chosen}
/* the choice is only remembered once the browser has finished loading its voice list (Chrome adds its better voices a moment later) */
if(window.speechSynthesis&&speechSynthesis.getVoices){voicesReady=(speechSynthesis.getVoices()||[]).length>0;if('onvoiceschanged' in speechSynthesis)speechSynthesis.onvoiceschanged=function(){voicesReady=true}}
function stopSpeaking(){speakQueue=[];if(window.speechSynthesis)speechSynthesis.cancel();if(speaking){speaking=false;vstate('')}}
/* MA is written "MA" everywhere but always pronounced as its letters: "Em Ay" / «إم إيه» (never "ma" / «ما») */
function sayName(t,ar){return t.replace(/(^|[^A-Za-z])MA(?=$|[^A-Za-z])/g,function(m,pre){return pre+(ar?'إم إيه':'Em Ay')})}
function speechText(t,ar){return sayName(speechLines(t,ar),ar)}
function speechLines(t,ar){
 var lines=String(t).split('\n').filter(function(l){return l.trim()}),pick=lines.filter(function(l){return /[؀-ۿ]/.test(l)===ar});
 return (pick.length?pick:lines).join('. ').replace(/[•✔\u2022\u2714]/g,'').replace(/https?:\/\/\S+/g,'').replace(/\s+/g,' ').trim()}
/* long answers are read sentence by sentence (browsers cut off long single utterances) */
function speakNext(){
 var part=speakQueue.shift();if(!part){speaking=false;vstate('');if(afterSpeech)afterSpeech();return}
 var u=new SpeechSynthesisUtterance(part.text);u.lang=part.ar?'ar-LB':'en-US';var v=pickVoice(part.ar);if(v){u.voice=v;u.lang=/multilingual/i.test(v.name)?(part.ar?'ar-LB':'en-US'):v.lang}
 u.rate=1;u.pitch=1;u.onend=function(){if(speaking)speakNext()};u.onerror=function(){if(speaking){speaking=false;speakQueue=[];vstate('');if(afterSpeech)afterSpeech()}};
 speechSynthesis.speak(u)}
/* MA answers aloud after you speak to him (if MA voice is on); any answer can also be replayed with its speaker button */
function speak(t,force,ar){
 if(!t||!window.speechSynthesis||!window.SpeechSynthesisUtterance)return;
 if(!force&&!(voiceTurn&&voiceOn))return;
 if(ar===undefined)ar=lastArabic;var text=speechText(t,ar);if(!text)return;
 if(speaking&&text===spokenNow)return;           /* the same answer is never read twice over itself */
 stopSpeaking();speakQueue=text.split(/(?<=[.!?؟])\s+/).map(function(s){return s.trim()}).filter(Boolean)
  .reduce(function(acc,s){var last=acc[acc.length-1];if(last&&(last.text+' '+s).length<180)last.text+=' '+s;else acc.push({text:s,ar:ar});return acc},[]);
 spokenNow=text;speaking=true;vstate('speaking');if(window.liveSpeaking)liveSpeaking();speakNext()}
function setVoiceToggle(){var b=$('voiceToggle');b.setAttribute('aria-pressed',voiceOn?'true':'false');b.classList.toggle('off',!voiceOn);
 b.title=voiceOn?'MA answers aloud after you speak. Tap to mute.':'MA voice is muted. Tap to turn it on.';
 b.innerHTML='<i data-lucide="'+(voiceOn?'volume-2':'volume-x')+'"></i><span>'+(voiceOn?'Voice on':'Voice off')+'</span>';refreshIcons()}
$('voiceToggle').onclick=function(){voiceOn=!voiceOn;try{localStorage.setItem('ma-voice-on',voiceOn?'1':'0')}catch(e){}if(!voiceOn)stopSpeaking();setVoiceToggle()};
setVoiceToggle();
/* Cancel (while MA is thinking) / Stop voice (while MA is speaking) */
function cancelVoice(quiet){
 if(rec&&rec.state!=='inactive'){discard=true;rec.stop()}
 runId++;workCancel();
 if(inflight){convo.pop();var lc=$('chat').lastElementChild;if(lc&&lc.classList.contains('user'))lc.remove();if(!quiet)tx.value=inflight;inflight=null}
 $('play').pause();stopSpeaking();voiceTurn=false;
 lockInput(false);vstate('');if(!quiet)say('Stopped. / وقّفنا.')}
$('vStop').onclick=function(){if(speaking&&!busy){stopSpeaking();say('')}else cancelVoice(false)};
var tx=$('tx');tx.addEventListener('input',function(){tx.style.height='auto';tx.style.height=tx.scrollHeight+'px'});
tx.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('gen').click()}});
mic.onclick=function(){rec?stop():start()};
/* ---- app state: cache of what the backend returned ---- */
var DB={invoices:[],customers:[],catalog:[],company:{name:USER.company.name||'',phone:'',logo:''}},convo=[],convoId=0,busy=false;
var productArabic={};
var inv=$('inv'),ai=$('ai'),pg=$('page'),paper=$('paper'),NB=document.querySelectorAll('nav > button'),cur=null,editing=false,curPage=0;
var LBL={draft:['DRAFT','s-draft'],pending:['PENDING','s-pending'],approved:['APPROVED','s-appr'],rejected:['REJECTED','s-rej']};
/* money: display only. Totals always come from the backend (invoice.totals). */
function num(n,d){return (+n||0).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d})}
function missing(n){return n==null||n===''||!Number.isFinite(Number(n))}
function usd(n){return missing(n)?'—':'$'+num(n,2)}
function invoiceUsd(n){return missing(n)?'—':'$'+num(n,Number.isInteger(Number(n))?0:2)}
function lbp(n){return missing(n)?'—':num(Math.round(+n),0)+' LBP'}
function isLabor(it){return /^labou?r\b/i.test(it.d||'')}
function itemLabel(it){var ar=isLabor(it)?'أجرة اليد':productArabic[(it.d||'').toLowerCase()];return esc(it.d)+(ar?' / <bdi lang="ar">'+esc(ar)+'</bdi>':'')}
/* what is still missing before approval (mirrors web_api.readiness on the server) */
function reviewList(){var L=[],seen={},dup=[];if(!cur)return;
 cur.items.forEach(function(it,i){var n=String(it.d||'').trim()||('Item '+(i+1));
  if(!String(it.d||'').trim())L.push('Item '+(i+1)+': description missing / الاسم ناقص');
  if(missing(it.q)||Number(it.q)<=0)L.push(n+': quantity missing / الكمية ناقصة');
  if(missing(it.p))L.push(n+': unit price missing / السعر ناقص');
  var k=(it.catalog_id||n.toLowerCase());if(!isLabor(it)){if(seen[k]&&dup.indexOf(n)<0)dup.push(n);seen[k]=1}});
 dup.forEach(function(n){L.push('⚠ '+n+' appears twice: check it is not a duplicate / مكرّر؟')});
 var ul=$('iReview');ul.innerHTML=L.map(function(x){return '<li>'+esc(x)+'</li>'}).join('');ul.hidden=!L.length||cur.status==='approved'}
/* the truck plate number (the truck's ID) is required; the customer name is optional (mirrors invoice_identity.has_identity) */
/* customer FULL name + truck number (one letter + four digits) are required: same rules as the server (js/validation.js) */
function identityProblems(ar){return cur?Validation.identity(cur,ar):[]}
function missingIdentity(){return identityProblems(false).length>0}
function showIdentity(){var el=$('iIdentityMissing'),pr=identityProblems(lastArabic);el.hidden=!pr.length||cur.status==='approved';el.textContent=pr.map(function(x){return x.message}).join(' ')}
function incomplete(){return !cur.items.length||cur.items.some(function(it){return !String(it.d||'').trim()||missing(it.q)||Number(it.q)<=0||missing(it.p)||Number(it.p)<0})}
function money(n){return usd(n)}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function clone(o){return JSON.parse(JSON.stringify(o))}
function ref(c){return c.id!=null?c.id:c.no}
function canEdit(d){return d.status!=='approved'}
function msg(t){$('aMsg').textContent=t}
function fail(e,fn){(fn||say)(e&&e.message?e.message:'Something went wrong.')}
function icons(){if(window.lucide)lucide.createIcons()}
function normCo(c){c=c||{};return {id:c.id,name:c.name||USER.company.name||'',phone:c.phone||'',logo:c.logo_url||'',vat:c.vat_rate,rate:c.exchange_rate}}
function applyCompany(){var n=DB.company.name||'your garage';
 $('hdrCompany').innerHTML=DB.company.name?'<span class="cl">Company Name: </span>'+esc(DB.company.name):'';$('hdrCompany2').textContent=DB.company.name||'—';
 var wl=$('welcome');if(wl)document.documentElement.style.setProperty('--welH',(wl.offsetHeight+20)+'px');
 document.title=(DB.company.name?DB.company.name+' · ':'')+'InvoiceFlow AI';$('modePill').hidden=API.mode()!=='mock'}
async function loadCompany(){DB.company=normCo(await API.getCompany());applyCompany()}
async function refresh(){var r=await Promise.all([API.listInvoices(),API.getCustomers(),API.getCatalog(),API.getCompany(),API.getProducts()]);DB.invoices=r[0];DB.customers=r[1];DB.catalog=r[2];DB.company=normCo(r[3]);(r[4].products||[]).forEach(function(p){productArabic[p.name_en.toLowerCase()]=p.name_ar});applyCompany();if(cur)render()}
function view(v,ni){$('work').hidden=v==='pg';pg.hidden=v!=='pg';inv.hidden=!cur;$('invEmpty').hidden=!!cur;NB.forEach(function(b,i){b.classList.toggle('on',i===ni)});setMenu(false)}
/* ---- signed-in user + role-based UI (display only: the backend re-checks every permission) ---- */
var can=Auth.can;
function initials(n){return (n||'?').trim().split(/\s+/).slice(0,2).map(function(w){return w[0]}).join('').toUpperCase()}
function avatar(el){el.textContent='';if(USER.picture){var im=new Image();im.alt='';im.src=USER.picture;im.onerror=function(){el.textContent=initials(USER.name)};el.appendChild(im)}else el.textContent=initials(USER.name||USER.username)}
function applyUser(){USER=Auth.user||USER;
 $('hdrName').textContent=USER.name||USER.username;$('hdrRole').textContent=USER.roleLabel;
 $('navName').textContent=USER.name||'Signed in';$('navUsername').textContent='@'+USER.username;
 $('navRole').textContent=USER.roleLabel;$('navRole').className='role-b '+USER.role;
 avatar($('hdrAv'));avatar($('navAv'));
 [].forEach.call(document.querySelectorAll('nav [data-perm]'),function(b){b.hidden=!can(b.dataset.perm)});
 }
applyUser();applyCompany();
$('profileBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('logoutBtn').onclick=async function(){var b=this;if(b.disabled)return;b.disabled=true;b.querySelector('span').textContent='Signing out...';try{await Auth.logout()}catch(e){b.disabled=false;b.querySelector('span').textContent='Log out';alert(e.message)}};
function denied(t){return '<h2>'+t+'</h2><p class="muted">Your account ('+esc(USER.roleLabel)+') does not have access to this page. Ask the garage owner if you need it.</p>'}
/* ---- voice + AI conversation ---- */
function lockInput(value){busy=value;$('gen').disabled=value||!!rec;mic.disabled=value||(typeof live!=='undefined'&&!!live&&live.on);tx.disabled=value;$('deleteRecording').disabled=value;$('sendRecording').disabled=value}
function bubble(r,t){var d=document.createElement('div');d.className='msg '+r;d.dir='auto';d.textContent=t;
 if(r==='ai'&&window.speechSynthesis){var b=document.createElement('button');b.type='button';b.className='msg-say';b.setAttribute('aria-label','Listen to MA');b.title='Listen / اسمع';b.innerHTML='<i data-lucide="volume-2"></i>';
  b.onclick=function(){var ar=/[\u0600-\u06ff]/.test(t)&&(lastArabic||!/[a-z]/i.test(t));speak(t,true,ar)};d.appendChild(b);refreshIcons()}
 $('chat').appendChild(d);$('chat').scrollTop=$('chat').scrollHeight}
var pendingParts=null;
function clearSuggestions(){pendingParts=null;$('partSuggestions').hidden=true;$('partSuggestions').replaceChildren()}
function offerParts(r){
 clearSuggestions();pendingParts={token:r.confirmation_token,selections:{},result:r};var box=$('partSuggestions');box.hidden=false;
 var confirm=document.createElement('button');confirm.className='btn pri';confirm.textContent='Confirm selected items / تأكيد البنود';confirm.disabled=true;
 function ready(){confirm.disabled=r.suggestions.some(function(x){return !pendingParts.selections[String(x.index)]})}
 r.suggestions.forEach(function(s){var section=document.createElement('div');section.className='suggestion-item';var label=document.createElement('p');label.dir='auto';label.textContent=s.description;section.appendChild(label);
 s.candidates.forEach(function(c){var b=document.createElement('button');b.className='btn sm';b.textContent=c.name_en+' / '+c.name_ar;b.onclick=function(){if(busy)return;pendingParts.selections[String(s.index)]=c.id;section.querySelectorAll('button').forEach(function(x){x.classList.toggle('pri',x===b)});ready()};section.appendChild(b)});
 if(s.lookup){var evidence=document.createElement('div');evidence.className='part-evidence';var note=document.createElement('p');note.dir='auto';note.textContent=s.lookup.status==='supported'?'الاسم المقترح بالفصحى: '+s.lookup.name_ar+' / '+s.lookup.name_en+' — اقتراح للمراجعة، وليس إثبات توافق مع شاحنتك.':s.lookup.question;evidence.appendChild(note);
 if(s.lookup.explanation_ar){var explanation=document.createElement('p');explanation.dir='auto';explanation.textContent=s.lookup.explanation_ar;evidence.appendChild(explanation)}
 (s.lookup.sources||[]).forEach(function(source){var a=document.createElement('a');a.href=source.url;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Source / المصدر: '+source.title;a.style.display='block';evidence.appendChild(a)});
 if(s.lookup.search_html){var frame=document.createElement('iframe');frame.title='Google Search suggestions';frame.setAttribute('sandbox','allow-popups allow-popups-to-escape-sandbox');frame.setAttribute('referrerpolicy','no-referrer');frame.srcdoc=s.lookup.search_html;frame.style.width='100%';frame.style.border='0';evidence.appendChild(frame)}
 section.appendChild(evidence)}
 if(!s.custom_allowed){box.appendChild(section);return}
 var custom=document.createElement('details');var title=document.createElement('summary');title.textContent='Not in catalog? Add a custom invoice item / بند مخصّص';custom.appendChild(title);if(!s.candidates.length)custom.open=true;
 var instructions=document.createElement('p');instructions.textContent='What name would you like to display on the invoice for this item? Type it, then enter quantity, unit price and currency. This adds a line to this invoice only, never to the catalog, and does not confirm vehicle fitment.';custom.appendChild(instructions);
 function field(label,value,type){var l=document.createElement('label');l.textContent=label;var i=document.createElement('input');i.type=type||'text';i.value=value==null?'':value;i.setAttribute('aria-label',label);if(type==='number'){i.min='0';i.step='any'}l.appendChild(i);custom.appendChild(l);return i}
 var name=field('Name on invoice / الاسم عالفاتورة',s.lookup&&s.lookup.status==='supported'&&s.lookup.name_ar||s.description),qty=field('Custom quantity / الكمية',s.quantity,'number'),price=field('Custom unit price / سعر الوحدة',s.unit_price,'number');
 name.placeholder='Name to show on the invoice / الاسم يلي بيطلع عالفاتورة';var currency=document.createElement('select');currency.setAttribute('aria-label','Custom currency');['','USD','LBP'].forEach(function(v){var o=document.createElement('option');o.value=v;o.textContent=v||'Currency / العملة';currency.appendChild(o)});currency.value=s.price_currency||'';custom.appendChild(currency);
 var choose=document.createElement('button');choose.className='btn';choose.textContent='Use this custom line / اختيار البند';choose.onclick=function(){if(busy)return;if(!name.value.trim()||!qty.value||Number(qty.value)<=0||price.value===''||Number(price.value)<0||!currency.value){say('Enter the custom name, quantity, price and currency. عبّي الحقول الناقصة.');return}pendingParts.selections[String(s.index)]={custom:true,name:name.value.trim(),quantity:Number(qty.value),unit_price:Number(price.value),currency:currency.value};choose.textContent='Selected: '+qty.value+' × '+price.value+' '+currency.value+' — '+name.value;ready()};custom.appendChild(choose);
 [name,qty,price,currency].forEach(function(i){i.oninput=function(){delete pendingParts.selections[String(s.index)];choose.textContent='Use this custom line / اختيار البند';ready()}});section.appendChild(custom);box.appendChild(section)});
 confirm.onclick=async function(){if(busy||!pendingParts)return;lockInput(true);confirm.disabled=true;try{var names=r.suggestions.map(function(s){var chosen=pendingParts.selections[String(s.index)];return typeof chosen==='object'?chosen.name:s.candidates.find(function(c){return c.id===chosen}).name_en});var response=await API.confirmParts({confirmation_token:pendingParts.token,selections:pendingParts.selections,confirm:true});convo.push({role:'user',text:'Confirmed invoice descriptions: '+names.join(', ')});clearSuggestions();if(response.question){convo.push({role:'assistant',text:response.question,kind:'question'});bubble('ai',response.question);if(response.suggestions)offerParts(response)}else{bubble('ai','تم تأكيد البنود. الفاتورة جاهزة على اليمين.\nItems confirmed. Your invoice is ready on the right.');showInvoice(response)}}catch(e){fail(e);confirm.disabled=false}finally{lockInput(false)}};
 var reject=document.createElement('button');reject.className='btn';reject.textContent='Describe again / وضّح أكتر';reject.onclick=function(){if(busy)return;clearSuggestions();bubble('ai','Nothing added. Describe the part further. ما أضفت شي، وضّح أكتر.');tx.focus()};box.appendChild(confirm);box.appendChild(reject)
}
function resetChat(){workCancel();if(typeof live!=='undefined'&&live&&live.on)liveEnd('');if(rec){discard=true;stop()}clearRecording();clearSuggestions();$('chat').innerHTML='';convo=[];convoId++;cur=null;editing=false;tx.value='';tx.style.height='auto';msg('');closeModal();tx.placeholder='Message MA… / احكي مع MA';say('');greet();pendingShare=null;actReset();view('ai',1)}
/* MA greets the signed-in EMPLOYEE (first name from their account, never a customer) once per AI session,
   in the language they last used with MA (or the browser language). Later answers never repeat it. */
var greetText='',greetAr=false,greetSpoken=false;
function myLang(){try{var l=localStorage.getItem('ma-lang');if(l==='ar'||l==='en')return l}catch(e){}return /^ar/i.test(navigator.language||'')?'ar':'en'}
function rememberLang(l){if(l!=='ar'&&l!=='en')return;lastArabic=l==='ar';try{localStorage.setItem('ma-lang',l)}catch(e){}}
function greet(){var first=String(USER.firstName||'').trim().split(/\s+/)[0]||'';greetAr=myLang()==='ar';
 greetText=greetAr?('أهلا'+(first?' '+first:'')+'! أنا MA، كيف فيني ساعدك اليوم؟'):('Welcome'+(first?' '+first:'')+'! I\'m MA. How can I help you today?');
 bubble('ai',greetText);greetSpoken=false;sayGreeting()}
/* read the greeting aloud once (browsers only allow speech after the employee has interacted with the page) */
function sayGreeting(){if(greetSpoken||!voiceOn||!greetText||!window.speechSynthesis)return false;if(navigator.userActivation&&!navigator.userActivation.hasBeenActive)return false;
 greetSpoken=true;speak(greetText,true,greetAr);return true}
/* ---- MA at work: the invoice is written live on the invoice screen, from the server's real steps ----
   Customer and truck fill in as MA finds them, item lines are typed in, the total appears at the end, and
   "MA's notes" keep a short log of what it is doing. Starts as soon as a message or voice message is sent. */
var work={on:false,run:0,ar:false,prev:null,typing:[],q:[],busy:false,idle:[],rows:0};
var WORK_PROGRESS={listen:10,heard:20,start:12,intent:22,extract:40,memory:58,customer:62,item:72,check:84,totals:94};
function workStart(run,ar){
 if(work.on){work.run=run;work.ar=ar||work.ar;return}          /* a voice message continues the same draft */
 work.on=true;work.run=run;work.ar=ar;work.typing.forEach(clearTimeout);work.typing=[];work.q=[];work.busy=false;work.rows=0;
 work.prev={inv:!inv.hidden,empty:!$('invEmpty').hidden};
 $('mwSteps').replaceChildren();$('mwCust').textContent='';$('mwTruck').textContent='';$('mwTotal').textContent='';$('mwLoyal').hidden=true;
 $('mwRows').innerHTML='<tr class="sk-row"><td><span style="width:60%"></span></td><td><span></span></td><td><span></span></td></tr><tr class="sk-row"><td><span style="width:45%"></span></td><td><span></span></td><td><span></span></td></tr>';
 $('mwCo').textContent=(coOf({}).name||'').toUpperCase();$('mwSub').textContent=ar?'مسودة فاتورة':'Invoice draft';
 $('mwTitle').textContent=ar?'MA عم يكتب…':'MA is writing…';$('mwNotesH').textContent=ar?'ملاحظات MA':"MA's notes";$('mwProg').style.width='6%';
 inv.hidden=true;$('invEmpty').hidden=true;$('maWork').hidden=false;$('maWork').dataset.s='busy';$('maWork').classList.add('waiting')}
function workText(e){return work.ar?e.ar:e.en}
function typeInto(el,txt,ms){var i=0,step=Math.max(1,Math.ceil(txt.length/Math.max(1,(ms||300)/25)));el.classList.add('typing');
 (function tick(){i=Math.min(txt.length,i+step);el.textContent=txt.slice(0,i);if(i<txt.length)work.typing.push(setTimeout(tick,25));else el.classList.remove('typing')})()}
/* steps that arrive together are shown one after another, so the writing can be followed */
function workStep(run,e){if(!work.on||run!==work.run)return;work.q.push(e);workPump()}
function workPump(){
 if(work.busy)return;var e=work.q.shift();
 if(!e){var w=work.idle;work.idle=[];w.forEach(function(f){f()});return}
 work.busy=true;workShow(e);work.typing.push(setTimeout(function(){work.busy=false;workPump()},/^(item|customer|memory|totals|check)$/.test(e.key)?340:80))}
function workIdle(){return new Promise(function(res){if(!work.busy&&!work.q.length)res();else work.idle.push(res)})}
function workNote(e){var list=$('mwSteps'),last=list.lastElementChild;
 if(e.key==='item'&&last&&last.dataset.key==='item'){last.querySelector('span').textContent=workText(e);return}
 if(last)last.className='done';var li=document.createElement('li');li.className='now';li.dataset.key=e.key;var sp=document.createElement('span');sp.dir='auto';sp.textContent=workText(e);li.appendChild(sp);list.appendChild(li);list.scrollTop=list.scrollHeight}
function workShow(e){
 $('mwProg').style.width=Math.max(parseFloat($('mwProg').style.width)||0,WORK_PROGRESS[e.key]||50)+'%';
 $('maWork').classList.toggle('waiting',e.key==='extract'||e.key==='listen'||e.key==='start');
 if(e.key==='customer'){if(e.customer)typeInto($('mwCust'),e.customer,280);if(e.plate)typeInto($('mwTruck'),(work.ar?'نمرة ':'Plate ')+e.plate,280)}
 if(e.key==='memory'&&e.profile){var p=e.profile,L={loyal:['⭐ Loyal customer','زبون دايم'],returning:['↺ Returning customer','زبون راجع'],new:['Known truck','شاحنة معروفة']}[p.status]||['',''];
  var b=$('mwLoyal');b.className='mw-loyal '+p.status;b.hidden=false;b.textContent=(work.ar?L[1]:L[0])+' · '+p.invoices+(work.ar?' فواتير قبل':' earlier invoice'+(p.invoices===1?'':'s'))+(p.approved?' · '+money0(p.total_usd):'')}
 if(e.key==='item'){
  if(!work.rows)$('mwRows').replaceChildren();work.rows++;
  var tr=document.createElement('tr'),a=document.createElement('td'),q=document.createElement('td'),c=document.createElement('td');
  tr.className='new';q.className=c.className='r';a.dir='auto';tr.append(a,q,c);$('mwRows').appendChild(tr);
  typeInto(a,e.item.d,320);q.textContent=e.item.q;c.textContent=e.item.p==null?'—':invoiceUsd(e.item.p)}
 if(e.key==='totals')$('mwTotal').textContent=work.ar?'عم إحسب…':'Calculating…';
 workNote(e)}
/* finish: a draft takes the screen; a question/answer hands back to the chat and the previous view returns */
async function workEnd(run,kind,r){
 if(!work.on||run!==work.run)return;await workIdle();if(!work.on||run!==work.run)return;
 if(kind==='draft'&&r&&r.totals){$('mwTotal').textContent=r.totals.total_usd==null?'—':invoiceUsd(r.totals.total_usd);
  if(!work.rows&&r.items){$('mwRows').replaceChildren();r.items.forEach(function(it){var tr=document.createElement('tr');tr.innerHTML='<td></td><td class="r"></td><td class="r"></td>';tr.cells[0].textContent=it.d;tr.cells[1].textContent=it.q==null?'—':it.q;tr.cells[2].textContent=it.p==null?'—':invoiceUsd(it.p);$('mwRows').appendChild(tr)})}}
 var done={draft:['Invoice ready','الفاتورة جاهزة'],question:['MA asked you a question in the chat','MA سألك سؤال بالمحادثة'],answer:['Answered in the chat','جاوبتك بالمحادثة'],error:['Stopped: see the message in the chat','وقّفت: شوف الرسالة بالمحادثة']}[kind]||['Done','خلص'];
 var list=$('mwSteps'),last=list.lastElementChild;if(last)last.className='done';
 var li=document.createElement('li');li.className=kind==='error'?'err':'done';li.textContent=work.ar?done[1]:done[0];list.appendChild(li);list.scrollTop=list.scrollHeight;
 $('mwProg').style.width='100%';$('maWork').classList.remove('waiting');$('maWork').dataset.s=kind;$('mwTitle').textContent=work.ar?done[1]:done[0];
 if(kind==='draft')await new Promise(function(res){work.typing.push(setTimeout(res,700))});
 if(!work.on||run!==work.run)return;
 work.on=false;var prev=work.prev;
 work.typing.push(setTimeout(function(){if(work.on)return;$('maWork').hidden=true;if(kind!=='draft'&&prev){inv.hidden=!(prev.inv&&cur);$('invEmpty').hidden=!(prev.empty||!cur)}},kind==='draft'?0:1600))}
function workCancel(){if(!work.on)return;work.on=false;work.q=[];work.busy=false;var w=work.idle;work.idle=[];w.forEach(function(f){f()});work.typing.forEach(clearTimeout);$('maWork').hidden=true;inv.hidden=!cur;$('invEmpty').hidden=!!cur}
/* a voice message goes to MA in ONE request: the server transcribes it (Arabic / English detected automatically)
   and answers right away; the transcript appears in the chat as soon as it is heard */
async function transcribe(b){if(busy||!b)return;$('play').pause();clearRecording();await sendMessage(true,undefined,b)}
/* what is on screen, so MA can answer "what's the total of this invoice?" (the server re-reads / recomputes it) */
function invoiceContext(){if(!cur)return {};if(cur.id)return {invoice_id:cur.id};return {draft:{cust:cur.cust,truck:cur.truck,items:cur.items,notes:cur.notes}}}
function isAr(t){return /[؀-ۿ]/.test(t||'')}
async function sendMessage(fromVoice,spoken,audio){
 if(busy)return;var live1=spoken!==undefined||(audio&&live.on),txt=audio?'':(spoken!==undefined?String(spoken).trim():tx.value.trim());
 if(!txt&&!audio){say('Tap the microphone or type what was repaired.');return}
 if(fromVoice!==true){voiceTurn=false;stopSpeaking();lastArabic=isAr(txt)}else voiceTurn=true;
 var run=++runId,heard=false;inflight=txt||null;
 function hear(t){if(heard)return;heard=true;txt=t;inflight=t;bubble('user',t);convo.push({role:'user',text:t});if(live.on)$('liveHeard').textContent=t;
  workStep(run,{key:'heard',en:'Heard: “'+t.slice(0,90)+'”',ar:'سمعت: «'+t.slice(0,90)+'»'})}
 clearSuggestions();if(txt){bubble('user',txt);convo.push({role:'user',text:txt});heard=true}
 if(!live1&&!audio){tx.value='';tx.style.height='auto'}say('');lockInput(true);vstate('thinking');
 actStart(audio?'voice':'text');
 try{workStart(run,isAr(txt)||(audio?myLang()==='ar':false));if(audio)workStep(run,{key:'listen',en:'Listening to your voice message',ar:'عم إسمع رسالتك الصوتية'});
  var payload={text:txt,history:convo.slice(),context:invoiceContext()};
  var onEvent=function(e){if(run!==runId)return;if(e.type==='activity'){actUpdate(e);return}if(e.type==='transcript'){hear(e.text);if(e.language)lastArabic=e.language==='ar';return}workStep(run,e)};
  var r=audio?await API.generateVoice(audio,payload,onEvent):await API.generateLive(payload,onEvent);
  if(run!==runId)return;if(r.transcript)hear(r.transcript);inflight=null;
  if(r.language){rememberLang(r.language)}
  var ar=r.language?r.language==='ar':isAr(txt);
  await workEnd(run,r.reply!==undefined?'answer':r.question?'question':'draft',r);if(run!==runId)return;
  if(r.reply!==undefined){convo.push({role:'assistant',text:r.reply,kind:r.kind||'answer',ask:r.ask||'',state:r.state||''});answer(r);say('');speak(r.reply,live1,ar);actFinish(r.action&&r.action.type==='pause'?'paused':'answer');
   if(r.action&&r.action.type==='cancel'){if(cur&&cur.id==null){cur=null;view('ai',1)}convoId++;clearSuggestions()}
   else if(r.action&&r.action.type==='pause'){if(live.on)livePause(true)}
   else if(r.action)share(r.action,ar)}
  else if(r.question){convo.push({role:'assistant',text:r.question,kind:'question',state:r.state||''});bubble('ai',r.question);if(r.suggestions)offerParts(r);say('');speak(r.question,live1,ar);actFinish('question')}
  else{var ready=ar?'الفاتورة جاهزة على اليمين. فيك تحكي أي تصحيح، أو تراجعها وتوافق عليها.':'Your invoice is ready on the right. Tell me any correction, or review and approve it.';bubble('ai',ready);if(r.warnings&&r.warnings.length)bubble('ai',(ar?'انتبه:\n• ':'Please check:\n• ')+r.warnings.join('\n• '));say('');showInvoice(r);
   convo.push({role:'assistant',text:ready,kind:'draft'});speak(ready,live1,ar);actDraftShown()}}
 catch(e){if(run!==runId)return;workEnd(run,'error');actFail(e.message);inflight=null;if(heard){convo.pop();var lc=$('chat').lastElementChild;if(lc&&lc.classList.contains('user'))lc.remove();if(!live1&&!audio)tx.value=txt}fail(e)}
 finally{if(run===runId){lockInput(false);if(!speaking)vstate('')}}}
/* answers to questions about invoices, help, or "open invoice N" */
function answer(r){
 if(r.understood){var u=document.createElement('div');u.className='msg-und';u.dir='auto';u.textContent='\u2714 '+r.understood;$('chat').appendChild(u)}
 bubble('ai',r.reply);
 if(r.invoices&&r.invoices.length){var box=document.createElement('div');box.className='msg-list';
  r.invoices.forEach(function(c){var b=document.createElement('button');b.type='button';b.dataset.open=c.id;b.dir='auto';
   b.innerHTML='<b>'+esc(c.no)+'</b><span>'+esc(c.customer||'-')+(c.plate?' · '+esc(c.plate):'')+'</span><span>'+esc(c.date)+'</span><span class="r">'+(c.total_usd!=null?invoiceUsd(c.total_usd):'—')+'</span>'+badge(c.status);
   box.appendChild(b)});
  $('chat').appendChild(box)}
 $('chat').scrollTop=$('chat').scrollHeight;
 if(r.open)show(clone(r.open),1)}
$('chat').addEventListener('click',async function(e){var b=e.target.closest('button[data-open]');if(!b)return;b.disabled=true;
 try{show(clone(await API.getInvoice(b.dataset.open)),1)}catch(er){say(er.message)}finally{b.disabled=false}});
$('gen').onclick=sendMessage;
/* ---- Activity panel: what MA is doing for this request. Steps come from the server's real events
   (type "activity" in the NDJSON stream) and from the real API calls made here (approval, PDF, sending).
   Nothing is simulated: a step only changes when its work actually started, finished or failed. ---- */
var ACT={steps:[]};
var ACT_LBL={answer:['Answering in the chat','عم جاوبك بالمحادثة'],paused:['Paused · everything so far is kept','توقّفنا · كل شي محفوظ'],error:['MA stopped','MA وقّف'],
 send_whatsapp:['Sending the invoice PDF by WhatsApp','عم إبعت الفاتورة عالواتساب'],send_email:['Sending the invoice PDF by email','عم إبعت الفاتورة عالإيميل'],
 preview:['Preparing invoice preview','عم حضّر معاينة الفاتورة'],approval:['Waiting for employee approval','ناطر موافقتك'],pdf:['Generating invoice PDF','عم إعمل الـ PDF للفاتورة']};
var ACT_WORD={pending:['Pending','بالانتظار'],processing:['Processing','عم يشتغل'],completed:['Completed','خلص'],failed:['Failed','فشل']};
function actStep(key){for(var i=0;i<ACT.steps.length;i++)if(ACT.steps[i].key===key)return ACT.steps[i];var L=ACT_LBL[key]||['',''];var s={key:key,status:'pending',en:L[0],ar:L[1]};ACT.steps.push(s);return s}
function actReset(){ACT.steps=[];actRender()}
function actStart(){ACT.steps=[];actRender()}
function actUpdate(e){
 if(e.plan)e.plan.forEach(function(p){var s=actStep(p.key);if(!s.en)s.en=p.en;if(!s.ar)s.ar=p.ar});
 var s=actStep(e.key);s.status=e.status||s.status;if(e.en)s.en=e.en;if(e.ar)s.ar=e.ar;
 s.error=s.status==='failed'?String(e.error||''):'';if(e.detail!=null)s.detail=String(e.detail||'');s.at=Date.now();actRender()}
function actFinish(kind){if(kind==='paused'){actUpdate({key:'paused',status:'completed'});return}
 if(kind==='answer'&&!ACT.steps.some(function(s){return s.key==='extract'}))actUpdate({key:'answer',status:'completed'})}
function actFail(m){var s=ACT.steps.filter(function(x){return x.status==='processing'}).pop();if(s){s.status='failed';s.error=m||'';actRender()}else actUpdate({key:'error',status:'failed',error:m||''})}
function actDraftShown(){actUpdate({key:'preview',status:'completed',detail:cur&&cur.totals&&cur.totals.total_usd!=null?invoiceUsd(cur.totals.total_usd):''});actUpdate({key:'approval',status:'processing'});actStep('pdf');actRender()}
function actRender(){var ar=lastArabic,ol=$('actSteps');if(!ol)return;
 ol.innerHTML=ACT.steps.map(function(s){var w=ACT_WORD[s.status]||ACT_WORD.pending;
  return '<li class="'+s.status+'" dir="auto"><i class="st '+s.status+'" aria-hidden="true"></i><span class="lbl">'+esc(ar?(s.ar||s.en):(s.en||s.ar))+'<span class="vh"> — '+(ar?w[1]:w[0])+'</span>'+(s.at&&s.status!=='pending'?'<span class="tm">'+new Date(s.at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})+'</span>':'')+'</span>'+
   (s.detail&&s.status!=='failed'?'<span class="det">'+esc(s.detail)+'</span>':'')+(s.error?'<span class="err" role="alert">'+esc(s.error)+'</span>':'')+'</li>'}).join('');
 $('actEmpty').hidden=!!ACT.steps.length;$('actTitle').textContent=ar?'شو عم يعمل MA':'What MA is doing';$('actSub').textContent=ar?'خطوات حقيقية من السيرفر':'Live steps from the server';
 var any=function(st){return ACT.steps.some(function(s){return s.status===st})};
 $('actBtn').dataset.s=any('processing')?'processing':any('failed')?'failed':ACT.steps.length?'completed':''}
function actToggle(open){var p=$('actPanel'),o=open===undefined?p.hidden:open;p.hidden=!o;$('actBtn').setAttribute('aria-expanded',String(o));if(o){actRender();icons()}}
$('actBtn').onclick=function(e){e.preventDefault();actToggle()};
$('actClose').onclick=function(){actToggle(false);$('actBtn').focus()};
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('actPanel').hidden&&$('modal').hidden)actToggle(false)});
/* ---- Live Voice: a hands-free conversation with MA ----
   The mic stays open. The browser notices when you start and stop talking (voice activity detection), and sends
   that sentence straight to the server, which recognises Arabic or English by itself (no language button), answers
   in the same language, and MA reads it aloud. Talking while MA speaks interrupts it. Pause keeps everything. */
var live={on:false,paused:false,state:'',turn:0,stream:null,ac:null,an:null,rec:null,chunks:[],timer:0,speech:false,voiceMs:0,quietMs:0,last:0,noise:0.008,calib:[],startedAt:0,buf:null};
var LIVE_TXT={listening:['Listening…','عم إسمعك…'],hearing:['Hearing you…','عم إسمعك…'],thinking:['MA is thinking…','MA عم يفكّر…'],speaking:['MA is speaking','MA عم يحكي'],paused:['Paused · tap Resume','متوقّف · اضغط كمّل']};
function liveSet(s){live.state=s;var p=$('livePanel');p.dataset.s=s;$('liveOrb').title=s==='speaking'?'Tap or just talk to interrupt MA':'';var t=LIVE_TXT[s];$('liveState').textContent=t?(lastArabic?t[1]:t[0]):'';$('aiState').textContent=t?t[0]:'Ready'}
function liveRecStart(){if(!live.on||live.paused||!live.stream||live.rec)return;var r;try{r=new MediaRecorder(live.stream)}catch(e){return}
 live.rec=r;live.chunks=[];r.ondataavailable=function(e){if(e.data&&e.data.size)live.chunks.push(e.data)};r.start();live.startedAt=Date.now()}
function liveRecStop(send){var r=live.rec;live.rec=null;if(!r||r.state==='inactive')return;var ms=Date.now()-live.startedAt;
 r.onstop=function(){var c=live.chunks;live.chunks=[];
  if(send&&live.on&&!live.paused&&ms>500){var blob=new Blob(c,{type:c[0]&&c[0].type||'audio/webm'});if(blob.size>1500){liveTurn(blob);return}}
  if(live.on&&!live.paused&&live.state!=='thinking')liveRecStart()};
 try{r.stop()}catch(e){}}
function liveLoop(){if(!live.on||!live.an)return;
 var d=live.buf||(live.buf=new Float32Array(live.an.fftSize));live.an.getFloatTimeDomainData(d);var s=0;for(var i=0;i<d.length;i++)s+=d[i]*d[i];
 var rms=Math.sqrt(s/d.length),now=performance.now(),dt=Math.min(200,now-(live.last||now));live.last=now;
 if(live.calib){live.calib.push(rms);if(live.calib.length>=20){var a=live.calib.slice().sort(function(x,y){return x-y});live.noise=Math.max(0.003,a[Math.floor(a.length/2)]);live.calib=null}return}
 if(live.paused||live.state==='thinking')return;
 var thr=Math.max(0.012,live.noise*3)*(live.state==='speaking'?2.6:1),loud=rms>thr;
 if(loud){live.voiceMs+=dt;live.quietMs=0}else{live.quietMs+=dt;if(!live.speech)live.voiceMs=Math.max(0,live.voiceMs-dt)}
 if(!live.speech&&live.voiceMs>(live.state==='speaking'?320:150)){
  live.speech=true;
  if(live.state==='speaking'){stopSpeaking();var r=live.rec;live.rec=null;if(r){r.onstop=null;try{r.stop()}catch(e){}}liveRecStart()}  /* barge-in: MA stops, your words are recorded fresh */
  liveSet('hearing')}
 if(live.speech&&(live.quietMs>700||Date.now()-live.startedAt>20000)){live.speech=false;live.voiceMs=0;live.quietMs=0;liveRecStop(true);return}
 if(!live.speech&&live.rec&&Date.now()-live.startedAt>8000&&live.state!=='speaking'){liveRecStop(false)}   /* drop long silences */
}
async function liveTurn(blob){
 var my=++live.turn;
 if(busy)cancelVoice(true);          /* you spoke again while MA was thinking: the newer request wins */
 stopSpeaking();liveSet('thinking');
 await sendMessage(true,undefined,blob);
 if(live.on&&my===live.turn&&!live.paused){if(!speaking)liveSet('listening');liveRecStart()}}
window.liveSpeaking=function(){if(live.on&&!live.paused){liveSet('speaking');liveRecStart()}};
afterSpeech=function(){if(live.on&&live.state==='speaking'&&!live.paused){liveSet('listening');var r=live.rec;live.rec=null;if(r){r.onstop=null;try{r.stop()}catch(e){}}liveRecStart()}};
async function liveStart(){
 if(!window.MediaRecorder||!navigator.mediaDevices){say('Live Voice is not available in this browser. You can still send voice messages with the mic. Live Voice مش متوفر بهالمتصفح.');return}
 if(rec||startingRecording){say('Finish or delete your voice message first. خلّص التسجيل أو احذفو أوّل.');return}
 $('play').pause();var b=$('liveBtn');b.disabled=true;
 try{live.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}})}
 catch(e){b.disabled=false;say(e&&e.name==='NotAllowedError'?'Microphone permission was denied. Allow it in the browser to use Live Voice. المايك مش مسموح.':'No microphone was found. ما في مايك.');return}
 b.disabled=false;
 try{live.ac=new (window.AudioContext||window.webkitAudioContext)();live.an=live.ac.createAnalyser();live.an.fftSize=1024;live.ac.createMediaStreamSource(live.stream).connect(live.an)}catch(e){}
 live.on=true;live.paused=false;live.calib=[];live.speech=false;live.voiceMs=live.quietMs=0;live.buf=null;live.last=0;
 document.body.classList.add('live');$('livePanel').hidden=false;b.setAttribute('aria-pressed','true');b.setAttribute('aria-label','End Live Voice');mic.disabled=true;
 setPauseBtn();$('liveHeard').textContent='';liveSet('listening');say('');
 live.timer=setInterval(liveLoop,40);liveRecStart();
 sayGreeting()}                      /* the employee's welcome, spoken once per session */
function livePause(on){if(!live.on)return;live.paused=on;setPauseBtn();
 if(on){var r=live.rec;live.rec=null;if(r){r.onstop=null;try{r.stop()}catch(e){}}stopSpeaking();live.speech=false;live.voiceMs=0;liveSet('paused');say('Paused. Nothing is lost. / وقّفنا، ما راح شي.')}
 else{liveSet('listening');liveRecStart();say('')}}
function setPauseBtn(){var b=$('livePause'),p=live.paused;b.setAttribute('aria-pressed',String(p));b.setAttribute('aria-label',p?'Resume Live Voice':'Pause Live Voice');b.title=p?'Resume / كمّل':'Pause / وقّف شوي';b.innerHTML='<i data-lucide="'+(p?'play':'pause')+'"></i><span>'+(p?'Resume':'Pause')+'</span>';icons()}
function liveEnd(message){
 live.on=false;live.paused=false;live.turn++;clearInterval(live.timer);var r=live.rec;live.rec=null;if(r){r.onstop=null;try{r.stop()}catch(e){}}
 if(live.stream)live.stream.getTracks().forEach(function(t){t.stop()});live.stream=null;if(live.ac){try{live.ac.close()}catch(e){}}live.ac=live.an=null;
 stopSpeaking();document.body.classList.remove('live');$('livePanel').hidden=true;
 var b=$('liveBtn');b.setAttribute('aria-pressed','false');b.setAttribute('aria-label','Start Live Voice');mic.disabled=busy;
 $('aiState').textContent='Ready';say(message||'Live Voice ended. انتهت المحادثة الصوتية.')}
$('liveBtn').onclick=function(){live.on?liveEnd():liveStart()};
$('liveEnd').onclick=function(){liveEnd()};
$('livePause').onclick=function(){livePause(!live.paused)};
$('liveOrb').onclick=function(){if(live.state==='speaking'){stopSpeaking();liveSet('listening')}};
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&live.on&&$('modal').hidden&&$('actPanel').hidden)liveEnd()});
/* ---- invoice preview / editing ---- */
function coOf(d){var c=d.company||{};return {name:c.name||DB.company.name,phone:c.phone||DB.company.phone,logo:c.logo_url||DB.company.logo}}
function totals(){
 var t=cur.totals,dirty=!!cur._dirty;
 [].forEach.call($('iRows').rows,function(r,i){var it=cur.items[i],c=r.querySelector('.rt');if(!it||!c)return;var bk=!dirty&&it.total_usd!=null;c.textContent=invoiceUsd(missing(it.q)||missing(it.p)?null:(bk?it.total_usd:it.q*it.p));c.classList.toggle('pv',!bk)});
 var ok=t&&!dirty;
 $('iSub').textContent=ok?invoiceUsd(t.subtotal_usd):'—';$('iVatL').textContent='VAT'+(t&&t.vat_rate!=null?' ('+t.vat_rate+'%)':'');
 $('iVat').textContent=ok?invoiceUsd(t.vat_usd):'—';$('iTot').textContent=ok&&!incomplete()?invoiceUsd(t.total_usd):'—';$('iTotL').textContent=ok&&!incomplete()?lbp(t.total_lbp):'—';
 $('iSubRow').hidden=$('iVatRow').hidden=!t||!t.vat_rate;
 $('iMissing').hidden=!incomplete();showIdentity();reviewList();
 $('iTotals').classList.toggle('stale',!ok);$('iStale').hidden=ok;
 $('iStale').textContent=t?'You changed items — the server recalculates the USD and LBP totals when you save.':'Totals will be calculated by the server when you save the invoice.';
 var rate=(t&&t.exchange_rate)||DB.company.rate;$('iFx').textContent=rate?'Exchange rate: 1 USD = '+num(rate,0)+' LBP (fixed rate used by InvoiceFlow AI).':''}
function btns(){var ce=canEdit(cur),ap=cur.status==='approved';$('aEdit').disabled=!ce;$('aEdit').textContent=editing&&ce?'Done Editing':'Edit Invoice';$('aDraft').disabled=!ce;$('sPend').classList.toggle('on',!ap);$('sAppr').classList.toggle('on',ap);$('sPend').setAttribute('aria-pressed',String(!ap));$('sAppr').setAttribute('aria-pressed',String(ap));$('sAppr').querySelector('span').textContent=ap?'Approved':'Approve';$('aWa').classList.toggle('locked',!ap);$('aWa').title=ap?'Send this invoice by WhatsApp':'Approve the invoice first';$('aMail').classList.toggle('locked',!ap);$('aMail').title=ap?'Send this invoice by email':'Approve the invoice first';$('aPrint').disabled=!cur.items.length;$('aMail').disabled=false;$('aPrint').title=ap?'Download the final PDF':'Download a preview PDF (marked PENDING)'}
function render(){
 var d=cur,ed=editing&&canEdit(d),C=d.cust,T=d.truck,co=coOf(d),h='',s=LBL[d.status];
 $('iCo').textContent=(co.name||'').toUpperCase();$('iCoPhone').textContent=co.phone?'Phone: '+Phone.pretty(co.phone):'';
 var lg=$('iLogo');lg.hidden=!co.logo;if(co.logo)lg.src=co.logo;else lg.removeAttribute('src');
 $('iNo').textContent=d.no?'INVOICE #'+d.no:'INVOICE — not saved yet';$('iDate').textContent=new Date(d.date||Date.now()).toLocaleDateString([], {year:'numeric',month:'long',day:'numeric'});
 $('iSt').textContent=s[0];$('iSt').className='badge-s '+s[1];var n=document.querySelector('.note');n.hidden=!d.mock;n.textContent='Mock data from the frontend test layer, not from the AI backend.';
 function fld(g,list){return list.map(function(x){var p=x.split('|');return '<input data-s="'+g+'.'+p[0]+'" placeholder="'+p[1]+'" value="'+esc((g==='cust'?C:T)[p[0]])+'">'}).join('')}
 $('iCust').innerHTML=ed?fld('cust',['name|Customer full name (first and last)','contact|Contact person','tel|Phone','email|Email']):([C.name,C.contact&&'Contact: '+C.contact,C.tel&&'Tel: '+C.tel,C.email].filter(Boolean).map(esc).join('<br>')||'-');
 $('iTruck').innerHTML=ed?fld('truck',['plate|Truck number, e.g. A1234','model|Truck model']):([T.plate&&'Truck: '+T.plate,T.model].filter(Boolean).map(esc).join('<br>')||'-');
 $('invoiceItems').classList.toggle('editing',ed);$('iTotalLabel').colSpan=ed?5:3;
 $('iRows').parentNode.tHead.innerHTML=ed?'<tr><th>Item / البند</th><th>Type</th><th class="r">Qty / الكمية</th><th class="r">Unit USD / سعر الوحدة</th><th class="r">Total / المجموع</th><th></th></tr>':'<tr><th>Item / <bdi lang="ar">البند</bdi></th><th class="r">Quantity / <bdi lang="ar">الكمية</bdi></th><th class="r">Unit price / <bdi lang="ar">سعر الوحدة</bdi></th><th class="r">Total / <bdi lang="ar">المجموع</bdi></th></tr>';
 d.items.forEach(function(it,i){
  h+=ed?'<tr><td><input aria-label="Item '+(i+1)+' description" data-i="'+i+'" data-k="d" value="'+esc(it.d)+'"></td><td><input aria-label="Item '+(i+1)+' type" data-i="'+i+'" data-k="t" value="'+esc(it.t)+'"></td><td><input aria-label="Item '+(i+1)+' quantity" data-i="'+i+'" data-k="q" type="number" min="0" step="any" placeholder="—" value="'+(missing(it.q)?'':it.q)+'"></td><td><input aria-label="Item '+(i+1)+' unit price USD" data-i="'+i+'" data-k="p" type="number" min="0" step="any" placeholder="—" value="'+(missing(it.p)?'':it.p)+'"></td><td class="r rt"></td><td><button class="x" data-del="'+i+'" aria-label="Remove row">&times;</button></td></tr>'
  :'<tr><td>'+itemLabel(it)+'</td><td class="r">'+(isLabor(it)||missing(it.q)?'—':it.q)+'</td><td class="r">'+(isLabor(it)?'—':invoiceUsd(it.p))+'</td><td class="r rt"></td></tr>'});
 $('iRows').innerHTML=h;$('iEd').hidden=!ed;
 $('iRepairNotes').hidden=!d.notes;$('iRepairNotes').textContent=d.notes||'';
 $('iEd').innerHTML=ed?'<button class="btn sm" id="addRow">+ Add row</button><select id="catSel"><option value="">Add product (enter price)...</option>'+DB.catalog.map(function(c,i){return '<option value="'+i+'">'+esc(c[0])+'</option>'}).join('')+'</select>':'';
 var lookup=$('customerLookup');lookup.hidden=!ed||!DB.customers.length;lookup.innerHTML=ed&&DB.customers.length?'<label>Use a saved customer / زبون محفوظ <select id="chooseCustomer"><option value="">Select and review…</option>'+DB.customers.map(function(c,i){return '<option value="'+i+'">'+esc(c.name+' '+(c.tel||c.email||''))+'</option>'}).join('')+'</select></label>':'';
 if(ed&&DB.customers.length)$('chooseCustomer').onchange=function(){if(this.value==='')return;cur.cust=clone(DB.customers[Number(this.value)]);dirty();render()};
 loyalBadge();totals();btns()}
function show(c,ni){cur=c;editing=false;render();msg('');loadActivity();view('inv',ni||1);if(window.innerWidth<1100)inv.scrollIntoView({behavior:'smooth',block:'start'})}
function showInvoice(d){if(d.new_invoice){convoId++;cur=null}var c=clone(d);delete c.new_invoice;c.status='pending';c._convo=convoId;c.client_request_id=rid();
 if(cur&&cur._convo===convoId&&cur.id!=null&&canEdit(cur)){c.id=cur.id;c.no=cur.no}
 show(c,1)}
function dirty(){cur._dirty=true;cur.client_request_id=rid()}
/* customer memory (by plate number = the truck's ID): who this truck's customer is, and how loyal */
function money0(v){return '$'+Number(v||0).toLocaleString('en-US',{maximumFractionDigits:2})}
function loyalBadge(){
 var b=$('iLoyal'),p=cur&&cur.customer_profile;if(!p||!p.status){b.hidden=true;b.innerHTML='';return}
 var L={loyal:['⭐ Loyal customer','زبون دايم'],returning:['↺ Returning customer','زبون راجع'],new:['Known truck','شاحنة معروفة']}[p.status]||['',''];
 var since=p.first?new Date(p.first*1000).toLocaleDateString([], {month:'short',year:'numeric'}):'';
 var bits=[p.invoices+' earlier invoice'+(p.invoices===1?'':'s'),p.approved?money0(p.total_usd)+' approved':'',since?'since '+since:''].filter(Boolean).join(' · ');
 var filled=(cur.filled_from_memory||[]).map(function(f){return {truck_plate:'plate number',customer:'name',customer_phone:'phone',customer_email:'email',truck_model:'truck model'}[f]}).filter(Boolean);
 b.className='loyal '+p.status;b.hidden=false;
 b.innerHTML='<b>'+esc(L[0])+'</b> <bdi lang="ar">'+esc(L[1])+'</bdi><span>'+esc(bits)+'</span>'+(filled.length?'<small>Filled from customer memory: '+esc(filled.join(', '))+'</small>':'')}
var lookupT=0;
paper.addEventListener('change',function(e){var d=e.target.dataset;if(!d.s||!editing||(d.s!=='truck.plate'&&d.s!=='cust.tel'))return;
 clearTimeout(lookupT);lookupT=setTimeout(async function(){
  try{var p=await API.truckLookup({plate:cur.truck.plate||'',tel:cur.cust.tel||'',exclude:cur.id||''});if(!p||!p.status)return;
   var got=[];[['cust','name','name'],['cust','tel','tel'],['cust','email','email'],['truck','plate','plate'],['truck','model','model']].forEach(function(f){
    if(!(cur[f[0]][f[1]]||'').trim()&&p[f[2]]){cur[f[0]][f[1]]=p[f[2]];got.push(f[2])}});
   cur.customer_profile=p;if(got.length){cur.filled_from_memory=got.map(function(g){return {name:'customer',tel:'customer_phone',email:'customer_email',plate:'truck_plate',model:'truck_model'}[g]});dirty();render();msg('Filled from customer memory: '+got.join(', ')+'. / عبّيت من ذاكرة الزبائن.')}else loyalBadge()}
  catch(x){}},150)});
paper.addEventListener('input',function(e){var t=e.target,d=t.dataset;if(d.k){cur.items[+d.i][d.k]=(d.k==='q'||d.k==='p')?(t.value.trim()===''?null:Number(t.value)):t.value;if(d.k==='q'||d.k==='p')dirty();totals()}else if(d.s){var a=d.s.split('.');cur[a[0]][a[1]]=t.value;cur.client_request_id=rid();showIdentity()}});
/* a valid truck number is written in its standard form (a 1234 -> A1234) when you leave the field */
paper.addEventListener('change',function(e){if(e.target.dataset.s==='truck.plate'&&Validation.truckValid(e.target.value)){e.target.value=Validation.normalizeTruck(e.target.value);cur.truck.plate=e.target.value;showIdentity()}});
paper.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;if(b.id==='addRow'){cur.items.push({d:'',t:'Service',q:1,p:null});dirty();render()}else if(b.dataset.del!=null){cur.items.splice(+b.dataset.del,1);dirty();render()}});
paper.addEventListener('change',function(e){if(e.target.id==='catSel'&&e.target.value!==''){var c=DB.catalog[+e.target.value];cur.items.push({d:c[0],t:c[1],q:1,p:null});dirty();render()}});
function payload(){var p=clone(cur);delete p._dirty;delete p._convo;delete p.totals;delete p.mock;p.items.forEach(function(i){delete i.total_usd});return p}
async function run(fn,ok){if(busy)return;busy=true;try{var r=await fn();if(ok&&r!==false)msg(ok);refresh().catch(function(){})}catch(e){fail(e,msg)}finally{busy=false}}
window.addEventListener('resize',function(){var wl=$('welcome');if(wl&&wl.offsetHeight)document.documentElement.style.setProperty('--welH',(wl.offsetHeight+20)+'px')});
$('newChat').onclick=function(){cancelVoice(true);resetChat();say('');tx.focus()};
$('expand').onclick=function(){var big=document.body.classList.toggle('chat-big');this.setAttribute('aria-pressed',String(big));
 this.setAttribute('aria-label',big?'Restore chat size':'Expand chat');this.title=big?'Restore chat size':'Expand chat';
 this.innerHTML='<i data-lucide="'+(big?'minimize-2':'maximize-2')+'"></i>';icons();$('chat').scrollTop=$('chat').scrollHeight};
/* save the current invoice (new invoices are saved as Pending) */
async function persist(){if(!cur.items.length)throw Error('Add at least one item first.');var c=cur._convo,prof=cur.customer_profile,fill=cur.filled_from_memory;cur=await API.saveInvoice(payload());cur._convo=c;if(prof&&!cur.customer_profile)cur.customer_profile=prof;if(fill)cur.filled_from_memory=fill;editing=false;render();return cur}
$('aEdit').onclick=function(){editing=!editing;render();msg('')};
$('aDraft').onclick=function(){run(persist,'Saved as Pending. Totals were recalculated by the server.')};
/* Status: Pending / Approve. Only a person can approve, never the AI. */
$('sPend').onclick=function(){run(async function(){
 if(cur.status==='approved'){
  var ok=await ask({title:'Move '+cur.no+' back to Pending?',body:'<p>It can be edited again, and it must be approved again before it is sent.</p><p dir="rtl">رح ترجع قيد الانتظار وبتنعدّل، ولازم توافق عليها من جديد قبل ما تنبعت.</p>',ok:'Move to Pending'});
  if(!ok)return false;cur=Object.assign(await API.markPending(ref(cur)),{_convo:cur._convo});render();return}
 await persist();if(cur.status!=='pending'){cur=Object.assign(await API.markPending(ref(cur)),{_convo:cur._convo});render()}
},'Status: Pending. / الحالة: قيد الانتظار.')};
$('sAppr').onclick=function(){if(cur.status==='approved'){msg('This invoice is already approved.');return}
 if(!can('invoice.approve')){msg('Only the garage owner can approve invoices. / بس صاحب الكاراج فيه يوافق على الفواتير.');return}
 if(!cur.items.length){msg('Add at least one item first.');return}
 if(missingIdentity()){msg(identityProblems(false).map(function(x){return x.message}).join(' ')+' (Edit Invoice) / '+identityProblems(true).map(function(x){return x.message}).join(' '));showIdentity();return}
 if(incomplete()){msg('Fill in the missing quantities and prices before approving (Edit Invoice). / عبّي الأسعار والكميات الناقصة قبل الموافقة.');return}
 run(async function(){
  var saved=await persist(),reviewed=await API.getInvoice(ref(saved)),t=reviewed.totals||{};
  var ok=await ask({title:'Approve invoice '+reviewed.no+'?',ok:'Approve',
   body:'<dl class="mdl"><dt>Customer</dt><dd>'+esc(reviewed.cust.name||'-')+'</dd><dt>Items</dt><dd>'+reviewed.items.length+'</dd><dt>Total</dt><dd><b>'+invoiceUsd(t.total_usd)+'</b> / '+lbp(t.total_lbp)+'</dd></dl>'+
    ((reviewed.warnings||[]).length?'<p class="mwarn">'+reviewed.warnings.map(esc).join('<br>')+'</p>':'')+'<p class="muted small">Check the invoice before approving. Approved invoices can be downloaded as PDF and sent by WhatsApp.</p>'});
  if(!ok){cur=Object.assign(reviewed,{_convo:saved._convo});render();return false}
  actUpdate({key:'approval',status:'completed',detail:reviewed.no});actUpdate({key:'pdf',status:'processing'});
  try{cur=Object.assign(await API.approveInvoice(ref(reviewed),reviewed),{_convo:saved._convo})}catch(e){actUpdate({key:'approval',status:'failed',error:e.message});actUpdate({key:'pdf',status:'pending'});throw e}
  actUpdate({key:'pdf',status:'completed',detail:(lastArabic?'انحفظ الـ PDF النهائي مع الفاتورة ':'Final PDF stored with ')+cur.no});render();loadActivity();
  if(pendingShare){var a=pendingShare;pendingShare=null;setTimeout(function(){share(a,false)},150)}},'Approved. The final PDF is stored; you can download, print or send it. / تمت الموافقة.')};
$('aPrint').onclick=function(){var ap=cur.status==='approved';run(async function(){
 if(!cur.items.length)throw Error('Add at least one item first.');
 if(!ap)await persist();   /* the PDF always shows the latest saved information */
actUpdate({key:'pdf',status:'processing'});try{await API.downloadPdf(ref(cur),!ap)}catch(e){actUpdate({key:'pdf',status:'failed',error:e.message});throw e}
 actUpdate({key:'pdf',status:ap?'completed':'pending',detail:ap?'Final PDF downloaded':'Preview PDF downloaded (final PDF is made at approval)'})},ap?'PDF downloaded. / تنزّل الـ PDF.':'Preview PDF downloaded (marked PENDING). Approve the invoice for the final PDF. / تنزّلت نسخة أولية.')};
async function savedContact(kind){var v=kind==='email'?cur.cust.email:cur.cust.tel;
 if(!v&&cur.truck&&cur.truck.plate){try{var p=await API.truckLookup({plate:cur.truck.plate});v=p&&(kind==='email'?p.email:p.tel)}catch(e){}}
 return v||''}
$('aMail').onclick=async function(){
 if(cur.status!=='approved'){msg('Approve this invoice first, then send it by email. / وافق على الفاتورة أوّل، بعدين ابعتها عالإيميل.');$('sAppr').focus();return}
 var saved=await savedContact('email');if(saved&&EMAIL_RE.test(saved))emailPreview(saved);else emailAddress(lastEmail||saved||'')};
$('aNativePrint').onclick=function(){if(cur.status!=='approved'){msg('Approve this invoice first, then print it. / وافق على الفاتورة أوّل.');$('sAppr').focus();return}window.open('/print.html?invoice='+encodeURIComponent(ref(cur)),'_blank')};
async function loadActivity(){var box=$('deliveryActivity');box.textContent='';if(!cur||!cur.id||cur.status!=='approved')return;try{var id=cur.id,r=await API.activity(id);if(!cur||cur.id!==id)return;
 var L=r.deliveries.map(function(d){return (d.method==='email'?'✉ Email':'WhatsApp')+': '+(d.status==='sent'?'sent to provider (delivery not confirmed)':d.status==='opened'?'opened in '+(d.method==='email'?'email app':'WhatsApp')+', you press Send (not confirmed)':d.status)+' — '+d.recipient+(d.error?' — '+d.error:'')});
 if(r.prints.length)L.push('🖨 Print started '+r.prints.length+'× (paper output not confirmed)');box.textContent=L.join('\n')}catch(e){box.textContent=''}}
/* ---- WhatsApp: number -> confirm -> the SERVER sends the invoice PDF through the WhatsApp Business (Meta Cloud) API.
   No share sheet, no wa.me link, nothing to press in WhatsApp. "Sent" is shown only when WhatsApp accepted it. ---- */
$('aWa').onclick=async function(){
 if(cur.status!=='approved'){msg('Approve this invoice first, then send it by WhatsApp. / وافق على الفاتورة أوّل، بعدين ابعتها عالواتساب.');$('sAppr').focus();return}
 var saved=await savedContact('whatsapp');                 /* saved number: straight to the confirmation */
 if(saved){var p=/^\+/.test(saved)?Phone.split(saved):{cc:Phone.DEFAULT,national:saved},v=Phone.validate(p.cc,p.national);if(v.ok){waPreview(v.e164);return}}
 waNumber(lastPhone||saved||'')};
function waNumber(pre){
 var p=/^\+/.test(pre)?Phone.split(pre):{cc:Phone.DEFAULT,national:pre};
 modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> Send via WhatsApp</h3><div class="msteps"><b class="on">1 Number</b><b>2 Confirm</b><b>3 Sent</b></div>'+
  '<label class="mlab" for="waNum">What\'s the customer\'s WhatsApp number? / <bdi lang="ar">شو رقم واتساب الزبون؟</bdi></label>'+
  '<div class="ph wa-ph"><select id="waCc" aria-label="Country code"></select><input id="waNum" type="tel" inputmode="tel" autocomplete="off" placeholder="71 123 456" value="'+esc(p.national)+'" aria-describedby="waErr"></div>'+
  '<small class="ferr2" id="waErr" role="alert"></small><p class="muted small">Choose the country code, then the number. / <bdi lang="ar">اختار رمز البلد وبعدين الرقم.</bdi></p>'+
  '<div class="mact"><button class="btn" data-m="no">Cancel</button><button class="btn pri" id="waNext">Next <i data-lucide="arrow-right"></i></button></div>');
 Phone.fillSelect($('waCc'),p.cc);$('waNum').focus();
 function next(){var v=Phone.validate($('waCc').value,$('waNum').value);
  if(v.ok&&$('waCc').value==='+961'&&v.type!=='mobile')v={ok:false,message:'WhatsApp needs a mobile number, e.g. 71 123 456 or 03 123 456 (not a landline).'};
  if(!v.ok){$('waErr').textContent=v.message;$('waNum').setAttribute('aria-invalid','true');$('waNum').focus();return}
  lastPhone=v.e164;waPreview(v.e164)}
 $('waNext').onclick=next;$('waNum').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();next()}};
 $('waNum').oninput=function(){$('waErr').textContent='';this.removeAttribute('aria-invalid')}}
function notConfigured(kind){var miss=(DELIVERY[kind]&&DELIVERY[kind].missing)||[];
 return '<div class="mnote warn" role="status"><b>'+(kind==='whatsapp'?'Direct WhatsApp sending is not set up on the server.':'Direct email sending is not set up on the server.')+'</b><br>'+
  (kind==='whatsapp'?'MA sends the PDF itself only through an authorized WhatsApp Business account (Meta WhatsApp Cloud API). ':'MA sends the PDF itself only through an authorized mail server (SMTP). ')+
  'Ask the administrator to add these settings to the server\'s private <code>.env</code> file'+(miss.length?': <code>'+miss.map(esc).join(', ')+'</code>':'')+', then restart it. Nothing has been sent.'+
  '<br><bdi lang="ar">'+(kind==='whatsapp'?'الإرسال المباشر عالواتساب مش مفعّل بالسيرفر.':'الإرسال المباشر بالإيميل مش مفعّل بالسيرفر.')+' ما انبعت شي.</bdi></div>'}
function pdfView(ref1){return async function(){var w=window.open('','_blank');try{var f=await API.pdfFile(ref1);var u=URL.createObjectURL(f);if(w)w.location=u;else location.assign(u);setTimeout(function(){URL.revokeObjectURL(u)},60000)}catch(e){if(w)w.close();alert(e.message)}}}
/* WhatsApp message for Method A (the chat opens with it ready). It never claims the PDF is attached:
   a WhatsApp link can carry text only, the employee attaches the PDF in the chat. */
function waText(){var d=cur,t=d.totals||{},co={name:DB.company.name||coOf(d).name,phone:DB.company.phone||coOf(d).phone},L=[];
 L.push('Hello'+(d.cust.name?' '+d.cust.name:'')+',','','This is '+co.name+'. Your invoice *'+d.no+'* is ready.');
 if(d.truck.plate||d.truck.model)L.push('Truck: '+[d.truck.plate,d.truck.model].filter(Boolean).join(' - '));
 L.push('');d.items.forEach(function(it){L.push('• '+it.d+(isLabor(it)?'':' × '+it.q)+': '+invoiceUsd(it.total_usd!=null?it.total_usd:it.q*it.p))});
 L.push('','*Total: '+invoiceUsd(t.total_usd)+'* ('+lbp(t.total_lbp)+')','','The invoice PDF ('+d.no+'.pdf) follows in this chat.','','Thank you for choosing '+co.name+'.'+(co.phone?'\n'+Phone.pretty(co.phone):''));
 return L.join('\n')}
function waLink(e164,text){return 'https://wa.me/'+e164.replace(/\D/g,'')+'?text='+encodeURIComponent(text)}
/* method: '' (let the employee choose) | 'chat' (Method A) | 'direct' (Method B, only with the WhatsApp Business API) */
function waPreview(e164,method){var d=cur,t=d.totals||{},ref1=ref(cur),api=WA_API===true,pdfOk=null;
 if(method==='direct'&&!api)method='chat';
 var rows=d.items.map(function(it){return '<tr><td>'+itemLabel(it)+'</td><td class="r">'+(isLabor(it)?'—':esc(it.q))+'</td><td class="r">'+invoiceUsd(it.total_usd)+'</td></tr>'}).join('');
 modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> Send via WhatsApp</h3><div class="msteps"><b class="done">1 Number</b><b class="on">2 Confirm</b><b>3 Send</b></div>'+
  '<dl class="mdl"><dt>Customer</dt><dd dir="ltr">'+esc(Phone.pretty(e164))+'</dd><dt>Invoice</dt><dd>'+esc(d.no)+' · '+esc(d.cust.name||'—')+'</dd><dt>Total</dt><dd>'+invoiceUsd(t.total_usd)+' / '+lbp(t.total_lbp)+'</dd><dt>PDF</dt><dd id="waPdfState">Preparing '+esc(d.no)+'.pdf…</dd></dl>'+
  '<div class="tw mtab"><table><thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Total</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
  '<div class="wa-methods" role="radiogroup" aria-label="Sending method">'+
   '<label class="wa-m"><input type="radio" name="waM" value="chat"><span><b>Open WhatsApp chat</b><small>WhatsApp opens the customer\'s chat with the message ready. <b>WhatsApp links can\'t attach files</b>: download the PDF, attach it in the chat (📎 → Document), then press Send.</small></span></label>'+
   '<label class="wa-m'+(api?'':' off')+'"><input type="radio" name="waM" value="direct"'+(api?'':' disabled')+'><span><b>Send PDF directly</b><small>'+(api?'MA sends the PDF itself from the garage\'s WhatsApp Business account. Nothing to do in WhatsApp.':'Not available: the WhatsApp Business Platform is not connected on the server.')+'</small></span></label></div>'+
  '<div id="waChatBox"><label class="mlab" for="waMsg">Message / <bdi lang="ar">الرسالة</bdi></label><textarea id="waMsg" class="mtext" rows="7">'+esc(waText())+'</textarea></div>'+
  (api?'':'<p class="muted small">Direct sending needs <code>'+esc(((DELIVERY.whatsapp||{}).missing||[]).join(', ')||'WhatsApp Business API settings')+'</code> in the server\'s .env, so manual attachment is required. <bdi lang="ar">الإرسال المباشر مش موصول، لازم ترفق الـ PDF بإيدك.</bdi></p>')+
  '<small class="ferr2" id="waSendErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" id="waBack"><i data-lucide="pencil"></i> Change number</button><button class="btn" data-m="no">Cancel</button><button class="btn" id="waPdf"><i data-lucide="download"></i> Download PDF</button><button class="btn wa" id="waGo"><i data-lucide="send"></i> <span id="waGoTxt">Open WhatsApp chat</span></button></div>');
 var pick=method||(api?'':'chat');[].forEach.call(document.querySelectorAll('input[name="waM"]'),function(r){r.checked=r.value===pick;r.onchange=sync});
 function chosen(){var r=document.querySelector('input[name="waM"]:checked');return r?r.value:''}
 function sync(){var m=chosen();$('waChatBox').hidden=m!=='chat';$('waGo').disabled=!m||pdfOk===false;$('waGoTxt').textContent=m==='direct'?'Send now':m==='chat'?'Open WhatsApp chat':'Choose a method';$('waSendErr').textContent=''}
 sync();
 /* the real PDF is generated/loaded first: if that fails, nothing can be sent */
 API.pdfFile(ref1).then(function(f){pdfOk=true;var s=$('waPdfState');if(s)s.textContent='📎 '+f.name+' ('+Math.max(1,Math.round(f.size/1024))+' KB), the approved invoice';sync()},
  function(e){pdfOk=false;var s=$('waPdfState');if(s)s.textContent='PDF could not be generated';var er=$('waSendErr');if(er)er.textContent='The invoice PDF could not be generated: '+(e.message||'')+' Nothing can be sent.';sync()});
 $('waBack').onclick=function(){waNumber(e164)};$('waPdf').onclick=pdfFromModal;
 $('waGo').onclick=async function(){var b=this,m=chosen();if(b.disabled||!m)return;$('waSendErr').textContent='';
  if(m==='chat'){var text=$('waMsg').value.trim()||waText();
   var w=window.open(waLink(e164,text),'_blank');if(w)try{w.opener=null}catch(x){}
   API.handoff(ref1,'whatsapp',e164).then(loadActivity).catch(function(){});
   actUpdate({key:'send_whatsapp',status:'completed',en:'Opened the WhatsApp chat (you attach the PDF and press Send)',ar:'فتحت محادثة الواتساب (إنت بترفق الـ PDF وبتبعت)',detail:Phone.pretty(e164)});
   waOpened(e164,text,!w);return}
  b.disabled=true;b.classList.add('busy');actUpdate({key:'send_whatsapp',status:'processing',detail:Phone.pretty(e164)});
  try{var r=await deliverNow('whatsapp',e164);if(!r){b.disabled=false;b.classList.remove('busy');actUpdate({key:'send_whatsapp',status:'pending',detail:''});return}
   if(r.status!=='sent')throw Error(r.error||'WhatsApp did not accept the invoice. Nothing was sent.');
   actUpdate({key:'send_whatsapp',status:'completed',detail:'WhatsApp accepted it · '+Phone.pretty(e164)});
   sentDone('whatsapp',Phone.pretty(e164),r)}
  catch(e){b.disabled=false;b.classList.remove('busy');$('waSendErr').textContent=e.message||'WhatsApp sending failed.';actUpdate({key:'send_whatsapp',status:'failed',error:e.message||''})}}}
/* Method A result: the chat was opened; MA never claims the PDF was attached or sent */
function waOpened(e164,text,blocked){var link=waLink(e164,text);
 modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> WhatsApp chat opened</h3><div class="msteps"><b class="done">1 Number</b><b class="done">2 Confirm</b><b class="on">3 Send</b></div>'+
  '<div class="mnote warn"><b>Not sent yet.</b> In the chat with <b dir="ltr">'+esc(Phone.pretty(e164))+'</b>: attach <b>'+esc(cur.no)+'.pdf</b> (📎 → Document), check the message, then press <b>Send</b>.<br><bdi lang="ar">لسّا ما انبعتت. بالمحادثة: رفّق الـ PDF (📎 ← مستند) واضغط «إرسال».</bdi></div>'+
  (blocked?'<p class="muted small">If WhatsApp did not open, your browser blocked the new window: use the button below.</p>':'')+
  '<div class="mact"><a class="btn wa" href="'+esc(link)+'" target="_blank" rel="noopener"><i data-lucide="external-link"></i> Open chat again</a><button class="btn" id="waPdf2"><i data-lucide="download"></i> Download PDF</button><button class="btn pri" data-m="no">Done</button></div>');
 $('waPdf2').onclick=pdfFromModal;msg('WhatsApp chat opened for '+Phone.pretty(e164)+'. Attach the PDF and press Send there: MA did not send it.')}
function sentDone(kind,who,r){var wa=kind==='whatsapp';
 modal('<h3 id="mTitle"'+(wa?'':' class="mail-h"')+'><i data-lucide="'+(wa?'check-circle-2':'mail-check')+'"></i> '+(wa?'Invoice sent on WhatsApp':'Email sent')+'</h3><div class="msteps'+(wa?'':' mail')+'"><b class="done">1 '+(wa?'Number':'Email')+'</b><b class="done">2 Confirm</b><b class="done on">3 Sent</b></div>'+
  '<div class="mnote ok"><b>'+esc(wa?'WhatsApp accepted the invoice PDF for '+who+'.':'The mail server accepted the email to '+who+' with the PDF attached.')+'</b><br><bdi lang="ar">'+(wa?'واتساب استلم الفاتورة للإرسال.':'سيرفر الإيميل استلم الرسالة مع الفاتورة.')+'</bdi></div>'+
  '<p class="muted small">'+(wa?'Final delivery to the phone is shown in your WhatsApp Business account.':'Final delivery depends on the customer\'s email provider.')+(r&&r.provider_id?' Reference: <code>'+esc(String(r.provider_id).slice(0,60))+'</code>':'')+'</p>'+
  '<div class="mact"><button class="btn pri" data-m="no">Done</button></div>');
 msg((wa?'WhatsApp accepted the invoice PDF for ':'Email accepted by the mail server for ')+who+'.')}
/* ---- MA commands: "send it on WhatsApp to 03 123 456", "email it to name@gmail.com" ---- */
var pendingShare=null,lastPhone='',lastEmail='',EMAIL_OK=null,WA_API=null,DELIVERY={};
function share(a,ar){
 if(a.phone)lastPhone=a.phone;if(a.email)lastEmail=a.email;
 if(!a.phone&&!a.email)return;                       /* MA asked for the missing number/email */
 var what=a.type==='email'?(ar?'الإيميل':'the email'):'WhatsApp',who=a.phone?Phone.pretty(a.phone):a.email;
 if(!cur){bubble('ai',ar?'ما في فاتورة مفتوحة. حضّر فاتورة أو افتح وحدة (مثلاً «افتحلي الفاتورة 3»)، وبعدين قلّي لوين إبعتها.':'There\'s no invoice open. Create or open one (e.g. "open invoice 3"), then tell me where to send it.');return}
 if(cur.status!=='approved'){pendingShare=a;
  bubble('ai',ar?'الفاتورة لسّا قيد الانتظار. وافق عليها (زر Approve على اليمين) وبحضّرلك الإرسال لـ '+who+' مباشرة.':'This invoice is still Pending. Approve it (Approve button on the right) and I\'ll get it ready to send to '+who+' right away.');
  $('sAppr').classList.add('nudge');setTimeout(function(){$('sAppr').classList.remove('nudge')},2400);return}
 if(a.type==='whatsapp'){var p=Phone.split(a.phone),v=Phone.validate(p.cc,p.national);if(v.ok)waPreview(v.e164,a.method||'');else waNumber(a.phone)}
 else{if(EMAIL_RE.test(a.email))emailPreview(a.email);else emailAddress(a.email)}}
/* ---- Email: address -> confirm -> the SERVER sends it with the PDF attached (SMTP). ---- */
var EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
API.deliveryConfig().then(function(r){DELIVERY=r||{};EMAIL_OK=!!(r.email&&r.email.configured);WA_API=!!(r.whatsapp&&r.whatsapp.configured)}).catch(function(){EMAIL_OK=false;WA_API=false});
/* has this exact recipient already been sent to? then the server needs an explicit resend */
async function alreadySent(method,to){try{var a=await API.activity(ref(cur));return a.deliveries.some(function(d){return d.method===method&&d.recipient===to&&d.status==='sent'})}catch(e){return false}}
async function deliverNow(method,to,extra){var resend=await alreadySent(method,to);
 if(resend&&!(await ask({title:'Send again?',body:'<p>This invoice was already sent to <b>'+esc(to)+'</b>. Send another copy?</p>',ok:'Send again'})))return null;
 var r=await API.deliver(ref(cur),method,Object.assign({to:to,confirm:true,resend:resend,request_key:rid()},extra||{}));loadActivity();return r}
/* the email message: garage name from the registered account (editable in the preview) */
function emailText(){var co=DB.company.name||coOf(cur).name||'Our garage';
 return 'Dear Customer,\n\nPlease find attached your invoice from '+co+'.\n\nThank you for choosing our services.\n\nBest regards,\n'+co}
function emailSubject(){return 'Invoice #'+cur.no+' — '+(DB.company.name||coOf(cur).name)}
function emailAddress(pre){
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Send via Email</h3><div class="msteps mail"><b class="on">1 Email</b><b>2 Confirm</b><b>3 Sent</b></div>'+
  '<label class="mlab" for="emTo">What\'s the customer\'s email address? / <bdi lang="ar">شو إيميل الزبون؟</bdi></label>'+
  '<div class="wa-ph"><input id="emTo" type="email" inputmode="email" autocomplete="off" placeholder="name@gmail.com" value="'+esc(pre)+'" aria-describedby="emErr"></div>'+
  '<small class="ferr2" id="emErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" data-m="no">Cancel</button><button class="btn pri" id="emNext">Next <i data-lucide="arrow-right"></i></button></div>');
 $('emTo').focus();
 function next(){var v=$('emTo').value.trim();
  if(!EMAIL_RE.test(v)){$('emErr').textContent='Enter a valid email address, e.g. name@gmail.com.';$('emTo').setAttribute('aria-invalid','true');$('emTo').focus();return}
  lastEmail=v;emailPreview(v)}
 $('emNext').onclick=next;$('emTo').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();next()}};
 $('emTo').oninput=function(){$('emErr').textContent='';this.removeAttribute('aria-invalid')}}
function emailPreview(to){var d=cur,t=d.totals||{},ok=EMAIL_OK===true;
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Confirm email sending</h3><div class="msteps mail"><b class="done">1 Email</b><b class="on">2 Confirm</b><b>3 Sent</b></div>'+
  '<dl class="mdl"><dt>Recipient</dt><dd>'+esc(to)+'</dd><dt>Invoice</dt><dd>'+esc(d.no)+' · '+esc(d.cust.name||'—')+'</dd><dt>Total</dt><dd>'+invoiceUsd(t.total_usd)+' / '+lbp(t.total_lbp)+'</dd>'+
  '<dt>From</dt><dd>'+esc(DB.company.name||coOf(d).name||'')+'</dd><dt>Attachment</dt><dd>📎 '+esc(d.no)+'.pdf (the approved invoice PDF)</dd></dl>'+
  '<label class="mlab" for="emSub">Subject</label><div class="wa-ph"><input id="emSub" value="'+esc(emailSubject())+'"></div>'+
  '<label class="mlab" for="emBody" style="margin-top:10px">Message</label><textarea id="emBody" class="mtext" rows="8">'+esc(emailText())+'</textarea>'+
  (ok?'<p class="muted small">When you press <b>Confirm</b>, the server emails this message with the PDF attached. The invoice number is always kept in the subject.</p>':notConfigured('email'))+
  '<small class="ferr2" id="emSendErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" id="emBack"><i data-lucide="arrow-left"></i> Back</button><button class="btn" data-m="no">Cancel</button><button class="btn" id="emPdf"><i data-lucide="download"></i> PDF</button>'+
  (ok?'':'<button class="btn" id="emApp" title="Opens your own email app; you attach the PDF and press Send there">Use my email app</button>')+
  '<button class="btn pri" id="emGo"'+(ok?'':' disabled title="Email sending is not configured on the server"')+'><i data-lucide="send"></i> Confirm</button></div>');
 $('emBack').onclick=function(){emailAddress(to)};
 $('emPdf').onclick=pdfFromModal;
 if(!ok)$('emApp').onclick=function(){mailApp(to,$('emSub').value.trim()||emailSubject(),$('emBody').value)};
 $('emGo').onclick=async function(){var b=this;if(b.disabled)return;var sub=$('emSub').value.trim()||emailSubject(),body=$('emBody').value;
  b.disabled=true;b.classList.add('busy');$('emSendErr').textContent='';actUpdate({key:'send_email',status:'processing',detail:to});
  try{var r=await deliverNow('email',to,{subject:sub,message:body});if(!r){b.disabled=false;b.classList.remove('busy');actUpdate({key:'send_email',status:'pending',detail:''});return}
   if(r.status!=='sent')throw Error(r.error||'The email could not be sent. Nothing was sent.');
   actUpdate({key:'send_email',status:'completed',detail:'Accepted by the mail server · '+to});sentDone('email',to,r)}
  catch(e){b.disabled=false;b.classList.remove('busy');$('emSendErr').textContent=e.message||'The email could not be sent.';actUpdate({key:'send_email',status:'failed',error:e.message||''})}}}
function mailApp(to,sub,body){
 var link='mailto:'+to+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(body);
 var a=document.createElement('a');a.href=link;document.body.appendChild(a);a.click();a.remove();
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Your email app is opening</h3>'+
  '<p>The message to <b>'+esc(to)+'</b> is ready in your own email app. <b>MA has not sent anything</b>: attach the PDF (download it below) and press Send there.</p><p dir="rtl">MA ما بعت شي. نزّل الـ PDF وزيدو كمرفق، وبعدين اضغط إرسال ببرنامج الإيميل.</p>'+
  '<div class="mact"><a class="btn mailb" href="'+esc(link)+'"><i data-lucide="external-link"></i> Open email app again</a><button class="btn" id="emPdf2"><i data-lucide="download"></i> Download PDF</button><button class="btn pri" data-m="no">Done</button></div>');
 $('emPdf2').onclick=pdfFromModal;msg('Your email app opened. MA did not send this email: attach the PDF and press Send there.');
 API.handoff(ref(cur),'email',to).then(loadActivity).catch(function(){})}
async function pdfFromModal(){var b=this;b.disabled=true;try{await API.downloadPdf(ref(cur),cur.status!=='approved')}catch(e){alert(e.message)}finally{b.disabled=false}}
/* ---- small modal used for confirmations and WhatsApp ---- */
var modalCancel=null,lastFocus=null;
function modal(html){var m=$('modal');if(m.hidden)lastFocus=document.activeElement;$('mbox').innerHTML=html;m.hidden=false;icons();
 $('mbox').onclick=function(e){var b=e.target.closest('[data-m="no"]');if(b)closeModal()}}
function closeModal(){var m=$('modal');if(m.hidden)return;m.hidden=true;$('mbox').innerHTML='';var c=modalCancel;modalCancel=null;if(c)c();if(lastFocus&&lastFocus.focus)lastFocus.focus()}
function ask(o){return new Promise(function(res){
 modal('<h3 id="mTitle">'+esc(o.title)+'</h3><div class="mbody">'+o.body+'</div><div class="mact"><button class="btn" data-m="no">'+(o.no||'Cancel')+'</button><button class="btn pri" id="mYes">'+esc(o.ok)+'</button></div>');
 modalCancel=function(){res(false)};$('mYes').focus();$('mYes').onclick=function(){modalCancel=null;closeModal();res(true)}})}
$('modal').addEventListener('mousedown',function(e){if(e.target===this)closeModal()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('modal').hidden){e.stopPropagation();closeModal()}},true);
/* ---- pages ---- */
function table(hd,rows){return '<div class="tw"><table><thead><tr>'+hd.map(function(x){return '<th>'+x+'</th>'}).join('')+'</tr></thead><tbody>'+(rows||'<tr><td colspan="'+hd.length+'" class="muted">Nothing here yet.</td></tr>')+'</tbody></table></div>'}
function badge(s){return '<span class="badge-s '+LBL[s][1]+'">'+LBL[s][0]+'</span>'}
function totCell(c){var t=c.totals;return t?usd(t.total_usd)+'<small class="lbp-s">'+lbp(t.total_lbp)+'</small>':'—'}
function invRows(L,acts){return L.map(function(c){return '<tr><td>'+esc(c.no)+'</td><td>'+esc(c.cust.name||'-')+'</td><td>'+esc(c.truck.plate||'-')+'</td><td class="r">'+totCell(c)+'</td><td>'+badge(c.status)+'</td><td>'+dlvCell(c)+'</td><td class="r">'+acts(c)+'</td></tr>'}).join('')}
var IH=['No.','Customer','Truck','Total','Status','Delivery',''];
var DLV={not_sent:'Not sent',sending:'Sending…',sent:'Sent',failed:'Failed',opened:'Opened in app'};
function dlvCell(c){if(c.status!=='approved'||!c.delivery)return '—';return '<small class="dlv">✉ '+DLV[c.delivery.email]+'<br>WA '+DLV[c.delivery.whatsapp]+'</small>'}
function op(c){return '<button class="btn sm" data-open="'+esc(ref(c))+'">Open</button>'+(c.status==='approved'?' <button class="btn sm" data-pdf="'+esc(ref(c))+'" title="Download PDF">PDF</button> <button class="btn sm" data-print="'+esc(ref(c))+'" title="Print">Print</button>':'')}
function histRows(){var q=($('q')||{value:''}).value.toLowerCase(),f=($('fs')||{value:''}).value,from=($('fromDate')||{value:''}).value,to=($('toDate')||{value:''}).value;return invRows(DB.invoices.slice().reverse().filter(function(c){return(!from||String(c.date).slice(0,10)>=from)&&(!to||String(c.date).slice(0,10)<=to)&&(!f||c.status===f)&&(!q||(c.no+' '+c.cust.name+' '+c.truck.plate).toLowerCase().indexOf(q)>=0)}),op)}
async function openPage(i){curPage=i;view('pg',{0:0,3:2,4:3,7:4}[i]);
 if(i===4&&!can('invoice.approve')){pg.innerHTML=denied('Pending Approvals');return}
 pg.innerHTML='<p class="muted">Loading...</p>';
 try{await refresh()}catch(e){pg.innerHTML='<h2>Backend unavailable</h2><p>'+esc(e.message)+'</p>';return}
 var L=DB.invoices.slice().reverse(),h='',n=function(s){return L.filter(function(c){return c.status===s}).length};
 if(i===0){var td=new Date().toDateString();h='<div class="dash-wel"><h2>Welcome to MA</h2><p>Your AI-powered invoice assistant is ready.</p></div><div class="qa"><button class="btn pri sm" data-go="1">Talk with AI</button>'+(can('invoice.approve')?'<button class="btn sm" data-go="3">Pending approvals</button>':'')+'<button class="btn sm" data-go="2">Invoice history</button></div><div class="stats"><div><h3>Today</h3><b>'+L.filter(function(c){return new Date(c.date).toDateString()===td}).length+'</b></div><div><h3>Pending</h3><b>'+n('pending')+'</b></div><div><h3>Approved</h3><b>'+n('approved')+'</b></div></div><h3>Recent invoices</h3>'+table(IH,invRows(L.slice(0,5),op))}
 else if(i===3)h='<h2>Invoice History</h2><div class="bar"><input id="q" placeholder="Search by number, customer or plate..."><input type="date" id="fromDate" aria-label="From date" title="From date"><input type="date" id="toDate" aria-label="To date" title="To date"><select id="fs"><option value="">All statuses</option><option value="draft">Draft</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div><div id="list">'+table(IH,histRows())+'</div>';
 else if(i===4)h='<h2>Pending Approvals</h2>'+table(IH,invRows(L.filter(function(c){return c.status==='pending'}),function(c){return op(c)+' <button class="btn sm pri" data-ap="'+esc(ref(c))+'">Approve</button> <button class="btn sm" data-rj="'+esc(ref(c))+'">Reject</button>'}))+'<div class="pmsg" role="status"></div>';
 else if(i===5)h='<h2>Customers</h2>'+table(['Name','Contact','Phone','Email'],DB.customers.map(function(c){return '<tr><td>'+esc(c.name)+'</td><td>'+esc(c.contact)+'</td><td>'+esc(c.tel)+'</td><td>'+esc(c.email)+'</td></tr>'}).join(''));
 else if(i===6)h='<h2>Garage Catalog</h2><p class="muted">Read from the backend. Prices are validated there.</p>'+table(['Item','Type','Price (USD)'],DB.catalog.map(function(c){return '<tr><td>'+esc(c[0])+'</td><td>'+esc(c[1])+'</td><td>'+usd(c[2])+'</td></tr>'}).join(''));
 else {pg.innerHTML=Settings.html();Settings.init();icons();return}
 pg.innerHTML=h}
function find(r){return DB.invoices.find(function(c){return String(ref(c))===String(r)})}
pg.addEventListener('input',function(e){if(['q','fs','fromDate','toDate'].indexOf(e.target.id)>=0)$('list').innerHTML=table(IH,histRows())});
pg.addEventListener('click',async function(e){var b=e.target.closest('button');if(!b)return;var d=b.dataset;
 if(d.pdf){b.disabled=true;try{await API.downloadPdf(d.pdf,false)}catch(er){alert(er.message)}finally{b.disabled=false}return}
 if(d.print){window.open('/print.html?invoice='+encodeURIComponent(d.print),'_blank');return}

 if(d.go)NB[+d.go].click();
 else if(d.open){b.disabled=true;try{show(clone(await API.getInvoice(d.open)),1)}catch(er){var c=find(d.open);if(c)show(clone(c),1);else alert(er.message)}finally{b.disabled=false}}
 else if(d.ap||d.rj){var m=pg.querySelector('.pmsg');try{if(d.ap){var reviewed=await API.getInvoice(d.ap);if(!confirm('Approve '+reviewed.no+' for '+reviewed.cust.name+'?\nTotal: '+usd(reviewed.totals.total_usd)+' / '+lbp(reviewed.totals.total_lbp)+'\n'+(reviewed.warnings||[]).join('\n')))return;await API.approveInvoice(d.ap,reviewed);}else await API.rejectInvoice(d.rj);await openPage(curPage)}catch(er){m.textContent=er.message}}});
NB.forEach(function(b,i){b.onclick=function(){if(i===1)view('ai',1);else openPage([0,1,3,4,7][i])}});

/* ---- Settings: personal info, password, company profile ---- */
var Settings=(function(){
 var LOGO_TYPES=['image/png','image/jpeg','image/webp'],LOGO_MAX=2*1024*1024,unTimer=0,unOk=true,logoFile=null,removeLogo=false;
 function f(id,label,val,attrs){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><input id="'+id+'" value="'+esc(val)+'" '+(attrs||'')+'><small class="ferr2" id="'+id+'Err"></small></label>'}
 function phone(id,label,e164,dis){var p=Phone.split(e164);return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="ph"><select id="'+id+'Cc" '+dis+'></select><input id="'+id+'" type="tel" inputmode="tel" value="'+esc(p.national)+'" placeholder="71 123 456" '+dis+'></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function pw(id,label,ac){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="pwbox"><input id="'+id+'" type="password" autocomplete="'+ac+'"><button type="button" class="eye2" data-eye="'+id+'" aria-label="Show password"><i data-lucide="eye"></i></button></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function html(){var C=DB.company,own=can('company.manage'),dis=own?'':'disabled';
  return '<h2>Settings</h2>'+
  '<form class="sform" id="fMe" novalidate><h3>Personal information</h3><div class="sgrid">'+
   f('sFirst','First name',USER.firstName,'autocomplete="given-name" maxlength="50"')+f('sLast','Last name',USER.lastName,'autocomplete="family-name" maxlength="50"')+
   f('sUser','Username',USER.username,'autocomplete="username" maxlength="30" autocapitalize="none" spellcheck="false"')+phone('sPhone','Phone number',USER.phone,'')+
  '</div><div class="srow"><button class="btn pri sm" id="bMe">Save personal info</button><span class="smsg" id="mMe" role="status"></span></div></form>'+
  '<form class="sform" id="fPw" novalidate><h3>Change password</h3><div class="sgrid">'+
   pw('sCur','Current password','current-password')+'<span></span>'+pw('sNew','New password','new-password')+pw('sNew2','Confirm new password','new-password')+
  '</div><p class="muted small">At least 8 characters with an uppercase letter, a lowercase letter and a number.</p><div class="srow"><button class="btn pri sm" id="bPw">Change password</button><span class="smsg" id="mPw" role="status"></span></div></form>'+
  '<form class="sform" id="fCo" novalidate><h3>Company information</h3>'+(own?'':'<p class="muted small">Only the garage owner can change company information.</p>')+'<div class="sgrid">'+
   f('cName','Company name',C.name,'maxlength="120" '+dis)+phone('cPhone','Company phone number',C.phone,dis)+
  '</div><div class="logo-row"><div class="logo-prev" id="cLogoPrev">'+(C.logo?'<img src="'+esc(C.logo)+'" alt="Company logo">':'<span>No logo</span>')+'</div>'+
   (own?'<div><label class="btn sm file-btn"><input type="file" id="cLogo" accept="image/png,image/jpeg,image/webp" hidden>Upload logo</label> <button type="button" class="btn sm" id="cLogoRm"'+(C.logo?'':' hidden')+'>Remove</button><small class="muted small block">PNG, JPG or WebP, up to 2 MB. Shown on every invoice.</small><small class="ferr2" id="cLogoErr"></small></div>':'')+
  '</div><dl class="dl"><dt>VAT rate</dt><dd>'+(C.vat!=null?esc(C.vat)+'%':'Set by the backend')+'</dd><dt>Exchange rate</dt><dd>'+(C.rate?'1 USD = '+num(C.rate,0)+' LBP':'Set by the backend')+'</dd></dl>'+
  (own?'<div class="srow"><button class="btn pri sm" id="bCo">Save company info</button><span class="smsg" id="mCo" role="status"></span></div>':'')+'</form>'}
 function err(id,t){var e=$(id+'Err');if(e)e.textContent=t||'';var l=pg.querySelector('[data-f="'+id+'"]');if(l)l.classList.toggle('bad',!!t)}
 function note(id,t,ok){var m=$(id);m.textContent=t||'';m.className='smsg'+(ok?' ok':'')}
 function load(btn,on){btn.disabled=on;btn.classList.toggle('busy',on)}
 function serverErr(e,map,box){Object.keys(e.fields||{}).forEach(function(k){if(map[k])err(map[k],e.fields[k])});note(box,e.message)}
 var NAME=/^[\p{L}\p{M}][\p{L}\p{M}' .-]*$/u,PWR=function(p){return p.length>=8&&/[A-Z]/.test(p)&&/[a-z]/.test(p)&&/\d/.test(p)};
 function init(){unOk=true;logoFile=null;removeLogo=false;
  Phone.fillSelect($('sPhoneCc'),Phone.split(USER.phone).cc);Phone.fillSelect($('cPhoneCc'),Phone.split(DB.company.phone).cc);
  pg.querySelectorAll('[data-eye]').forEach(function(b){b.onclick=function(){var i=$(b.dataset.eye),s=i.type==='password';i.type=s?'text':'password';b.setAttribute('aria-label',s?'Hide password':'Show password');b.innerHTML='<i data-lucide="'+(s?'eye-off':'eye')+'"></i>';icons()}});
  /* username availability (only when it differs from the current one) */
  $('sUser').oninput=function(){var u=this;u.value=u.value.toLowerCase().replace(/\s/g,'');clearTimeout(unTimer);var v=u.value;
   if(v===USER.username){unOk=true;err('sUser','');return}
   if(!Auth.USERNAME_RE.test(v)){unOk=false;err('sUser','Use 3–30 letters, numbers, "_" or "." — start with a letter.');return}
   unOk=false;err('sUser','');$('sUserErr').textContent='Checking availability…';
   unTimer=setTimeout(async function(){try{var r=await Auth.checkUsername(v);if($('sUser').value!==v)return;unOk=r.available;
    if(r.available){$('sUserErr').innerHTML='<span class="okc">✓ Username is available</span>'}else err('sUser','⚠ Username is already taken'+(r.suggestions.length?' — try '+r.suggestions.slice(0,3).join(', '):''))}
    catch(e){unOk=true;$('sUserErr').textContent='Couldn’t check now; the server will confirm on save.'}},450)};
  $('fMe').onsubmit=async function(e){e.preventDefault();var b=$('bMe'),ok=true;note('mMe','');
   [['sFirst','first name'],['sLast','last name']].forEach(function(x){var v=$(x[0]).value.trim();var m=!v?'Please enter your '+x[1]+'.':!NAME.test(v)?'Use letters only.':'';err(x[0],m);if(m)ok=false});
   var ph=Phone.validate($('sPhoneCc').value,$('sPhone').value);err('sPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;
   if(!unOk){ok=false;if(!$('sUserErr').textContent)err('sUser','Choose an available username.')}
   if(!ok)return;load(b,true);
   try{await Auth.updateMe({first_name:$('sFirst').value.trim(),last_name:$('sLast').value.trim(),username:$('sUser').value.trim(),phone:ph.e164});applyUser();note('mMe','Saved.',true)}
   catch(er){if(er.status===409)err('sUser','⚠ Username is already taken');serverErr(er,{first_name:'sFirst',last_name:'sLast',username:'sUser',phone:'sPhone'},'mMe')}finally{load(b,false)}};
  $('fPw').onsubmit=async function(e){e.preventDefault();var b=$('bPw'),c=$('sCur').value,n=$('sNew').value,n2=$('sNew2').value,ok=true;note('mPw','');
   err('sCur',c?'':'Enter your current password.');if(!c)ok=false;
   var m=!n?'Enter a new password.':!PWR(n)?'Doesn’t meet the requirements below.':n===c?'Choose a different password.':'';err('sNew',m);if(m)ok=false;
   err('sNew2',n2===n?'':'Passwords don’t match.');if(n2!==n)ok=false;if(!ok)return;load(b,true);
   try{await Auth.changePassword(c,n);['sCur','sNew','sNew2'].forEach(function(i){$(i).value=''});note('mPw','Password changed. Other devices were signed out.',true)}
   catch(er){if(er.status===400||er.status===401&&er.code)err('sCur','Current password is incorrect.');serverErr(er,{current_password:'sCur',new_password:'sNew'},'mPw')}finally{load(b,false)}};
  if(!can('company.manage'))return;
  $('cLogo').onchange=function(){var fl=this.files[0];err('cLogo','');if(!fl)return;
   if(LOGO_TYPES.indexOf(fl.type)<0){err('cLogo','Please choose a PNG, JPG or WebP image.');this.value='';return}
   if(fl.size>LOGO_MAX){err('cLogo','The logo must be 2 MB or smaller.');this.value='';return}
   logoFile=fl;removeLogo=false;var u=URL.createObjectURL(fl);$('cLogoPrev').innerHTML='<img src="'+u+'" alt="New logo preview">';$('cLogoRm').hidden=false};
  $('cLogoRm').onclick=function(){logoFile=null;removeLogo=true;$('cLogo').value='';$('cLogoPrev').innerHTML='<span>No logo</span>';this.hidden=true};
  $('fCo').onsubmit=async function(e){e.preventDefault();var b=$('bCo'),nm=$('cName').value.trim().replace(/\s+/g,' '),ok=true;note('mCo','');
   err('cName',nm.length<2?'Please enter the company name.':'');if(nm.length<2)ok=false;
   var ph=Phone.validate($('cPhoneCc').value,$('cPhone').value);err('cPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;if(!ok)return;
   var fd=new FormData();fd.append('name',nm);fd.append('phone',ph.e164);if(logoFile)fd.append('logo',logoFile);if(removeLogo)fd.append('remove_logo','1');
   load(b,true);try{DB.company=normCo(await API.updateCompany(fd));applyCompany();logoFile=null;removeLogo=false;note('mCo','Saved. The homepage and new invoices now use this information.',true)}
   catch(er){serverErr(er,{name:'cName',phone:'cPhone',logo:'cLogo'},'mCo')}finally{load(b,false)}}}
 return {html:html,init:init}})();

loadCompany().catch(function(e){say(e.message)});refresh().catch(function(e){say(e.message)});resetChat();icons();
});
