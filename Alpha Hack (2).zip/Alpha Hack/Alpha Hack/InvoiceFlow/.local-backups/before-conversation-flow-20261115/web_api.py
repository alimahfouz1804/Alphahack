"""Web-app API for the InvoiceFlow AI frontend (frontend/ folder).

Adds, next to the existing Flask routes:
  - username + password accounts with HttpOnly cookie sessions and a CSRF token
  - companies (name, phone, logo, VAT) - each signup creates its own company
  - invoices in the frontend's shape with server-side USD + LBP totals
  - POST /api/invoices/generate: runs the existing Gemini agent (invoice_engine.create_invoice)
  - serves the frontend pages from frontend/ so everything runs on one origin

The existing Bearer-token employee routes (workflow_routes.py) keep working unchanged.
"""
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
import contextvars
import concurrent.futures
import queue
import threading
from contextlib import contextmanager
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path

from flask import request, jsonify, current_app, g, send_from_directory, redirect, Response, abort, send_file, copy_current_request_context
from werkzeug.exceptions import HTTPException
from io import BytesIO
from pdf_invoice import invoice_pdf
from werkzeug.security import generate_password_hash, check_password_hash

import delivery_providers
import invoice_services
import invoice_validation
import truck_memory
import part_lookup
from ai_agent import GeminiUnavailable
from database import load_products, get_product_by_id
from itsdangerous import URLSafeTimedSerializer, BadSignature
PROPOSALS = URLSafeTimedSerializer(secrets.token_hex(32), salt="invoice-part-confirmation")

BASE = Path(__file__).parent
FRONTEND = BASE / "frontend"

# Fixed project exchange rate (not a market rate). Override with EXCHANGE_RATE_LBP in .env.
EXCHANGE_RATE = Decimal(str(json.loads((BASE / "products.json").read_text(encoding="utf-8"))["currency"]["sample_exchange_rate_lbp_per_usd"]))
DEFAULT_VAT = Decimal("0")

SESSION_COOKIE, CSRF_COOKIE, CSRF_HEADER = "if_session", "if_csrf", "X-CSRF-Token"
REMEMBER_SECONDS, SESSION_SECONDS = 30 * 24 * 3600, 12 * 3600

USERNAME_RE = re.compile(r"^[a-z](?!.*[_.]{2})[a-z0-9_.]{1,28}[a-z0-9]$")
NAME_RE = re.compile(r"^[^\W\d_]+(?:[ '\-.][^\W\d_]+)*\.?$", re.UNICODE)
LB_PHONE_RE = re.compile(r"^\+961(3\d{6}|(70|71|76|78|79|81)\d{6}|[14-9]\d{6})$")
E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")

OWNER_PERMS = ["ai.chat", "invoice.create", "invoice.edit", "invoice.submit", "invoice.history", "account.edit",
               "invoice.history.all", "invoice.approve", "invoice.reject", "invoice.send", "company.manage"]
EMPLOYEE_PERMS = OWNER_PERMS[:6]
CSRF_EXEMPT = {"/api/auth/login", "/api/auth/register", "/api/auth/password/forgot", "/api/auth/password/reset"}

_failures = {}  # simple in-memory login limiter: key -> (count, reset_at)


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS companies(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
  logo BLOB, logo_type TEXT, logo_ver TEXT, vat_rate TEXT NOT NULL DEFAULT '0', created_at REAL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  first_name TEXT NOT NULL, last_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'employee',
  is_active INTEGER NOT NULL DEFAULT 1, created_at REAL);
CREATE TABLE IF NOT EXISTS web_sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires REAL NOT NULL, remember INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS reset_codes(
  user_id INTEGER PRIMARY KEY, code_hash TEXT NOT NULL, expires REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS web_invoices(
  id TEXT PRIMARY KEY, company_id INTEGER NOT NULL, seq INTEGER NOT NULL, no TEXT NOT NULL,
  created_by INTEGER NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL,
  created_at REAL NOT NULL, updated_at REAL NOT NULL, approved_by INTEGER, approved_at REAL,
  UNIQUE(company_id, seq));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, invoice_id TEXT, employee TEXT, action TEXT, at REAL);
"""


def db_path():
    return current_app.config["INVOICE_DB"]


@contextmanager
def connect(path=None):
    db = sqlite3.connect(path or db_path(), timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA + invoice_services.SCHEMA + truck_memory.SCHEMA)
    try:
        with db:
            yield db
    finally:
        db.close()


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


# ---------------------------------------------------------------- helpers
def err(status, message, fields=None, code=None):
    detail = message if not (fields or code) else {"message": message, "fields": fields or {}, "code": code or ""}
    return jsonify(detail=detail), status


def err_response(status, message, code=None):
    response, _ = err(status, message, code=code)
    response.status_code = status
    return response


def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def text(value, limit):
    return value.strip()[:limit] if isinstance(value, str) else ""


def money(value):
    return float(value)


def q2(value):
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def valid_phone(phone):
    return isinstance(phone, str) and (LB_PHONE_RE.match(phone) if phone.startswith("+961") else E164_RE.match(phone))


def check_password_rules(password, username=""):
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        return "Password must be 8-128 characters."
    if not (re.search(r"[A-Z]", password) and re.search(r"[a-z]", password) and re.search(r"\d", password)):
        return "Password needs an uppercase letter, a lowercase letter and a number."
    if username and len(username) >= 3 and username.lower() in password.lower():
        return "Password must not contain the username."
    return ""


def user_json(row, company):
    role = "owner" if row["role"] == "owner" else "employee"
    return {"user": {
        "id": row["id"], "first_name": row["first_name"], "last_name": row["last_name"],
        "username": row["username"], "phone": row["phone"], "role": role,
        "permissions": OWNER_PERMS if role == "owner" else EMPLOYEE_PERMS,
        "company": {"id": company["id"], "name": company["name"]}}}


def company_json(c):
    return {"id": c["id"], "name": c["name"], "phone": c["phone"],
            "logo_url": "/media/logo/%d?v=%s" % (c["id"], c["logo_ver"]) if c["logo"] else "",
            "vat_rate": money(Decimal(c["vat_rate"])), "exchange_rate": int(EXCHANGE_RATE)}


def limited(key):
    count, reset = _failures.get(key, (0, 0))
    return reset > time.time() and count >= 5


def fail(key):
    count, reset = _failures.get(key, (0, 0))
    now = time.time()
    _failures[key] = (count + 1, reset) if reset > now else (1, now + 300)


# ---------------------------------------------------------------- sessions
def session_user():
    """The signed-in web user (sqlite Row joined with company) or None."""
    if "web_user" in g:
        return g.web_user
    g.web_user = None
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as db:
            row = db.execute(
                "SELECT u.*, s.expires, s.remember FROM web_sessions s JOIN users u ON u.id=s.user_id "
                "WHERE s.token_hash=? AND s.expires>? AND u.is_active=1", (sha(token), time.time())).fetchone()
        g.web_user = row
    return g.web_user


def company_of(db, user):
    return db.execute("SELECT * FROM companies WHERE id=?", (user["company_id"],)).fetchone()


def start_session(response, user_id, remember):
    token = secrets.token_urlsafe(32)
    age = REMEMBER_SECONDS if remember else SESSION_SECONDS
    with connect() as db:
        db.execute("DELETE FROM web_sessions WHERE expires<?", (time.time(),))
        db.execute("INSERT INTO web_sessions VALUES (?,?,?,?)", (sha(token), user_id, time.time() + age, int(bool(remember))))
    secure = request.is_secure
    max_age = age if remember else None
    response.set_cookie(SESSION_COOKIE, token, max_age=max_age, httponly=True, secure=secure, samesite="Lax", path="/")
    response.set_cookie(CSRF_COOKIE, secrets.token_urlsafe(24), max_age=max_age, httponly=False, secure=secure, samesite="Lax", path="/")
    return response


def clear_session(response):
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")
    return response


def web_login(username, password, remember):
    """Called by the shared /api/auth/login route. Returns a response, or None if the
    username is not a web account (then the older employee-token login is tried)."""
    uname = username.strip().lower()
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE username=?", (uname,)).fetchone()
        if not row:
            return None
        key = "web:" + uname
        if limited(key) or limited("ip:" + (request.remote_addr or "")):
            return err(429, "Too many attempts. Please wait 5 minutes and try again.")
        if not check_password_hash(row["password_hash"], password):
            fail(key); fail("ip:" + (request.remote_addr or ""))
            return err(401, "Incorrect username or password.")
        if not row["is_active"]:
            return err(403, "This account has been disabled. Please contact your garage owner.", code="account_disabled")
        _failures.pop(key, None)
        company = company_of(db, row)
    return start_session(jsonify(user_json(row, company)), row["id"], remember)


def web_logout():
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as db:
            db.execute("DELETE FROM web_sessions WHERE token_hash=?", (sha(token),))
    return clear_session(Response(status=204))


def require_user(perm=None):
    user = session_user()
    if not user:
        abort(err_response(401, "Please sign in again."))
    perms = OWNER_PERMS if user["role"] == "owner" else EMPLOYEE_PERMS
    if perm and perm not in perms:
        abort(err_response(403, "Your account is not allowed to do this. Ask the garage owner if you need access."))
    return user


# ---------------------------------------------------------------- invoices
def compute(payload, vat_rate):
    items, sub = [], Decimal("0")
    incomplete = False
    if not isinstance(payload.get("items", []), list): raise ValueError("Items must be a list")
    for raw in payload.get("items", [])[:100]:
        if isinstance(raw,dict) and part_lookup.obvious_non_part(raw.get('d','')):
            raise ValueError('This item is outside the garage scope. هالبند خارج نطاق الورشة.')
        try:
            qty = None if raw.get("q") in (None, "") else Decimal(str(raw["q"]))
            price = None if raw.get("p") in (None, "") else Decimal(str(raw["p"]))
        except (InvalidOperation, AttributeError):
            raise ValueError("Each item needs a numeric quantity and price.")
        if any(v is not None and (not v.is_finite() or v < 0 or v > limit) for v, limit in ((qty, 10000), (price, 10000000))):
            raise ValueError("Quantities and prices must be positive numbers.")
        line = None if qty is None or price is None else q2(qty * price)
        if line is None:
            incomplete = True
        else:
            sub += qty * price
        catalog_id = raw.get('catalog_id')
        if catalog_id is not None and (not isinstance(catalog_id,str) or not get_product_by_id(catalog_id)):
            raise ValueError('Invalid catalog reference.')
        if catalog_id and text(raw.get('d'),200) != get_product_by_id(catalog_id)['name_en']:
            catalog_id = None  # An edited description becomes a custom line, not a verified identity.
        items.append({'catalog_id':catalog_id, 'is_custom':not bool(catalog_id), "d": text(raw.get("d"), 200), "t": text(raw.get("t"), 40) or "Service",
                      "q": money(qty) if qty is not None else None,
                      "p": money(price) if price is not None else None,
                      "total_usd": money(line) if line is not None else None})
    if incomplete:
        return items, {"subtotal_usd": None, "vat_rate": money(vat_rate), "vat_usd": None,
                       "total_usd": None, "total_lbp": None, "exchange_rate": int(EXCHANGE_RATE), "incomplete": True}
    raw_sub = sub
    sub = q2(sub)
    vat = q2(sub * vat_rate / 100)
    total = sub + vat
    lbp = ((raw_sub + vat) * EXCHANGE_RATE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return items, {"subtotal_usd": money(sub), "vat_rate": money(vat_rate), "vat_usd": money(vat),
                   "total_usd": money(total), "total_lbp": int(lbp), "exchange_rate": int(EXCHANGE_RATE), "incomplete": False}


from invoice_identity import has_identity

def clean_payload(data, company):
    cust = data.get("cust") if isinstance(data.get("cust"), dict) else {}
    truck = data.get("truck") if isinstance(data.get("truck"), dict) else {}
    out = {
        "cust": {k: text(cust.get(k), 200) for k in ("name", "contact", "tel", "email")},
        "truck": {k: text(truck.get(k), 100) for k in ("plate", "model")},
        "notes": text(data.get("notes"), 2000),
        "warnings": [text(w, 500) for w in data.get("warnings", [])[:30] if isinstance(w, str)] if isinstance(data.get("warnings"), list) else [],
        "items": data.get("items") if isinstance(data.get("items"), list) else [],
    }
    # Truck number is stored in its canonical form (A1234) when it is valid; anything else is kept as typed
    # so the review can explain exactly what is wrong with it. Names keep their spelling, extra spaces go.
    out["cust"]["name"] = invoice_validation.clean_name(out["cust"]["name"])
    if invoice_validation.truck_valid(out["truck"]["plate"]):
        out["truck"]["plate"] = invoice_validation.normalize_truck(out["truck"]["plate"])
    cid = cust.get('id')
    if isinstance(cid,int) and not isinstance(cid,bool):
        with sqlite3.connect(db_path()) as customer_db:
            found = customer_db.execute('SELECT id FROM web_customers WHERE id=? AND company_id=?',(cid,company['id'])).fetchone()
        if not found: raise ValueError('Customer not found in this company.')
        out['cust']['id'] = cid
    if out['cust']['tel']:
        tel = re.sub(r'[ ()-]', '', out['cust']['tel'].translate(AR_DIGITS))
        if not tel.startswith('+'):   # local Lebanese form: 71 234 567 / 03 123 456 / 01 234 567 / 00961...
            d = tel[2:] if tel.startswith('00') else tel
            tel = '+' + d if tel.startswith('00') or (d.startswith('961') and len(d) >= 10) else '+961' + d.lstrip('0')
        out['cust']['tel'] = tel
        if not valid_phone(out['cust']['tel']):
            raise ValueError('Customer phone must be a valid international number, e.g. +96171123456.')
    if out["cust"]["email"] and not EMAIL_RE.fullmatch(out["cust"]["email"]):
        raise ValueError("Customer email address is not valid.")
    out["items"], out["totals"] = compute(out, Decimal(company["vat_rate"]))
    out["company"] = company_json(company)
    out["company"].pop("id", None)
    return out


def readiness(inv):
    """Structured, server-computed review of an invoice draft: what is missing before approval.
    The AI never decides this; the frontend shows the same rules while the employee edits."""
    items = inv.get("items") or []
    missing, seen, duplicates = [], {}, []
    if not items:
        missing.append({"field": "items", "message": "Add at least one item."})
    for i, it in enumerate(items):
        name = str(it.get("d") or "").strip()
        if not name:
            missing.append({"item": i, "field": "description", "message": "Item %d needs a description." % (i + 1)})
        if it.get("q") is None or (isinstance(it.get("q"), (int, float)) and it["q"] <= 0):
            missing.append({"item": i, "field": "quantity", "message": "Quantity is missing for %s." % (name or "item %d" % (i + 1))})
        if it.get("p") is None:
            missing.append({"item": i, "field": "unit_price", "message": "Unit price is missing for %s." % (name or "item %d" % (i + 1))})
        key = (it.get("catalog_id") or name.casefold())
        if key and not re.match(r"^labou?r\b", name, re.I):
            if key in seen and seen[key] not in duplicates:
                duplicates.append(seen[key])
            seen.setdefault(key, name)
    # Required identity: customer's full name + truck number (one letter + four digits). Same rules as MA's questions.
    for p in invoice_validation.invoice_problems(inv):
        missing.append({"field": p["field"], "code": p["code"], "message": p["message"]})
    return {"ready": not missing, "missing": missing, "duplicates": duplicates,
            "custom_items": [it.get("d") for it in items if it.get("is_custom") and not re.match(r"^labou?r\b", str(it.get("d") or ""), re.I)],
            "approval_required": True}


def invoice_out(row):
    data = json.loads(row["payload"])
    data.update(approved_at=row["approved_at"], approved_by=row["approved_by"], id=row["id"], no=row["no"], status=row["status"], review_digest=sha(row["payload"]),
                date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(row["created_at"])))
    data["review"] = readiness(data)
    return data


def find_invoice(db, user, ident):
    row = db.execute("SELECT * FROM web_invoices WHERE id=? AND company_id=?", (ident, user["company_id"])).fetchone()
    if row and user["role"] != "owner" and row["created_by"] != user["id"]:
        return None
    return row


def is_web_invoice(ident):
    with connect() as db:
        return db.execute("SELECT 1 FROM web_invoices WHERE id=?", (ident,)).fetchone() is not None


def web_get_invoice(ident):
    user = require_user("invoice.history")
    with connect() as db:
        row = find_invoice(db, user, ident)
    if not row:
        return err(404, "Invoice not found.")
    out = invoice_out(row)
    with connect() as db:
        known = truck_memory.profile(db, user["company_id"], (out.get("truck") or {}).get("plate"), exclude=row["id"])
    if known:
        out["customer_profile"] = known
    return jsonify(out)


def move(ident, allowed_from, to, perm, who_ok=None, strict=False):
    """strict=True (Submit for approval) applies the approval checks to 'pending' too."""
    user = require_user(perm)
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        row = find_invoice(db, user, ident)
        if not row:
            return err(404, "Invoice not found.")
        if to == 'approved' and row['status'] == 'approved':
            if body().get('confirm') is True and body().get('review_digest') == sha(row['payload']):
                return jsonify(invoice_out(row))
        if row["status"] not in allowed_from:
            return err(409, "This invoice is %s and cannot be changed that way." % row["status"])
        payload = json.loads(row["payload"])
        # Pending may be incomplete (it is still being worked on). Approval and Submit need a complete invoice.
        check = to == "approved" or strict
        problems = invoice_validation.invoice_problems(payload) if check else []
        if problems:
            return err(409, " ".join(p["message"] for p in problems), {p["field"]: p["message"] for p in problems}, code="identity_invalid")
        if check and (payload.get("totals", {}).get("incomplete") or
                any(i.get("p") is None or i.get("q") is None for i in payload.get("items", []))):
            return err(409, "Fill in all missing quantities and prices before approving.")
        if check and (not payload.get('items') or any(
                not i.get('d','').strip() or i.get('q',0) <= 0 for i in payload['items'])):
            return err(409,'Each invoice needs at least one named item with a quantity greater than zero.')
        now = time.time()
        if to == "approved":
            approval = body()
            if approval.get("confirm") is not True or approval.get("review_digest") != sha(row["payload"]):
                return err(409, "Review the saved invoice and explicitly confirm approval.")
            if json.loads(row["payload"]).get("warnings") and approval.get("acknowledge_warnings") is not True:
                return err(409, "Acknowledge the invoice warnings before approval.")
            # Render first. Any error rolls back approval and customer changes atomically.
            try:
                invoice_services.store_approved_pdf(db,row,user['username'])
                cid = invoice_services.save_customer(db,user['company_id'],payload['cust'])
                truck_memory.remember(db, user['company_id'], payload['cust'], payload.get('truck'))
                if cid: db.execute('INSERT OR REPLACE INTO invoice_customers VALUES (?,?)',(ident,cid))
            except ValueError as exc:
                raise ValueError('Could not save the approved invoice: '+str(exc)) from None
            db.execute("UPDATE web_invoices SET status=?, updated_at=?, approved_by=?, approved_at=? WHERE id=?",
                       (to, now, user["id"], now, ident))
        else:
            db.execute("UPDATE web_invoices SET status=?, updated_at=?, approved_by=NULL, approved_at=NULL WHERE id=?", (to, now, ident))
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)", (ident, user["username"], to, now))
        row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
    return jsonify(invoice_out(row))


def web_approve_invoice(ident):
    return move(ident, ("pending",), "approved", "invoice.approve")


# ---------------------------------------------------------------- AI draft
# ---- live progress: real steps MA takes, streamed to the invoice screen while it works ----
PROGRESS = contextvars.ContextVar("progress", default=None)


def step(key, en, ar, **extra):
    """Report a step that is actually happening now (no-op when the client did not ask for progress)."""
    emit = PROGRESS.get()
    if emit:
        emit(dict(type="step", key=key, en=en, ar=ar, **extra))


def act(key, status, en="", ar="", **extra):
    """Activity panel event: a real step of this request changed state (processing / completed / failed)."""
    emit = PROGRESS.get()
    if emit:
        emit(dict(type="activity", key=key, status=status, en=en, ar=ar, **extra))


INVOICE_PLAN = [("understand", "Understanding employee request", "عم إفهم طلبك"),
                ("extract", "Extracting customer information", "عم طلّع معلومات الزبون"),
                ("validate_name", "Validating customer full name", "عم إتأكّد من اسم الزبون الكامل"),
                ("validate_truck", "Checking truck number", "عم إتأكّد من رقم الشاحنة"),
                ("check_items", "Checking parts, quantities and prices", "عم إتأكّد من القطع والكميات والأسعار"),
                ("totals", "Calculating invoice totals", "عم إحسب مجموع الفاتورة"),
                ("preview", "Preparing invoice preview", "عم حضّر معاينة الفاتورة"),
                ("approval", "Waiting for employee approval", "ناطر موافقتك"),
                ("pdf", "Generating invoice PDF", "عم إعمل الـ PDF للفاتورة")]


def apply_identity(result, order, slots=None, collected=None):
    """Customer + truck for this draft: what the employee just answered (slots) wins, then what the AI read,
    then values already collected and validated earlier in this conversation. Nothing is invented."""
    for field in ("customer", "truck_plate"):
        said = (slots or {}).get(field)
        if said:
            result[field] = said
        elif not str(result.get(field) or "").strip() and (collected or {}).get(field):
            result[field] = collected[field]
        if order is not None and result.get(field):
            order[field] = result[field]
    result["customer"] = invoice_validation.clean_name(result.get("customer"))
    if invoice_validation.truck_valid(result.get("truck_plate")):
        result["truck_plate"] = invoice_validation.normalize_truck(result["truck_plate"])
        if order is not None:
            order["truck_plate"] = result["truck_plate"]


def ai_draft(message, company, confirmed_order=None, ar=None, precomputed=None, slots=None, collected=None):
    """Turn the repair conversation into a validated draft, or into ONE question listing exactly what is missing.
    Questions carry '_state' (the understood order + what was asked) so the next answer can be applied
    without re-asking, and without another AI call when it is a short answer."""
    from invoice_engine import create_invoice  # the teammate's Gemini pipeline
    if ar is None:
        ar = bool(re.search(r'[؀-ۿ]', message))
    step("extract", "Extracting customer, parts, quantities and prices", "عم طلّع الزبون والقطع والكميات والأسعار")
    act("extract", "processing", *INVOICE_PLAN[1][1:])
    try:
        if confirmed_order is not None:
            result = create_invoice(message, confirmed_order=confirmed_order)
        elif precomputed is not None:
            result = create_invoice(message, precomputed_order=precomputed)
        else:
            result = create_invoice(message)
    except Exception:
        act("extract", "failed", *INVOICE_PLAN[1][1:], error="AI service unavailable" if not ar else "خدمة الذكاء مش متوفرة هلّق")
        raise
    order = result.pop("_order", None)
    apply_identity(result, order, slots, collected)
    act("extract", "completed", *INVOICE_PLAN[1][1:],
        detail=", ".join(x for x in (result.get("customer"), result.get("truck_plate")) if x))
    known, filled = None, []
    company_id = company["id"] if company is not None and "id" in company.keys() else None
    if company_id is not None:
        with connect() as db:
            known, filled = truck_memory.fill_order(db, company_id, result)
        apply_identity(result, order)       # memory may have filled the name / truck number: same rules apply
    # identity is validated below with exact messages; the engine's generic plate warning is not shown
    result["warnings"] = [w for w in result.get("warnings") or [] if w != "Truck plate number is required"]
    if known:
        label = {"loyal": ("Loyal customer", "زبون دايم"), "returning": ("Returning customer", "زبون راجع"), "new": ("Known truck", "شاحنة معروفة")}[known["status"]]
        step("memory", "%s: %s · plate %s · %d earlier invoice%s" % (label[0], known.get("name") or "-", known["plate"], known["invoices"], "" if known["invoices"] == 1 else "s"),
             "%s: %s · نمرة %s · %d فواتير قبل" % (label[1], known.get("name") or "-", known["plate"], known["invoices"]), profile=known)
    if result.get("customer") or result.get("truck_plate"):
        step("customer", "Customer: %s" % (result.get("customer") or result.get("truck_plate")), "الزبون: %s" % (result.get("customer") or result.get("truck_plate")),
             customer=result.get("customer") or "", plate=result.get("truck_plate") or "")
    for it in result.get("items") or []:
        step("item", "Found in catalog: %s × %s" % (it["name"], it["quantity"]), "لقيت بالكتالوج: %s × %s" % (it["name"], it["quantity"]),
             item={"d": it["name"], "q": it["quantity"], "p": float(it["price_usd"]) if it.get("price_usd") is not None else None})
    step("check", "Checking for anything missing", "عم إتأكّد إذا في شي ناقص")
    # ---- required identity: customer full name + truck number (exact problem, asked only when wrong/missing)
    arabic = ar
    act("validate_name", "processing", *INVOICE_PLAN[2][1:])
    name_problem = invoice_validation.customer_problem(result.get("customer"), arabic)
    act("validate_name", "failed" if name_problem else "completed", *INVOICE_PLAN[2][1:],
        error=name_problem["message"] if name_problem else "", detail="" if name_problem else result.get("customer", ""))
    act("validate_truck", "processing", *INVOICE_PLAN[3][1:])
    truck_problem = invoice_validation.truck_problem(result.get("truck_plate"), arabic)
    act("validate_truck", "failed" if truck_problem else "completed", *INVOICE_PLAN[3][1:],
        error=truck_problem["message"] if truck_problem else "", detail="" if truck_problem else result.get("truck_plate", ""))
    problems = [p for p in (name_problem, truck_problem) if p]
    collected = {"customer": result.get("customer") if not name_problem else (collected or {}).get("customer", ""),
                 "truck_plate": result.get("truck_plate") if not truck_problem else (collected or {}).get("truck_plate", "")}
    if name_problem and name_problem["code"] == "last_name_missing":
        collected["first_name"] = name_problem["first"]

    def ask(question, item_questions=False, **extra):
        """A question back to the employee, with the conversation state needed to continue from the answer."""
        out = {"question": question, "missing": [{k: p[k] for k in ("field", "code", "message")} for p in problems], **extra}
        out["_state"] = {"order": order if not item_questions else None, "collected": collected,
                         "asked": {p["field"]: {"code": p["code"], "first": p.get("first", "")} for p in problems}}
        return out

    act("check_items", "processing", *INVOICE_PLAN[4][1:])
    if result.get('blocked_items'):
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error=', '.join(result['blocked_items']))
        return ask('هالبنود خارج نطاق قطع وخدمات الورشة: '+', '.join(result['blocked_items'])+'. صحّح أو احذف هالبنود.' if arabic else
                   'Outside garage scope: '+', '.join(result['blocked_items'])+'. Correct or remove these items.', True,
                   blocked_items=result['blocked_items'])
    if result.get('suggestions') and problems:
        act("check_items", "pending", *INVOICE_PLAN[4][1:])
        return ask(" ".join(p["message"] for p in problems), True)
    if result.get('suggestions'):
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error="Part confirmation needed" if not arabic else "لازم تأكّد القطعة")
        proposal = {'question': 'هيدي اقتراحات حسب وصفك. اختار القطعة الصحيحة لتأكيدها، أو اضغط «مش هيدي» ووضّح أكتر. إذا ما لقيت القطعة، أكّد اسمها وكمّيتها وسعرها كبند مخصّص.' if arabic else 'These are suggestions from your description. Confirm the correct part, or choose Not this part and describe it further. If no match fits, confirm a custom invoice description, quantity and price.',
                'suggestions':result['suggestions'],'_pending_order':result['_pending_order']}
        proposal['question'] += ' '+ ' / '.join(s['description']+' '+ ' / '.join(c['name_ar' if arabic else 'name_en'] for c in s['candidates']) for s in result['suggestions'])
        if any(not s['candidates'] for s in result['suggestions']):
            proposal['question'] += (' ما لقيت هالبند بالكتالوج: شو الاسم يلي بدك يطلع عالفاتورة لهالبند؟ وأكّد الكمية والسعر.' if arabic else
                                     ' Not found in the catalog: what name would you like to display on the invoice for this item? Then confirm its quantity and price.')
        if arabic and any(re.search(r'\d+\s*(?:لتر|ليتر|l\b)',s['description']) for s in result['suggestions']): proposal['question'] += ' وضّح إذا التفصيل حجم القطعة أو سعرها.'
        return proposal
    items = [{"catalog_id":it.get("id"),"is_custom":it.get("is_custom",False), "d": it["name"], "t": "Part", "q": it["quantity"],
              "p": float(it["price_usd"]) if it["price_usd"] is not None else None} for it in result["items"]]
    warnings = list(result.get("warnings", []))
    # Never offer a partial invoice after dropping an unresolved repair item.
    from database import search_products, suggest_products
    def part_label(name):
        found = search_products(name)
        return found[0]['name_ar'] if arabic and len(found) == 1 else name
    questions = []
    for warning in warnings:
        if warning.startswith("Unknown product: "):
            name = warning.split(": ", 1)[1]
            candidates = suggest_products(name)
            options = ' / '.join(p['name_ar' if arabic else 'name_en'] for p in candidates[:4])
            if options:
                questions.append(f'تقصد {options}؟ وضّح التفصيل «{name}»: هو حجم القطعة أو سعرها؟' if arabic else f'Do you mean {options}? Please clarify "{name}": is that a size or a price?')
            else:
                questions.append(f'ما قدرت أحدّد القطعة «{name}». فيك توصف شو هي أو شو بتعمل؟' if arabic else f'I could not identify "{name}". Can you describe the part or what it does?')
        elif warning.startswith("Ambiguous product: "):
            name = warning.split(": ", 1)[1]
            options = " / ".join(p['name_ar' if arabic else 'name_en'] for p in search_products(name))
            questions.append(f'أي نوع تقصد: {options}؟' if arabic else f'Which type do you mean: {options}?')
        elif warning.startswith("Invalid quantity: "):
            name = warning.split(": ", 1)[1]
            questions.append(f'قدّيش عدد {part_label(name)}؟' if arabic else f'How many "{name}" were used?')
        elif warning.startswith('Part detail needs review: '):
            questions.append(warning.split(': ',1)[1])
        elif warning.startswith('Conflicting price: '):
            name = warning.split(': ',1)[1]
            questions.append(f'سعر الوحدة ومجموع {part_label(name)} مش متطابقين. قديش حق الواحد؟' if arabic else f'The unit price and line total for {name} disagree. What is the price per item?')
    if questions:
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error=" ".join(questions))
    elif problems and items:
        act("check_items", "completed", *INVOICE_PLAN[4][1:], detail="%d item%s" % (len(items), "" if len(items) == 1 else "s"))
    if problems or questions:
        # one message: identity first, then the item details, so nothing has to be asked twice
        return ask(" ".join([p["message"] for p in problems] + questions), bool(questions))
    labor = Decimal(str(result["labor_amount"])) if result.get("labor_amount") is not None else None
    cur = result.get("labor_currency")
    if labor is not None and labor > 0 and cur in ("USD", "LBP"):
        usd = labor if cur == "USD" else labor / EXCHANGE_RATE
        items.append({"d": "Labor" + (" (%s LBP)" % format(int(labor), ",") if cur == "LBP" else ""), "t": "Service", "q": 1, "p": float(usd)})
    if not items:
        unknown = [w.split(": ", 1)[1] for w in warnings if w.startswith(("Unknown product", "Ambiguous product"))]
        if arabic:
            q = ("ما قدرت لاقي %s بكتالوج الكاراج. " % "، ".join('«%s»' % u for u in unknown)) if unknown else ""
            act("check_items", "failed", *INVOICE_PLAN[4][1:], error="ما في قطع بعد")
            return ask(q + "شو القطع يلي تغيّرت، وقدّيش العدد؟ فيك تزيد أجرة اليد إذا بدك.", True)
        q = ("I couldn't match %s to the garage catalog. " % ", ".join('"%s"' % u for u in unknown)) if unknown else ""
        act("check_items", "failed", *INVOICE_PLAN[4][1:], error="No parts yet")
        return ask(q + "Which parts were replaced, and how many? You can include labor if you want to charge it.", True)
    act("check_items", "completed", *INVOICE_PLAN[4][1:], detail="%d item%s" % (len(items), "" if len(items) == 1 else "s"))
    if any(w in warnings for w in ("Invalid labor amount", "Labor currency is unclear")):
        items.append({"d": "Labor", "t": "Service", "q": 1, "p": None})
    draft = {"status": "draft", "cust": {"name": result.get("customer", ""), "contact": "", "tel": result.get("customer_phone", ""), "email": result.get("customer_email", "")},
             "truck": {"plate": result.get("truck_plate", "") or "", "model": result.get("truck_model", "") or ""},
             "notes": result.get("notes", ""), "items": items}
    act("totals", "processing", *INVOICE_PLAN[5][1:])
    try:
        payload = clean_payload(draft, company)
    except ValueError as exc:
        act("totals", "failed", *INVOICE_PLAN[5][1:], error=str(exc))
        return ask(str(exc), True)
    step("totals", "Calculating totals (USD and LBP)", "عم إحسب المجموع بالدولار والليرة")
    t = payload.get("totals") or {}
    act("totals", "completed", *INVOICE_PLAN[5][1:],
        detail="" if t.get("total_usd") is None else "$%s / %s LBP" % (format(Decimal(str(t["total_usd"])), ",.2f"), format(t["total_lbp"], ",")))
    payload.update(status="draft", date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   warnings=[friendly(w) for w in warnings])
    payload["review"] = readiness(payload)
    if known:
        payload["customer_profile"] = known
    if filled:
        payload["filled_from_memory"] = filled
    return payload


def friendly(w):
    return {"Customer name is missing": "Customer name wasn't mentioned - add it before submitting.",
            "Labor amount is missing": "No labour cost was mentioned.",
            "Labor currency is unclear": "Labour currency wasn't clear (USD or LBP?), so its price is blank."}.get(w, w)
CANCEL_RE = re.compile(r"\b(?:cancel|forget (?:it|this)|never ?mind|discard)\b|إلغاء|الغي|الغيها|لغيها|انسى|انساها|بلاها", re.I)


# ---------------------------------------------------------------- routes
# ---------------------------------------------------------------- assistant: understand any request
STATUSES = ("draft", "pending", "approved", "rejected")
STATUS_AR = {"draft": "مسودة", "pending": "بانتظار الموافقة", "approved": "موافق عليها", "rejected": "مرفوضة"}
STATUS_EN = {"draft": "draft", "pending": "pending approval", "approved": "approved", "rejected": "rejected"}
MONTHS_AR = ["كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"]


def visible_rows(user):
    """Invoices this user may see: owners see the whole garage, employees only their own."""
    sql, args = "SELECT * FROM web_invoices WHERE company_id=?", [user["company_id"]]
    if user["role"] != "owner":
        sql += " AND created_by=?"
        args.append(user["id"])
    with connect() as db:
        return db.execute(sql + " ORDER BY seq", args).fetchall()


def local_day(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def nice_day(day, ar):
    y, m, d = (int(x) for x in day.split("-"))
    return "%d %s %d" % (d, MONTHS_AR[m - 1], y) if ar else time.strftime("%d %b %Y", (y, m, d, 0, 0, 0, 0, 1, -1)).lstrip("0")


def valid_day(value):
    try:
        time.strptime(value, "%Y-%m-%d")
        return value
    except (TypeError, ValueError):
        return ""


def loose(value):
    """Lower-case letters/digits only, so 'ABC-123', 'abc 123' and 'Abc123' compare equal."""
    return re.sub(r"[\W_]+", "", str(value or "").casefold())


def similar(wanted, actual):
    """Typo-tolerant match for customer names and plates."""
    from difflib import SequenceMatcher
    a, b = loose(wanted), loose(actual)
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    if SequenceMatcher(None, a, b).ratio() >= 0.75:
        return True
    words = [loose(w) for w in str(actual).split()]
    return any(w and SequenceMatcher(None, a, w).ratio() >= 0.8 for w in words)


def invoice_no_from(text_value):
    digits = re.findall(r"\d+", str(text_value or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")))
    return "INV-%04d" % int(digits[-1]) if digits else ""


def summary(row):
    inv = invoice_out(row)
    return {"id": inv["id"], "no": inv["no"], "status": inv["status"], "date": local_day(row["created_at"]),
            "customer": inv.get("cust", {}).get("name", ""), "plate": inv.get("truck", {}).get("plate", ""),
            "total_usd": inv.get("totals", {}).get("total_usd"), "total_lbp": inv.get("totals", {}).get("total_lbp")}


def describe_filters(r, ar):
    parts = []
    a, b = r.get("date_from"), r.get("date_to")
    if a and b and a == b:
        parts.append(("بتاريخ " if ar else "on ") + nice_day(a, ar))
    elif a and b:
        parts.append(("من %s لـ %s" if ar else "from %s to %s") % (nice_day(a, ar), nice_day(b, ar)))
    elif a:
        parts.append(("من " if ar else "since ") + nice_day(a, ar))
    elif b:
        parts.append(("لغاية " if ar else "up to ") + nice_day(b, ar))
    if r.get("customer"):
        parts.append(("للزبون «%s»" if ar else "for customer \"%s\"") % r["customer"])
    if r.get("plate"):
        parts.append(("للنمرة %s" if ar else "for plate %s") % r["plate"])
    if r.get("status"):
        parts.append(("حالتها: " + STATUS_AR[r["status"]]) if ar else ("that are " + STATUS_EN[r["status"]]))
    return " ".join(parts)


def money_usd(v):
    v = Decimal(str(v))
    return "$" + (format(v, ",.0f") if v == v.to_integral_value() else format(v, ",.2f"))


def answer_query(user, r):
    ar = r.get("language") == "ar"
    r = dict(r)
    r["date_from"], r["date_to"] = valid_day(r.get("date_from")), valid_day(r.get("date_to"))
    if r["date_from"] and r["date_to"] and r["date_from"] > r["date_to"]:
        r["date_from"], r["date_to"] = r["date_to"], r["date_from"]
    r["status"] = r.get("status") if r.get("status") in STATUSES else ""
    metric = r.get("metric") if r.get("metric") in ("count", "list", "total") else "count"

    found = []
    for row in visible_rows(user):
        s = summary(row)
        if r["date_from"] and s["date"] < r["date_from"]: continue
        if r["date_to"] and s["date"] > r["date_to"]: continue
        if r["status"] and s["status"] != r["status"]: continue
        if r.get("customer") and not similar(r["customer"], s["customer"]): continue
        if r.get("plate") and not similar(r["plate"], s["plate"]): continue
        found.append(s)

    where = describe_filters(r, ar)
    n = len(found)
    if ar:
        head = "ما في ولا فاتورة" if n == 0 else ("في فاتورة وحدة" if n == 1 else "في %d فواتير" % n)
    else:
        head = "There are no invoices" if n == 0 else ("There is 1 invoice" if n == 1 else "There are %d invoices" % n)
    text_out = (head + (" " + where if where else "") + ".")
    if n:
        by = {}
        for s in found:
            by[s["status"]] = by.get(s["status"], 0) + 1
        text_out += " (" + "، ".join("%d %s" % (c, STATUS_AR[k]) for k, c in by.items()) + ")" if ar else \
                    " (" + ", ".join("%d %s" % (c, STATUS_EN[k]) for k, c in by.items()) + ")"
    if metric == "total" and n:
        complete = [s for s in found if s["total_usd"] is not None]
        usd = sum((Decimal(str(s["total_usd"])) for s in complete), Decimal("0"))
        lbp = sum(int(s["total_lbp"] or 0) for s in complete)
        text_out += ("\nالمجموع: %s / %s ل.ل." if ar else "\nTotal: %s / %s LBP") % (money_usd(usd), format(lbp, ","))
        missing = n - len(complete)
        if missing:
            text_out += ("\n(%d فاتورة ناقصة أسعار ما انحسبت)" if ar else "\n(%d incomplete invoice(s) without prices are not counted)") % missing
    if user["role"] != "owner":
        text_out += "\n(بس الفواتير يلي إنت عملتها)" if ar else "\n(Only invoices you created.)"
    if n and metric != "list" and n > 10:
        text_out += "\nآخر 10:" if ar else "\nLatest 10:"
    return {"reply": text_out, "understood": r.get("understood", ""), "invoices": list(reversed(found))[:10]}


def open_by_number(user, r):
    ar = r.get("language") == "ar"
    no = invoice_no_from(r.get("invoice_no"))
    if no:
        for row in visible_rows(user):
            if row["no"] == no:
                return {"reply": ("هيدي الفاتورة %s." if ar else "Here is invoice %s.") % no, "open": invoice_out(row)}
    return {"reply": ("ما لقيت الفاتورة %s." if ar else "I couldn't find invoice %s.") % (no or r.get("invoice_no") or "?")
                     + (" جرّب «شو آخر الفواتير؟»" if ar else " Try \"show my latest invoices\".")}


# ---- contacts given to MA: must come from what the user actually typed/said ----
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
LB_MOBILE_RE = re.compile(r"^\+961(3\d{6}|(70|71|76|78|79|81)\d{6})$")
EMAIL_FIND = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}")
PHONE_FIND = re.compile(r"(?:\+|00)?\d[\d\s\-().]{4,18}\d")


def normalize_phone(raw):
    """'03 123 456' -> '+9613123456'. Lebanese numbers must be mobiles (WhatsApp). None if not valid."""
    s = str(raw or "").translate(AR_DIGITS).strip()
    d = re.sub(r"\D", "", s)
    if not d:
        return None
    if s.startswith("00"):
        d, intl = d[2:], True
    else:
        intl = s.startswith("+") or (d.startswith("961") and len(d) >= 10)
    e = "+" + d if intl else "+961" + d.lstrip("0")
    if e.startswith("+961"):
        return e if LB_MOBILE_RE.match(e) else None
    return e if E164_RE.match(e) else None


def phone_from_text(text):
    for m in PHONE_FIND.finditer(str(text or "").translate(AR_DIGITS)):
        e = normalize_phone(m.group(0))
        if e:
            return e
    return None


def phone_in_text(e164, text):
    digits = re.sub(r"\D", "", str(text or "").translate(AR_DIGITS))
    core = e164[4:] if e164.startswith("+961") else e164[1:]
    return bool(core) and (core in digits or core[-8:] in digits)


def email_in_text(email, text):
    t = str(text or "").lower()
    spoken = re.sub(r"\s*(?:\(at\)|\[at\]|\bat\b|@|آت)\s*", "@", t)
    spoken = re.sub(r"\s*(?:\bdot\b|نقطة|دوت)\s*", ".", spoken)
    return email.lower() in t or email.lower() in spoken.replace(" ", "")


def pretty_phone(e164):
    m = re.match(r"^\+961(\d+)$", e164 or "")
    if not m:
        return e164 or ""
    d = m.group(1)
    return "+961 " + (d[:2] + " " + d[2:5] + " " + d[5:] if len(d) == 8 else d[:1] + " " + d[1:4] + " " + d[4:])


def saved_contact(user, kind, opened=None, context=None):
    """The number/email already known for the invoice in question: on the invoice itself, else in the
    customer memory of its plate number (the truck's ID). Never invented."""
    inv = opened
    ctx = context if isinstance(context, dict) else {}
    with connect() as db:
        if inv is None and isinstance(ctx.get("invoice_id"), str):
            row = find_invoice(db, user, ctx["invoice_id"])
            inv = invoice_out(row) if row else None
        if inv is None and isinstance(ctx.get("draft"), dict):
            inv = ctx["draft"]
        if not isinstance(inv, dict):
            return ""
        cust, truck = inv.get("cust") or {}, inv.get("truck") or {}
        value = cust.get("tel" if kind == "whatsapp" else "email") or ""
        if not value:
            known = truck_memory.find(db, user["company_id"], truck.get("plate"))
            value = (known["tel"] if kind == "whatsapp" else known["email"]) if known else ""
    if kind == "whatsapp":
        return normalize_phone(value) or ""
    return value if EMAIL_RE.match(value or "") else ""


def share_request(user, r, turns, context=None):
    """MA was asked to send an invoice by WhatsApp or email. Uses only contact details the user gave."""
    ar = r.get("language") == "ar"
    said = "\n".join(h["text"] for h in turns[-6:] if h["role"] == "user")
    latest = turns[-1]["text"]
    out = {}
    if r.get("invoice_no"):
        opened = open_by_number(user, r)
        if "open" not in opened:
            return opened
        out["open"] = opened["open"]
    if r["intent"] == "send_whatsapp":
        phone = normalize_phone(r.get("phone")) if r.get("phone") else None
        if phone and not r.get("phone_from_ma") and not phone_in_text(phone, said):
            phone = None                      # the AI produced a number the user never said
        phone = phone or phone_from_text(latest)
        saved = False
        if not phone and not (r.get("phone") or re.search(r"\d{3}", latest.translate(AR_DIGITS))):
            phone = saved_contact(user, "whatsapp", out.get("open"), context)
            saved = bool(phone)
        if phone:
            # Two honest ways: open the customer's WhatsApp chat (the employee attaches the PDF and presses Send), or
            # send the PDF directly through the garage's WhatsApp Business (Cloud API) account, when it is connected.
            method = r.get("method") if r.get("method") in ("chat", "direct") else ""
            direct_ok = delivery_providers.configuration()["whatsapp"]["configured"]
            who = pretty_phone(phone) + (" (المحفوظ)" if ar and saved else " (saved)" if saved else "")
            if method == "direct" and not direct_ok:
                method = "chat"
                note = (" الإرسال المباشر مش موصول بالكاراج، فرح إفتحلك محادثة الواتساب." if ar else
                        " Direct sending isn't connected for this garage, so I'll open the WhatsApp chat instead.")
            else:
                note = ""
            if not method and direct_ok:
                out.update(reply=("أكيد، الرقم %s. بتحب إفتحلك محادثة الواتساب، ولا إبعتها مباشرة من حساب واتساب الأعمال تبع الكاراج؟" if ar else
                                  "Got it, %s. Would you like me to open the WhatsApp chat or send it directly using the connected business account?") % who,
                           ask="wa_method", action={"type": "whatsapp", "phone": phone, "saved": saved, "choose": True})
            elif method == "direct":
                out.update(reply=("تمام، رح إبعت الفاتورة PDF مباشرة لـ %s. راجع التفاصيل واضغط «Send now»." if ar else
                                  "OK, I'll send the invoice PDF directly to %s. Check the details, then press Send now.") % who,
                           action={"type": "whatsapp", "phone": phone, "saved": saved, "method": "direct"})
            else:
                out.update(reply=note.strip() + (" " if note else "") + (
                    ("رح إفتح محادثة الواتساب مع %s والرسالة جاهزة. روابط الواتساب ما بتقدر ترفق ملفات، فنزّل الـ PDF وزيدو بالمحادثة قبل ما تضغط إرسال." if ar else
                     "I'll open the WhatsApp chat with %s with the message ready. WhatsApp links can't attach files, so download the PDF and attach it in the chat before pressing Send.") % who),
                           action={"type": "whatsapp", "phone": phone, "saved": saved, "method": "chat"})
        elif r.get("phone") or re.search(r"\d{3}", latest.translate(AR_DIGITS)):
            out.update(reply=("الرقم مش واضح أو مش رقم واتساب صحيح. اكتبو مع رمز البلد، مثلاً 96170123456 أو 03 123 456. شو الرقم الصحيح؟" if ar else
                              "That doesn't look like a valid WhatsApp number. Include the country code, e.g. 96170123456 or 03 123 456. What's the correct number?"),
                       ask="whatsapp", action={"type": "whatsapp"})
        else:
            out.update(reply="أكيد، شو رقم واتساب الزبون؟" if ar else "Sure. What's the customer's WhatsApp number?",
                       ask="whatsapp", action={"type": "whatsapp"})
    else:
        email = (r.get("email") or "").strip().strip(".,;")
        if email and not (EMAIL_RE.match(email) and email_in_text(email, said)):
            email = ""
        if not email:
            m = EMAIL_FIND.search(latest)
            email = m.group(0) if m else ""
        saved = False
        if not email and not (r.get("email") or "@" in latest):
            email = saved_contact(user, "email", out.get("open"), context)
            saved = bool(email)
        if email and saved:
            out.update(reply=("رح إبعتها على إيميل الزبون المحفوظ %s." if ar else "I'll send it to the customer's saved email %s.") % email,
                       action={"type": "email", "email": email, "saved": True})
        elif email:
            out.update(reply=("تمام، رح إبعت الفاتورة PDF بالإيميل لـ %s. راجع التفاصيل واضغط «Confirm»." if ar else
                              "Got it. I'll email the invoice PDF to %s. Check the details, then press Confirm.") % email,
                       action={"type": "email", "email": email})
        elif r.get("email") or "@" in latest:
            out.update(reply="الإيميل مش صحيح. شو إيميل الزبون؟ مثلاً name@gmail.com" if ar else
                       "That email address doesn't look valid. What's the customer's email? For example name@gmail.com.",
                       ask="email", action={"type": "email"})
        else:
            out.update(reply="أكيد، شو إيميل الزبون؟" if ar else "Sure. What's the customer's email address?", ask="email", action={"type": "email"})
    return out


NEW_INVOICE_RE = re.compile(r"\b(?:new|another|next|second|different)\s+(?:invoice|customer|bill|job)\b|"
                            r"فاتورة\s+(?:جديدة|جديده|تانية|تانيه|ثانية|غير)|زبون\s+(?:جديد|تاني|ثاني)", re.I)


PAUSE_RE = re.compile(r"^\s*(?:ma[\s,]*)?(?:pause|hold on|wait(?: a (?:sec|second|minute|moment))?|one (?:sec|second|minute|moment)|"
                      r"give me a (?:sec|second|minute|moment)|وقّف شوي|وقف شوي|استنى|إستنى|لحظة|دقيقة|ناطر)\b[\s.!]*$", re.I)
# while MA waits for an invoice answer, these mean the employee asks something else (route it normally)
FOLLOWUP_OTHER_RE = re.compile(r"[?؟]|\b(?:how many|how much|what(?:'s| is)|which|show|list|open|send|whats ?app|e-?mail|help|cancel|who|total)\b|"
                               r"قدّيش|قديش|كم |شو |افتح|فرجيني|ابعت|إبعت|واتس|ايميل|إيميل|مساعدة|الغي|انسى|مين", re.I)
WA_DIRECT_RE = re.compile(r"\b(?:direct(?:ly)?|business|api|automatic(?:ally)?|send it(?: now)?|just send)\b|مباشر|مباشرة|الأعمال|اعمال|ابعتها|إبعتها|بعتها", re.I)
WA_CHAT_RE = re.compile(r"\b(?:open|chat|link|myself|manual(?:ly)?|attach)\b|افتح|إفتح|فتاح|محادثة|المحادثة|الشات|شات|بإيدي|بايدي", re.I)
CHAT_INPUT = contextvars.ContextVar("chat_input", default=None)   # (json body, audio bytes) of this chat request
STATES = URLSafeTimedSerializer(secrets.token_hex(32), salt="ma-conversation-state")


def repair_window(turns, new_from_router):
    """The turns that belong to the invoice being prepared, and whether this message starts a new one."""
    start, new_invoice = 0, False
    for i, h in enumerate(turns):
        if h['role'] == 'assistant' and h.get('kind') == 'answer':
            start = i + 1
        elif h['role'] == 'user' and i > 0 and NEW_INVOICE_RE.search(h['text']):
            start, new_invoice = i, (i == len(turns) - 1) or new_invoice
    if new_from_router and len(turns) > 1:
        start, new_invoice = len(turns) - 1, True
    return turns[start:], new_invoice


def quick_route(turns):
    """Clear 'send to WhatsApp 03 123 456' / 'email it to x@y.com' commands (and answers to MA's
    'what's the number/email?') are understood without calling Gemini."""
    latest = turns[-1]["text"]
    if CANCEL_RE.search(latest) and len(latest) < 80 and not re.search(r"\d", latest):
        return {"intent": "cancel"}
    if PAUSE_RE.search(latest):
        return {"intent": "pause"}
    prev0 = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
    if prev0.get("ask") == "wa_method":            # answer to "open the WhatsApp chat or send it directly?"
        direct = WA_DIRECT_RE.search(latest)
        chat = WA_CHAT_RE.search(latest)
        phone = phone_from_text(prev0.get("text", ""))
        if phone and bool(direct) != bool(chat):
            return {"intent": "send_whatsapp", "phone": phone, "method": "direct" if direct else "chat", "phone_from_ma": True}
    prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
    asked = prev.get("ask")
    no = re.search(r"(?:\binv(?:oice)?|فاتورة|الفاتورة)\s*(?:no\.?|number|num|#|رقم)?\s*-?\s*(\d{1,5})\b", latest.translate(AR_DIGITS), re.I)
    extra = {"invoice_no": no.group(1)} if no else {}
    rest = latest.translate(AR_DIGITS).replace(no.group(0), " ") if no else latest
    em = EMAIL_FIND.search(latest)
    if em and (asked == "email" or re.search(r"e-?mail|mail|ايميل|إيميل|ميل|ابعت|إبعت|send", latest, re.I)):
        return dict(intent="send_email", email=em.group(0), **extra)
    ph = phone_from_text(rest)
    if ph and (asked == "whatsapp" or re.search(r"whats|wats|واتس|وتس", latest, re.I)):
        return dict(intent="send_whatsapp", phone=ph, **extra)
    return None


HELP_EN = ("Hi, I'm MA, your AI assistant. I'm here to help you understand, organize, and complete your tasks. Here's what I can do:\n"
           "\u2022 Describe a repair (type or tap the mic, Arabic or English) and I'll prepare a draft invoice.\n"
           "\u2022 Ask about your invoices: \"how many invoices today?\", \"total of approved invoices this month\", \"invoices for plate 123456\".\n"
           "\u2022 Open one: \"open invoice 3\".\n"
           "\u2022 Send an approved invoice: \"send it on WhatsApp to 03 123 456\" or \"email it to name@gmail.com\".")
HELP_AR = ("أهلا، أنا MA، مساعدك الذكي. أنا هون لساعدك تفهم وتنظّم وتخلّص شغلك. هيدا شو فيني أعمل:\n"
           "\u2022 احكيلي شو تصلّح (كتابة أو بالمايك، عربي أو إنكليزي) وبحضّرلك مسودة فاتورة.\n"
           "\u2022 إسألني عن الفواتير: «قديش فاتورة اليوم؟»، «مجموع الفواتير الموافق عليها هالشهر»، «فواتير النمرة 123456».\n"
           "\u2022 إفتح فاتورة: «افتحلي الفاتورة 3».\n"
           "\u2022 ابعت فاتورة موافق عليها: «ابعتها عالواتساب لـ 03 123 456» أو «ابعتها عالإيميل name@gmail.com».")


def current_invoice_answer(user, r, context):
    """Answer about the invoice on screen from real data: a saved invoice is re-read from the database
    (with the same company/ownership check as opening it); an unsaved draft is recomputed by the server."""
    ar = r.get("language") == "ar"
    ctx = context if isinstance(context, dict) else {}
    inv = None
    with connect() as db:
        if isinstance(ctx.get("invoice_id"), str) and ctx["invoice_id"]:
            row = find_invoice(db, user, ctx["invoice_id"])
            inv = invoice_out(row) if row else None
        elif isinstance(ctx.get("draft"), dict):
            try:
                inv = clean_payload(ctx["draft"], company_of(db, user))
            except (ValueError, TypeError):
                inv = None
    if not inv:
        return {"reply": "ما في فاتورة مفتوحة هلّق. احكيلي شو صلّحت لحضّرلك وحدة، أو قول «افتحلي الفاتورة 3»." if ar else
                "There's no invoice open right now. Tell me about a repair and I'll draft one, or say \"open invoice 3\"."}
    items = [i for i in inv.get("items") or [] if i.get("d")]
    tot = (inv.get("totals") or {}).get("total_usd")
    name = (inv.get("cust") or {}).get("name") or ("بلا اسم" if ar else "no name")
    label = inv.get("no") or ("المسودة" if ar else "this draft")
    detail = r.get("detail") or "items"
    def amount():
        if tot is None:
            return "المجموع مش كامل لأن في سعر ناقص." if ar else "The total isn't complete yet because a price is missing."
        return ("المجموع %s دولار." if ar else "The total is $%s.") % format(Decimal(str(tot)), ",.2f")
    if detail == "count":
        reply = ("بـ %s في %d بند." if ar else "There are %d items in %s.") % ((label, len(items)) if ar else (len(items), label))
    elif detail == "total":
        reply = amount()
    elif detail == "customer":
        reply = ("الزبون: %s." if ar else "The customer is %s.") % name
    elif detail == "status":
        reply = ("الحالة: %s." if ar else "The status is %s.") % (inv.get("status") or ("مسودة" if ar else "draft"))
    else:
        lines = ["%s × %s" % (format(Decimal(str(i["q"])).normalize(), "f") if i.get("q") is not None else "?", i["d"]) for i in items[:12]]
        reply = (("بـ %s: " if ar else "%s has: ") % label) + "، ".join(lines) + ". " + amount() if lines else \
                ("ما في بنود بعد." if ar else "It has no items yet.")
    return {"reply": reply, "understood": r.get("understood") or ""}


def product_answer(r):
    """Product questions are answered only from the catalog (products.json): never invented."""
    from database import search_products, suggest_products
    ar = r.get("language") == "ar"
    q = (r.get("product") or "").strip()
    if not q:
        return {"reply": "أي قطعة بتقصد؟ قلّي اسمها." if ar else "Which part do you mean? Tell me its name."}
    found = search_products(q) or suggest_products(q)
    if not found:
        return {"reply": ("ما لقيت «%s» بالكتالوج." if ar else "I couldn't find \"%s\" in the catalog.") % q}
    if len(found) > 1:
        names = "، ".join(p["name_ar"] if ar else p["name_en"] for p in found[:4])
        return {"reply": ("لقيت أكتر من قطعة: %s. أي وحدة بتقصد؟" if ar else "I found a few: %s. Which one do you mean?") % names}
    p = found[0]
    nm = p["name_ar"] if ar else p["name_en"]
    unit = p.get("unit") or ("قطعة" if ar else "piece")
    price = p.get("price_usd")
    price_txt = (("سعرها بالكتالوج %s دولار للـ%s." if ar else "Its catalog price is $%s per %s.") % (price, unit)) if price is not None else \
                ("ما في سعر إلها بالكتالوج." if ar else "The catalog has no price for it.")
    reply = ("%s (%s): %s" % (nm, p["id"], price_txt))
    if r.get("detail") == "stock":
        reply += (" الكتالوج ما فيه كميات المخزون، فما فيني أعرف قديش في." if ar else
                  " The catalog doesn't track stock, so I can't tell you how many are available.")
    return {"reply": reply, "product": {k: p.get(k) for k in ("id", "name_en", "name_ar", "unit", "price_usd")}}


CAPS_RE = re.compile(r"what can you do|how (?:do|does|to) (?:i|it|this|you)|\bhelp\b|features|شو (?:بتعمل|فيك|بتقدر)|كيف بستعمل|ساعدني|مساعدة", re.I)


def route(conversation, employee=""):
    from ai_agent import route_message
    now = time.localtime()
    return route_message(conversation, time.strftime("%Y-%m-%d", now), time.strftime("%A", now), employee)


def register_web(app):
    app.config.setdefault("INVOICE_DB", str(BASE / "garage.db"))
    invoice_services.register(app)

    @app.before_request
    def csrf_guard():
        if not request.path.startswith("/api/") or request.method in ("GET", "HEAD", "OPTIONS"):
            return None
        if request.path in CSRF_EXEMPT or not request.cookies.get(SESSION_COOKIE):
            return None
        sent, expected = request.headers.get(CSRF_HEADER, ""), request.cookies.get(CSRF_COOKIE, "")
        if not expected or not secrets.compare_digest(sent, expected):
            return err(403, "Security check failed. Refresh the page and try again.", code="csrf")
        return None

    # ---- accounts
    @app.post("/api/auth/register")
    def register():
        d = body()
        f = {k: text(d.get(k), 130) for k in ("first_name", "last_name", "username", "phone", "company_name")}
        f["username"] = f["username"].lower()
        password = d.get("password") if isinstance(d.get("password"), str) else ""
        errors = {}
        for k in ("first_name", "last_name"):
            if not f[k] or len(f[k]) > 50 or not NAME_RE.match(f[k]):
                errors[k] = "Use letters only (1-50 characters)."
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "3-30 characters: letters, numbers, '_' or '.'; start with a letter."
        msg = check_password_rules(password, f["username"])
        if msg:
            errors["password"] = msg
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        company_name = re.sub(r"\s+", " ", f["company_name"])
        if not 2 <= len(company_name) <= 120:
            errors["company_name"] = "Company name must be 2-120 characters."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        if limited("reg:" + (request.remote_addr or "")):
            return err(429, "Too many attempts. Please wait a few minutes.")
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to an existing terminal account. Choose a different web username.")
        try:
            with connect() as db:
                now = time.time()
                cid = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                 (company_name, f["phone"], str(DEFAULT_VAT), now)).lastrowid
                # The person who registers a new company is its owner. Nobody can join an existing company this way.
                uid = db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                                 "VALUES (?,?,?,?,?,?,?,?)", (cid, f["first_name"], f["last_name"], f["username"],
                                                              generate_password_hash(password), f["phone"], "owner", now)).lastrowid
                row = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
                company = company_of(db, row)
        except sqlite3.IntegrityError:
            fail("reg:" + (request.remote_addr or ""))
            return err(409, "Username is already taken.")
        resp = jsonify(user_json(row, company))
        resp.status_code = 201
        return start_session(resp, uid, True)

    @app.get("/api/auth/check-username")
    def check_username():
        name = text(request.args.get("username"), 40).lower()
        if not USERNAME_RE.match(name):
            return jsonify(available=False, suggestions=[], message="Invalid username format.")
        with connect() as db:
            taken = lambda n: db.execute("SELECT 1 FROM users WHERE username=?", (n,)).fetchone() is not None
            if not taken(name):
                return jsonify(available=True, suggestions=[])
            base = re.sub(r"[^a-z0-9]", "", name)[:20] or "user"
            cands = [base + "_garage", base + time.strftime("%Y"), base + "_trucks", base + "_auto", "%s.%d" % (base, secrets.randbelow(90) + 10)]
            free = [c for c in cands if USERNAME_RE.match(c) and not taken(c)][:3]
        return jsonify(available=False, suggestions=free)

    @app.get("/api/auth/me")
    def me():
        user = require_user()
        with connect() as db:
            return jsonify(user_json(user, company_of(db, user)))

    @app.put("/api/auth/me")
    def update_me():
        user = require_user("account.edit")
        d = body()
        f = {k: text(d.get(k), 60) for k in ("first_name", "last_name", "username", "phone")}
        f["username"] = f["username"].lower()
        errors = {k: "Use letters only." for k in ("first_name", "last_name") if not f[k] or not NAME_RE.match(f[k])}
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "Invalid username."
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to a terminal employee account. Choose a different website username.")
        try:
            with connect() as db:
                db.execute("UPDATE users SET first_name=?, last_name=?, username=?, phone=? WHERE id=?",
                           (f["first_name"], f["last_name"], f["username"], f["phone"], user["id"]))
                row = db.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
                return jsonify(user_json(row, company_of(db, row)))
        except sqlite3.IntegrityError:
            return err(409, "Username is already taken.")

    @app.post("/api/auth/password/change")
    def change_password():
        user = require_user("account.edit")
        d = body()
        if not check_password_hash(user["password_hash"], str(d.get("current_password", ""))):
            return err(400, "Current password is incorrect.", {"current_password": "Current password is incorrect."})
        msg = check_password_rules(d.get("new_password"), user["username"])
        if msg:
            return err(422, msg, {"new_password": msg})
        token = request.cookies.get(SESSION_COOKIE, "")
        with connect() as db:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(d["new_password"]), user["id"]))
            db.execute("DELETE FROM web_sessions WHERE user_id=? AND token_hash<>?", (user["id"], sha(token)))
        return Response(status=204)

    @app.post("/api/auth/password/forgot")
    def forgot():
        return err(501, "SMS password recovery is not configured. Contact the laptop administrator.")

    @app.post("/api/auth/password/reset")
    def reset():
        d = body()
        name = text(d.get("username"), 40).lower()
        code = text(d.get("code"), 10)
        with connect() as db:
            row = db.execute("SELECT u.*, r.code_hash, r.expires AS r_exp, r.attempts FROM users u JOIN reset_codes r ON r.user_id=u.id "
                             "WHERE u.username=?", (name,)).fetchone()
            if not row or row["r_exp"] < time.time() or row["attempts"] >= 5:
                return err(400, "This code is wrong or has expired.")
            if not secrets.compare_digest(row["code_hash"], sha(code)):
                db.execute("UPDATE reset_codes SET attempts=attempts+1 WHERE user_id=?", (row["id"],))
                return err(400, "This code is wrong or has expired.")
            msg = check_password_rules(d.get("password"), name)
            if msg:
                return err(422, msg, {"password": msg})
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(d["password"]), row["id"]))
            db.execute("DELETE FROM reset_codes WHERE user_id=?", (row["id"],))
            db.execute("DELETE FROM web_sessions WHERE user_id=?", (row["id"],))
        return jsonify(message="Password updated.")

    # ---- company
    @app.get("/api/company")
    def get_company():
        user = require_user()
        with connect() as db:
            return jsonify(company_json(company_of(db, user)))

    @app.put("/api/company")
    def put_company():
        user = require_user("company.manage")
        name = re.sub(r"\s+", " ", text(request.form.get("name"), 130))
        phone = text(request.form.get("phone"), 20)
        errors = {}
        if not 2 <= len(name) <= 120:
            errors["name"] = "Company name must be 2-120 characters."
        if not valid_phone(phone):
            errors["phone"] = "Enter a valid phone number."
        logo = request.files.get("logo")
        data = ctype = None
        if logo:
            data = logo.read(2 * 1024 * 1024 + 1)
            if len(data) > 2 * 1024 * 1024:
                errors["logo"] = "The logo must be 2 MB or smaller."
            elif data[:8] == b"\x89PNG\r\n\x1a\n":
                ctype = "image/png"
            elif data[:3] == b"\xff\xd8\xff":
                ctype = "image/jpeg"
            elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
                ctype = "image/webp"
            else:
                errors["logo"] = "Please upload a PNG, JPG or WebP image."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        with connect() as db:
            db.execute("UPDATE companies SET name=?, phone=? WHERE id=?", (name, phone, user["company_id"]))
            if data:
                db.execute("UPDATE companies SET logo=?, logo_type=?, logo_ver=? WHERE id=?",
                           (data, ctype, secrets.token_hex(4), user["company_id"]))
            elif request.form.get("remove_logo") == "1":
                db.execute("UPDATE companies SET logo=NULL, logo_type=NULL, logo_ver=NULL WHERE id=?", (user["company_id"],))
            return jsonify(company_json(company_of(db, user)))

    @app.get("/media/logo/<int:cid>")
    def logo(cid):
        user = require_user()
        if user["company_id"] != cid:
            return err(404, "Not found.")
        with connect() as db:
            c = db.execute("SELECT logo, logo_type FROM companies WHERE id=?", (cid,)).fetchone()
        if not c or not c["logo"]:
            return err(404, "No logo.")
        resp = Response(c["logo"], mimetype=c["logo_type"])
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "private, max-age=86400"
        return resp

    # ---- catalog & customers
    @app.get("/api/catalog")
    def catalog():
        require_user()
        return jsonify([[p["name_en"], "Part", p["price_usd"]] for p in load_products()])

    @app.get("/api/trucks/lookup")
    def truck_lookup():
        """Customer memory for the invoice editor: by plate number (the truck's ID), or by phone."""
        user = require_user("ai.chat")
        with connect() as db:
            known = truck_memory.profile(db, user["company_id"], request.args.get("plate"), request.args.get("tel"),
                                         exclude=request.args.get("exclude"))
        return jsonify(known or {})

    @app.get("/api/customers")
    def customers():
        user = require_user("invoice.history")
        with connect() as db:
            out = [invoice_services.customer_out(r) for r in db.execute('SELECT * FROM web_customers WHERE company_id=? ORDER BY name',(user['company_id'],)).fetchall()]
        seen = {(c['name'].casefold(),c.get('tel',''),c.get('email','')) for c in out}
        for inv in _list(user):
            c = inv.get("cust", {})
            key = (c.get("name","").casefold(),c.get("tel",""),c.get("email",""))
            if c.get("name") and key not in seen:
                seen.add(key)
                out.append(c)
        return jsonify(out)

    def _list(user):
        sql, args = "SELECT * FROM web_invoices WHERE company_id=?", [user["company_id"]]
        if user["role"] != "owner":
            sql += " AND created_by=?"
            args.append(user["id"])
        with connect() as db:
            rows = db.execute(sql + " ORDER BY seq", args).fetchall()
            # latest delivery status per method, shown in Invoice History (Not Sent / Sending / Sent / Failed)
            last = {}
            for d in db.execute("SELECT invoice_id, method, status FROM delivery_attempts WHERE invoice_id IN (SELECT id FROM web_invoices WHERE company_id=?) "
                                "ORDER BY attempted_at", (user["company_id"],)).fetchall():
                last.setdefault(d["invoice_id"], {})[d["method"]] = d["status"]
            out = []
            for r in rows:
                inv = invoice_out(r)
                inv["delivery"] = {m: last.get(r["id"], {}).get(m, "not_sent") for m in ("email", "whatsapp")}
                out.append(inv)
            return out

    # ---- invoices
    @app.get("/api/invoices")
    def list_invoices():
        return jsonify(_list(require_user("invoice.history")))

    @app.post("/api/invoices/generate")
    def generate():
        """One chat endpoint. With ?progress=1 the answer is streamed as NDJSON: {"type":"step"|"activity",...} lines
        for each real step MA takes, then one {"type":"result","status":...,"body":...} line.
        Voice turns: multipart with an "audio" file and a "payload" JSON field. The recording is transcribed and
        answered in the same request (one round trip); a {"type":"transcript"} line arrives as soon as it is heard."""
        user = require_user("ai.chat")       # auth/CSRF problems are answered normally, before streaming
        audio = None
        if request.files.get("audio") is not None:
            from voice_agent import MAX_AUDIO_BYTES
            audio = request.files["audio"].read(MAX_AUDIO_BYTES + 1)
            if len(audio) > MAX_AUDIO_BYTES:
                return err(413, "Recording exceeds 10 MB.")
            try:
                data = json.loads(request.form.get("payload") or "{}")
            except ValueError:
                return err(400, "Invalid voice request.")
        else:
            data = body()
        data = data if isinstance(data, dict) else {}
        if request.args.get("progress") != "1":
            CHAT_INPUT.set((data, audio))
            return generate_once()
        events = queue.Queue()

        @copy_current_request_context
        def work():
            PROGRESS.set(events.put)
            CHAT_INPUT.set((data, audio))
            try:
                resp = current_app.make_response(generate_once())
                events.put({"type": "result", "status": resp.status_code, "body": resp.get_json(silent=True)})
            except HTTPException as exc:
                events.put({"type": "result", "status": exc.code or 500, "body": {"detail": exc.description}})
            except Exception:
                current_app.logger.error("AI generation failed")
                events.put({"type": "result", "status": 500, "body": {"detail": "MA couldn't finish this. Please try again."}})
            finally:
                events.put(None)

        threading.Thread(target=work, daemon=True).start()

        def lines():
            while True:
                item = events.get()
                if item is None:
                    return
                yield json.dumps(item, ensure_ascii=False) + "\n"
        return Response(lines(), mimetype="application/x-ndjson", headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    def generate_once():
        """Understands what the employee wants, then drafts, answers or opens. Every answer carries `language`
        (the language MA replied in, so the right voice reads it)."""
        user = require_user("ai.chat")
        d, audio = CHAT_INPUT.get() or (body(), None)
        history = d.get("history") if isinstance(d.get("history"), list) else []
        turns = [h for h in history if isinstance(h, dict) and h.get('role') in ('user','assistant') and isinstance(h.get('text'),str) and h['text'].strip()]
        latest = text(d.get('text'),5000)
        if audio is not None:
            from voice_agent import transcribe_audio
            act("transcribe", "processing", "Listening to your voice message", "عم إسمع رسالتك الصوتية")
            try:
                latest = transcribe_audio(audio)
            except ValueError as exc:
                act("transcribe", "failed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", error=str(exc))
                return err(400, "I couldn't hear anything clear. Please try again. ما سمعت شي واضح، جرّب كمان مرّة.")
            except GeminiUnavailable:
                act("transcribe", "failed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", error="AI service busy")
                return err(503, "MA is busy right now. Please say it again in a moment.")
            lang = "ar" if re.search(r'[؀-ۿ]', latest) else "en"
            act("transcribe", "completed", "Listening to your voice message", "عم إسمع رسالتك الصوتية", detail=latest[:120])
            emit = PROGRESS.get()
            if emit:
                emit({"type": "transcript", "text": latest, "language": lang})
        if latest and (not turns or turns[-1]['role'] != 'user' or turns[-1]['text'].strip() != latest):
            turns.append({'role':'user','text':latest})
        if not turns or turns[-1]['role'] != 'user':
            return err(400, "Describe the repair first.")
        out = converse(user, d, turns)
        if isinstance(out, tuple):
            return out
        if audio is not None:
            out["transcript"] = latest
        return jsonify(out)

    def load_state(turns):
        """The signed state of MA's last invoice question (what it understood + what it asked), if still valid."""
        prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), None)
        token = prev.get("state") if prev else None
        if not isinstance(token, str) or not token:
            return None
        try:
            st = STATES.loads(token, max_age=1800)
        except (BadSignature, TypeError):
            return None
        user = session_user()
        if not user or st.get("user") != user["id"] or st.get("session") != sha(request.cookies.get(SESSION_COOKIE, "")):
            return None
        return st

    def sign_state(user, result, ar):
        st = result.pop("_state", None)
        if st is not None:
            result["state"] = STATES.dumps({**st, "ar": ar, "user": user["id"], "session": sha(request.cookies.get(SESSION_COOKIE, ""))})
        return result

    def converse(user, d, turns):
        label = lambda h: ('Mechanic: ' if h['role']=='user' else 'Assistant: ')+h['text'].strip()
        latest = turns[-1]["text"]
        step("start", "Reading your message", "عم إقرا رسالتك")
        act("understand", "processing", *INVOICE_PLAN[0][1:])
        prev = next((h for h in reversed(turns[:-1]) if h["role"] == "assistant"), {})
        state = load_state(turns)
        has_ar = bool(re.search(r'[؀-ۿ]', latest))
        has_en = bool(re.search(r'[A-Za-z]{3,}', re.sub(r'(?<![A-Za-z])[A-Za-z]{1,3}\s?-?\d{2,6}', ' ', latest)))
        # language of THIS message; a bare answer ("A1234", "Haddad") keeps the conversation's language
        ar_now = has_ar or (not has_en and bool(state and state.get("ar")))
        # 1) Understand the request. Fast paths first (no AI call), then the router.
        r, speculative = quick_route(turns), None
        slots = {}
        if not r and state and state.get("asked"):
            slots = invoice_validation.answer_slots(latest, state["asked"])
            leftover = re.sub(r"(?<![A-Za-z0-9])[A-Za-z]{0,3}[\s\-]?\d{2,6}(?![A-Za-z0-9])", " ", latest)
            short = len(latest.split()) <= 6 and not re.search(r"\d", leftover.translate(AR_DIGITS))
            if slots and short:
                r = {"intent": "invoice", "fast": True}
        if not r and prev.get("kind") == "question" and not FOLLOWUP_OTHER_RE.search(latest):
            r = {"intent": "invoice"}            # answering MA's invoice question: no need to re-route
        if not r:
            convo = '\n\n'.join(label(h) for h in turns[-12:])[-5000:]
            likely_repair = len(latest) > 25 and not FOLLOWUP_OTHER_RE.search(latest)
            pool = concurrent.futures.ThreadPoolExecutor(max_workers=2) if likely_repair else None
            if pool:   # start reading the repair while the intent is decided: saves one full AI round trip
                window = '\n\n'.join(('Mechanic: ' if h['role']=='user' else 'Assistant question: ')+h['text'].strip() for h in repair_window(turns, False)[0])
                import invoice_engine
                speculative = (window, pool.submit(invoice_engine.understand_message, window))
            try:
                r = route(convo, user["first_name"])
            except GeminiUnavailable:
                r = {"intent": "invoice"}
            except Exception:
                current_app.logger.warning("Intent detection failed; treating the message as a repair")
                r = {"intent": "invoice"}
            finally:
                if pool:
                    pool.shutdown(wait=False)
        r = dict(r)                              # never modify the router's own result
        intent = r.get("intent")
        ar = (r.get("language") == "ar") if r.get("language") in ("ar", "en") and not has_ar else ar_now
        lang = "ar" if ar else "en"
        step("intent", *{"invoice": ("Preparing an invoice", "عم حضّر فاتورة"), "invoice_query": ("Looking up your invoices", "عم دوّر بفواتيرك"),
                         "current_invoice": ("Reading the invoice on screen", "عم إقرا الفاتورة المفتوحة"), "product_info": ("Checking the catalog", "عم شوف الكتالوج"),
                         "open_invoice": ("Opening the invoice", "عم إفتح الفاتورة"), "send_whatsapp": ("Preparing to send", "عم حضّر للإرسال"),
                         "send_email": ("Preparing to send", "عم حضّر للإرسال")}.get(intent, ("Answering in the chat", "عم جاوبك بالمحادثة")), intent=intent or "")
        act("understand", "completed", *INVOICE_PLAN[0][1:], intent=intent or "",
            plan=[{"key": k, "en": en, "ar": a} for k, en, a in INVOICE_PLAN] if intent == "invoice" else None,
            detail={"invoice": ("Invoice", "فاتورة"), "invoice_query": ("Question about invoices", "سؤال عن الفواتير"),
                    "send_whatsapp": ("Send by WhatsApp", "إرسال عالواتساب"), "send_email": ("Send by email", "إرسال عالإيميل"),
                    "cancel": ("Cancel", "إلغاء"), "pause": ("Pause", "توقيف مؤقت")}.get(intent, ("Conversation", "محادثة"))[1 if ar else 0])
        r["language"] = lang
        done = lambda o: {**o, "language": lang}
        if intent == "invoice_query":
            return done(answer_query(user, r))
        if intent == "open_invoice":
            return done(open_by_number(user, r))
        if intent in ("send_whatsapp", "send_email"):
            return done(share_request(user, r, turns, d.get("context")))
        if intent == "current_invoice":
            return done(current_invoice_answer(user, r, d.get("context")))
        if intent == "product_info":
            return done(product_answer(r))
        if intent == "cancel":
            return done({"reply": "تمام، لغيت المسودة. ما انحفظ شي، والفواتير المحفوظة ما بتنمحى." if ar else
                         "OK, I cancelled this draft. Nothing new was saved, and saved invoices are never deleted.",
                         "action": {"type": "cancel"}})
        if intent == "pause":
            # nothing is lost: the next message continues the same invoice (the question's state is kept)
            out = {"reply": "تمام، وقّفنا شوي. كل المعلومات محفوظة، قلّي «كمّل» لما تكون جاهز." if ar else
                   "Sure, paused. Everything so far is kept. Say \"continue\" when you're ready.",
                   "action": {"type": "pause"}, "kind": "pause"}
            if prev.get("state"):
                out["state"] = prev["state"]
            return done(out)
        if intent in ("help", "chat"):
            reply = (r.get("reply") or "").strip()[:1500] or (HELP_AR if ar else HELP_EN)
            if intent == "help" and len(reply) < 60 and CAPS_RE.search(latest):
                reply += "\n\n" + (HELP_AR if ar else HELP_EN)
            return done({"reply": reply})
        # 2) A repair: only the turns since the last non-repair answer belong to this invoice,
        #    and "new invoice / another customer" starts a fresh one (never mixed with the previous draft).
        repair, new_invoice = repair_window(turns, bool(r.get("new_invoice")))
        message = '\n\n'.join(('Mechanic: ' if h['role']=='user' else 'Assistant question: ')+h['text'].strip() for h in repair)
        if len(message) > 5000:
            return err(400, "That description is too long. Please keep it under 5000 characters.")
        if new_invoice:
            state, slots = None, {}
        try:
            with connect() as db:
                company = company_of(db, user)
            collected = (state or {}).get("collected")
            if r.get("fast") and state.get("order"):
                step("extract", "Using your answer", "عم إستعمل جوابك")
                result = ai_draft(message, company, confirmed_order=state["order"], ar=ar, slots=slots, collected=collected)
            else:
                pre = None
                if speculative and speculative[0] == message:
                    try:
                        pre = speculative[1].result(timeout=25)
                    except Exception:
                        pre = None
                # a short answer the AI might read differently: what the employee clearly answered still wins
                result = ai_draft(message, company, ar=ar, precomputed=pre, slots=slots, collected=collected)
            if new_invoice:
                result['new_invoice'] = True     # the frontend must not overwrite the previous invoice
            if '_pending_order' in result:
                result = part_lookup.enrich_proposal(result)
                result['confirmation_token'] = PROPOSALS.dumps({'user':user['id'], 'company':user['company_id'],
                    'session':sha(request.cookies.get(SESSION_COOKIE,'')), 'message':message,
                    'order':result.pop('_pending_order'), 'suggestions':result['suggestions']})
            return done(sign_state(user, result, ar))
        except GeminiUnavailable:
            act("extract", "failed", *INVOICE_PLAN[1][1:], error="AI service busy")
            return err(503, "The AI service is busy right now. Please try again in a moment.")
        except Exception:
            current_app.logger.exception("AI invoice generation failed")
            return err(500, "The AI couldn't prepare this invoice. Please try again or rephrase the repair.")

    @app.post('/api/invoices/confirm-parts')
    def confirm_parts():
        user = require_user('ai.chat')
        data = body()
        try:
            proposal = PROPOSALS.loads(data.get('confirmation_token',''), max_age=900)
        except (BadSignature, TypeError):
            return err(409, 'This suggestion expired. Describe the part again.')
        if proposal['user'] != user['id'] or proposal['company'] != user['company_id'] or proposal['session'] != sha(request.cookies.get(SESSION_COOKIE,'')):
            return err(403, 'This suggestion belongs to another session.')
        selections = data.get('selections')
        if data.get('confirm') is not True or not isinstance(selections,dict):
            return err(409, 'Explicitly select and confirm each suggested part.')
        order = proposal['order']
        for suggestion in proposal['suggestions']:
            selected = selections.get(str(suggestion['index']))
            if isinstance(selected,dict) and selected.get('custom') is True:
                name = text(selected.get('name'),120)
                if not suggestion.get('custom_allowed'):
                    return err(422,'This item cannot be added as a custom line. Describe it again.')
                if not name:
                    return err(422,'Enter the name to display on the invoice for this item.')
                if part_lookup.obvious_non_part(name):
                    return err(422,'This item is outside the garage scope.')
                try:
                    qty = Decimal(str(selected.get('quantity')))
                    price = Decimal(str(selected.get('unit_price')))
                    if not name or not qty.is_finite() or qty != qty.to_integral() or not 0 < qty <= 10000:
                        raise ValueError()
                    if not price.is_finite() or not 0 <= price <= 10000000: raise ValueError()
                    currency = selected.get('currency')
                    if currency not in ('USD','LBP'): raise ValueError()
                except (ValueError,InvalidOperation,TypeError):
                    return err(422,'Custom items require a description, positive whole quantity, nonnegative unit price and USD/LBP currency.')
                order['parts'][suggestion['index']].update(name=name,quantity=int(qty),unit_price=float(price),
                    line_price=None,price_currency=currency,match_type='named',scope='automotive',clarification='',_custom_confirmed=True)
                continue
            if selected not in [x['id'] for x in suggestion['candidates']]:
                return err(422, 'Choose one of the suggested catalog parts for each description.')
            product = get_product_by_id(selected)
            if not product: return err(409, 'The product is no longer available.')
            part = order['parts'][suggestion['index']]
            part.update(name=product['name_en'],match_type='named',clarification='')
        with connect() as db:
            company = company_of(db,user)
        ar = bool(re.search(r'[؀-ۿ]', proposal['message']))
        return jsonify(sign_state(user, ai_draft(proposal['message'],company,confirmed_order=order,ar=ar), ar))

    @app.post("/api/invoices")
    def create():
        user = require_user("invoice.create")
        try:
            with connect() as db:
                company = company_of(db, user)
                payload = clean_payload(body(), company)
                request_key = text(request.headers.get('Idempotency-Key') or body().get('client_request_id'),100)
                digest = sha(json.dumps(payload,sort_keys=True,ensure_ascii=False))
                db.execute("BEGIN IMMEDIATE")
                if request_key:
                    prior = db.execute('SELECT * FROM invoice_create_requests WHERE company_id=? AND user_id=? AND request_key=?',
                                       (user['company_id'],user['id'],request_key)).fetchone()
                    if prior:
                        if prior['digest'] != digest: return err(409,'This save request was already used for different invoice data.')
                        return jsonify(invoice_out(find_invoice(db,user,prior['invoice_id'])))
                seq = db.execute("SELECT COALESCE(MAX(seq),0)+1 FROM web_invoices WHERE company_id=?", (user["company_id"],)).fetchone()[0]
                ident, now = uuid.uuid4().hex, time.time()
                db.execute("INSERT INTO web_invoices(id, company_id, seq, no, created_by, status, payload, created_at, updated_at) "
                           "VALUES (?,?,?,?,?,?,?,?,?)", (ident, user["company_id"], seq, "INV-%04d" % seq, user["id"], "pending",
                                                          json.dumps(payload, ensure_ascii=False), now, now))
                truck_memory.remember(db, user["company_id"], payload["cust"], payload["truck"])
                if request_key:
                    db.execute('INSERT INTO invoice_create_requests VALUES (?,?,?,?,?)',
                               (user['company_id'],user['id'],request_key,digest,ident))
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row)), 201

    @app.put("/api/invoices/<ident>")
    def update(ident):
        user = require_user("invoice.edit")
        try:
            with connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row = find_invoice(db, user, ident)
                if not row:
                    return err(404, "Invoice not found.")
                if row["status"] not in ("draft", "rejected", "pending"):
                    return err(409, "Approved invoices can't be edited. Move the invoice back to Pending first.")
                payload = clean_payload(body(), company_of(db, user))
                db.execute("UPDATE web_invoices SET payload=?, status='pending', updated_at=? WHERE id=?",
                           (json.dumps(payload, ensure_ascii=False), time.time(), ident))
                truck_memory.remember(db, user["company_id"], payload["cust"], payload["truck"])
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row))

    @app.post("/api/invoices/<ident>/submit")
    def submit(ident):
        return move(ident, ("draft", "rejected", "pending"), "pending", "invoice.submit", strict=True)

    @app.post("/api/invoices/<ident>/pending")
    def mark_pending(ident):
        """The employee's Pending button. Moving an approved invoice back needs approval rights."""
        user = require_user("invoice.submit")
        with connect() as db:
            row = find_invoice(db, user, ident)
        if row and row["status"] == "approved":
            return move(ident, ("approved",), "pending", "invoice.approve")
        return move(ident, ("draft", "rejected", "pending"), "pending", "invoice.submit")

    @app.post("/api/invoices/<ident>/reject")
    def reject(ident):
        return move(ident, ("pending",), "rejected", "invoice.reject")

    @app.post("/api/invoices/<ident>/email")
    def email(ident):
        """Sends the approved invoice PDF through the SMTP settings in .env (delivery_providers)."""
        return invoice_services.deliver(ident,'email')

    # ---- frontend pages (same origin as the API)
    @app.get("/")
    def home():
        return redirect("/signin.html")

    @app.get("/<path:filename>")
    def frontend(filename):
        if filename.startswith(("api/", "media/")):
            return err(404, "Not found.")
        target = (FRONTEND / filename).resolve()
        if FRONTEND.resolve() not in target.parents or not target.is_file() or target.suffix == ".md":
            abort(404)
        resp = send_from_directory(FRONTEND, filename)
        resp.headers["Cache-Control"] = "no-cache"
        return resp


def create_user(username, password, first, last, company_name, phone="+96171123456", role="owner", company_id=None, path=None):
    """Helper for scripts: create a web account (and a company if company_id is None)."""
    with connect(path) as db:
        now = time.time()
        if company_id is None:
            company_id = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                    (company_name, phone, str(DEFAULT_VAT), now)).lastrowid
        db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                   "VALUES (?,?,?,?,?,?,?,?)", (company_id, first, last, username.lower(), generate_password_hash(password), phone, role, now))
        return company_id


def web_pdf(ident):
    """Approved invoice -> final PDF. Pending invoice -> PDF stamped PREVIEW (only with ?preview=1)."""
    user = require_user("invoice.history")
    preview = request.args.get("preview") in ("1", "true")
    with connect() as db:
        row = find_invoice(db, user, ident)
        if not row: return err(404, "Invoice not found.")
        approved = row["status"] == "approved"
        if not approved and not preview:
            return err(409, "Approve this invoice before downloading its final PDF.")
        payload = json.loads(row["payload"])
        if approved:
            # The approved PDF is stored once at approval; every download/print/send uses the same bytes.
            if not has_identity(payload):
                return err(409, "The truck plate number is required before releasing an invoice.")
            approver = db.execute("SELECT username FROM users WHERE id=?",(row['approved_by'],)).fetchone()
            content = invoice_services.store_approved_pdf(db,row,approver['username'] if approver else 'Owner')
        else:
            # Pending: a fresh preview stamped PENDING - PREVIEW (never stored, never sent).
            content = invoice_services.render_pdf(db, row)
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)",
                   (ident, user["username"], "pdf_released" if approved else "pdf_preview", time.time()))
    return send_file(BytesIO(content), mimetype="application/pdf", as_attachment=request.args.get('inline')!='1',
                     download_name=row["no"] + ("" if approved else "-PREVIEW") + ".pdf")
