import sys,tempfile,unittest,copy
from pathlib import Path

from app import app
from test_web import SIGNUP
from unittest.mock import patch
import web_api
ORDER={'customer':'Demo Haddad','truck_plate':'D0001','parts':[{'name':'charging part','description':'charges battery','match_type':'description','candidate_ids':['P009','P999'],'quantity':1,'unit_price':240,'price_currency':'USD'}],'labor_amount':None,'labor_currency':None}
class SuggestionTests(unittest.TestCase):
 def setUp(self):
  from test_part_lookup import fixture_lookup
  lookup_mock=patch('part_lookup.lookup_part',side_effect=fixture_lookup);lookup_mock.start();self.addCleanup(lookup_mock.stop)
  router_mock=patch('ai_agent.route_message',side_effect=lambda *a,**k:{'intent':'invoice'});router_mock.start();self.addCleanup(router_mock.stop)
  self.temp=tempfile.TemporaryDirectory();self.old=app.config['INVOICE_DB'];app.config['INVOICE_DB']=self.temp.name+'/test.db';self.c=app.test_client();self.c.post('/api/auth/register',json=SIGNUP);self.h={'X-CSRF-Token':self.c.get_cookie('if_csrf').value}
 def tearDown(self):app.config['INVOICE_DB']=self.old;self.temp.cleanup()
 def proposal(self,order=None):
  with patch('invoice_engine.understand_message',return_value=order or ORDER):r=self.c.post('/api/invoices/generate',json={'text':'charges battery'},headers=self.h)
  self.assertEqual(r.status_code,200);self.assertNotIn('items',r.json);self.assertNotIn('_pending_order',r.json);return r.json
 def confirm(self,r,selections=None,**extra):
  return self.c.post('/api/invoices/confirm-parts',json={'confirmation_token':r['confirmation_token'],'selections':selections or {'0':'P009'},'confirm':True,**extra},headers=self.h)
 def test_confirm_preserves_price_and_quantity(self):
  r=self.proposal();self.assertEqual([x['id'] for x in r['suggestions'][0]['candidates']],['P009'])
  with patch('invoice_engine.understand_message',side_effect=AssertionError('Must not re-guess')):
   d=self.confirm(r)
  self.assertEqual(d.status_code,200);self.assertEqual(d.json['items'][0]['d'],'Alternator');self.assertEqual(d.json['totals']['total_usd'],240)
 def test_guards(self):
  r=self.proposal()
  self.assertEqual(self.confirm(r,{'0':'P008'}).status_code,422)
  self.assertEqual(self.confirm(r,confirm=False).status_code,409)
  self.assertEqual(self.confirm(r,confirmation_token=r['confirmation_token']+'x').status_code,409)
  self.assertEqual(self.c.post('/api/invoices/confirm-parts',json={}).status_code,403)
  other=app.test_client();other.post('/api/auth/register',json={**SIGNUP,'username':'other_owner'});h={'X-CSRF-Token':other.get_cookie('if_csrf').value}
  self.assertEqual(other.post('/api/invoices/confirm-parts',json={'confirmation_token':r['confirmation_token'],'selections':{'0':'P009'},'confirm':True},headers=h).status_code,403)
 def test_missing_price_remains_null(self):
  order=copy.deepcopy(ORDER);order['parts'][0]['unit_price']=None
  d=self.confirm(self.proposal(order)).json;self.assertIsNone(d['items'][0]['p']);self.assertTrue(d['totals']['incomplete'])
 def test_unknown_and_ambiguous(self):
  order=copy.deepcopy(ORDER);order['parts'][0]['candidate_ids']=['P999']
  r=self.proposal(order);self.assertEqual(r['suggestions'][0]['candidates'],[]);self.assertEqual(self.confirm(r).status_code,422)
  order['parts'][0]['candidate_ids']=['P008','P010'];r=self.proposal(order)
  self.assertEqual(len(r['suggestions'][0]['candidates']),2)
  d=self.confirm(r,{'0':'P010'}).json;self.assertEqual(d['items'][0]['d'],'Starter Motor')
if __name__=='__main__':unittest.main()

