"""Persistent local employee authentication and immutable invoice approvals."""
import hashlib, json, secrets, sqlite3, time, uuid
from invoice_identity import has_identity
from contextlib import contextmanager
from pathlib import Path
from werkzeug.security import generate_password_hash, check_password_hash

DEFAULT_DB = Path(__file__).parent / 'garage.db'
DUMMY_HASH = generate_password_hash('not-a-real-password')

@contextmanager
def connect(path=DEFAULT_DB):
    db=sqlite3.connect(path, timeout=10)
    db.row_factory=sqlite3.Row
    db.executescript('''
    CREATE TABLE IF NOT EXISTS employees(username TEXT PRIMARY KEY, password_hash TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, expires REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS login_limits(bucket TEXT PRIMARY KEY, failures INTEGER NOT NULL, reset_at REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS invoices(id TEXT PRIMARY KEY, payload TEXT NOT NULL, digest TEXT NOT NULL, approved_by TEXT, approved_at REAL);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, invoice_id TEXT, employee TEXT, action TEXT, at REAL);
    ''')
    try:
        with db:
            yield db
    finally:
        db.close()

def create_employee(username,password,path=DEFAULT_DB):
    username=username.strip()
    if not username or len(username)>80 or len(password)<12: raise ValueError('Username required; password must have at least 12 characters')
    with connect(path) as db:
        db.execute('INSERT OR REPLACE INTO employees VALUES (?,?)',(username,generate_password_hash(password)))
        db.execute('DELETE FROM sessions WHERE username=?',(username,))

def login(username,password,address,path):
    now=time.time(); bucket=hashlib.sha256(address.encode()).hexdigest()
    with connect(path) as db:
        db.execute('BEGIN IMMEDIATE')
        limit=db.execute('SELECT * FROM login_limits WHERE bucket=?',(bucket,)).fetchone()
        if limit and limit['reset_at']>now and limit['failures']>=5: return None,429
        row=db.execute('SELECT password_hash FROM employees WHERE username=?',(username,)).fetchone()
        valid=check_password_hash(row['password_hash'] if row else DUMMY_HASH,password)
        if not row or not valid:
            count=limit['failures']+1 if limit and limit['reset_at']>now else 1
            reset=limit['reset_at'] if limit and limit['reset_at']>now else now+300
            db.execute('INSERT OR REPLACE INTO login_limits VALUES (?,?,?)',(bucket,count,reset))
            return None,401
        db.execute('DELETE FROM login_limits WHERE bucket=?',(bucket,))
        db.execute('DELETE FROM sessions WHERE expires<?',(now,))
        token=secrets.token_urlsafe(32)
        db.execute('INSERT INTO sessions VALUES (?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),username,now+3600))
        return token,200

def employee(token,path):
    with connect(path) as db:
        row=db.execute('SELECT username FROM sessions WHERE token_hash=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
    return row['username'] if row else None

def logout(token,path):
    with connect(path) as db: db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))

def save_draft(invoice,path):
    payload=json.dumps(invoice,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    ident=uuid.uuid4().hex; digest=hashlib.sha256(payload.encode()).hexdigest()
    with connect(path) as db:
        db.execute('INSERT INTO invoices(id,payload,digest) VALUES (?,?,?)',(ident,payload,digest))
    return {**invoice,'invoice_id':ident,'review_digest':digest}

def get_invoice(ident,path):
    with connect(path) as db: row=db.execute('SELECT * FROM invoices WHERE id=?',(ident,)).fetchone()
    if not row: return None
    return {**json.loads(row['payload']),'invoice_id':ident,'review_digest':row['digest'],'approved':bool(row['approved_by']),'status':'approved' if row['approved_by'] else 'needs_review','approved_by':row['approved_by'],'approved_at':row['approved_at']}

def approve(ident,digest,user,ack,path):
    with connect(path) as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT * FROM invoices WHERE id=?',(ident,)).fetchone()
        if not row: return 404
        if not isinstance(digest,str) or not secrets.compare_digest(row['digest'],digest): return 409
        invoice = json.loads(row['payload'])
        if not has_identity(invoice): return 409
        if invoice.get('incomplete') or any(i.get('price_usd') is None for i in invoice.get('items', [])): return 409
        if invoice.get('warnings') and ack is not True: return 409
        if not row['approved_by']:
            now=time.time()
            db.execute('UPDATE invoices SET approved_by=?,approved_at=? WHERE id=?',(user,now,ident))
            db.execute('INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)',(ident,user,'approved',now))
    return 200

def record_release(ident,user,path):
    with connect(path) as db: db.execute('INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)',(ident,user,'pdf_released',time.time()))
