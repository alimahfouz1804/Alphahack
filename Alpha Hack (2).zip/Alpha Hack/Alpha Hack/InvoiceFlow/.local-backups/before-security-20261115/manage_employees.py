"""Run locally to create/reset an employee. Passwords are never echoed."""
import getpass
from approval_store import create_employee
if __name__ == '__main__':
    username=input('Employee username: ').strip()
    password=getpass.getpass('Password (12+ characters): ')
    if password != getpass.getpass('Confirm password: '):
        raise SystemExit('Passwords do not match')
    try: create_employee(username,password)
    except ValueError as error: raise SystemExit(str(error))
    print('Employee saved. Existing sessions for this employee were revoked.')
