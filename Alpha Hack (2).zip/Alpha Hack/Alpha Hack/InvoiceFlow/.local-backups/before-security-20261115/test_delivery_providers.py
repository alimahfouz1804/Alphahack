import io,json,os,smtplib,unittest
from unittest.mock import patch,MagicMock
from urllib.error import HTTPError
import delivery_providers as p
SMTP={'SMTP_HOST':'mail.example.test','SMTP_USER':'test','SMTP_PASSWORD':'not-a-secret','SMTP_FROM':'shop@example.test'}
WA={'WHATSAPP_ACCESS_TOKEN':'test-token','WHATSAPP_PHONE_NUMBER_ID':'123','WHATSAPP_API_VERSION':'v27.0'}
class ProviderTests(unittest.TestCase):
 def test_email_uses_exact_pdf_and_tls(self):
  inv={'no':'INV-123','cust':{'name':'Test'},'company':{'name':'Garage'}};pdf=b'%PDF-test-exact'
  with patch.dict(os.environ,SMTP),patch('delivery_providers.smtplib.SMTP') as smtp:
   client=smtp.return_value;client.send_message.return_value={}
   p.send_email('customer@example.test',pdf,inv)
   msg=client.send_message.call_args.args[0];self.assertEqual(next(msg.iter_attachments()).get_payload(decode=True),pdf)
   client.starttls.assert_called_once();self.assertEqual(msg['To'],'customer@example.test')
 def test_email_shows_company_name_and_invoice_number(self):
  inv={'no':'INV-0042','cust':{'name':'Ahmad Haddad'},'company':{'name':'Cedar Trucks'},'email_subject':'Your repair'}
  with patch.dict(os.environ,SMTP),patch('delivery_providers.smtplib.SMTP') as smtp:
   smtp.return_value.send_message.return_value={}
   p.send_email('customer@example.test',b'%PDF',inv)
   msg=smtp.return_value.send_message.call_args.args[0]
  self.assertEqual(msg['From'],'Cedar Trucks <shop@example.test>')
  self.assertEqual(msg['Subject'],'Invoice #INV-0042 — Your repair')
  self.assertEqual(p.email_subject({'no':'INV-7','company':{'name':'Cedar'}}),'Invoice #INV-7 — Cedar')
  self.assertIn('Please find attached your invoice from Cedar.',p.email_body({'company':{'name':'Cedar'}}))
 def test_email_errors_are_explained_without_secrets(self):
  inv={'no':'INV-1','company':{'name':'G'}}
  for exc,words in ((smtplib.SMTPAuthenticationError(535,b'bad'),'refused the login'),(smtplib.SMTPRecipientsRefused({}),'rejected this email address'),(ConnectionRefusedError(),'network')):
   with patch.dict(os.environ,SMTP),patch('delivery_providers.smtplib.SMTP') as smtp:
    smtp.return_value.login.side_effect=exc
    with self.assertRaises(p.DeliveryError) as e: p.send_email('c@example.test',b'%PDF',inv)
   self.assertIn(words,str(e.exception));self.assertNotIn('not-a-secret',str(e.exception))
  with patch.dict(os.environ,{k:'' for k in SMTP}):
   with self.assertRaises(p.DeliveryError) as e: p.send_email('c@example.test',b'%PDF',inv)
  self.assertIn('not configured',str(e.exception))
 def test_whatsapp_upload_and_document_submission(self):
  pdf=b'%PDF-identical-bytes'
  with patch.dict(os.environ,WA),patch('delivery_providers.meta_request',side_effect=[{'id':'media-123'},{'messages':[{'id':'message-123'}]}]) as req:
   os.environ.pop('WHATSAPP_TEMPLATE_NAME',None)
   self.assertEqual(p.send_whatsapp('+96171123456',pdf,{'no':'INV-123','company':{'name':'Cedar'}}),'message-123')
   self.assertIn(pdf,req.call_args_list[0].args[1]);sent=json.loads(req.call_args_list[1].args[1])
   self.assertEqual((sent['type'],sent['document']['id'],sent['to']),('document','media-123','96171123456'));self.assertIn('INV-123',sent['document']['caption'])
 def test_whatsapp_template_for_business_initiated_messages(self):
  env=dict(WA,WHATSAPP_TEMPLATE_NAME='invoice_pdf',WHATSAPP_TEMPLATE_LANG='ar',WHATSAPP_TEMPLATE_BODY_PARAMS='invoice_no,company')
  with patch.dict(os.environ,env),patch('delivery_providers.meta_request',side_effect=[{'id':'m1'},{'messages':[{'id':'w1'}]}]) as req:
   p.send_whatsapp('+96171123456',b'%PDF',{'no':'INV-9','company':{'name':'Cedar'}})
   sent=json.loads(req.call_args_list[1].args[1])
  self.assertEqual(sent['type'],'template');self.assertEqual(sent['template']['language']['code'],'ar')
  self.assertEqual(sent['template']['components'][0]['parameters'][0]['document']['id'],'m1')
  self.assertEqual([x['text'] for x in sent['template']['components'][1]['parameters']],['INV-9','Cedar'])
 def test_whatsapp_provider_errors_are_specific(self):
  body=io.BytesIO(json.dumps({'error':{'code':131047,'message':'secret text from meta'}}).encode())
  err=HTTPError('https://graph.facebook.com','400','Bad',{},body)
  with patch.dict(os.environ,WA),patch('delivery_providers.urlopen',side_effect=err):
   with self.assertRaises(p.DeliveryError) as e: p.send_whatsapp('+96171123456',b'%PDF',{'no':'INV-1'})
  self.assertIn('24 hours',str(e.exception));self.assertNotIn('secret text',str(e.exception))
  with patch.dict(os.environ,{k:'' for k in WA}):
   self.assertFalse(p.configuration()['whatsapp']['configured'])
   self.assertEqual(set(p.configuration()['whatsapp']['missing']),set(WA))
if __name__=='__main__':unittest.main()
