import sys,json,unittest
from unittest.mock import patch
from test_web import WebTests,ORDER
from invoice_engine import create_invoice
import web_api,approval_store,invoice_validation as V
from app import app

class IdentityTests(WebTests):
    """An invoice needs the customer's FULL name and a valid truck number (one letter + four digits)."""
    def draft(self,c,h,name,plate,text='test'):
        with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer=name,truck_plate=plate)):
            return c.post('/api/invoices/generate',json={'text':text},headers=h).json

    def test_full_name_and_valid_truck_number_make_a_draft(self):
        c=self.client(); h=self.csrf(c)
        draft=self.draft(c,h,'Demo Haddad','d 0001')
        self.assertIn('items',draft); self.assertEqual(draft['truck']['plate'],'D0001')
        saved=c.post('/api/invoices',json=draft,headers=h).json
        path='/api/invoices/'+saved['id']
        self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,200)
        self.assertEqual(c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h).status_code,200)

    def test_only_the_missing_or_invalid_fields_are_asked(self):
        c=self.client(); h=self.csrf(c)
        d=self.draft(c,h,'Ahmad','A1234')
        self.assertEqual(d['question'],"Please provide Ahmad's last name."); self.assertNotIn('items',d)
        d=self.draft(c,h,'Ahmad Haddad','AB1234')
        self.assertEqual(d['question'],'Invalid truck number. Only one letter is allowed, followed by exactly four digits.')
        # one detail at a time: the customer's name first, then the truck number
        d=self.draft(c,h,'','')
        self.assertEqual([m['field'] for m in d['missing']],['customer_name'])
        d=self.draft(c,h,'أحمد','',text='بدي فاتورة لأحمد')
        self.assertIn('اسم العيلة',d['question']); self.assertNotIn('رقم الشاحنة',d['question'])

    def test_name_without_truck_number_is_not_enough(self):
        c=self.client(); h=self.csrf(c)
        draft=self.draft(c,h,'Rami Khoury','',text='Rami 2 oil filters 25 each')
        self.assertIn('truck number',draft['question']); self.assertNotIn('items',draft)
        saved=c.post('/api/invoices',json={'cust':{'name':'Rami'},'truck':{'plate':'1234'},'items':[{'d':'Oil Filter','q':1,'p':25}]},headers=h).json
        self.assertEqual({m['field'] for m in saved['review']['missing']},{'customer_name','truck_number'})
        path='/api/invoices/'+saved['id']
        self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,409)
        r=c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h)
        self.assertEqual(r.status_code,409); self.assertEqual(r.json['detail']['code'],'identity_invalid')

    def test_missing_identity_cannot_bypass_server(self):
        c=self.client(); h=self.csrf(c)
        with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer='',truck_plate='')):
            draft=c.post('/api/invoices/generate',json={'text':'غيرنا فلتر زيت'},headers=h).json
            legacy=create_invoice('test')
        self.assertIn('اسم الزبون',draft['question']); self.assertNotIn('items',draft)
        self.assertTrue(legacy['incomplete'])
        legacy.pop('_order',None)
        saved=approval_store.save_draft(legacy,app.config['INVOICE_DB'])
        self.assertEqual(approval_store.approve(saved['invoice_id'],saved['review_digest'],'tester',True,app.config['INVOICE_DB']),409)
        for name,plate in [('', ''),('   ','  '),('—','-'),('Ahmad','A1234'),('Ahmad Haddad','A123'),('Ahmad Haddad','1234')]:
            saved=c.post('/api/invoices',json={'cust':{'name':name},'truck':{'plate':plate},'items':[{'d':'Oil Filter','q':1,'p':25}]},headers=h).json
            path='/api/invoices/'+saved['id']
            self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,409)
            with web_api.connect(app.config['INVOICE_DB']) as db:
                db.execute("UPDATE web_invoices SET status='pending' WHERE id=?",(saved['id'],))
            self.assertEqual(c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h).status_code,409)

    def test_answer_to_the_question_completes_the_draft_without_another_ai_call(self):
        c=self.client(); h=self.csrf(c)
        with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer='Ahmad',truck_plate='AB1234')):
            q=c.post('/api/invoices/generate',json={'text':'Customer name is Ahmad, truck AB1234, 2 oil filters 25 each'},headers=h).json
        self.assertEqual(q['question'],"Please provide Ahmad's last name."); self.assertTrue(q['state'])   # asked one at a time
        hist=[{'role':'user','text':'Customer name is Ahmad, truck AB1234, 2 oil filters 25 each'},
              {'role':'assistant','text':q['question'],'kind':'question','state':q['state']}]
        with patch('invoice_engine.understand_message',side_effect=AssertionError('must not call the AI again')), \
             patch('ai_agent.route_message',side_effect=AssertionError('must not route again')):
            d=c.post('/api/invoices/generate',json={'text':'Haddad, A1234','history':hist},headers=h).json
        self.assertEqual((d['cust']['name'],d['truck']['plate']),('Ahmad Haddad','A1234'))
        self.assertEqual([i['d'] for i in d['items']][:2],['Oil Filter','Fuel Filter'])   # earlier details kept
        # a tampered state is ignored (falls back to the normal path, never trusted)
        hist[1]['state']=q['state'][:-3]+'xyz'
        with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer='Ahmad',truck_plate='AB1234')), \
             patch('ai_agent.route_message',return_value={'intent':'invoice'}):
            d=c.post('/api/invoices/generate',json={'text':'Haddad, A1234','history':hist},headers=h).json
        self.assertNotIn('items',d)


class ValidationRules(unittest.TestCase):
    def test_truck_numbers(self):
        for ok in ('A1234','b5678','M2025',' m 2025 ','a-1234','A١٢٣٤'):
            self.assertTrue(V.truck_valid(ok),ok)
        self.assertEqual(V.normalize_truck('b5678'),'B5678')
        for bad,code in (('1234','no_letter'),('AB1234','too_many_letters'),('A123','too_few_digits'),('A12345','too_many_digits'),('ب1234','letter_not_english'),('','missing')):
            self.assertEqual(V.truck_problem(bad)['code'],code,bad)
        self.assertEqual(V.truck_problem('AB1234')['message'],'Invalid truck number. Only one letter is allowed, followed by exactly four digits.')

    def test_customer_names(self):
        for ok in ('Ahmad Haddad','أحمد حداد',"Rami O'Neil",'Abi-Khalil Georges'):
            self.assertIsNone(V.customer_problem(ok),ok)
        self.assertEqual(V.customer_problem('Ahmad')['message'],"Please provide Ahmad's last name.")
        self.assertEqual(V.customer_problem('علي',True)['message'],'عطيني اسم العيلة لـ علي لو سمحت.')
        self.assertEqual(V.customer_problem('')['code'],'missing')
        self.assertEqual(V.customer_problem('Ahmad 2')['code'],'invalid')

    def test_short_answers(self):
        asked={'customer_name':{'code':'last_name_missing','first':'Ahmad'},'truck_number':{'code':'too_many_letters'}}
        self.assertEqual(V.answer_slots('Haddad, A1234',asked),{'customer':'Ahmad Haddad','truck_plate':'A1234'})
        self.assertEqual(V.answer_slots('his last name is Haddad',{'customer_name':asked['customer_name']}),{'customer':'Ahmad Haddad'})
        self.assertEqual(V.answer_slots('حداد',{'customer_name':{'code':'last_name_missing','first':'أحمد'}}),{'customer':'أحمد حداد'})
        self.assertEqual(V.answer_slots('b 5678',{'truck_number':{'code':'missing'}}),{'truck_plate':'B5678'})

if __name__=='__main__': unittest.main()
