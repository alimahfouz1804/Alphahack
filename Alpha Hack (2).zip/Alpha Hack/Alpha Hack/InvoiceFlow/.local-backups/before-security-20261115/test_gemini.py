
import os
from pathlib import Path
from dotenv import load_dotenv
from google import genai

load_dotenv(Path(__file__).parent / ".env")

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)

model_name = os.getenv(
    "GEMINI_MODEL", "gemini-3.8-flash"
)

print("Testing model:", model_name)

response = client.models.generate_content(
    model=model_name,
    contents="Reply with only the word OK."
)

print("Gemini response:", response.text)
