"""MA's conversation stages: chat -> collecting (name, truck, repair) -> validation -> preview.
Talking to MA never starts an invoice; the invoice is only built once everything required is collected and valid."""
import io, json, tempfile, unittest
from unittest.mock import patch
from app import app
import web_api

NO_AI = dict(side_effect=AssertionError('no AI call expected here'))
REPAIR = dict(customer='', customer_phone='', customer_email='', truck_plate='', truck_model='', notes='',
              parts=[dict(name='oil filter', quantity=2, quantity_evidence='2 oil filters', unit_price=25, price_currency='USD')],
              labor_amount=None, labor_currency=None)


class ConversationFlow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.old = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.tmp.name + '/flow.db'
        self.c = app.test_client()
        self.c.post('/api/auth/register', json=dict(first_name='Ali', last_name='Mansour', username='ali_flow', password='Garage2026',
                                                    phone='+96171123456', company_name='Cedar Trucks'))
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}
        self.convo = []

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old; self.tmp.cleanup()

    def say(self, text, route=None, order=None, progress=False):
        """One employee turn, kept in the history exactly like the browser does."""
        with patch('ai_agent.route_message', return_value=route) as rm, patch('invoice_engine.understand_message', return_value=order) as um:
            r = self.c.post('/api/invoices/generate' + ('?progress=1' if progress else ''),
                            json={'text': text, 'history': list(self.convo)}, headers=self.h)
            raw = r.data                     # a progress reply streams: read it while the AI is still mocked
        if route is None:
            self.assertFalse(rm.called, 'no intent AI call expected for %r' % text)
        if order is None:
            self.assertFalse(um.called, 'no extraction AI call expected for %r' % text)
        if progress:
            ev = [json.loads(l) for l in raw.decode().splitlines()]
            d = ev[-1]['body']
        else:
            ev, d = None, r.json
        self.convo.append({'role': 'user', 'text': text})
        if 'reply' in d:
            self.convo.append({'role': 'assistant', 'text': d['reply'], 'kind': d.get('kind') or 'answer', 'state': d.get('state', '')})
        elif 'question' in d:
            self.convo.append({'role': 'assistant', 'text': d['question'], 'kind': 'question', 'state': d.get('state', '')})
        else:
            self.convo.append({'role': 'assistant', 'text': 'Your invoice is ready.', 'kind': 'draft', 'state': d.get('state', '')})
        return (d, ev) if progress else d

    def test_the_example_conversation_in_english(self):
        d = self.say('Hello MA.')
        self.assertEqual(d['reply'], 'Hello Ali! How can I help you today?'); self.assertEqual(d['stage'], 'chat')
        d = self.say('How are you?')
        self.assertEqual(d['reply'], "I'm doing great! How can I assist you?"); self.assertNotIn('question', d)
        d, ev = self.say('I want to create an invoice.', progress=True)
        self.assertEqual(d['question'], "Sure! Let's start. What's the customer's full name (first and last name)?")
        self.assertEqual(d['stage'], 'collecting')
        d, ev = self.say('Ahmad Hassan.', progress=True)
        self.assertTrue(d['question'].startswith("Great! What's the truck number?"), d['question'])
        # nothing of the invoice is drawn while MA is still collecting
        self.assertFalse({'preview', 'customer', 'item', 'totals'} & {e['key'] for e in ev if e['type'] == 'step'})
        d = self.say('A1234.')
        self.assertTrue(d['question'].startswith('Perfect! Now, can you describe the repair?'), d['question'])
        d, ev = self.say('I replaced 2 oil filters at 25 dollars each', route={'intent': 'invoice'}, order=REPAIR, progress=True)
        self.assertEqual((d['cust']['name'], d['truck']['plate']), ('Ahmad Hassan', 'A1234'))
        self.assertEqual(d['totals']['total_usd'], 50); self.assertEqual(d['stage'], 'preview'); self.assertEqual(d['status'], 'draft')
        keys = [e['key'] for e in ev if e['type'] == 'step']
        self.assertLess(keys.index('check'), keys.index('preview')); self.assertLess(keys.index('preview'), keys.index('item'))

    def test_the_example_conversation_in_lebanese_arabic(self):
        d = self.say('مرحبا MA')
        self.assertEqual(d['reply'], 'أهلين Ali! كيف فيني ساعدك اليوم؟'); self.assertEqual(d['language'], 'ar')
        d = self.say('كيفك؟')
        self.assertIn('منيح', d['reply'])
        d = self.say('بدي إعمل فاتورة')
        self.assertEqual(d['question'], 'أكيد! يلّا نبلّش. شو اسم الزبون الكامل؟ (الاسم واسم العيلة)')
        d = self.say('أحمد حسن')
        self.assertTrue(d['question'].startswith('تمام! شو رقم الشاحنة؟'), d['question'])
        d = self.say('A1234')
        self.assertTrue(d['question'].startswith('ممتاز!'), d['question']); self.assertEqual(d['language'], 'ar')

    def test_a_first_name_alone_asks_for_the_last_name(self):
        self.say('new invoice')
        d = self.say('Ahmad')
        self.assertEqual(d['question'], "Please provide Ahmad's last name.")
        d = self.say('Hassan')
        self.assertTrue(d['question'].startswith("Great! What's the truck number?"))

    def test_small_talk_while_collecting_keeps_the_invoice(self):
        self.say('I want to create an invoice')
        self.say('Ahmad Hassan')
        d = self.say('thanks MA')                     # an aside, not an answer
        self.assertEqual(d['kind'], 'aside'); self.assertEqual(d['stage'], 'collecting'); self.assertTrue(d['state'])
        d = self.say('what can you do?', route={'intent': 'help', 'reply': 'Lots of things.'})
        self.assertEqual(d['kind'], 'aside'); self.assertIn('continue the invoice', d['reply'])
        d = self.say('A1234')                         # the earlier question is still answered, with the name kept
        self.assertTrue(d['question'].startswith('Perfect!'))
        d = self.say('I replaced 2 oil filters at 25 dollars each', route={'intent': 'invoice'}, order=REPAIR)
        self.assertEqual((d['cust']['name'], d['truck']['plate']), ('Ahmad Hassan', 'A1234'))

    def test_greetings_and_questions_never_start_an_invoice(self):
        for text in ('hi', 'Hey MA, how are you doing?', 'good morning', 'شكرا', 'كيف حالك'):
            d = self.say(text)
            self.assertIn('reply', d, text); self.assertNotIn('question', d, text); self.assertEqual(d['stage'], 'chat')
        # the router is down: a short message gets a polite reply, never an invoice question
        with patch('ai_agent.route_message', side_effect=web_api.GeminiUnavailable('x')):
            d = self.c.post('/api/invoices/generate', json={'text': 'what time do we close'}, headers=self.h).json
        self.assertIn('say it again', d['reply']); self.assertNotIn('question', d)

    def test_a_new_invoice_after_a_finished_one_is_kept_apart(self):
        self.say('Ahmad Hassan, truck A1234, 2 oil filters 25 each', route={'intent': 'invoice'},
                 order=dict(REPAIR, customer='Ahmad Hassan', truck_plate='A1234'))
        d = self.say('I want to create an invoice')
        self.assertIn("customer's full name", d['question'])      # not the previous customer
        self.say('Rami Khoury'); self.say('B5678')
        d = self.say('replaced 2 oil filters at 25 dollars each', route={'intent': 'invoice'}, order=REPAIR)
        self.assertEqual((d['cust']['name'], d['truck']['plate']), ('Rami Khoury', 'B5678')); self.assertTrue(d.get('new_invoice'))
        d = self.say('make it 3 oil filters', route={'intent': 'invoice'},
                     order=dict(REPAIR, parts=[dict(REPAIR['parts'][0], quantity=3, quantity_evidence='3 oil filters')]))
        self.assertFalse(d.get('new_invoice'))                     # a correction updates the invoice on screen
        self.assertEqual((d['cust']['name'], d['truck']['plate']), ('Rami Khoury', 'B5678'))   # nothing asked again
        self.assertEqual(d['totals']['total_usd'], 75)

    def test_live_voice_ignores_mas_own_voice(self):
        hist = [{'role': 'assistant', 'text': "Great! What's the truck number? It's one English letter followed by four digits, e.g. A1234.", 'kind': 'question'}]
        payload = json.dumps({'history': hist, 'context': {}, 'live': True})
        with patch('voice_agent.transcribe_audio', return_value="What's the truck number? It's one English letter followed by four digits"), \
             patch('ai_agent.route_message', **NO_AI), patch('invoice_engine.understand_message', **NO_AI):
            r = self.c.post('/api/invoices/generate', data={'audio': (io.BytesIO(b'\x1aE\xdf\xa3webm'), 'v.webm'), 'payload': payload},
                            headers=self.h, content_type='multipart/form-data')
        self.assertTrue(r.json['ignored'])


class Helpers(unittest.TestCase):
    def test_start_requests(self):
        for t in ('I want to create an invoice', 'create invoice', 'new invoice', "let's make an invoice please", 'MA, start a new invoice',
                  'بدي إعمل فاتورة', 'بدّي اعمل فاتورة جديدة', 'فاتورة جديدة', 'baddi a3mel fatoura'):
            self.assertTrue(web_api.is_invoice_start(t), t)
        for t in ('open the invoice', 'invoice 3', 'how many invoices today', 'I want to create an invoice for Ahmad with 2 oil filters',
                  'بدي فاتورة لأحمد'):
            self.assertFalse(web_api.is_invoice_start(t), t)

    def test_echo(self):
        self.assertTrue(web_api.is_echo('perfect now can you describe the repair', 'Perfect! Now, can you describe the repair? Tell me the parts.'))
        self.assertFalse(web_api.is_echo('A1234', "What's the truck number?"))
        self.assertFalse(web_api.is_echo('I replaced two oil filters', 'Perfect! Now, can you describe the repair?'))


if __name__ == '__main__':
    unittest.main()
