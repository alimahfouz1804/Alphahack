"""Start the existing local server if necessary, then open the website."""
import json, subprocess, sys, time, urllib.request, webbrowser
from pathlib import Path
BASE='http://localhost:5000'
def ready():
    try:
        with urllib.request.urlopen(BASE+'/api/health',timeout=2) as r:
            return json.load(r).get('status')=='ok'
    except (OSError,ValueError): return False
if __name__=='__main__':
    server=None
    if not ready():
        server=subprocess.Popen([sys.executable,'app.py'],cwd=Path(__file__).parent)
        for _ in range(40):
            if ready(): break
            if server.poll() is not None: raise SystemExit('Server stopped. Check the error above.')
            time.sleep(.25)
        else: raise SystemExit('Server did not become ready. Check port 5000.')
    webbrowser.open(BASE+'/signin.html')
    print('InvoiceFlow is ready at '+BASE+'/signin.html')
    if server:
        print('Keep this window open. Ctrl+C stops the server.')
        try: server.wait()
        except KeyboardInterrupt: server.terminate(); server.wait()
