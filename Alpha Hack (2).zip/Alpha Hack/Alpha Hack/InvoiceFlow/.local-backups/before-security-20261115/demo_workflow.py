"""Interactive localhost workflow demo. Never prints login tokens or passwords."""
import argparse, getpass, json, secrets, urllib.request, urllib.error
from pathlib import Path
BASE='http://127.0.0.1:5000'

def request(path,payload=None,token=None,content_type='application/json'):
    headers={}
    if token: headers['Authorization']='Bearer '+token
    if payload is not None: headers['Content-Type']=content_type
    data=json.dumps(payload).encode() if isinstance(payload,dict) else payload
    try:
        with urllib.request.urlopen(urllib.request.Request(BASE+path,data=data,headers=headers),timeout=100) as r:
            return r.read() if r.headers.get_content_type()=='application/pdf' else json.load(r)
    except urllib.error.HTTPError as e:
        raise SystemExit('Request failed: '+e.read().decode()) from None
    except OSError:
        raise SystemExit('Cannot reach the backend. Start python app.py in another terminal.') from None

def main():
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--audio',type=Path); group.add_argument('--message')
    args=parser.parse_args()
    if args.audio:
        data=args.audio.read_bytes()
        if len(data)>10*1024*1024: raise SystemExit('Recording exceeds 10 MB')
        boundary=secrets.token_hex(16)
        body=(f'--{boundary}\r\nContent-Disposition: form-data; name="generate_invoice"\r\n\r\ntrue\r\n--{boundary}\r\nContent-Disposition: form-data; name="audio"; filename="recording"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+data+f'\r\n--{boundary}--\r\n'.encode()
        result=request('/api/transcribe',body,content_type='multipart/form-data; boundary='+boundary)
        print('Transcript:',result['transcript']); draft=result['invoice']
    else: draft=request('/api/invoice/draft',{'message':args.message})
    print(json.dumps(draft,ensure_ascii=False,indent=2))
    username=input('Employee username: ')
    password=getpass.getpass('Employee password: ')
    session=request('/api/auth/login',{'username':username,'password':password})
    token=session['token']
    try:
        route='/api/invoices/'+draft['invoice_id']
        reviewed=request(route,token=token)
        print('Saved invoice for approval:')
        print(json.dumps(reviewed,ensure_ascii=False,indent=2))
        out=Path(__file__).parent/'output'/'pdf'; out.mkdir(parents=True,exist_ok=True)
        preview=out/('draft-'+draft['invoice_id']+'.pdf')
        preview.write_bytes(request(route+'/pdf?preview=true',token=token))
        print('Preview saved:',preview)
        if input('Review the draft. Type APPROVE to authorize the final invoice: ')!='APPROVE':
            print('Draft left unapproved. Nothing sent.'); return
        ack=not reviewed['warnings'] or input('Type ACKNOWLEDGE to accept the listed warnings: ')=='ACKNOWLEDGE'
        if not ack: print('Draft left unapproved.'); return
        request(route+'/approve',{'confirm':True,'review_digest':reviewed['review_digest'],'acknowledge_warnings':ack},token)
        final=out/('invoice-'+draft['invoice_id']+'.pdf')
        final.write_bytes(request(route+'/pdf',token=token))
        print('Approved PDF saved:',final)
        print('Ready for manual sending. No message was sent automatically.')
    finally: request('/api/auth/logout',{},token)
if __name__=='__main__': main()
