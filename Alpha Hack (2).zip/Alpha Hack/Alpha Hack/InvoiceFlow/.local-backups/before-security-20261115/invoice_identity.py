"""An invoice needs the truck's plate number (its ID). The customer name is optional: name + plate number, or plate number alone."""
def present(value):
    return isinstance(value, str) and any(c.isalnum() for c in value.strip())

def has_identity(invoice):
    customer = invoice.get('cust')
    truck = invoice.get('truck')
    name = customer.get('name') if isinstance(customer, dict) else invoice.get('customer')
    plate = truck.get('plate') if isinstance(truck, dict) else invoice.get('truck_plate')
    return present(plate)
