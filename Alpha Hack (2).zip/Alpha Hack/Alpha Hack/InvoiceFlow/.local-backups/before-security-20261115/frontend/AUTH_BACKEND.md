# InvoiceFlow AI — Backend contract: accounts, company profile & dual-currency invoices

The frontend (HTML/CSS/JS) is finished and calls the endpoints below. These are **proposed contracts** —
agree on them together; if you change a name or field, tell the frontend owner (all calls live in
`js/auth.js` and `js/api.js`). The frontend never stores auth tokens and never computes money totals.

**Authentication method: username + password only.** No email login, no Google sign-in.
(Customer email addresses are still used for sending invoices: `POST /api/invoices/{id}/email`.)

Frontend files: `signin.html`, `signup.html`, `forgot-password.html`, `index.html` (workspace),
`js/config.js` (backend URL), `js/auth.js`, `js/auth-pages.js`, `js/phone.js`, `js/api.js`, `js/app.js`.

---

## 1. Sessions & security basics

| Item | Requirement |
|---|---|
| Session | Server-side session, id in cookie `if_session`: `HttpOnly; Secure; SameSite=Lax; Path=/`. Store only a **hash** of the id. New id on every login. |
| Remember me | `remember_me: true` → `Max-Age=2592000` (30 days). `false` → no Max-Age (dies with the browser) + ~12 h idle timeout on the server. |
| CSRF | Also set cookie `if_csrf` (readable, not HttpOnly). On every POST/PUT/PATCH/DELETE require header `X-CSRF-Token` == cookie (constant-time compare) and an `Origin` equal to the frontend's. Login/register/forgot/reset have no session yet: check `Origin` only. |
| Passwords | Hash with **Argon2id** (`argon2-cffi`/`pwdlib`) or bcrypt. Never log or return them. |
| Rate limits | login: ~5 failures / username / 15 min and ~20 / IP → `429`. Also limit check-username (~60/min/IP), register, forgot, reset. (`slowapi`) |
| Same origin (recommended) | Serve the frontend from FastAPI: `app.mount("/", StaticFiles(directory="frontend", html=True))` after the API routers, and set `baseUrl: ''` in `js/config.js`. |
| Different origins | `CORSMiddleware(allow_origins=["http://localhost:5500"], allow_credentials=True, allow_headers=["Content-Type","X-CSRF-Token","X-Requested-With"], allow_methods=["GET","POST","PUT","DELETE"])` — never `"*"`. |

Error format (the UI understands all three): `{"detail":"text"}`, `{"detail":{"code":"...","message":"...","fields":{"username":"..."}}}`,
and FastAPI's 422 list `{"detail":[{"loc":["body","phone"],"msg":"..."}]}` (shown under the matching input).

---

## 2. Data model (suggested)

```
companies(id, name, phone, logo_path NULL, vat_rate DEFAULT 11, created_at)
users(id, company_id FK, first_name, last_name, username UNIQUE (lower-case), password_hash,
      phone, role DEFAULT 'employee', is_active DEFAULT true, created_at, last_login_at)
sessions(id_hash PK, user_id FK, expires_at, last_seen_at, remember BOOL, user_agent, ip)
password_reset_codes(id, user_id FK, code_hash, expires_at, attempts, used_at NULL)
invoices(id, company_id FK, no, created_by FK users.id, status, date, customer..., truck...,
         company_snapshot JSON,            -- name/phone/logo at the time the invoice was created
         subtotal_usd, vat_rate, vat_usd, total_usd, total_lbp, exchange_rate, approved_by NULL, approved_at NULL)
invoice_items(id, invoice_id FK, description, type, qty, unit_price_usd, total_usd)
```
Add a DB unique index on `lower(username)`. Use `Decimal` (not float) for money.

**Every query is scoped by `company_id` of the signed-in user.** Never trust a `company_id` sent by the browser.

---

## 3. Auth endpoints

### User object (returned by `/me`, login, register, `PUT /me`)
```json
{ "user": {
    "id": 12, "first_name": "Karim", "last_name": "Haddad", "username": "karim_garage",
    "phone": "+96171123456",
    "role": "owner",                                   // "employee" | "owner"
    "permissions": ["ai.chat","invoice.create","invoice.edit","invoice.submit","invoice.history","account.edit",
                    "invoice.history.all","invoice.approve","invoice.reject","invoice.send","company.manage"],
    "company": { "id": 3, "name": "Cedar Truck Garage" }
} }
```

| Method & path | Body / query | Success | Errors the UI handles |
|---|---|---|---|
| `GET /api/auth/me` | — | `200 {user}` | `401` → frontend goes to Sign In |
| `POST /api/auth/login` | `{username, password, remember_me}` | `200 {user}` + cookies | `401` (same message for unknown user and wrong password), `403 {"detail":{"code":"account_disabled",...}}`, `429` |
| `POST /api/auth/register` | `{first_name, last_name, username, password, phone, company_name}` | `201 {user}` + cookies (user is signed in) | `409` username taken, `422` field errors, `429` |
| `GET /api/auth/check-username?username=x` | — | `200 {"available": bool, "suggestions": ["x_garage","x2026","x_trucks"]}` | `429` |
| `POST /api/auth/logout` | — | `204`, clear both cookies, delete session | — |
| *additional* `PUT /api/auth/me` | `{first_name, last_name, username, phone}` | `200 {user}` | `409` username taken, `422` |
| *additional* `POST /api/auth/password/change` | `{current_password, new_password}` | `204` — delete the user's **other** sessions | `400` wrong current password, `422` weak |
| *additional* `POST /api/auth/password/forgot` | `{username}` | `202 {"masked_phone":"+961 •• ••• 456","resend_after":60}` | `429` |
| *additional* `POST /api/auth/password/reset` | `{username, code, password}` | `200` — delete **all** the user's sessions | `400` wrong/expired code, `422` weak |

### Validation (backend is the authority — frontend mirrors it)
- `first_name`, `last_name`: required, 1–50 chars, letters (Arabic included), spaces, `'`, `-`, `.`.
- `username`: lower-case + trim, regex `^[a-z](?!.*[_.]{2})[a-z0-9_.]{1,28}[a-z0-9]$` (3–30 chars). Optionally block reserved names (`admin`, `support`, …).
- `password`: 8–128 chars, ≥1 upper-case, ≥1 lower-case, ≥1 digit, must not contain the username.
- `phone`: E.164 string, frontend sends e.g. `+96171123456`. For `+961` accept only
  mobile `^\+961(3\d{6}|(70|71|76|78|79|81)\d{6})$` or landline `^\+961[14-9]\d{6}$`.
  (Library option: `phonenumbers`.) Other country codes: valid E.164 (≤15 digits).
- `company_name`: required, 2–120 chars, collapse spaces.

### Username uniqueness
`check-username` is only for instant feedback. **The final check is the unique index at insert time** in
`register` and `PUT /me`: catch the `IntegrityError` and return `409` (two people can pass the check at the same moment).
Return suggestions that you have verified are free (e.g. `base_garage`, `base2026`, `base_trucks`, `base_auto`).
If you return none, the frontend checks its own candidates against this endpoint.

### Forgot password (no email)
There is no email in the account, so the reset code goes by **SMS** to `users.phone`:
generate a 6-digit code, store its hash, expire after 10 minutes, max 5 attempts, single use.
Always answer `202` (also for unknown usernames). If you don't have an SMS provider for the project,
replace this with an owner-driven reset (owner sets a temporary password for an employee) — the page already
tells users they can ask their garage owner.

### Roles — decision to confirm with the team
Registration creates a **new company** with the given `company_name`. Recommended rule:
- The person who registers a new company becomes that company's **owner** (it is their own, empty company — they get no access to anyone else's data).
- **Never** attach a registrant to an existing company because the name matches. Two garages can have the same name; matching by name would let a stranger join someone else's garage and read its invoices.
- Employees join an existing company only through the owner (e.g. a future "Add employee" / invite code feature). They start as `employee` and nobody can choose their own role.
- No endpoint lets a user change their own `role`.

---

## 4. Company endpoints

### Company object
```json
{ "id": 3, "name": "Cedar Truck Garage", "phone": "+96171123456",
  "logo_url": "/media/logos/3-9f2c.png",     // "" when no logo
  "vat_rate": 11, "exchange_rate": 89500 }
```

| Method & path | Body | Who | Result |
|---|---|---|---|
| `GET /api/company` | — | any signed-in user | the **user's own** company |
| `PUT /api/company` | `multipart/form-data`: `name`, `phone`, optional `logo` (file), optional `remove_logo=1` | owner (`company.manage`) | `200 company`, else `403` |

Logo upload rules: accept PNG/JPEG/WebP only (check the file's real bytes, e.g. with Pillow, not just the
extension), max 2 MB, re-encode/resize (e.g. max 600×300), save with a random filename. **Do not accept SVG**
(it can contain scripts). Serve logos from the same origin.

Changes apply to the homepage immediately and to **new** invoices. Existing invoices keep their `company_snapshot`.

---

## 5. Invoices: company info + USD/LBP totals

The backend must:
1. Fill `company` on every invoice from the signed-in user's company (the employee never types it).
2. Calculate all totals server-side and return them. The frontend shows them exactly as returned.

```
line total_usd   = round(qty × unit_price_usd, 2)
subtotal_usd     = Σ line total_usd
vat_usd          = round(subtotal_usd × vat_rate / 100, 2)      -- vat_rate from the company settings
total_usd        = subtotal_usd + vat_usd
total_lbp        = round(total_usd × 89500)                     -- whole pounds, ROUND_HALF_UP
exchange_rate    = 89500   (fixed project configuration, e.g. env EXCHANGE_RATE_LBP=89500)
```
Example: subtotal $100.00, VAT 11% → $11.00, total $111.00 → **9,934,500 LBP**.
Store the rate used on each invoice so old invoices keep their numbers if the setting ever changes.

### Invoice object (all invoice endpoints return this)
```json
{ "id": 41, "no": "INV-0001", "date": "2026-11-14T10:20:00Z", "status": "draft",
  "company": { "name": "Cedar Truck Garage", "phone": "+96171123456", "logo_url": "" },
  "cust":  { "name": "", "contact": "", "tel": "", "email": "" },
  "truck": { "plate": "4521", "model": "" },
  "items": [ { "d": "Engine oil change (15W-40)", "t": "Service", "q": 1, "p": 60, "total_usd": 60.00 } ],
  "totals": { "subtotal_usd": 85.00, "vat_rate": 11, "vat_usd": 9.35, "total_usd": 94.35,
              "total_lbp": 8444325, "exchange_rate": 89500 } }
```
Send numbers as JSON numbers (or strings — the frontend accepts both).

| Method & path | Notes |
|---|---|
| `POST /api/invoices/generate` | AI draft; must already include `company` and `totals`. Or `{question}` for a clarification. |
| `POST /api/invoices`, `PUT /api/invoices/{id}` | The frontend sends the invoice **without** `totals`; ignore any money fields except `q` and `p`, re-validate prices against the catalog, recalculate totals, return the saved invoice. |
| `GET /api/invoices` | Owner: all invoices of the company. Employee: only invoices they created. |
| `GET /api/invoices/{id}` | Return `404` if the invoice belongs to another company (or, for employees, another user). Don't reveal it exists. |
| `POST /api/invoices/{id}/submit` | creator or owner; only from `draft`/`rejected`. |
| `POST /api/invoices/{id}/approve`, `/reject` | owner only; only from `pending`. |
| `POST /api/invoices/{id}/email` `{to}` | owner only; only `approved`. PDF/print must contain both totals and the rate note. |

`{id}` = the invoice's `id` (the frontend falls back to `no` if there is no separate id).

---

## 6. Permission matrix (enforce on the server; the UI only hides buttons)

| Permission | Employee | Owner |
|---|:-:|:-:|
| `ai.chat` (transcribe, generate) | ✓ | ✓ |
| `invoice.create` / `invoice.edit` (own drafts) | ✓ | ✓ |
| `invoice.submit` | ✓ own | ✓ |
| `invoice.history` | own only | whole company |
| `invoice.approve` / `invoice.reject` | ✗ | ✓ |
| `invoice.send` (email) | ✗ | ✓ |
| `account.edit` (own profile, own password) | ✓ | ✓ |
| `company.manage` (`PUT /api/company`) | ✗ | ✓ |

Missing session → `401`. Missing permission → `403 {"detail":"..."}` (message is shown to the user).

---

## 7. Test checklist
- [ ] `index.html` without a session → Sign In page.
- [ ] Login with `Karim_Garage` works for `karim_garage` (case-insensitive); wrong user/password give the same `401`.
- [ ] Two simultaneous registrations with the same username → exactly one succeeds, the other gets `409`.
- [ ] `check-username` returns verified-free suggestions.
- [ ] `+961 71 123 456`, `+961 3 123 456`, `+961 1 234 567` accepted; `+961 70 12 34` rejected.
- [ ] After registering, `/api/company` returns the typed company name; the homepage shows "Welcome to …".
- [ ] Invoice totals: $100 + 11% → $111.00 and 9,934,500 LBP; editing an item and saving recalculates.
- [ ] User of company A requesting `/api/invoices/{id of company B}` → `404`.
- [ ] Employee calling approve/reject/email/`PUT /api/company` directly → `403`.
- [ ] Logo: SVG and 5 MB files rejected; PNG accepted and shown on new invoices.
- [ ] Password change signs out other devices; reset code works once and expires after 10 min.
