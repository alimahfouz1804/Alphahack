/* phone.js - phone input helpers (sign-up + settings). Lebanon (+961) is the default.
   The backend must validate again; this only gives instant feedback and builds the E.164 value. */
const Phone = (() => {
  const COUNTRIES = [
    ['+961', 'LB', 'Lebanon'], ['+963', 'SY', 'Syria'], ['+962', 'JO', 'Jordan'], ['+964', 'IQ', 'Iraq'],
    ['+966', 'SA', 'Saudi Arabia'], ['+971', 'AE', 'UAE'], ['+974', 'QA', 'Qatar'], ['+965', 'KW', 'Kuwait'],
    ['+20', 'EG', 'Egypt'], ['+90', 'TR', 'Türkiye'], ['+33', 'FR', 'France'], ['+49', 'DE', 'Germany'],
    ['+44', 'GB', 'United Kingdom'], ['+1', 'US', 'USA / Canada']
  ];
  const DEFAULT = '+961';
  /* Lebanon, national number without the leading 0:
     mobile 3 + 6 digits (03 xxx xxx) or 70/71/76/78/79/81 + 6 digits;
     landline area 1,4,5,6,7,8,9 + 6 digits (01 xxx xxx Beirut, 04, 05, 06, 07, 08, 09). */
  const LB_MOBILE = /^(3\d{6}|(70|71|76|78|79|81)\d{6})$/, LB_LAND = /^[14-9]\d{6}$/;

  function clean(cc, national) {
    let d = String(national || '').replace(/\D/g, '');
    const ccd = cc.replace('+', '');
    if (d.startsWith('00' + ccd)) d = d.slice(2 + ccd.length);
    else if (d.startsWith(ccd) && d.length > ccd.length + 6) d = d.slice(ccd.length);
    return d.replace(/^0+/, '');
  }
  /* -> {ok, e164, type, message} */
  function validate(cc, national) {
    const d = clean(cc, national);
    if (!d) return { ok: false, message: 'Please enter a phone number.' };
    if (cc === '+961') {
      if (LB_MOBILE.test(d)) return { ok: true, e164: '+961' + d, type: 'mobile' };
      if (LB_LAND.test(d)) return { ok: true, e164: '+961' + d, type: 'landline' };
      return { ok: false, message: 'Enter a valid Lebanese number, e.g. 71 123 456, 03 123 456 or 01 234 567.' };
    }
    if (d.length < 6 || d.length + cc.length - 1 > 15) return { ok: false, message: 'Enter a valid phone number for ' + cc + '.' };
    return { ok: true, e164: cc + d, type: 'other' };
  }
  /* "+96171123456" -> "+961 71 123 456" */
  function pretty(e164) {
    if (!e164) return '';
    const m = /^\+961(\d+)$/.exec(e164);
    if (!m) return e164;
    const d = m[1];
    return '+961 ' + (d.length === 8 ? d.slice(0, 2) + ' ' + d.slice(2, 5) + ' ' + d.slice(5) : d.slice(0, 1) + ' ' + d.slice(1, 4) + ' ' + d.slice(4));
  }
  /* "+96171123456" -> {cc:"+961", national:"71 123 456"} */
  function split(e164) {
    const s = String(e164 || '');
    const hit = COUNTRIES.map((c) => c[0]).sort((a, b) => b.length - a.length).find((c) => s.startsWith(c));
    if (!hit) return { cc: DEFAULT, national: s.replace(/^\+/, '') };
    return { cc: hit, national: hit === '+961' ? pretty(s).replace('+961 ', '') : s.slice(hit.length) };
  }
  function fillSelect(sel, value) {
    sel.innerHTML = COUNTRIES.map((c) => '<option value="' + c[0] + '"' + (c[0] === (value || DEFAULT) ? ' selected' : '') + '>' + c[1] + ' ' + c[0] + '</option>').join('');
    sel.title = 'Country code';
  }
  return { COUNTRIES, DEFAULT, validate, pretty, split, fillSelect };
})();
