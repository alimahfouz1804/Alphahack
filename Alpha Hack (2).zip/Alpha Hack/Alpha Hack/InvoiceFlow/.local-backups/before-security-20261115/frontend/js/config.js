/* config.js - shared settings for the workspace AND the sign-in pages.
   baseUrl: where the FastAPI backend runs. Use '' (empty string) if FastAPI serves these
            frontend files itself (same origin - the simplest and most secure setup).
   useMock: true = invoice data comes from js/mock.js (temporary).
            Authentication NEVER uses the mock: sign-in always talks to the real backend. */
const API_CONFIG = {
  useMock: false,
  baseUrl: '',   /* the Flask backend serves these pages, so the API is on the same origin */
  pages: { signIn: 'signin.html', signUp: 'signup.html', workspace: 'index.html' }
};
