/* validation.js - the same invoice identity rules as the server (invoice_validation.py), so the employee sees
   the exact problem while editing. The server always re-checks; this file never decides approval on its own.
     Customer full name: first + last name (Arabic or English letters).
     Truck number: one English letter followed by four digits, ^[A-Za-z][0-9]{4}$, stored uppercase (A1234). */
var Validation = (function () {
  var AR_DIGITS = '٠١٢٣٤٥٦٧٨٩', FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
  var TRUCK_RE = /^[A-Za-z][0-9]{4}$/;
  var WORD_RE = /^[\p{L}][\p{L}\p{M}'’\-.]*$/u;
  var NOT_NAME = ['mr', 'mrs', 'ms', 'miss', 'dr', 'customer', 'name', 'is', 'the', 'client', 'اسم', 'الزبون', 'اسمو', 'اسمه', 'السيد', 'استاذ', 'أستاذ'];
  function digits(s) { return String(s == null ? '' : s).replace(/[٠-٩۰-۹]/g, function (c) { var i = AR_DIGITS.indexOf(c); return String(i >= 0 ? i : FA_DIGITS.indexOf(c)); }); }
  function normalizeTruck(raw) { return digits(raw).trim().replace(/[\s\-_.\/]/g, '').toUpperCase(); }
  function truck(raw, ar) {
    var t = normalizeTruck(raw);
    if (!t) return { field: 'truck_number', code: 'missing', message: ar ? 'شو رقم الشاحنة؟ حرف إنكليزي واحد وبعده أربع أرقام، متل A1234.' : "What's the truck number? It's one English letter followed by four digits, e.g. A1234." };
    if (TRUCK_RE.test(t)) return null;
    var letters = (t.match(/^\p{L}*/u) || [''])[0], rest = t.slice(letters.length), r;
    if (letters && !/^[A-Z]+$/.test(letters)) r = ['letter_not_english', 'Invalid truck number. The letter must be an English letter (A-Z), followed by exactly four digits, e.g. A1234.', 'رقم الشاحنة مش صحيح. لازم يكون الحرف إنكليزي (A-Z)، وبعده أربع أرقام بالظبط، متل A1234.'];
    else if (letters.length > 1) r = ['too_many_letters', 'Invalid truck number. Only one letter is allowed, followed by exactly four digits.', 'رقم الشاحنة مش صحيح. مسموح حرف واحد بس، وبعده أربع أرقام بالظبط.'];
    else if (!letters) r = ['no_letter', 'Invalid truck number. It must start with one English letter, followed by four digits (e.g. A1234).', 'رقم الشاحنة مش صحيح. لازم يبلّش بحرف إنكليزي واحد، وبعده أربع أرقام (متل A1234).'];
    else if (!/^\d+$/.test(rest)) r = ['bad_characters', 'Invalid truck number. Use only one English letter followed by four digits, e.g. A1234.', 'رقم الشاحنة مش صحيح. استعمل حرف إنكليزي واحد وبعده أربع أرقام بس، متل A1234.'];
    else r = [rest.length < 4 ? 'too_few_digits' : 'too_many_digits', 'Invalid truck number. The letter must be followed by exactly four digits (' + rest.length + ' given).', 'رقم الشاحنة مش صحيح. لازم يكون بعد الحرف أربع أرقام بالظبط (عطيتني ' + rest.length + ').'];
    return { field: 'truck_number', code: r[0], message: ar ? r[2] : r[1] };
  }
  function customer(raw, ar) {
    var words = String(raw == null ? '' : raw).trim().split(/\s+/).filter(Boolean);
    if (!words.length) return { field: 'customer_name', code: 'missing', message: ar ? 'شو اسم الزبون الكامل؟ (الاسم واسم العيلة)' : "What's the customer's full name (first and last name)?" };
    if (words.some(function (w) { return !WORD_RE.test(w); })) return { field: 'customer_name', code: 'invalid', message: ar ? 'اسم الزبون لازم يكون أحرف بس (بدون أرقام). شو اسمه الكامل؟' : "The customer name should contain letters only. What's the customer's full name?" };
    var real = words.filter(function (w) { return NOT_NAME.indexOf(w.toLowerCase().replace(/\.$/, '')) < 0; });
    if (real.length < 2) { var first = (real[0] || words[0]); return { field: 'customer_name', code: 'last_name_missing', first: first, message: ar ? 'عطيني اسم العيلة لـ ' + first + ' لو سمحت.' : 'Please provide ' + first + "'s last name." }; }
    return null;
  }
  function identity(inv, ar) { inv = inv || {}; return [customer((inv.cust || {}).name, ar), truck((inv.truck || {}).plate, ar)].filter(Boolean); }
  return { normalizeTruck: normalizeTruck, truck: truck, customer: customer, identity: identity, truckValid: function (v) { return TRUCK_RE.test(normalizeTruck(v)); } };
})();
