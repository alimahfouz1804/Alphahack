/* Use the authenticated, immutable PDF endpoint for display and printing. */
Auth.requireUser().then(async function(){
 var id=new URLSearchParams(location.search).get('invoice'),status=document.getElementById('status'),frame=document.getElementById('pdf'),button=document.getElementById('print');
 if(!id){status.textContent='No invoice selected.';return}
 var path='/api/invoices/'+encodeURIComponent(id);
 try{
  var invoice=await Auth.request(path);
  if(invoice.status!=='approved')throw Error('Approve this invoice before printing.');
  var url=API_CONFIG.baseUrl+path+'/pdf?inline=1';document.getElementById('open').href=url;
  async function print(){
   button.disabled=true;
   try{await Auth.request(path+'/print',{method:'POST',body:{}});frame.contentWindow.focus();frame.contentWindow.print();status.textContent='Print requested. Choose printer and copies in the dialog. Physical completion is not confirmed.'}
   catch(e){status.textContent='If no dialog appeared, open the PDF in a new tab and use its Print button. '+e.message}
   finally{button.disabled=false}
  }
  button.onclick=print;
  frame.onload=function(){button.disabled=false;status.textContent='Approved PDF loaded. If the dialog does not open automatically, click Print Invoice or open the PDF in a new tab.';print()};
  frame.src=url;
 }catch(e){status.textContent=e.message}
});
