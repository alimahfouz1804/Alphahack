/* auth-pages.js - UI logic for signin.html, signup.html and forgot-password.html.
   Username + password only. Validation here is for a friendly experience; the backend validates everything again. */
(function () {
  const $ = (id) => document.getElementById(id);
  const page = document.body.dataset.page;
  const alertBox = $('alert'), card = document.querySelector('.auth-card');
  const icons = () => { if (window.lucide) lucide.createIcons(); };
  document.querySelectorAll('.yr').forEach((e) => { e.textContent = new Date().getFullYear(); });

  /* ---------- messages passed in the URL ---------- */
  const URL_MSG = {
    account_disabled: ['err', 'This account has been disabled. Please contact your garage owner.'],
    session_expired: ['info', 'Your session has ended. Please sign in again.'],
    offline: ['err', 'We couldn’t reach the InvoiceFlow server to check your session. Please try again in a moment.'],
    password_reset: ['ok', 'Your password was updated. Sign in with your new password.'],
    signed_out: ['ok', 'You have been signed out.']
  };
  const ICON = { err: 'circle-alert', ok: 'circle-check', info: 'info' };
  function showAlert(type, text) {
    if (!alertBox) return;
    alertBox.innerHTML = '';
    if (!text) return;
    const d = document.createElement('div');
    d.className = 'alert ' + type;
    d.innerHTML = '<i data-lucide="' + ICON[type] + '"></i>';
    const s = document.createElement('span'); s.textContent = text; d.appendChild(s);
    alertBox.appendChild(d); icons();
  }
  const qp = new URLSearchParams(location.search);
  const urlCode = qp.get('error') || qp.get('status');
  if (urlCode && URL_MSG[urlCode]) showAlert(URL_MSG[urlCode][0], URL_MSG[urlCode][1]);
  if (location.protocol === 'file:') showAlert('info', 'You opened this page as a file. Sign-in needs the backend: start the FastAPI server and open the page through it (e.g. http://localhost:8000/signin.html).');

  const next = Auth.safeNext(qp.get('next'));
  const alt = $('altLink');
  if (alt && qp.get('next')) alt.href = alt.getAttribute('href') + '?next=' + encodeURIComponent(next);
  if (page === 'signin' || page === 'signup') Auth.redirectIfSignedIn();

  /* ---------- helpers ---------- */
  const val = (id) => ($(id) ? $(id).value : '');
  const fieldEl = (n) => document.querySelector('.field[data-field="' + n + '"]');
  function setLoading(b, on) { if (!b) return; b.disabled = on; b.classList.toggle('loading', on); b.setAttribute('aria-busy', on ? 'true' : 'false'); }
  function setError(name, text) {
    const f = fieldEl(name); if (!f) return;
    const e = $(name + '-err'), inp = $(name);
    f.classList.toggle('bad', !!text); if (text) f.classList.remove('good', 'avail'); else f.classList.remove('good');
    if (e) e.textContent = text || '';
    if (inp) inp.setAttribute('aria-invalid', text ? 'true' : 'false');
  }
  function shake() { if (!card) return; card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake'); }
  const SERVER_FIELD = { first_name: 'first', last_name: 'last', username: 'username', password: 'password', new_password: 'password',
    phone: 'phone', company_name: 'company', code: 'code' };
  function showServerError(err) {
    let focused = false;
    Object.keys(err.fields || {}).forEach((k) => {
      const f = SERVER_FIELD[k]; if (!f || !$(f)) return;
      setError(f, err.fields[k]); if (!focused) { $(f).focus(); focused = true; }
    });
    showAlert('err', err.message); shake();
  }

  /* ---------- show / hide password + caps lock ---------- */
  document.querySelectorAll('[data-eye]').forEach((b) => {
    b.addEventListener('click', () => {
      const inp = $(b.dataset.eye), show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      b.setAttribute('aria-pressed', String(show));
      b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      b.innerHTML = '<i data-lucide="' + (show ? 'eye-off' : 'eye') + '"></i>'; icons();
      inp.focus({ preventScroll: true });
    });
  });
  ['password', 'confirm'].forEach((id) => {
    const inp = $(id), caps = $(id + '-caps'); if (!inp || !caps) return;
    const chk = (e) => { if (e.getModifierState) caps.hidden = !e.getModifierState('CapsLock'); };
    inp.addEventListener('keydown', chk); inp.addEventListener('keyup', chk);
    inp.addEventListener('blur', () => { caps.hidden = true; });
  });

  /* ---------- validation rules ---------- */
  const RULES = { len: (p) => p.length >= 8, upper: (p) => /[A-Z]/.test(p), lower: (p) => /[a-z]/.test(p), num: (p) => /\d/.test(p) };
  const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}' .-]*$/u;
  const strict = page !== 'signin';
  const CHECKS = {
    first: () => { const v = val('first').trim(); if (!v) return 'Please enter your first name.'; if (!NAME_RE.test(v)) return 'Use letters only (spaces, ’ and - are fine).'; return ''; },
    last: () => { const v = val('last').trim(); if (!v) return 'Please enter your last name.'; if (!NAME_RE.test(v)) return 'Use letters only (spaces, ’ and - are fine).'; return ''; },
    username: () => {
      const v = val('username').trim().toLowerCase();
      if (!v) return 'Please enter your username.';
      if (!strict) return '';
      if (v.length < 3) return 'Username must be at least 3 characters.';
      if (!Auth.USERNAME_RE.test(v)) return 'Use 3–30 letters, numbers, "_" or "." — start with a letter, end with a letter or number.';
      if (page === 'signup' && unState.name === v && unState.status === 'taken') return 'Username is already taken. Pick another one.';
      return '';
    },
    password: () => {
      const v = val('password');
      if (!v) return strict ? 'Please create a password.' : 'Please enter your password.';
      if (!strict) return '';
      if (Object.keys(RULES).some((k) => !RULES[k](v))) return 'Your password doesn’t meet all the requirements below.';
      const u = val('username').trim().toLowerCase();
      if (u.length >= 3 && v.toLowerCase().indexOf(u) >= 0) return 'Your password shouldn’t contain your username.';
      return '';
    },
    confirm: () => { const v = val('confirm'); if (!v) return 'Please confirm your password.'; if (v !== val('password')) return 'Passwords don’t match.'; return ''; },
    phone: () => { const r = Phone.validate(val('cc'), val('phone')); return r.ok ? '' : r.message; },
    company: () => { const v = val('company').trim(); if (!v) return 'Please enter your company name.'; if (v.length < 2) return 'Company name must be at least 2 characters.'; return ''; },
    code: () => (/^\d{6}$/.test(val('code').trim()) ? '' : 'Enter the 6-digit code from the SMS.')
  };
  function check(name) {
    const m = CHECKS[name] ? CHECKS[name]() : '';
    setError(name, m);
    if (!m && val(name) && !(name === 'username' && page === 'signup')) fieldEl(name).classList.add('good');
    return !m;
  }
  const fieldsIn = (f) => [].map.call(f.querySelectorAll('.field[data-field]'), (x) => x.dataset.field);
  function checkAll(f) {
    let first = null;
    fieldsIn(f).forEach((n) => { if (!check(n) && !first) first = n; });
    if (first) { $(first).focus(); shake(); }
    return !first;
  }
  let submitted = false;
  document.querySelectorAll('.field[data-field]').forEach((f) => {
    const n = f.dataset.field, inp = $(n);
    inp.addEventListener('blur', () => { if (inp.value || submitted) check(n); });
    inp.addEventListener('input', () => {
      if (submitted || f.classList.contains('bad')) check(n);
      if (n === 'password' && $('confirm') && val('confirm')) check('confirm');
    });
  });

  /* password checklist + strength meter */
  const meter = $('meter');
  if (meter) {
    const paint = () => {
      const p = val('password'); let score = 0;
      document.querySelectorAll('.rules li').forEach((li) => { const ok = RULES[li.dataset.rule](p); li.classList.toggle('ok', ok); if (ok) score++; });
      if (p.length >= 12) score++; if (/[^A-Za-z0-9]/.test(p)) score++;
      const pct = p ? Math.min(100, Math.round(score / 6 * 100)) : 0;
      const lvl = !p ? null : pct < 50 ? ['Weak', '#ef4444'] : pct < 70 ? ['Fair', '#f59e0b'] : pct < 90 ? ['Good', '#22c55e'] : ['Strong', '#10b981'];
      meter.style.width = pct + '%'; meter.style.background = lvl ? lvl[1] : 'transparent';
      const st = $('strength'); if (st) { st.textContent = lvl ? 'Password strength: ' + lvl[0] : ''; st.style.color = lvl ? lvl[1] : ''; }
    };
    $('password').addEventListener('input', paint); paint();
  }

  /* phone: +961 selected by default */
  if ($('cc')) {
    Phone.fillSelect($('cc'), Phone.DEFAULT);
    $('cc').addEventListener('change', () => {
      const lb = val('cc') === '+961';
      $('phone').placeholder = lb ? '71 123 456' : 'Phone number';
      $('phone-hint').textContent = lb ? 'Lebanese mobile or landline, e.g. 71 123 456 or 01 234 567.' : 'Enter the number without the country code.';
      if (val('phone')) check('phone');
    });
  }

  /* ---------- live username availability (sign-up) ---------- */
  const unState = { name: '', status: 'idle', pending: null }; /* status: idle|checking|available|taken|error */
  const cache = {};
  let unTimer = 0, unCtl = null;
  function paintUsername(status, text, suggestions) {
    const ic = $('unState'), st = $('username-status'), f = fieldEl('username'), sg = $('sugg');
    if (!ic) return;
    ic.className = 'un-state' + ({ checking: ' checking', available: ' ok', taken: ' bad' }[status] || '');
    st.className = 'un-status' + ({ checking: ' wait', available: ' ok', taken: ' bad', error: ' wait' }[status] || '');
    st.textContent = text || '';
    f.classList.toggle('avail', status === 'available');
    if (status === 'taken') { f.classList.remove('good'); }
    sg.querySelectorAll('button').forEach((b) => b.remove());
    (suggestions || []).forEach((s) => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = s; b.dataset.u = s;
      b.setAttribute('aria-label', 'Use username ' + s); sg.appendChild(b);
    });
    sg.hidden = !(suggestions && suggestions.length);
  }
  async function suggestionsFor(name, fromServer) {
    if (fromServer && fromServer.length) return fromServer.filter((s) => Auth.USERNAME_RE.test(s)).slice(0, 4);
    /* backend gave none: check our own candidates and keep only the free ones */
    const cands = Auth.suggestionCandidates(name).slice(0, 5);
    const res = await Promise.all(cands.map((c) => Auth.checkUsername(c).then((r) => { cache[c] = r; return r.available ? c : null; }).catch(() => null)));
    return res.filter(Boolean).slice(0, 3);
  }
  function checkUsernameNow(name) {
    if (unCtl) unCtl.abort();
    unCtl = new AbortController();
    const ctl = unCtl;
    unState.name = name; unState.status = 'checking';
    paintUsername('checking', 'Checking availability…');
    unState.pending = (async () => {
      try {
        const r = cache[name] || await Auth.checkUsername(name, ctl.signal);
        cache[name] = r;
        if (ctl.signal.aborted || unState.name !== name) return;
        if (r.available) { unState.status = 'available'; paintUsername('available', '✓ Username is available'); setError('username', ''); }
        else {
          unState.status = 'taken'; paintUsername('taken', '⚠ Username is already taken');
          const s = await suggestionsFor(name, r.suggestions);
          if (unState.name === name && unState.status === 'taken') paintUsername('taken', '⚠ Username is already taken', s);
        }
      } catch (e) {
        if (e.code === 'cancelled' || unState.name !== name) return;
        unState.status = 'error';
        paintUsername('error', 'Couldn’t check right now — we’ll confirm it when you create the account.');
      }
    })();
    return unState.pending;
  }
  if (page === 'signup') {
    const u = $('username');
    u.addEventListener('input', () => {
      const pos = u.selectionStart, low = u.value.toLowerCase().replace(/\s/g, '');
      if (low !== u.value) { u.value = low; try { u.setSelectionRange(pos, pos); } catch (e) {} }
      clearTimeout(unTimer); if (unCtl) unCtl.abort();
      const v = low.trim();
      unState.name = v; unState.status = 'idle'; paintUsername('idle', '');
      if (v.length >= 3 && !Auth.USERNAME_RE.test(v)) { setError('username', CHECKS.username()); return; }
      if (v.length < 3) return;
      setError('username', '');
      unTimer = setTimeout(() => checkUsernameNow(v), 450);
    });
    $('sugg').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-u]'); if (!b) return;
      u.value = b.dataset.u; setError('username', ''); clearTimeout(unTimer);
      checkUsernameNow(b.dataset.u); u.focus();
    });
  }

  /* ---------- page actions ---------- */
  function success(btn, label) {
    btn.classList.remove('loading'); btn.classList.add('done'); btn.querySelector('.lbl').textContent = label;
    setTimeout(() => Auth.goWorkspace(next), 600);
  }
  async function signin(btn) {
    try {
      await Auth.login({ username: val('username').trim().toLowerCase(), password: val('password'), remember: $('remember').checked });
      showAlert('ok', 'Signed in. Opening your workspace…'); success(btn, 'Signed in ✓');
    } catch (e) {
      if (e.status === 401) { showAlert('err', 'Incorrect username or password.'); $('password').select(); shake(); }
      else if (e.code === 'account_disabled') showAlert('err', URL_MSG.account_disabled[1]);
      else showServerError(e);
      throw e;
    }
  }
  async function signup(btn) {
    const name = val('username').trim().toLowerCase();
    if (unState.name !== name || unState.status === 'idle') checkUsernameNow(name);
    if (unState.pending) await unState.pending;
    if (unState.status === 'taken') { setError('username', 'Username is already taken. Pick another one.'); $('username').focus(); shake(); throw new Error('taken'); }
    try {
      await Auth.register({
        first_name: val('first').trim(), last_name: val('last').trim(), username: name, password: val('password'),
        phone: Phone.validate(val('cc'), val('phone')).e164, company_name: val('company').trim().replace(/\s+/g, ' ')
      });
      showAlert('ok', 'Account created. Opening your workspace…'); success(btn, 'Account created ✓');
    } catch (e) {
      if (e.status === 409) { /* someone took it between the check and the submit */
        cache[name] = { available: false, suggestions: [] };
        await checkUsernameNow(name);
        setError('username', 'Username is already taken. Pick another one.'); showAlert('err', 'That username was just taken. Choose one of the suggestions or try another.');
        $('username').focus(); shake();
      } else showServerError(e);
      throw e;
    }
  }
  let resendAt = 0, resendTimer = 0;
  function startResendTimer(sec) {
    const b = $('resend'); resendAt = Date.now() + sec * 1000; clearInterval(resendTimer);
    const tick = () => { const left = Math.ceil((resendAt - Date.now()) / 1000); b.disabled = left > 0; b.textContent = left > 0 ? 'Send a new code in ' + left + 's' : 'Didn’t get it? Send a new code'; if (left <= 0) clearInterval(resendTimer); };
    tick(); resendTimer = setInterval(tick, 1000);
  }
  async function requestCode() {
    let r = null;
    try { r = await Auth.forgotPassword(val('username').trim().toLowerCase()); }
    catch (e) { if (e.status !== 404) { showServerError(e); throw e; } }
    const to = r && r.masked_phone ? ' to ' + r.masked_phone : ' to the phone number on this account';
    $('lead').textContent = 'If the username exists, we sent a 6-digit code' + to + '. It expires in 10 minutes.';
    startResendTimer((r && r.resend_after) || 60);
  }
  async function forgot() {
    await requestCode();
    $('form').hidden = true; $('form2').hidden = false; showAlert('', ''); $('code').focus();
  }
  async function reset(btn) {
    try {
      await Auth.resetPassword(val('username').trim().toLowerCase(), val('code').trim(), val('password'));
      btn.classList.remove('loading'); btn.classList.add('done'); btn.querySelector('.lbl').textContent = 'Password updated \u2713';
      setTimeout(() => location.replace(API_CONFIG.pages.signIn + '?status=password_reset'), 650);
    } catch (e) {
      if (e.status === 400 || e.status === 410) { setError('code', 'This code is wrong or has expired. Request a new one.'); $('code').select(); shake(); }
      else showServerError(e);
      throw e;
    }
  }
  if ($('resend')) $('resend').addEventListener('click', async () => { $('resend').disabled = true; try { await requestCode(); showAlert('info', 'A new code is on its way.'); } catch (e) { $('resend').disabled = false; } });
  if ($('code')) $('code').addEventListener('input', () => { $('code').value = $('code').value.replace(/\D/g, '').slice(0, 6); });

  function bind(form, btn, action) {
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (btn.disabled) return;
      submitted = true; showAlert('', '');
      if (!checkAll(form)) return;
      setLoading(btn, true);
      try { await action(btn); if (!btn.classList.contains('done')) setLoading(btn, false); }
      catch (err) { setLoading(btn, false); }
    });
  }
  const ACTION = { signin, signup, forgot };
  bind($('form'), $('submitBtn'), ACTION[page]);
  if (page === 'forgot') bind($('form2'), $('submitBtn2'), reset);

  icons();
})();
