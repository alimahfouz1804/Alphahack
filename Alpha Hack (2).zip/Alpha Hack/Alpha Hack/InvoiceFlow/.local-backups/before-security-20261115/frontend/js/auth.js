/* auth.js - every authentication / account call lives here (used by the sign-in pages AND the workspace).
   Only method: USERNAME + PASSWORD. Security model (the backend enforces all of it - see AUTH_BACKEND.md):
   - The backend keeps the session in an HttpOnly, Secure, SameSite=Lax cookie. JavaScript never sees or
     stores a token, so nothing auth-related is kept in localStorage/sessionStorage.
   - Every request sends credentials:'include' so the cookie travels with it.
   - State-changing requests send the CSRF token the backend put in the readable "if_csrf" cookie.
   - Roles/permissions here only decide what the UI displays. The backend re-checks them on every request. */
const Auth = (() => {
  const CSRF_COOKIE = 'if_csrf', CSRF_HEADER = 'X-CSRF-Token', TIMEOUT_MS = 15000;

  /* UI-only fallback if the backend does not send a permissions list. Never trusted for security. */
  const ROLE_PERMISSIONS = {
    employee: ['ai.chat', 'invoice.create', 'invoice.edit', 'invoice.submit', 'invoice.history', 'account.edit'],
    owner: ['ai.chat', 'invoice.create', 'invoice.edit', 'invoice.submit', 'invoice.history', 'account.edit',
            'invoice.history.all', 'invoice.approve', 'invoice.reject', 'invoice.send', 'company.manage']
  };
  const ROLE_LABEL = { employee: 'Employee', owner: 'Garage Owner' };

  /* Username rules (same as the backend): 3-30 chars, starts with a letter, then letters, digits, "_" or ".",
     no "__"/".." and no trailing "_"/".". Stored lower-case. */
  const USERNAME_RE = /^[a-z](?!.*[_.]{2})[a-z0-9_.]{1,28}[a-z0-9]$/;

  let currentUser = null;

  function readCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[.$?*|{}()[\]\\/+^]/g, '\\$&') + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  class AuthError extends Error {
    constructor(message, status, code, fields) { super(message); this.status = status; this.code = code || ''; this.fields = fields || {}; }
  }

  /* FastAPI errors: {"detail":"text"} | {"detail":{"code","message","fields"}} | 422 {"detail":[{loc,msg}]} */
  function parseError(status, body) {
    const d = body && (body.detail !== undefined ? body.detail : body.error); /* FastAPI-style detail or Flask-style error */
    const fields = {};
    let message = '', code = '';
    if (Array.isArray(d)) {
      d.forEach((e) => { const f = Array.isArray(e.loc) ? e.loc[e.loc.length - 1] : ''; if (f && !fields[f]) fields[f] = String(e.msg || '').replace(/^Value error,\s*/i, ''); });
      message = 'Please check the highlighted fields.';
    } else if (d && typeof d === 'object') { message = d.message || ''; code = d.code || ''; Object.assign(fields, d.fields || {}); }
    else if (typeof d === 'string') message = d;
    if (!message) message = ({
      400: 'The request was not valid.', 401: 'Your session has ended. Please sign in again.',
      403: 'You do not have permission to do that.', 404: 'Not found.', 409: 'That already exists.',
      413: 'The file is too large.', 429: 'Too many attempts. Please wait a moment and try again.'
    })[status] || (status >= 500 ? 'The server had a problem. Please try again shortly.' : 'Request failed (' + status + ').');
    return new AuthError(message, status, code, fields);
  }

  async function request(path, { method = 'GET', body, signal, timeout } = {}) {
    const h = { Accept: 'application/json', 'X-Requested-With': 'InvoiceFlow' };
    const isForm = typeof FormData !== 'undefined' && body instanceof FormData;
    if (body !== undefined && !isForm) h['Content-Type'] = 'application/json';
    if (method !== 'GET' && method !== 'HEAD') { const t = readCookie(CSRF_COOKIE); if (t) h[CSRF_HEADER] = t; }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort('timeout'), timeout || TIMEOUT_MS);
    if (signal) { if (signal.aborted) ctl.abort('cancel'); else signal.addEventListener('abort', () => ctl.abort('cancel')); }
    let r;
    try {
      r = await fetch(API_CONFIG.baseUrl + path, { method, headers: h, credentials: 'include', cache: 'no-store',
        body: body === undefined ? undefined : (isForm ? body : JSON.stringify(body)), signal: ctl.signal });
    } catch (e) {
      if (signal && signal.aborted) throw new AuthError('Cancelled', 0, 'cancelled');
      throw new AuthError(ctl.signal.aborted ? 'The server took too long to answer. Please try again.'
        : (location.protocol === 'file:'
            ? 'This page was opened as a file. Open it through the backend server (e.g. http://localhost:5000/signin.html) so sign-in can work.'
            : 'Cannot reach the InvoiceFlow backend at ' + (API_CONFIG.baseUrl || location.origin) + '. Make sure the Flask server is running, then try again.'), 0, 'offline');
    } finally { clearTimeout(timer); }
    if (r.status === 204) return null;
    const data = await r.json().catch(() => null);
    if (!r.ok) throw parseError(r.status, data);
    return data;
  }

  function normalizeUser(u) {
    if (!u) return null;
    const role = u.role === 'owner' ? 'owner' : 'employee'; /* unknown roles get the lowest privileges */
    const first = u.first_name || '', last = u.last_name || '';
    const c = u.company || {};
    return {
      id: u.id, firstName: first, lastName: last, name: (first + ' ' + last).trim() || u.username || '',
      username: u.username || '', phone: u.phone || '', picture: u.avatar_url || '',
      role, roleLabel: ROLE_LABEL[role],
      company: { id: c.id != null ? c.id : u.company_id, name: c.name || '' },
      permissions: Array.isArray(u.permissions) ? u.permissions : ROLE_PERMISSIONS[role]
    };
  }
  const pickUser = (res) => normalizeUser(res && (res.user || res));

  /* Only allow redirects to pages of this site (blocks open-redirects like ?next=https://evil). */
  function safeNext(next) {
    const ws = API_CONFIG.pages.workspace;
    if (!next || typeof next !== 'string') return ws;
    if (/^[a-z][a-z0-9+.-]*:|^\/\/|\\/i.test(next) || /signin|signup|forgot/.test(next)) return ws;
    return next.replace(/^\/+/, '') || ws;
  }
  const query = (k) => new URLSearchParams(location.search).get(k);
  function goSignIn(reason) {
    const here = location.pathname.split('/').pop() + location.search + location.hash;
    const p = new URLSearchParams({ next: here || API_CONFIG.pages.workspace }); if (reason) p.set('error', reason);
    location.replace(API_CONFIG.pages.signIn + '?' + p.toString());
  }
  function goWorkspace(next) { location.replace(safeNext(next || query('next'))); }

  /* Candidate names when a username is taken (the backend's own suggestions are preferred). */
  function suggestionCandidates(u) {
    const base = (u || '').toLowerCase().replace(/[^a-z0-9]/g, '').replace(/^[0-9]+/, '').slice(0, 20) || 'user';
    const yr = new Date().getFullYear();
    return [base + '_garage', base + yr, base + '_trucks', base + '_auto', base + '.' + String(Math.floor(Math.random() * 90) + 10)]
      .filter((x) => USERNAME_RE.test(x));
  }

  return {
    AuthError, USERNAME_RE,
    get user() { return currentUser; },
    can: (perm) => !!(currentUser && currentUser.permissions.indexOf(perm) >= 0),
    isOwner: () => !!(currentUser && currentUser.role === 'owner'),
    request, safeNext, query, goSignIn, goWorkspace, suggestionCandidates,

    async me() { currentUser = pickUser(await request('/api/auth/me')); return currentUser; },
    async login({ username, password, remember }) {
      currentUser = pickUser(await request('/api/auth/login', { method: 'POST', body: { username, password, remember_me: !!remember } }));
      return currentUser;
    },
    /* data: {first_name,last_name,username,password,phone,company_name}. Backend re-checks everything. */
    async register(data) {
      currentUser = pickUser(await request('/api/auth/register', { method: 'POST', body: data }));
      return currentUser;
    },
    /* -> {available:boolean, suggestions:[string]} */
    async checkUsername(username, signal) {
      const r = await request('/api/auth/check-username?username=' + encodeURIComponent(username), { signal });
      return { available: !!(r && r.available), suggestions: (r && Array.isArray(r.suggestions)) ? r.suggestions : [], message: r && r.message };
    },
    async logout() {
      try { await request('/api/auth/logout', { method: 'POST' }); }
      finally { currentUser = null; location.replace(API_CONFIG.pages.signIn + '?status=signed_out'); }
    },
    /* Account settings (any signed-in user, for their own account) */
    async updateMe(data) { currentUser = pickUser(await request('/api/auth/me', { method: 'PUT', body: data })); return currentUser; },
    changePassword: (current, next) => request('/api/auth/password/change', { method: 'POST', body: { current_password: current, new_password: next } }),
    /* Forgot password (no email): a 6-digit code is sent by SMS to the account's phone. */
    forgotPassword: (username) => request('/api/auth/password/forgot', { method: 'POST', body: { username } }),
    resetPassword: (username, code, password) => request('/api/auth/password/reset', { method: 'POST', body: { username, code, password } }),

    /* Workspace guard: resolves with the user, or sends the visitor to the sign-in page. */
    async requireUser() {
      try { return await this.me(); }
      catch (e) { goSignIn(e.status === 401 || e.status === 403 ? '' : 'offline'); return new Promise(() => {}); }
    },
    /* Auth pages: if a valid session already exists, skip straight to the workspace. */
    async redirectIfSignedIn() { try { await this.me(); goWorkspace(); return true; } catch (e) { return false; } }
  };
})();
