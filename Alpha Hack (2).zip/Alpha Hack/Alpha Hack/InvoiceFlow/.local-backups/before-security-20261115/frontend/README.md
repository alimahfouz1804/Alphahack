# InvoiceFlow AI - frontend
Serve the folder (best from FastAPI itself, or `python -m http.server`) so cookies and the microphone work. Needs internet once for the Lucide icon CDN.

Pages
- `signin.html` - username + password (the only sign-in method). Visitors without a session are sent here.
- `signup.html` - first/last name, username (live availability check), password, +961 phone, company name.
- `forgot-password.html` - reset with a 6-digit SMS code sent to the account's phone.
- `index.html` - the AI Agent workspace ("Welcome to <company>"). Opens only after `GET /api/auth/me` confirms the session.

Scripts
- `js/config.js` - backend URL (`baseUrl`) and `useMock`. Shared by every page.
- `js/auth.js` - every account call (session cookie, CSRF header, username check, roles for the UI).
- `js/phone.js` - phone input helpers (Lebanese mobile/landline validation, E.164).
- `js/auth-pages.js` - form validation, loading/error/success states for the auth pages.
- `js/api.js` - every workspace backend call + the endpoint contract (top of file). A 401 sends the user back to Sign In.
- `js/mock.js` - temporary fake *invoice* data (delete later). Accounts and the company profile never use the mock.
- `js/app.js` - workspace UI, invoice preview (company header, USD + LBP totals exactly as the backend returns them), Settings.

Backend teammate: see **AUTH_BACKEND.md** for accounts, company, invoice totals (1 USD = 89,500 LBP) and permission rules.
