"""Real provider adapters. Secrets stay in the server's environment (.env); they never reach the browser and
failures never echo provider responses (they may contain credentials or contact data).

WhatsApp: Meta WhatsApp Business Cloud API. The approved PDF is uploaded as media, then sent as a document
message (inside the 24-hour customer-service window) or, when WHATSAPP_TEMPLATE_NAME is set, as an approved
template whose header is that document (works for business-initiated messages too).
Email: authenticated TLS SMTP; the PDF is attached; From shows the garage's registered company name.
Success always means *accepted by the provider*, never "delivered" (there are no delivery-receipt webhooks).
"""
import json
import os
import re
import smtplib
import ssl
import uuid
from email.message import EmailMessage
from email.utils import formataddr, make_msgid, parseaddr
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


class DeliveryError(RuntimeError):
    pass


def configuration():
    """Which providers are usable (no secret values, only the names of missing settings)."""
    email_keys = ('SMTP_HOST', 'SMTP_USER', 'SMTP_PASSWORD', 'SMTP_FROM')
    wa_keys = ('WHATSAPP_ACCESS_TOKEN', 'WHATSAPP_PHONE_NUMBER_ID', 'WHATSAPP_API_VERSION')
    result = {}
    for method, keys in (('email', email_keys), ('whatsapp', wa_keys)):
        missing = [k for k in keys if not os.getenv(k)]
        result[method] = {'configured': not missing, 'missing': missing}
    result['whatsapp']['template'] = bool(os.getenv('WHATSAPP_TEMPLATE_NAME'))
    return result


def _one_line(value, limit=200):
    return re.sub(r'[\r\n]+', ' ', str(value or '')).strip()[:limit]


def email_subject(invoice):
    """The invoice number is always in the subject, whatever the employee typed."""
    no = invoice.get('no') or ''
    company = _one_line(invoice.get('company', {}).get('name'), 120)
    subject = _one_line(invoice.get('email_subject'))
    if not subject:
        subject = 'Invoice #%s%s' % (no, ' — ' + company if company else '')
    elif no and no not in subject:
        subject = 'Invoice #%s — %s' % (no, subject)
    return subject


def email_body(invoice):
    """Default message (the employee can edit it in the preview). The garage name comes from the registered account."""
    company = _one_line((invoice.get('company') or {}).get('name'), 120) or 'Our garage'
    return (f'Dear Customer,\n\nPlease find attached your invoice from {company}.\n\n'
            f'Thank you for choosing our services.\n\nBest regards,\n{company}')


def send_email(recipient, content, invoice):
    if not configuration()['email']['configured']:
        raise DeliveryError('Email is not configured on the server (SMTP settings are missing). Nothing was sent.')
    mode = os.getenv('SMTP_SECURITY', 'starttls').lower()
    if mode not in ('starttls', 'ssl'):
        raise DeliveryError('SMTP_SECURITY must be starttls or ssl; unencrypted SMTP is disabled.')
    company = _one_line(invoice.get('company', {}).get('name'), 120) or 'Our garage'
    try:
        port = int(os.getenv('SMTP_PORT', '465' if mode == 'ssl' else '587'))
        msg = EmailMessage()
        sender = parseaddr(os.environ['SMTP_FROM'])[1] or os.environ['SMTP_FROM']
        msg['From'] = formataddr((company, sender))          # the registered company name, the authorized address
        msg['To'] = recipient
        if os.getenv('SMTP_REPLY_TO'):
            msg['Reply-To'] = os.environ['SMTP_REPLY_TO']
        msg['Subject'] = email_subject(invoice)
        msg['Message-ID'] = make_msgid()
        msg.set_content(invoice.get('email_body') or email_body(invoice))
        msg.add_attachment(content, maintype='application', subtype='pdf', filename=invoice['no']+'.pdf')
        context = ssl.create_default_context()
        client = (smtplib.SMTP_SSL(os.environ['SMTP_HOST'], port, timeout=25, context=context)
                  if mode == 'ssl' else smtplib.SMTP(os.environ['SMTP_HOST'], port, timeout=25))
        with client:
            if mode == 'starttls':
                client.ehlo(); client.starttls(context=context); client.ehlo()
            client.login(os.environ['SMTP_USER'], os.environ['SMTP_PASSWORD'])
            if client.send_message(msg):
                raise DeliveryError('The mail server rejected the recipient address. Check the email and try again.')
        return msg['Message-ID']
    except DeliveryError:
        raise
    except smtplib.SMTPAuthenticationError:
        raise DeliveryError('The mail server refused the login. The SMTP user/password on the server must be fixed. Nothing was sent.') from None
    except smtplib.SMTPRecipientsRefused:
        raise DeliveryError('The mail server rejected this email address. Check it and try again. Nothing was sent.') from None
    except smtplib.SMTPSenderRefused:
        raise DeliveryError('The mail server does not allow sending from the configured SMTP_FROM address. Nothing was sent.') from None
    except (smtplib.SMTPConnectError, smtplib.SMTPServerDisconnected, TimeoutError, ConnectionError):
        raise DeliveryError('Could not reach the mail server (network problem). Check the connection and try again.') from None
    except (smtplib.SMTPException, OSError, ValueError):
        raise DeliveryError('Email could not be confirmed. Check SMTP settings and recipient; '
                            'verify the mailbox before retrying to avoid duplicates.') from None


# Meta error codes -> what to tell the employee (the provider's own text is never shown)
WA_ERRORS = {
    190: 'The WhatsApp access token is invalid or expired. The administrator must renew WHATSAPP_ACCESS_TOKEN.',
    10: 'The WhatsApp Business account does not have permission to send messages (check the app permissions).',
    200: 'The WhatsApp Business account does not have permission to send messages (check the app permissions).',
    100: 'WhatsApp rejected the request parameters (check the phone number ID, API version and template).',
    131026: 'This number cannot receive WhatsApp messages (not on WhatsApp, or the number is wrong).',
    131030: 'This number is not in the allowed recipient list of the WhatsApp test account.',
    131047: 'More than 24 hours passed since the customer last messaged the garage. WhatsApp only allows an approved '
            'template then: the administrator must set WHATSAPP_TEMPLATE_NAME (a template with a document header).',
    131051: 'WhatsApp does not support this message type for the recipient.',
    132000: 'The WhatsApp template parameters do not match the approved template.',
    132001: 'The WhatsApp template does not exist or is not approved in this language (WHATSAPP_TEMPLATE_LANG).',
    133010: 'The garage\'s WhatsApp number is not registered with the Cloud API.',
    130429: 'WhatsApp rate limit reached. Wait a moment, then try again.',
    131056: 'Too many messages to this customer in a short time. Wait a moment, then try again.',
    368: 'The WhatsApp Business account is temporarily blocked from sending.',
}


def _meta_error(exc):
    try:
        data = json.loads(exc.read(64 * 1024) or b'{}')
        code = int((data.get('error') or {}).get('code') or 0)
    except (ValueError, TypeError, OSError, AttributeError):
        code = 0
    if code in WA_ERRORS:
        return WA_ERRORS[code] + ' Nothing was sent.'
    return (f'WhatsApp rejected the request (HTTP {exc.code}). Check the account permissions, the recipient '
            'and the messaging window. Nothing was sent.')


def meta_request(path, data, content_type):
    version, phone = os.environ['WHATSAPP_API_VERSION'], os.environ['WHATSAPP_PHONE_NUMBER_ID']
    if not re.fullmatch(r'v\d+\.\d+', version) or not phone.isdigit():
        raise DeliveryError('Invalid WhatsApp API version or phone number ID configuration.')
    req = Request(f'https://graph.facebook.com/{version}/{phone}/{path}', data=data,
                  headers={'Authorization': 'Bearer '+os.environ['WHATSAPP_ACCESS_TOKEN'],
                           'Content-Type': content_type}, method='POST')
    try:
        with urlopen(req, timeout=30) as response:
            return json.loads(response.read(1024*1024))
    except HTTPError as exc:
        raise DeliveryError(_meta_error(exc)) from None
    except (URLError, OSError, ValueError):
        raise DeliveryError('WhatsApp submission could not be confirmed (network problem). Check the provider '
                            'before retrying to avoid duplicate messages.') from None


def _template_payload(to, media_id, invoice):
    """Approved template with a DOCUMENT header. Optional body variables, in order, from
    WHATSAPP_TEMPLATE_BODY_PARAMS (comma list of: invoice_no, company, customer, total_usd)."""
    fields = {'invoice_no': invoice.get('no', ''), 'company': (invoice.get('company') or {}).get('name', ''),
              'customer': (invoice.get('cust') or {}).get('name', ''),
              'total_usd': '' if (invoice.get('totals') or {}).get('total_usd') is None else '$%.2f' % invoice['totals']['total_usd']}
    components = [{'type': 'header', 'parameters': [{'type': 'document', 'document': {'id': media_id, 'filename': invoice['no']+'.pdf'}}]}]
    names = [n.strip() for n in os.getenv('WHATSAPP_TEMPLATE_BODY_PARAMS', '').split(',') if n.strip()]
    if names:
        components.append({'type': 'body', 'parameters': [{'type': 'text', 'text': _one_line(fields.get(n, ''), 100) or '-'} for n in names]})
    return {'messaging_product': 'whatsapp', 'recipient_type': 'individual', 'to': to, 'type': 'template',
            'template': {'name': os.environ['WHATSAPP_TEMPLATE_NAME'], 'language': {'code': os.getenv('WHATSAPP_TEMPLATE_LANG', 'en')},
                         'components': components}}


def send_whatsapp(recipient, content, invoice):
    if not configuration()['whatsapp']['configured']:
        raise DeliveryError('WhatsApp Business API is not configured on the server. Nothing was sent.')
    boundary = 'InvoiceFlow'+uuid.uuid4().hex
    data = (f'--{boundary}\r\nContent-Disposition: form-data; name="messaging_product"\r\n\r\nwhatsapp\r\n'
            f'--{boundary}\r\nContent-Disposition: form-data; name="type"\r\n\r\napplication/pdf\r\n'
            f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{invoice["no"]}.pdf"\r\n'
            'Content-Type: application/pdf\r\n\r\n').encode()+content+f'\r\n--{boundary}--\r\n'.encode()
    uploaded = meta_request('media', data, 'multipart/form-data; boundary='+boundary)
    if not uploaded.get('id'):
        raise DeliveryError('WhatsApp did not return an uploaded document ID. Nothing was sent.')
    to = recipient.lstrip('+')
    if os.getenv('WHATSAPP_TEMPLATE_NAME'):
        payload = _template_payload(to, uploaded['id'], invoice)
    else:
        company = _one_line((invoice.get('company') or {}).get('name'), 120)
        payload = {'messaging_product': 'whatsapp', 'recipient_type': 'individual', 'to': to, 'type': 'document',
                   'document': {'id': uploaded['id'], 'filename': invoice['no']+'.pdf',
                                'caption': ('Invoice %s%s' % (invoice['no'], ' - ' + company if company else ''))[:1000]}}
    result = meta_request('messages', json.dumps(payload).encode(), 'application/json')
    ids = result.get('messages', [])
    if not ids or not ids[0].get('id'):
        raise DeliveryError('WhatsApp did not confirm message submission.')
    return ids[0]['id']
