
from flask import Flask, request, jsonify, current_app
from flask_cors import CORS

from ai_agent import GeminiUnavailable
from invoice_engine import create_invoice
from database import search_products, load_products
from approval_store import save_draft
from workflow_routes import register_workflow
from web_api import register_web

app = Flask(__name__)
app.json.ensure_ascii = False

# Allow local frontend development
CORS(app, resources={
    r"/api/*": {
        "origins": [
            "http://localhost:3000",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://127.0.0.1:3000"
        ]
    }
})


# Test whether backend is running
@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "message": "InvoiceFlow AI backend is running"
    })


# Return all garage products
@app.get("/api/products")
def get_products():
    return jsonify({
        "products": load_products()
    })


# Search garage products
@app.get("/api/products/search")
def search():
    query = request.args.get("q", "").strip()

    if not query:
        return jsonify({"products": []})

    return jsonify({
        "products": search_products(query)
    })


# Generate invoice draft with Gemini AI
@app.post("/api/invoice/draft")
def generate_invoice():
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Expected a JSON object"
        }), 400

    message = data.get("message")

    if not isinstance(message, str) or not message.strip():
        return jsonify({
            "error": "Message is required"
        }), 400

    if len(message) > 5000:
        return jsonify({
            "error": "Message is too long"
        }), 400

    try:
        invoice = create_invoice(message); invoice.pop("_order", None)
        return jsonify(save_draft(invoice, current_app.config["INVOICE_DB"]))

    except GeminiUnavailable:
        return jsonify({"error": "AI service is temporarily unavailable. Please try again."}), 503

    except Exception:
        app.logger.error("Invoice generation failed")
        return jsonify({
            "error": "Unable to generate invoice draft"
        }), 500


register_workflow(app)
register_web(app)  # web app: accounts, company, invoices, frontend pages

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False
    )
