"""MA agent upgrades: real activity events, one-request voice turns, automatic language, pause, employee name."""
import io, json, tempfile, unittest
from unittest.mock import patch
from app import app
import ai_agent

ORDER = dict(customer='Ahmad Haddad', customer_phone='', customer_email='', truck_plate='A1234', truck_model='',
             parts=[dict(name='oil filter', quantity=2, quantity_evidence='2', unit_price=25, price_currency='USD')],
             labor_amount=None, labor_currency=None, notes='')


class MATests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.old = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.tmp.name + '/ma.db'
        self.c = app.test_client()
        self.c.post('/api/auth/register', json=dict(first_name='Ali', last_name='Mansour', username='ali_ma', password='Garage2026',
                                                    phone='+96171123456', company_name='Cedar Trucks'))
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old; self.tmp.cleanup()

    def events(self, r):
        self.assertEqual(r.mimetype, 'application/x-ndjson')
        return [json.loads(l) for l in r.data.decode().splitlines()]

    def test_activity_events_follow_the_real_steps(self):
        with patch('ai_agent.route_message', return_value={'intent': 'invoice', 'language': 'en'}), \
             patch('invoice_engine.understand_message', return_value=ORDER):
            ev = self.events(self.c.post('/api/invoices/generate?progress=1', json={'text': 'Ahmad Haddad truck A1234 2 oil filters 25 each'}, headers=self.h))
        act = [(e['key'], e['status']) for e in ev if e['type'] == 'activity']
        self.assertEqual(act[:2], [('understand', 'processing'), ('understand', 'completed')])
        plan = next(e['plan'] for e in ev if e['type'] == 'activity' and e.get('plan'))
        self.assertEqual([p['key'] for p in plan][:6], ['understand', 'extract', 'validate_name', 'validate_truck', 'check_items', 'totals'])
        for key in ('extract', 'validate_name', 'validate_truck', 'check_items', 'totals'):
            self.assertIn((key, 'processing'), act); self.assertIn((key, 'completed'), act)
        self.assertEqual(ev[-1]['body']['totals']['total_usd'], 50); self.assertEqual(ev[-1]['body']['language'], 'en')

    def test_validation_failures_are_reported_in_their_step(self):
        with patch('ai_agent.route_message', return_value={'intent': 'invoice'}), \
             patch('invoice_engine.understand_message', return_value=dict(ORDER, customer='Ahmad', truck_plate='AB1234')):
            ev = self.events(self.c.post('/api/invoices/generate?progress=1', json={'text': 'Customer name is Ahmad, truck AB1234'}, headers=self.h))
        failed = {e['key']: e['error'] for e in ev if e['type'] == 'activity' and e['status'] == 'failed'}
        self.assertEqual(failed['validate_name'], "Please provide Ahmad's last name.")
        self.assertIn('Only one letter', failed['validate_truck'])
        self.assertNotIn('totals', [e['key'] for e in ev if e['type'] == 'activity' and e['status'] == 'completed'])

    def test_voice_turn_is_transcribed_and_answered_in_one_request(self):
        payload = json.dumps({'history': [], 'context': {}})
        with patch('voice_agent.transcribe_audio', return_value='بدي أعمل فاتورة لأحمد حداد، شاحنة A1234، فلترين زيت 25 دولار'), \
             patch('ai_agent.route_message', return_value={'intent': 'invoice', 'language': 'ar'}), \
             patch('invoice_engine.understand_message', return_value=ORDER):
            r = self.c.post('/api/invoices/generate?progress=1', data={'audio': (io.BytesIO(b'\x1aE\xdf\xa3webm'), 'v.webm'), 'payload': payload},
                            headers=self.h, content_type='multipart/form-data')
        ev = self.events(r)
        t = next(e for e in ev if e['type'] == 'transcript')
        self.assertEqual(t['language'], 'ar'); self.assertIn('أحمد', t['text'])
        self.assertLess(ev.index(t), len(ev) - 1)                     # heard before the answer is ready
        body = ev[-1]['body']
        self.assertEqual(body['language'], 'ar'); self.assertEqual(body['cust']['name'], 'Ahmad Haddad'); self.assertIn('transcript', body)

    def test_language_follows_the_latest_message(self):
        with patch('ai_agent.route_message', return_value={'intent': 'invoice', 'language': 'en'}), \
             patch('invoice_engine.understand_message', return_value=dict(ORDER, customer='', truck_plate='')):
            ar = self.c.post('/api/invoices/generate', json={'text': 'بدي أعمل فاتورة لشاحنة'}, headers=self.h).json
            en = self.c.post('/api/invoices/generate', json={'text': 'I want to create an invoice'}, headers=self.h).json
        self.assertEqual(ar['language'], 'ar'); self.assertIn('شو اسم الزبون الكامل', ar['question'])
        self.assertEqual(en['language'], 'en'); self.assertIn("customer's full name", en['question'])

    def test_answering_mas_question_skips_the_router(self):
        with patch('ai_agent.route_message', return_value={'intent': 'invoice'}), \
             patch('invoice_engine.understand_message', return_value=dict(ORDER, truck_plate='')):
            q = self.c.post('/api/invoices/generate', json={'text': 'Ahmad Haddad, 2 oil filters 25 each'}, headers=self.h).json
        hist = [{'role': 'user', 'text': 'Ahmad Haddad, 2 oil filters 25 each'}, {'role': 'assistant', 'text': q['question'], 'kind': 'question', 'state': q['state']}]
        with patch('ai_agent.route_message', side_effect=AssertionError('no routing needed')), \
             patch('invoice_engine.understand_message', return_value=ORDER):
            d = self.c.post('/api/invoices/generate', json={'text': 'the truck is a black volvo, number A1234', 'history': hist}, headers=self.h).json
        self.assertEqual(d['truck']['plate'], 'A1234'); self.assertEqual(d['cust']['name'], 'Ahmad Haddad')

    def test_pause_keeps_the_conversation(self):
        hist = [{'role': 'user', 'text': 'Ahmad 2 oil filters'}, {'role': 'assistant', 'text': "Please provide Ahmad's last name.", 'kind': 'question', 'state': 'x'}]
        with patch('ai_agent.route_message', side_effect=AssertionError('pause is understood locally')):
            d = self.c.post('/api/invoices/generate', json={'text': 'hold on', 'history': hist}, headers=self.h).json
        self.assertEqual(d['action']['type'], 'pause'); self.assertEqual(d['kind'], 'pause'); self.assertEqual(d['state'], 'x')

    def test_router_knows_the_employee_and_its_own_name(self):
        seen = {}
        def fake(prompt, schema, thinking=None):
            seen['prompt'] = prompt; return {'intent': 'chat', 'reply': 'Hi Ali!'}
        with patch('ai_agent.ask_gemini', side_effect=fake):
            d = self.c.post('/api/invoices/generate', json={'text': 'tell me a joke'}, headers=self.h).json
        self.assertIn('the employee "Ali"', seen['prompt']); self.assertIn('never call yourself InvoiceFlow', seen['prompt'])
        self.assertEqual(d['reply'], 'Hi Ali!')

    def test_delivery_config_exposes_no_secrets(self):
        cfg = self.c.get('/api/delivery/config').json
        self.assertEqual(set(cfg), {'email', 'whatsapp'}); self.assertIn('missing', cfg['whatsapp'])
        self.assertNotIn('token', json.dumps(cfg).lower().replace('whatsapp_access_token', ''))


class ThinkingFallback(unittest.TestCase):
    def test_model_without_thinking_levels_is_retried_plainly(self):
        from google.genai import errors
        from unittest.mock import Mock
        calls = []
        def gen(model, contents, config):
            calls.append(dict(config))
            if 'thinking_config' in config:
                raise errors.APIError(400, {})
            return Mock(parsed=ai_agent.Route(intent='chat'))
        ai_agent._THINKING_OK.clear()
        with patch.object(ai_agent.client.models, 'generate_content', side_effect=gen):
            self.assertEqual(ai_agent.ask_gemini('x', ai_agent.Route, thinking='minimal')['intent'], 'chat')
        self.assertIn('thinking_config', calls[0]); self.assertNotIn('thinking_config', calls[1])
        ai_agent._THINKING_OK.clear()


if __name__ == '__main__':
    unittest.main()
