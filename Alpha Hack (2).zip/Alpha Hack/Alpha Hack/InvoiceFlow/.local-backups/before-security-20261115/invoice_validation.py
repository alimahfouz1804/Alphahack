"""Required invoice identity for the web app: the customer's FULL name and the truck number.

One source of truth for the server (AI drafts, save review, approval). The frontend mirrors the same rules
in js/validation.js so the employee sees the same message before saving.

  Customer full name: at least a first and a last name (Arabic or English letters).
  Truck number:       exactly one English letter followed by four digits  ^[A-Za-z][0-9]{4}$  (stored uppercase).

Messages explain the exact problem and ask only for what is missing; nothing is ever invented.
"""
import re

TRUCK_RE = re.compile(r"^[A-Za-z][0-9]{4}$")
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
# a name word: letters (any script, incl. Arabic) with inner ' - . (O'Neil, Abi-Khalil, Jr.)
NAME_WORD_RE = re.compile(r"^[^\W\d_](?:[^\W\d_]|['’\-.])*$", re.UNICODE)
# words that are not names (said around a name: "customer name is Ahmad", "the customer Ahmad")
NOT_NAME = {"mr", "mrs", "ms", "miss", "dr", "customer", "name", "is", "the", "client", "اسم", "الزبون", "اسمو", "اسمه", "السيد", "استاذ", "أستاذ"}


# words around a spoken answer ("his last name is Haddad", "اسم العيلة حداد") that are not part of the name
FILLER = NOT_NAME | {"his", "her", "their", "last", "family", "first", "full", "surname", "it's", "its", "and", "truck",
                     "number", "plate", "no", "ok", "okay", "yes", "sure", "it", "العيلة", "عيلته", "عيلتو", "عيلتها", "هو",
                     "هي", "الشاحنة", "والشاحنة", "رقم", "ورقم", "و", "اسم", "اسمها", "تمام", "اكيد", "أكيد", "طيب",
                     "hello", "hi", "hey", "ma", "um", "uh", "hmm", "مرحبا", "أهلين", "اهلين", "يعني"}


# words that show the reply is more than a bare answer (a correction or another request)
NOT_AN_ANSWER = {"change", "changed", "actually", "not", "no", "instead", "remove", "add", "delete", "cancel", "wrong",
                 "update", "replace", "make", "set", "put", "غيّر", "غير", "غيرها", "مش", "لا", "بدل", "شيل", "زيد", "امحي", "الغي"}


def normalize_truck(raw):
    """'a 1234', 'A-1234', 'a١٢٣٤' -> 'A1234'. Only spacing/dashes are removed; letters/digits are never changed."""
    s = str(raw or "").translate(AR_DIGITS).strip()
    return re.sub(r"[\s\-_./]", "", s).upper()


def truck_valid(raw):
    return bool(TRUCK_RE.fullmatch(normalize_truck(raw)))


def truck_problem(raw, ar=False):
    """None when valid, else {'field','code','message'} explaining exactly what is wrong."""
    t = normalize_truck(raw)
    if not t:
        return {"field": "truck_number", "code": "missing",
                "message": "شو رقم الشاحنة؟ حرف إنكليزي واحد وبعده أربع أرقام، متل A1234." if ar else
                           "What's the truck number? It's one English letter followed by four digits, e.g. A1234."}
    if TRUCK_RE.fullmatch(t):
        return None
    letters = re.match(r"^[^\W\d_]*", t).group(0)
    digits = t[len(letters):]
    if letters and not re.fullmatch(r"[A-Z]+", letters):
        code, en, a = "letter_not_english", "Invalid truck number. The letter must be an English letter (A-Z), followed by exactly four digits, e.g. A1234.", \
            "رقم الشاحنة مش صحيح. لازم يكون الحرف إنكليزي (A-Z)، وبعده أربع أرقام بالظبط، متل A1234."
    elif len(letters) > 1:
        code, en, a = "too_many_letters", "Invalid truck number. Only one letter is allowed, followed by exactly four digits.", \
            "رقم الشاحنة مش صحيح. مسموح حرف واحد بس، وبعده أربع أرقام بالظبط."
    elif not letters:
        code, en, a = "no_letter", "Invalid truck number. It must start with one English letter, followed by four digits (e.g. A1234).", \
            "رقم الشاحنة مش صحيح. لازم يبلّش بحرف إنكليزي واحد، وبعده أربع أرقام (متل A1234)."
    elif not digits.isdigit():
        code, en, a = "bad_characters", "Invalid truck number. Use only one English letter followed by four digits, e.g. A1234.", \
            "رقم الشاحنة مش صحيح. استعمل حرف إنكليزي واحد وبعده أربع أرقام بس، متل A1234."
    else:
        n = len(digits)
        code = "too_few_digits" if n < 4 else "too_many_digits"
        en = "Invalid truck number. The letter must be followed by exactly four digits (%d given)." % n
        a = "رقم الشاحنة مش صحيح. لازم يكون بعد الحرف أربع أرقام بالظبط (عطيتني %d)." % n
    return {"field": "truck_number", "code": code, "message": a if ar else en, "value": t}


def name_words(raw):
    return [w for w in re.split(r"\s+", str(raw or "").strip()) if w]


def customer_problem(raw, ar=False):
    """None when the customer's full name (first + last) is given, else what to ask for."""
    words = name_words(raw)
    if not words:
        return {"field": "customer_name", "code": "missing",
                "message": "شو اسم الزبون الكامل؟ (الاسم واسم العيلة)" if ar else
                           "What's the customer's full name (first and last name)?"}
    if any(not NAME_WORD_RE.fullmatch(w) for w in words):
        return {"field": "customer_name", "code": "invalid",
                "message": "اسم الزبون لازم يكون أحرف بس (بدون أرقام). شو اسمه الكامل؟" if ar else
                           "The customer name should contain letters only. What's the customer's full name?"}
    real = [w for w in words if w.casefold().strip(".") not in NOT_NAME]
    if len(real) < 2:
        first = (real or words)[0]
        return {"field": "customer_name", "code": "last_name_missing", "first": first,
                "message": ("عطيني اسم العيلة لـ %s لو سمحت." % first) if ar else ("Please provide %s's last name." % first)}
    return None


def clean_name(raw):
    return " ".join(name_words(raw))


def identity_problems(customer, truck, ar=False):
    """[problem, ...] for the customer name and truck number (empty list = both valid)."""
    return [p for p in (customer_problem(customer, ar), truck_problem(truck, ar)) if p]


def invoice_problems(inv, ar=False):
    cust = inv.get("cust") if isinstance(inv.get("cust"), dict) else {}
    truck = inv.get("truck") if isinstance(inv.get("truck"), dict) else {}
    return identity_problems(cust.get("name"), truck.get("plate"), ar)


def answer_slots(text, asked):
    """Deterministic reading of a short reply to MA's own identity question (no AI call needed).
    asked: {'customer_name': {'code':..., 'first':...}, 'truck_number': {...}}.
    Returns {'customer': str?, 'truck_plate': str?} for the values this reply clearly gives."""
    out = {}
    t = str(text or "").translate(AR_DIGITS).strip()
    if "truck_number" in asked:
        m = re.findall(r"(?<![A-Za-z0-9])[A-Za-z]{1,3}[\s\-]?\d{2,6}(?![A-Za-z0-9])", t) or re.findall(r"(?<![A-Za-z0-9])\d{3,6}(?![A-Za-z0-9])", t)
        if m:
            out["truck_plate"] = normalize_truck(m[-1])
    else:
        # MA asks one thing at a time, but a valid truck number said along with the answer is kept ("Haddad, A1234")
        m = re.findall(r"(?<![A-Za-z0-9])[A-Za-z][\s\-]?\d{4}(?![A-Za-z0-9])", t)
        if m:
            out["truck_plate"] = normalize_truck(m[-1])
    if "customer_name" in asked:
        rest = re.sub(r"(?<![A-Za-z0-9])[A-Za-z]{0,3}[\s\-]?\d{2,6}(?![A-Za-z0-9])", " ", t)
        rest = re.sub(r"[,:;!?؟،.]+", " ", rest)
        words = [w for w in rest.split() if NAME_WORD_RE.fullmatch(w) and w.casefold() not in FILLER]
        info = asked["customer_name"]
        if any(w.casefold() in NOT_AN_ANSWER for w in rest.split()):
            return out                            # a sentence ("change it to ...", "no, ..."): let the AI read it
        if info.get("code") == "last_name_missing" and info.get("first"):
            first = info["first"]
            if words and words[0].casefold() == first.casefold():
                words = words[1:]
            if 1 <= len(words) <= 2:             # "Haddad", "Abi Khalil"
                out["customer"] = " ".join([first] + words)
        elif 2 <= len(words) <= 4:
            out["customer"] = " ".join(words)
        elif len(words) == 1 and info.get("code") == "missing":
            out["customer"] = words[0]           # a first name only: MA then asks for the last name
    return out
