"""Type the email (SMTP) settings for invoice sending; they are written into .env next to this file.
The password is hidden while you type and is never printed. Run:  python set_email_settings.py"""
import getpass
import re
from pathlib import Path

ENV = Path(__file__).with_name(".env")


def ask(label, default=""):
    value = input(f"{label}{f' [{default}]' if default else ''}: ").strip()
    return value or default


print("Email settings for sending invoice PDFs (Gmail: use an App Password, not your normal password).\n")
host = ask("SMTP host", "smtp.gmail.com")
port = ask("SMTP port", "587")
user = ask("Email address (SMTP user)")
password = getpass.getpass("App password (hidden): ").replace(" ", "")
sender = ask("Send from address", user)
if not (host and user and password and sender):
    raise SystemExit("Nothing saved: host, email, password and sender are all required.")

values = {"SMTP_HOST": host, "SMTP_PORT": port, "SMTP_SECURITY": "ssl" if port == "465" else "starttls",
          "SMTP_USER": user, "SMTP_PASSWORD": password, "SMTP_FROM": sender}
lines = ENV.read_text(encoding="utf-8").splitlines() if ENV.exists() else []
seen = set()
for i, line in enumerate(lines):
    m = re.match(r"\s*([A-Z_]+)\s*=", line)
    if m and m.group(1) in values:
        lines[i] = f"{m.group(1)}={values[m.group(1)]}"
        seen.add(m.group(1))
lines += [f"{k}={v}" for k, v in values.items() if k not in seen]
ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"\nSaved to {ENV}. Restart the InvoiceFlow server to use it.")
