
import json
import re
from pathlib import Path

BASE = Path(__file__).parent

def load_products():
    with open(BASE / "products.json", "r", encoding="utf-8") as f:
        return json.load(f)["products"]

def normalized_name(value):
    value = value.strip().casefold().translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    value = re.sub(r'[\u064b-\u065f\u0670\u0640]', '', value)
    value = value.translate(str.maketrans('أإآ', 'ااا'))
    value = re.sub(r'\bال(?=[\u0621-\u064a]{3,}\b)', '', value)
    value = re.sub(r'\bفلاتر\b', 'فلتر', value)
    value = re.sub(r'\bpads\b', 'pad', value)
    # Packaging words do not change the product; preserve the size/variant.
    value = re.sub(r'^(?:عبوة|علبة|container|bottle|can)\s+(?:of\s+)?', '', value)
    value = re.sub(r'\b(?:حجم (?:ال)?عبوة|حجم (?:ال)?علبة|حجم|سعة|container size|bottle size)\s+(?=\d)', '', value)
    value = re.sub(r'(\d)\s*(?:ليتر|لتر|litres?|liters?|l)\b', r'\1l', value)
    return ' '.join(value.split())


def search_products(query):
    query = normalized_name(query)

    if not query:
        return []

    results = []

    for product in load_products():
        names = [
            product["id"],
            product["name_en"],
            product["name_ar"],
            *product["aliases"]
        ]

        names = [normalized_name(name) for name in names]
        if any(query in name for name in names):
            results.append(product)

    return results

def get_product_by_id(product_id):
    for product in load_products():
        if product["id"] == product_id:
            return product
    return None


def catalog_context():
    """Product identities only: never supply saved prices for AI to invent quotes."""
    return json.dumps([{k:p[k] for k in ('id','name_en','name_ar','aliases','unit')}
                       for p in load_products()], ensure_ascii=False)


def suggest_products(query):
    """Suggestions for a clarification, never permission to discard a variant."""
    base = re.sub(r'\b\d+(?:\.\d+)?l\b', '', normalized_name(query)).strip()
    return search_products(base) if base else []

if __name__ == "__main__":
    for query in ["فلتر زيت", "oil filter", "زيت موتور"]:
        print(query, search_products(query))
