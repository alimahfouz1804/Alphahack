"""WhatsApp (chat link + direct Cloud API) and Email delivery, end to end through the real app (providers mocked)."""
import json, os, tempfile, unittest
from unittest.mock import patch
from app import app
import web_api

SMTP = {'SMTP_HOST': 'mail.example.test', 'SMTP_USER': 'u', 'SMTP_PASSWORD': 'not-a-secret', 'SMTP_FROM': 'garage@example.test'}
WA = {'WHATSAPP_ACCESS_TOKEN': 't', 'WHATSAPP_PHONE_NUMBER_ID': '123', 'WHATSAPP_API_VERSION': 'v23.0'}
NO_WA = {k: '' for k in WA}
NO_SMTP = {k: '' for k in SMTP}


class DeliveryFlow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.old = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.tmp.name + '/d.db'
        self.c = app.test_client()
        self.c.post('/api/auth/register', json=dict(first_name='Ali', last_name='Mansour', username='ali_del', password='Garage2026',
                                                    phone='+96171999888', company_name='MA Garage'))
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old; self.tmp.cleanup()

    def approved(self):
        inv = self.c.post('/api/invoices', json={'cust': {'name': 'Ahmad Haddad'}, 'truck': {'plate': 'A1234'},
                                                 'items': [{'d': 'Oil Filter', 'q': 2, 'p': 25}]}, headers=self.h).json
        r = self.c.post('/api/invoices/%s/approve' % inv['id'], json={'confirm': True, 'review_digest': inv['review_digest'], 'acknowledge_warnings': True}, headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        return r.json

    def send(self, inv, method, **data):
        body = {'to': 'customer@example.test' if method == 'email' else '+96170123456', 'confirm': True, 'request_key': 'key-12345678', **data}
        return self.c.post('/api/invoices/%s/%s' % (inv['id'], method), json=body, headers=self.h)

    # ---- PDF garage information
    def test_pdf_uses_the_registered_garage_name_and_phone(self):
        seen = {}
        def fake(inv, logo=None):
            seen.update(company=inv['company'], cust=inv['cust'], no=inv['no']); return b'%PDF-fake'
        with patch('pdf_invoice.web_invoice_pdf', side_effect=fake):
            inv = self.approved()
        self.assertEqual((seen['company']['name'], seen['company']['phone']), ('MA Garage', '+96171999888'))
        self.assertEqual((seen['cust']['name'], seen['no']), ('Ahmad Haddad', inv['no']))

    # ---- Email
    def test_email_sends_the_stored_pdf_with_garage_subject(self):
        inv = self.approved()
        pdf = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        with patch.dict(os.environ, SMTP), patch('delivery_providers.smtplib.SMTP') as smtp:
            smtp.return_value.send_message.return_value = {}
            r = self.send(inv, 'email')
            msg = smtp.return_value.send_message.call_args.args[0]
        self.assertEqual(r.json['status'], 'sent'); self.assertTrue(r.json['provider_id'])
        self.assertEqual(msg['Subject'], 'Invoice #%s — MA Garage' % inv['no'])
        self.assertEqual(msg['From'], 'MA Garage <garage@example.test>')
        self.assertEqual(next(msg.iter_attachments()).get_payload(decode=True), pdf)
        self.assertIn('Please find attached your invoice from MA Garage.', msg.get_body().get_content())

    def test_no_sending_without_confirmation_and_no_duplicates(self):
        inv = self.approved()
        with patch.dict(os.environ, SMTP), patch('delivery_providers.smtplib.SMTP') as smtp:
            smtp.return_value.send_message.return_value = {}
            self.assertEqual(self.send(inv, 'email', confirm=False).status_code, 409)
            self.assertEqual(smtp.call_count, 0)
            a = self.send(inv, 'email').json; b = self.send(inv, 'email').json          # double click: same request key
            self.assertEqual(a['id'], b['id']); self.assertEqual(smtp.return_value.send_message.call_count, 1)
            again = self.send(inv, 'email', request_key='key-87654321')                 # new click, same recipient
            self.assertEqual(again.status_code, 409); self.assertIn('resend', again.json['detail'])
            self.assertEqual(self.send(inv, 'email', request_key='key-87654321', resend=True).json['status'], 'sent')

    def test_errors_are_reported_and_saved_never_sent(self):
        inv = self.approved()
        self.assertEqual(self.send(inv, 'email', to='not-an-email').status_code, 422)
        self.assertEqual(self.send(inv, 'whatsapp', to='12').status_code, 422)
        with patch.dict(os.environ, NO_SMTP):
            r = self.send(inv, 'email', request_key='key-nosmtp1').json
        self.assertEqual(r['status'], 'failed'); self.assertIn('not configured', r['error'])
        with patch.dict(os.environ, SMTP), patch('delivery_providers.smtplib.SMTP', side_effect=ConnectionRefusedError()):
            r = self.send(inv, 'email', request_key='key-network').json
        self.assertEqual(r['status'], 'failed'); self.assertIn('network', r['error'])
        hist = self.c.get('/api/invoices/%s/activity' % inv['id']).json['deliveries']
        self.assertTrue(all(d['status'] == 'failed' and d['error'] and d['recipient'] and d['method'] == 'email' and d['attempted_at'] for d in hist))
        pending = self.c.post('/api/invoices', json={'cust': {'name': 'A B'}, 'truck': {'plate': 'B1234'}, 'items': [{'d': 'Oil Filter', 'q': 1, 'p': 5}]}, headers=self.h).json
        self.assertEqual(self.send(pending, 'email').status_code, 409)        # only approved invoices are sent

    # ---- WhatsApp
    def test_direct_whatsapp_saves_message_id_and_real_result(self):
        inv = self.approved()
        with patch.dict(os.environ, WA), patch('delivery_providers.meta_request', side_effect=[{'id': 'media-1'}, {'messages': [{'id': 'wamid.123'}]}]):
            r = self.send(inv, 'whatsapp').json
        self.assertEqual((r['status'], r['provider_id'], r['recipient']), ('sent', 'wamid.123', '+96170123456'))
        with patch.dict(os.environ, NO_WA):
            r = self.send(inv, 'whatsapp', request_key='key-nowa123', to='+96171111222').json
        self.assertEqual(r['status'], 'failed'); self.assertIn('not configured', r['error'])

    def test_chat_link_method_is_recorded_as_opened_never_sent(self):
        inv = self.approved()
        r = self.c.post('/api/invoices/%s/handoff' % inv['id'], json={'method': 'whatsapp', 'to': '+96170123456'}, headers=self.h).json
        self.assertEqual(r['status'], 'opened'); self.assertNotEqual(r['status'], 'sent')
        listed = next(i for i in self.c.get('/api/invoices').json if i['id'] == inv['id'])
        self.assertEqual(listed['delivery']['whatsapp'], 'opened')

    # ---- MA (text and Live Voice use the same endpoint)
    def say(self, text, route, history=None):
        with patch('ai_agent.route_message', return_value=route):
            return self.c.post('/api/invoices/generate', json={'text': text, 'history': history or [], 'context': {}}, headers=self.h).json

    def test_voice_whatsapp_asks_number_then_offers_both_methods(self):
        q = self.say('MA, send this invoice to WhatsApp.', {'intent': 'send_whatsapp', 'language': 'en'})
        self.assertEqual(q['reply'], "Sure. What's the customer's WhatsApp number?"); self.assertEqual(q['ask'], 'whatsapp')
        hist = [{'role': 'user', 'text': 'MA, send this invoice to WhatsApp.'}, {'role': 'assistant', 'text': q['reply'], 'kind': 'answer', 'ask': 'whatsapp'}]
        with patch.dict(os.environ, WA):
            a = self.say('96170123456', {'intent': 'chat'}, hist)        # understood locally, never as chat
        self.assertIn('open the WhatsApp chat or send it directly', a['reply']); self.assertEqual(a['action']['phone'], '+96170123456')
        self.assertTrue(a['action']['choose']); self.assertEqual(a['ask'], 'wa_method')
        hist += [{'role': 'user', 'text': '96170123456'}, {'role': 'assistant', 'text': a['reply'], 'kind': 'answer', 'ask': 'wa_method'}]
        with patch.dict(os.environ, WA), patch('ai_agent.route_message', side_effect=AssertionError('understood locally')):
            d = self.c.post('/api/invoices/generate', json={'text': 'send it directly', 'history': hist}, headers=self.h).json
        self.assertEqual(d['action'], {'type': 'whatsapp', 'phone': '+96170123456', 'saved': False, 'method': 'direct'})
        with patch.dict(os.environ, WA), patch('ai_agent.route_message', side_effect=AssertionError('understood locally')):
            d = self.c.post('/api/invoices/generate', json={'text': 'افتح المحادثة', 'history': hist}, headers=self.h).json
        self.assertEqual(d['action']['method'], 'chat'); self.assertEqual(d['language'], 'ar')

    def test_without_the_business_api_ma_opens_the_chat_and_says_attach_manually(self):
        hist = [{'role': 'assistant', 'text': "Sure. What's the customer's WhatsApp number?", 'kind': 'answer', 'ask': 'whatsapp'}]
        with patch.dict(os.environ, NO_WA):
            a = self.say('96170123456', {'intent': 'chat'}, hist)
        self.assertEqual(a['action']['method'], 'chat'); self.assertIn("can't attach files", a['reply'])
        self.assertNotIn('ask', a)

    def test_voice_email_in_arabic(self):
        d = self.say('MA، بعت الفاتورة على الإيميل.', {'intent': 'send_email', 'language': 'ar'})
        self.assertEqual(d['reply'], 'أكيد، شو إيميل الزبون؟'); self.assertEqual(d['language'], 'ar')
        hist = [{'role': 'user', 'text': 'MA، بعت الفاتورة على الإيميل.'}, {'role': 'assistant', 'text': d['reply'], 'kind': 'answer', 'ask': 'email'}]
        d = self.say('ahmad@example.com', {'intent': 'chat'}, hist)
        self.assertEqual(d['action'], {'type': 'email', 'email': 'ahmad@example.com'})


if __name__ == '__main__':
    unittest.main()
