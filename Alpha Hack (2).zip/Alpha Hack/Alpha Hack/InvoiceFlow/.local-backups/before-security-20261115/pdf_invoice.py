"""ReportLab invoice PDFs with Arabic shaping and a Unicode font."""
import os
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape
import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image

FONT=os.getenv('INVOICE_FONT_PATH',str(Path(os.getenv('WINDIR','C:/Windows'))/'Fonts'/'arial.ttf'))

def invoice_pdf(invoice):
    if 'InvoiceUnicode' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('InvoiceUnicode',FONT))
    style=ParagraphStyle('body',fontName='InvoiceUnicode',fontSize=10,leading=15,spaceAfter=8,wordWrap='LTR')
    def para(text):
        if text is None: text = '—'
        text=str(text)
        if any('\u0600'<=c<='\u06ff' for c in text): text=get_display(arabic_reshaper.reshape(text))
        return Paragraph(escape(text).replace('\n','<br/>'),style)
    stream=BytesIO()
    doc=SimpleDocTemplate(stream,pagesize=A4,rightMargin=36,leftMargin=36,topMargin=40,bottomMargin=45,title='InvoiceFlow Invoice')
    approved=invoice.get('approved') is True
    story=[para('INVOICEFLOW AI'),para('APPROVED INVOICE' if approved else 'DRAFT - NOT APPROVED - DO NOT SEND'),para('Invoice: '+invoice['invoice_id']),para('Customer: '+(invoice.get('customer') or 'Not provided')),Spacer(1,12)]
    if invoice.get('company'):
        company=invoice['company'];customer=invoice.get('customer_details',{});truck=invoice.get('truck',{})
        story=[para(company.get('name') or 'InvoiceFlow AI'),para(company.get('phone','')),
               para('APPROVED INVOICE' if approved else 'DRAFT - NOT APPROVED'),
               para('Invoice: '+invoice['invoice_id']+' | Date: '+invoice.get('date','')),
               para('Customer: '+(invoice.get('customer') or '—'))]
        if invoice.get('logo_bytes'):
            logo=Image(BytesIO(invoice['logo_bytes']))
            scale=min(120/logo.imageWidth,55/logo.imageHeight)
            logo.drawWidth=logo.imageWidth*scale;logo.drawHeight=logo.imageHeight*scale
            logo.hAlign='LEFT';story.insert(0,logo)
        for label,value in [('Phone',customer.get('tel')),('Email',customer.get('email')),('Contact',customer.get('contact')),('Truck ID',truck.get('plate')),('Truck model',truck.get('model'))]:
            if value: story.append(para(label+': '+value))
        story.append(Spacer(1,12))
    rows=[[para(x) for x in ['Product','Qty','Unit USD','Line USD','Line LBP']]]
    for item in invoice['items']:
        rows.append([para(item['name']),para(item['quantity']),para(item['price_usd']),para(item['total_usd']),para(item['total_lbp'])])
    table=Table(rows,colWidths=[195,40,75,75,138-0.72],repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E6EEF5')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),1,colors.HexColor('#315675')),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F5F7FA')])]))
    def amount(value): return '—' if value is None else str(value)
    story.extend([table,Spacer(1,14)])
    if invoice.get('labor_amount') is not None and invoice['labor_amount'] != 'Included in item rows':
        story.append(para(f"Labor: {amount(invoice['labor_amount'])} {invoice.get('labor_currency') or ''}"))
    if invoice.get('totals'):
        story.extend([para('Subtotal USD: '+format(invoice['totals']['subtotal_usd'],'.2f')),para('VAT ('+str(invoice['totals']['vat_rate'])+'%): '+format(invoice['totals']['vat_usd'],'.2f'))])
    story.extend([para(f"Total USD: {amount(invoice['subtotal_usd'])}"),para(f"Total LBP: {amount(invoice['subtotal_lbp'])}"),para('Totals use the entered prices and configured exchange rate.')])
    if invoice.get('incomplete'): story.append(para('Incomplete draft: resolve the missing or invalid amounts before approval.'))
    if invoice.get('notes'): story.extend([para('Notes'),para(invoice['notes'])])
    for warning in invoice.get('warnings',[]): story.append(para('Review warning: '+warning))
    if approved: story.append(para('Approved by: '+invoice['approved_by']+' '+str(invoice.get('approved_at',''))))
    def footer(canvas,doc):
        canvas.setFont('InvoiceUnicode',8)
        canvas.drawString(36,24,'InvoiceFlow AI | '+('Approved' if approved else 'Draft - not approved'))
        canvas.drawRightString(A4[0]-36,24,f'Page {doc.page}')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return stream.getvalue()


# ---------------------------------------------------------------- website invoices (professional layout)
from decimal import Decimal
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image as RLImage, KeepTogether

NAVY, ORANGE, MUTED, LINE = colors.HexColor('#101828'), colors.HexColor('#F59E0B'), colors.HexColor('#475569'), colors.HexColor('#E2E8F0')


def _fonts():
    if 'InvoiceUnicode' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('InvoiceUnicode', FONT))
    if 'InvoiceUnicodeBold' not in pdfmetrics.getRegisteredFontNames():
        bold = os.getenv('INVOICE_FONT_BOLD_PATH') or ''
        if not bold:
            p = Path(FONT)
            for name in (p.stem + 'bd' + p.suffix, p.stem + '-Bold' + p.suffix):
                if (p.parent / name).is_file():
                    bold = str(p.parent / name); break
        pdfmetrics.registerFont(TTFont('InvoiceUnicodeBold', bold if bold and Path(bold).is_file() else FONT))


def _usd(v):
    if v is None or v == '': return '—'
    v = Decimal(str(v))
    return '$' + (format(v, ',.0f') if v == v.to_integral_value() else format(v, ',.2f'))


def _qty(v):
    if v is None or v == '': return '—'
    v = Decimal(str(v)); return format(v.normalize(), 'f') if v != v.to_integral_value() else str(int(v))


def _phone(p):
    import re as _re
    m = _re.match(r'^\+961(\d+)$', p or '')
    if not m: return p or ''
    d = m.group(1)
    return '+961 ' + (d[:2] + ' ' + d[2:5] + ' ' + d[5:] if len(d) == 8 else d[:1] + ' ' + d[1:4] + ' ' + d[4:])


def _lbp(v):
    return '—' if v is None or v == '' else format(int(Decimal(str(v))), ',') + ' LBP'


def web_invoice_pdf(inv, logo=None):
    """inv: the website invoice (payload + no/date/status). Pending invoices get a clear PREVIEW stamp."""
    _fonts()
    approved = inv.get('status') == 'approved'
    def st(name, size=10, bold=False, color=colors.black, align=0, leading=None):
        return ParagraphStyle(name, fontName='InvoiceUnicodeBold' if bold else 'InvoiceUnicode', fontSize=size,
                              leading=leading or size * 1.35, textColor=color, alignment=align)
    body, small, right, rbold = st('b'), st('s', 8.5, color=MUTED), st('r', align=2), st('rb', bold=True, align=2)
    def P(text, style=body):
        text = '—' if text is None or text == '' else str(text)
        if any('؀' <= c <= 'ۿ' for c in text): text = get_display(arabic_reshaper.reshape(text))
        return Paragraph(escape(text).replace('\n', '<br/>'), style)

    co, cust, truck, t = inv.get('company') or {}, inv.get('cust') or {}, inv.get('truck') or {}, inv.get('totals') or {}
    stream = BytesIO()
    W = A4[0] - 72
    doc = SimpleDocTemplate(stream, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=48,
                            title='Invoice ' + str(inv.get('no') or ''), author=co.get('name') or 'InvoiceFlow AI')
    # header: company (left) / invoice meta (right)
    left = []
    if logo:
        try:
            img = ImageReader(BytesIO(logo)); iw, ih = img.getSize(); h = 46; w = min(140, iw * h / ih)
            left.append(RLImage(BytesIO(logo), width=w, height=w * ih / iw))
        except Exception:
            pass
    left += [P((co.get('name') or '').upper(), st('co', 17, True, NAVY)), P('Phone: ' + _phone(co['phone']) if co.get('phone') else '', st('cp', 9.5, color=MUTED))]
    status = 'APPROVED' if approved else 'PENDING — NOT APPROVED'
    meta = [P('INVOICE', st('t', 20, True, NAVY, 2)), P('No. ' + str(inv.get('no') or 'not saved'), rbold),
            P('Date: ' + str(inv.get('date_text') or ''), right),
            P(status, st('stt', 9.5, True, colors.HexColor('#166534') if approved else colors.HexColor('#92400E'), 2))]
    head = Table([[left, meta]], colWidths=[W * .58, W * .42])
    head.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LINEBELOW', (0, 0), (-1, 0), 3, ORANGE), ('BOTTOMPADDING', (0, 0), (-1, -1), 12), ('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 0)]))
    story = [head, Spacer(1, 14)]
    # customer / truck boxes
    lab = st('lab', 8, True, colors.HexColor('#2563EB'))
    cbox = [P('CUSTOMER', lab)] + [P(x) for x in [cust.get('name') or '—', cust.get('contact') and 'Contact: ' + cust['contact'], cust.get('tel') and 'Tel: ' + cust['tel'], cust.get('email')] if x]
    tbox = [P('TRUCK', lab)] + ([P(x) for x in [truck.get('plate') and 'Plate: ' + truck['plate'], truck.get('model')] if x] or [P('—')])
    boxes = Table([[cbox, tbox]], colWidths=[W / 2 - 5, W / 2 - 5], spaceBefore=0)
    boxes.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F1F5F9')), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('BOX', (0, 0), (0, 0), .5, LINE), ('BOX', (1, 0), (1, 0), .5, LINE), ('PADDING', (0, 0), (-1, -1), 9)]))
    story += [boxes, Spacer(1, 16)]
    # items
    rate = t.get('exchange_rate')
    hdr = st('h', 8.5, True, colors.white)
    rows = [[P('ITEM', hdr), P('QTY', st('h2', 8.5, True, colors.white, 2)), P('UNIT (USD)', st('h3', 8.5, True, colors.white, 2)),
             P('TOTAL (USD)', st('h4', 8.5, True, colors.white, 2)), P('TOTAL (LBP)', st('h5', 8.5, True, colors.white, 2))]]
    for it in inv.get('items') or []:
        line = it.get('total_usd')
        line_lbp = None if line is None or not rate else (Decimal(str(line)) * Decimal(str(rate))).quantize(Decimal('1'))
        rows.append([P(it.get('d')), P(_qty(it.get('q')), right), P(_usd(it.get('p')), right), P(_usd(line), right), P(_lbp(line_lbp), right)])
    items = Table(rows, colWidths=[W * .36, W * .09, W * .16, W * .17, W * .22], repeatRows=1)
    items.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), NAVY), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                               ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
                               ('LINEBELOW', (0, 1), (-1, -1), .4, LINE), ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7)]))
    story += [items, Spacer(1, 12)]
    # totals
    trows = []
    if t.get('vat_rate'):
        trows += [[P('Subtotal', body), P(_usd(t.get('subtotal_usd')), right)], [P('VAT (%s%%)' % t.get('vat_rate'), body), P(_usd(t.get('vat_usd')), right)]]
    trows += [[P('Total (USD)', st('tu', 12, True, NAVY)), P(_usd(t.get('total_usd')), st('tv', 12, True, NAVY, 2))],
              [P('Total (LBP)', st('tl', 10.5, True, colors.HexColor('#92400E'))), P(_lbp(t.get('total_lbp')), st('tlv', 10.5, True, colors.HexColor('#92400E'), 2))]]
    tot = Table(trows, colWidths=[W * .2, W * .25], hAlign='RIGHT')
    tot.setStyle(TableStyle([('LINEABOVE', (0, len(trows) - 2), (-1, len(trows) - 2), 1.5, NAVY), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
    story.append(KeepTogether([tot, Spacer(1, 4), P('Exchange rate: 1 USD = %s LBP' % format(int(rate), ',') if rate else '', st('fx', 8.5, color=MUTED, align=2))]))
    if t.get('incomplete'):
        story += [Spacer(1, 8), P('Some prices or quantities are missing: totals are not final.', st('inc', 9.5, True, colors.HexColor('#B45309')))]
    if inv.get('notes'):
        story += [Spacer(1, 14), P('NOTES', lab), P(inv['notes'])]
    if approved and inv.get('approved_by'):
        story += [Spacer(1, 18), P('Approved by: ' + inv['approved_by'], small)]
    story += [Spacer(1, 22), P('Thank you for your business.', st('ty', 10, True, NAVY, 1))]

    def stamp(canvas):  # drawn on top of the page content, so tables can't hide it
        canvas.saveState(); canvas.setFont('InvoiceUnicodeBold', 50); canvas.setFillColor(colors.Color(.96, .62, .04, alpha=.16))
        canvas.translate(A4[0] / 2, A4[1] / 2); canvas.rotate(35); canvas.drawCentredString(0, 0, 'PENDING - PREVIEW'); canvas.restoreState()
    if not approved:
        doc.afterPage = lambda: stamp(doc.canv)

    def deco(canvas, d):
        canvas.saveState()
        canvas.setStrokeColor(LINE); canvas.line(36, 38, A4[0] - 36, 38)
        canvas.setFont('InvoiceUnicode', 8); canvas.setFillColor(MUTED)
        canvas.drawString(36, 26, '%s · Invoice %s · %s' % (co.get('name') or 'InvoiceFlow AI', inv.get('no') or '', 'Approved' if approved else 'Pending - not approved, do not send'))
        canvas.drawRightString(A4[0] - 36, 26, 'Page %d' % d.page)
        canvas.restoreState()
    doc.build(story, onFirstPage=deco, onLaterPages=deco)
    return stream.getvalue()
