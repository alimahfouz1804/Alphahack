"""ReportLab invoice PDFs with Arabic shaping and a Unicode font."""
import os
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape
import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

FONT=os.getenv('INVOICE_FONT_PATH',str(Path(os.getenv('WINDIR','C:/Windows'))/'Fonts'/'arial.ttf'))

def invoice_pdf(invoice):
    if 'InvoiceUnicode' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('InvoiceUnicode',FONT))
    style=ParagraphStyle('body',fontName='InvoiceUnicode',fontSize=10,leading=15,spaceAfter=8,wordWrap='LTR')
    def para(text):
        text=str(text)
        if any('\u0600'<=c<='\u06ff' for c in text): text=get_display(arabic_reshaper.reshape(text))
        return Paragraph(escape(text).replace('\n','<br/>'),style)
    stream=BytesIO()
    doc=SimpleDocTemplate(stream,pagesize=A4,rightMargin=36,leftMargin=36,topMargin=40,bottomMargin=45,title='InvoiceFlow Invoice')
    approved=invoice.get('approved') is True
    story=[para('INVOICEFLOW AI'),para('APPROVED INVOICE' if approved else 'DRAFT - NOT APPROVED - DO NOT SEND'),para('Invoice: '+invoice['invoice_id']),para('Customer: '+(invoice.get('customer') or 'Not provided')),Spacer(1,12)]
    rows=[[para(x) for x in ['Product','Qty','Unit USD','Line USD','Line LBP']]]
    for item in invoice['items']:
        rows.append([para(item['name']),para(item['quantity']),para(item['price_usd']),para(item['total_usd']),para(item['total_lbp'])])
    table=Table(rows,colWidths=[195,40,75,75,138-0.72],repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E6EEF5')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),1,colors.HexColor('#315675')),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F5F7FA')])]))
    story.extend([table,Spacer(1,14),para(f"Labor: {invoice['labor_amount']} {invoice.get('labor_currency') or '(currency unspecified)'}"),para(f"Total USD: {invoice['subtotal_usd']}"),para(f"Total LBP: {invoice['subtotal_lbp']}"),para('Totals use the saved product catalog and configured exchange rate.')])
    if invoice.get('notes'): story.extend([para('Notes'),para(invoice['notes'])])
    for warning in invoice.get('warnings',[]): story.append(para('Review warning: '+warning))
    if approved: story.append(para('Approved by: '+invoice['approved_by']))
    def footer(canvas,doc):
        canvas.setFont('InvoiceUnicode',8)
        canvas.drawString(36,24,'InvoiceFlow AI | '+('Approved' if approved else 'Draft - not approved'))
        canvas.drawRightString(A4[0]-36,24,f'Page {doc.page}')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return stream.getvalue()
