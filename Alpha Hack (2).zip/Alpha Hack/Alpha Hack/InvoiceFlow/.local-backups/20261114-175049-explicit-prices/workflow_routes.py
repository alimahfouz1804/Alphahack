"""Voice, employee review and PDF routes added to the existing Flask app."""
from functools import wraps
from io import BytesIO
from flask import request, jsonify, current_app, g, send_file
from werkzeug.exceptions import RequestEntityTooLarge
from ai_agent import GeminiUnavailable
from invoice_engine import create_invoice
from voice_agent import transcribe_audio, MAX_AUDIO_BYTES
import approval_store as store
import web_api
from pdf_invoice import invoice_pdf

def register_workflow(app):
    app.config.setdefault('INVOICE_DB',str(store.DEFAULT_DB))
    app.config['MAX_CONTENT_LENGTH']=MAX_AUDIO_BYTES+1024*1024
    def db(): return current_app.config['INVOICE_DB']
    def auth(fn):
        @wraps(fn)
        def wrapped(*args,**kwargs):
            header=request.headers.get('Authorization','')
            token=header[7:] if header.startswith('Bearer ') else ''
            g.employee=store.employee(token,db()) if token else None
            g.token=token
            if not g.employee:
                web_user=web_api.session_user()  # signed in through the web app (cookie session)
                if web_user: g.employee=web_user['username']
            if not g.employee: return jsonify(error='Employee login required'),401
            return fn(*args,**kwargs)
        return wrapped

    @app.after_request
    def no_cache(response):
        if request.path.startswith('/api/'):
            response.headers['Cache-Control']='no-store'
            response.headers['X-Content-Type-Options']='nosniff'
        return response

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(error): return jsonify(error='Upload too large; maximum recording size is 10 MB'),413

    @app.post('/api/auth/login')
    def login():
        data=request.get_json(silent=True)
        if not isinstance(data,dict): return jsonify(error='Expected a JSON object'),400
        username,password=data.get('username'),data.get('password')
        if not isinstance(username,str) or not isinstance(password,str) or len(username)>80 or len(password)>1024: return jsonify(error='Username and password required'),400
        web=web_api.web_login(username,password,data.get('remember_me') is True)
        if web is not None: return web  # web-app account (cookie session)
        if request.headers.get('X-Requested-With')=='InvoiceFlow':
            return jsonify(error='No website account found. Use Create account with a new username; your terminal login stays unchanged.'),401
        token,status=store.login(username,password,request.remote_addr or 'local',db())
        if not token: return jsonify(error='Too many attempts; wait 5 minutes' if status==429 else 'Invalid credentials'),status
        return jsonify(token=token,expires_in=3600)

    @app.post('/api/auth/logout')
    @auth
    def logout():
        if not g.token: return web_api.web_logout()
        store.logout(g.token,db())
        return jsonify(status='logged_out')

    @app.post('/api/transcribe')
    def transcribe():
        recording=request.files.get('audio')
        if recording is None: return jsonify(error='Upload a recording in the audio form field'),400
        mode=request.form.get('generate_invoice','false').lower()
        if mode not in ('true','false'): return jsonify(error='generate_invoice must be true or false'),400
        data=recording.read(MAX_AUDIO_BYTES+1)
        if len(data)>MAX_AUDIO_BYTES: return jsonify(error='Recording exceeds 10 MB'),413
        try:
            text=transcribe_audio(data)
            result={'transcript':text}
            if mode=='true': result['invoice']=store.save_draft(create_invoice(text),db())
            return jsonify(result)
        except ValueError as error: return jsonify(error=str(error)),400
        except GeminiUnavailable: return jsonify(error='AI service temporarily unavailable'),503
        except Exception:
            app.logger.error('Voice processing failed')
            return jsonify(error='Unable to process recording'),500

    @app.get('/api/invoices/<ident>')
    @auth
    def review(ident):
        if web_api.is_web_invoice(ident): return web_api.web_get_invoice(ident)
        if not g.token: return jsonify(error='Use the original employee login for terminal invoices'),401
        invoice=store.get_invoice(ident,db())
        return (jsonify(invoice),200) if invoice else (jsonify(error='Invoice not found'),404)

    @app.post('/api/invoices/<ident>/approve')
    @auth
    def approve(ident):
        if web_api.is_web_invoice(ident): return web_api.web_approve_invoice(ident)
        if not g.token: return jsonify(error='Use the original employee login for terminal invoices'),401
        data=request.get_json(silent=True)
        if not isinstance(data,dict) or data.get('confirm') is not True: return jsonify(error='Explicit confirmation required'),400
        status=store.approve(ident,data.get('review_digest'),g.employee,data.get('acknowledge_warnings'),db())
        if status!=200: return jsonify(error='Invoice not found' if status==404 else 'Review the current draft and acknowledge all warnings'),status
        return jsonify(store.get_invoice(ident,db()))

    @app.get('/api/invoices/<ident>/pdf')
    @auth
    def pdf(ident):
        if web_api.is_web_invoice(ident): return web_api.web_pdf(ident)
        if not g.token: return jsonify(error='Use the original employee login for terminal invoices'),401
        invoice=store.get_invoice(ident,db())
        if not invoice: return jsonify(error='Invoice not found'),404
        preview=request.args.get('preview')=='true'
        if not invoice['approved'] and not preview: return jsonify(error='Employee approval required before releasing an invoice'),409
        try: content=invoice_pdf(invoice)
        except Exception:
            app.logger.error('PDF rendering failed')
            return jsonify(error='Unable to generate PDF; check font configuration'),500
        if invoice['approved']: store.record_release(ident,g.employee,db())
        return send_file(BytesIO(content),mimetype='application/pdf',as_attachment=True,download_name=('invoice-' if invoice['approved'] else 'draft-')+ident+'.pdf')
