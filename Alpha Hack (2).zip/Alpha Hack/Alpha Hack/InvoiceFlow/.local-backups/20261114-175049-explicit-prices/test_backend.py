import os
os.environ.setdefault('GEMINI_API_KEY', 'test-only')
import unittest
import tempfile
from unittest.mock import patch, Mock
from google.genai import errors
import ai_agent
from app import app
from invoice_engine import create_invoice

ORDER = dict(customer='Ali', parts=[dict(name='oil filter', quantity=2), dict(name='fuel filter',quantity=1)], labor_amount=30, labor_currency='USD', notes='')
class BackendTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.config["INVOICE_DB"]
        app.config["INVOICE_DB"] = self.temp.name + "/test.db"
    def tearDown(self):
        app.config["INVOICE_DB"] = self.old_db
        self.temp.cleanup()
    def test_routes(self):
        c=app.test_client()
        self.assertEqual(c.get('/api/health').status_code,200)
        self.assertEqual(len(c.get('/api/products').json['products']),20)
        self.assertEqual(c.get('/api/products/search?q=oil%20filter').json['products'][0]['id'],'P003')
        for body in [None, [], {}, {'message':''}, {'message':3}, {'message':'x'*5001}]:
            self.assertEqual(c.post('/api/invoice/draft',json=body).status_code,400)
    def test_invoice(self):
        with patch('invoice_engine.understand_message',return_value=ORDER):
            r=app.test_client().post('/api/invoice/draft',json={'message':'test'})
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json['subtotal_usd'],'110.00')
        self.assertEqual(r.json['subtotal_lbp'],'9900000')
        self.assertFalse(r.json['approved'])
    def test_fallback(self):
        for code in (404,429,503):
            with patch.object(ai_agent.client.models,'generate_content',side_effect=[errors.APIError(code,{}),Mock(parsed=ai_agent.RepairOrder(**ORDER))]) as call:
                self.assertEqual(ai_agent.understand_message('test')['customer'],'Ali')
                self.assertEqual(call.call_count,2)
    def test_all_failed(self):
        with patch.object(ai_agent.client.models,'generate_content',side_effect=errors.APIError(503,{})):
            r=app.test_client().post('/api/invoice/draft',json={'message':'test'})
        self.assertEqual(r.status_code,503)
    def test_missing_structured_data(self):
        with patch.object(ai_agent.client.models,'generate_content',side_effect=[Mock(parsed=None),Mock(parsed=ai_agent.RepairOrder(**ORDER))]):
            self.assertEqual(ai_agent.understand_message('test')['customer'],'Ali')
    def test_invalid_labor(self):
        with patch('invoice_engine.understand_message',return_value={**ORDER,'labor_amount':'bad'}):
            self.assertIn('Invalid labor amount',create_invoice('test')['warnings'])
    def test_unknown_and_ambiguous(self):
        with patch('invoice_engine.understand_message',return_value={**ORDER,'parts':[{'name':'unknown thing','quantity':1},{'name':'filter','quantity':1},{'name':'oil filter','quantity':0}]}):
            result=create_invoice('test')
        self.assertEqual(len(result['warnings']),3)
        self.assertEqual(result['items'],[])
    def test_notes_and_missing_labor(self):
        order = {**ORDER, 'notes': 'Check next week', 'labor_amount': None, 'labor_currency': None}
        with patch('invoice_engine.understand_message', return_value=order):
            result = app.test_client().post('/api/invoice/draft', json={'message': 'test'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json['notes'], 'Check next week')
        self.assertIn('Labor amount is missing', result.json['warnings'])
        self.assertEqual(result.json['subtotal_usd'], '80.00')

    def test_lbp_labor(self):
        with patch('invoice_engine.understand_message', return_value={**ORDER, 'labor_amount': 900000, 'labor_currency': 'LBP'}):
            result = create_invoice('test')
        self.assertEqual(result['subtotal_usd'], '90.00')
        self.assertEqual(result['subtotal_lbp'], '8100000')

    def test_explicit_zero_labor(self):
        with patch('invoice_engine.understand_message', return_value={**ORDER, 'labor_amount': 0}):
            result = create_invoice('test')
        self.assertNotIn('Labor amount is missing', result['warnings'])

if __name__=='__main__': unittest.main()

