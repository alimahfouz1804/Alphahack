# Open InvoiceFlow on this laptop

Double-click start-invoiceflow.bat in this folder, or run `python start_local.py` in VS Code. Open http://localhost:5000/signin.html (not the HTML file directly). No separate frontend server or Node installation is needed.

1. Click Create account. Use a new website username, for example alitaam_web. Your existing AliTaam terminal employee account remains separate and unchanged.
2. Enter your name, garage name, phone, and a private password following the form rules. The website account owns its new garage and can approve its invoices.
3. Select Talk with AI. Type a repair description and press the send arrow, or click the microphone, allow microphone access, speak, and click again to stop. Review the transcript, then press send.
4. Review the products and totals. The standard test of two oil filters, one fuel filter and USD 30 labor is USD 110 / LBP 9,900,000. No VAT is automatically added.
5. Click Save Draft or Submit for Approval. Open Pending Approvals, review the invoice, and click Approve. Confirm the displayed totals and any warnings.
6. Open the approved invoice from Invoice History and click Download PDF.

Email delivery and SMS password recovery are not configured. Download and manually send only an approved PDF. No messages are sent automatically. Test accounts from the uploaded ZIP were not imported.

Keep the server running while using the website. If a launcher opened a server console, closing that console stops the server. It listens only on this laptop. A friend on a different laptop cannot use your localhost address.

Tests: `python -m unittest test_backend test_workflow test_web -v`

Existing .env, garage.db records and products.json were preserved. Pre-installation backups are in .local-backups. The original terminal APIs and employee approval workflow remain available. Website invoices are stored separately in the same local database and are scoped to the signed-in garage.
