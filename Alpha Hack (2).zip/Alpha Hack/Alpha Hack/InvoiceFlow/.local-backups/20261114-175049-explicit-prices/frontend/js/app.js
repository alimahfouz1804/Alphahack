
/* The workspace only starts after the backend confirms the session (GET /api/auth/me).
   No session -> Auth.requireUser() sends the visitor to signin.html. */
Auth.requireUser().then(function(USER){
document.body.classList.remove('auth-pending');
var $=function(i){return document.getElementById(i)};
/* clock */
function tick(){var d=new Date();$('clock').textContent=d.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'})+' · '+d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}
tick();setInterval(tick,30000);
/* mobile menu */
function setMenu(o){document.body.classList.toggle('menu',o);$('menuBtn').setAttribute('aria-expanded',o)}
$('menuBtn').setAttribute('aria-expanded','false');
$('menuBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('scrim').onclick=function(){setMenu(false)};
document.addEventListener('click',function(e){if(document.body.classList.contains('menu')&&!e.target.closest('nav'))setMenu(false)});
document.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});
/* intro: once per session, skippable, reduced-motion aware */
var intro=$('intro'),seen=false;
try{seen=sessionStorage.getItem('ifIntro')==='1'}catch(e){}
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function finish(){document.body.classList.add('ready');intro.classList.add('done');try{sessionStorage.setItem('ifIntro','1')}catch(e){}setTimeout(function(){intro.style.display='none'},700)}
if(seen||reduce){intro.style.display='none';document.body.classList.add('ready')}
else{var t1=setTimeout(function(){intro.classList.add('open')},500),t2=setTimeout(finish,2500);
$('skip').onclick=function(){clearTimeout(t1);clearTimeout(t2);intro.style.display='none';document.body.classList.add('ready');try{sessionStorage.setItem('ifIntro','1')}catch(e){}}}
/* recording */
var mic=$('mic'),st=$('status'),rec=null,chunks=[],stream=null,ac=null,an=null,raf=0,t0=0,ti=0,url=null;
var cv=$('wave'),cx=cv.getContext('2d');
function say(m){st.textContent=m}
function fmt(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function draw(){
 var w=cv.width,h=cv.height;cx.clearRect(0,0,w,h);
 if(an){var d=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(d);var n=48,bw=w/n;
  for(var i=0;i<n;i++){var v=d[Math.floor(i*d.length/n/2)]/255,bh=Math.max(3,v*h);cx.fillStyle=i%2?'#06B6D4':'#2563EB';cx.fillRect(i*bw+1,(h-bh)/2,bw-3,bh)}}
 else{cx.fillStyle='#334155';for(var j=0;j<48;j++)cx.fillRect(j*(w/48)+1,h/2-2,w/48-3,4)}
 raf=requestAnimationFrame(draw)}
draw();
async function start(){
 if(rec)return;
 try{stream=await navigator.mediaDevices.getUserMedia({audio:true})}
 catch(e){say('Microphone not available. You can type the repair details instead.');return}
 try{ac=new (window.AudioContext||window.webkitAudioContext)();an=ac.createAnalyser();an.fftSize=256;ac.createMediaStreamSource(stream).connect(an);
  rec=new MediaRecorder(stream);chunks=[];rec.ondataavailable=function(e){chunks.push(e.data)};rec.onstop=onStop;rec.start()}
 catch(e){say('Recording is not supported in this browser. Please type instead.');cleanup();return}
 mic.classList.add('rec');mic.setAttribute('aria-label','Stop recording');$('recRow').hidden=false;
 t0=Date.now();$('timer').textContent='00:00';ti=setInterval(function(){$('timer').textContent=fmt(Math.floor((Date.now()-t0)/1000))},500);
 say('Recording… describe the repair.');$('aiState').textContent='Listening…'}
function cleanup(){clearInterval(ti);if(stream)stream.getTracks().forEach(function(t){t.stop()});if(ac)ac.close();an=null;ac=null;stream=null}
function stop(){if(rec&&rec.state!=='inactive')rec.stop()}
function onStop(){
 cleanup();rec=null;mic.classList.remove('rec');mic.setAttribute('aria-label','Start recording');$('recRow').hidden=true;
 var b=new Blob(chunks,{type:chunks[0]&&chunks[0].type||'audio/webm'});if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(b);
 var a=$('play');a.src=url;a.hidden=false;$('aiState').textContent='Recording saved';
 transcribe(b)}
var tx=$('tx');tx.addEventListener('input',function(){tx.style.height='auto';tx.style.height=tx.scrollHeight+'px'});
tx.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('gen').click()}});
mic.onclick=function(){rec?stop():start()};
/* ---- app state: cache of what the backend returned ---- */
var DB={invoices:[],customers:[],catalog:[],company:{name:USER.company.name||'',phone:'',logo:''}},convo=[],busy=false;
var inv=$('inv'),ai=$('ai'),pg=$('page'),paper=$('paper'),NB=document.querySelectorAll('nav > button'),cur=null,editing=false,curPage=0;
var LBL={draft:['DRAFT','s-draft'],pending:['PENDING APPROVAL','s-pending'],approved:['APPROVED','s-appr'],rejected:['REJECTED','s-rej']};
/* money: display only. Totals always come from the backend (invoice.totals). */
function num(n,d){return (+n||0).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d})}
function usd(n){return '$'+num(n,2)}
function lbp(n){return num(Math.round(+n||0),0)+' LBP'}
function money(n){return usd(n)}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function clone(o){return JSON.parse(JSON.stringify(o))}
function ref(c){return c.id!=null?c.id:c.no}
function canEdit(d){return d.status==='draft'||d.status==='rejected'}
function msg(t){$('aMsg').textContent=t}
function fail(e,fn){(fn||say)(e&&e.message?e.message:'Something went wrong.')}
function icons(){if(window.lucide)lucide.createIcons()}
function normCo(c){c=c||{};return {id:c.id,name:c.name||USER.company.name||'',phone:c.phone||'',logo:c.logo_url||'',vat:c.vat_rate,rate:c.exchange_rate}}
function applyCompany(){var n=DB.company.name||'your garage';
 $('hdrCompany').textContent=DB.company.name;$('hdrCompany2').textContent=DB.company.name;$('wCompany').textContent=n;
 document.title=(DB.company.name?DB.company.name+' · ':'')+'InvoiceFlow AI';$('modePill').hidden=API.mode()!=='mock'}
async function loadCompany(){DB.company=normCo(await API.getCompany());applyCompany()}
async function refresh(){var r=await Promise.all([API.listInvoices(),API.getCustomers(),API.getCatalog(),API.getCompany()]);DB.invoices=r[0];DB.customers=r[1];DB.catalog=r[2];DB.company=normCo(r[3]);applyCompany()}
function view(v,ni){$('work').hidden=v==='pg';pg.hidden=v!=='pg';inv.hidden=!cur;NB.forEach(function(b,i){b.classList.toggle('on',i===ni)});setMenu(false)}
/* ---- signed-in user + role-based UI (display only: the backend re-checks every permission) ---- */
var can=Auth.can;
function initials(n){return (n||'?').trim().split(/\s+/).slice(0,2).map(function(w){return w[0]}).join('').toUpperCase()}
function avatar(el){el.textContent='';if(USER.picture){var im=new Image();im.alt='';im.src=USER.picture;im.onerror=function(){el.textContent=initials(USER.name)};el.appendChild(im)}else el.textContent=initials(USER.name||USER.username)}
function applyUser(){USER=Auth.user||USER;
 $('hdrName').textContent=USER.name||USER.username;$('hdrRole').textContent=USER.roleLabel;
 $('navName').textContent=USER.name||'Signed in';$('navUsername').textContent='@'+USER.username;
 $('navRole').textContent=USER.roleLabel;$('navRole').className='role-b '+USER.role;
 avatar($('hdrAv'));avatar($('navAv'));
 [].forEach.call(document.querySelectorAll('nav [data-perm]'),function(b){b.hidden=!can(b.dataset.perm)});
 $('aMail').hidden=!can('invoice.send')}
applyUser();applyCompany();
$('profileBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('logoutBtn').onclick=async function(){var b=this;if(b.disabled)return;b.disabled=true;b.querySelector('span').textContent='Signing out...';try{await Auth.logout()}catch(e){b.disabled=false;b.querySelector('span').textContent='Log out';alert(e.message)}};
function denied(t){return '<h2>'+t+'</h2><p class="muted">Your account ('+esc(USER.roleLabel)+') does not have access to this page. Ask the garage owner if you need it.</p>'}
/* ---- voice + AI conversation ---- */
async function transcribe(b){say('Transcribing...');try{var r=await API.transcribe(b);tx.value=(tx.value+' '+(r.text||r.transcript||'')).trim();tx.dispatchEvent(new Event('input'));say('Transcription ready. Review it, then press send.')}catch(e){fail(e)}}
function bubble(r,t){var d=document.createElement('div');d.className='msg '+r;d.textContent=t;$('chat').appendChild(d);$('chat').scrollTop=$('chat').scrollHeight}
function resetChat(){$('chat').innerHTML='';convo=[];cur=null;editing=false;tx.value='';tx.placeholder='Describe the repair or tap the mic...';say('');bubble('ai','Hi! Tell me what work was done on the truck, in Arabic or English, and I\u2019ll prepare the invoice for you.');view('ai',1)}
$('gen').onclick=async function(){
 if(busy)return;var txt=tx.value.trim();
 if(!txt){say('Tap the microphone or type what was repaired.');return}
 bubble('user',txt);tx.value='';tx.style.height='auto';say('');busy=true;st.innerHTML='<span class="dots"><i></i><i></i><i></i></span>InvoiceFlow AI is working... (this can take up to a minute)';$('aiState').textContent='Processing...';
 try{convo.push({role:'user',text:txt});var r=await API.generateInvoice({text:txt,history:convo});
  if(r.question){convo.push({role:'assistant',text:r.question});bubble('ai',r.question);say('')}
  else{convo=[];bubble('ai','Your invoice is ready. Review it, correct anything that looks wrong, then submit it for owner approval.');if(r.warnings&&r.warnings.length)bubble('ai','Please check:\n\u2022 '+r.warnings.join('\n\u2022 '));say('');showInvoice(r)}}
 catch(e){convo.pop();$('chat').lastChild.remove();tx.value=txt;fail(e)}
 finally{busy=false;$('aiState').textContent='Ready'}};
/* ---- invoice preview / editing ---- */
function coOf(d){var c=d.company||{};return {name:c.name||DB.company.name,phone:c.phone||DB.company.phone,logo:c.logo_url||DB.company.logo}}
function totals(){
 var t=cur.totals,dirty=!!cur._dirty;
 [].forEach.call($('iRows').rows,function(r,i){var it=cur.items[i],c=r.querySelector('.rt');if(!it||!c)return;var bk=!dirty&&it.total_usd!=null;c.textContent=usd(bk?it.total_usd:it.q*it.p);c.classList.toggle('pv',!bk)});
 var ok=t&&!dirty;
 $('iSub').textContent=t?usd(t.subtotal_usd):'—';$('iVatL').textContent='VAT'+(t&&t.vat_rate!=null?' ('+t.vat_rate+'%)':'');
 $('iVat').textContent=t?usd(t.vat_usd):'—';$('iTot').textContent=t?usd(t.total_usd):'—';$('iTotL').textContent=t?lbp(t.total_lbp):'—';
 $('iTotals').classList.toggle('stale',!ok);$('iStale').hidden=ok;
 $('iStale').textContent=t?'You changed items — the server recalculates the USD and LBP totals when you save.':'Totals will be calculated by the server when you save the invoice.';
 var rate=(t&&t.exchange_rate)||DB.company.rate;$('iFx').textContent=rate?'Exchange rate: 1 USD = '+num(rate,0)+' LBP (fixed rate used by InvoiceFlow AI).':''}
function btns(){var ce=canEdit(cur),ap=cur.status==='approved';$('aEdit').disabled=!ce;$('aEdit').textContent=editing&&ce?'Done Editing':'Edit Invoice';$('aDraft').disabled=!ce;$('aSubmit').disabled=!ce;$('aPrint').disabled=!ap;$('aMail').disabled=true;$('aPrint').title=ap?'Download the approved PDF':'Available after owner approval';$('aMail').title='Email delivery is not configured; download the approved PDF for manual sending'}
function render(){
 var d=cur,ed=editing&&canEdit(d),C=d.cust,T=d.truck,co=coOf(d),h='',s=LBL[d.status];
 $('iCo').textContent=(co.name||'').toUpperCase();$('iCoPhone').textContent=co.phone?'Phone: '+Phone.pretty(co.phone):'';
 var lg=$('iLogo');lg.hidden=!co.logo;if(co.logo)lg.src=co.logo;else lg.removeAttribute('src');
 $('iNo').textContent=d.no?'INVOICE #'+d.no:'INVOICE — not saved yet';$('iDate').textContent=new Date(d.date||Date.now()).toLocaleDateString([], {year:'numeric',month:'long',day:'numeric'});
 $('iSt').textContent=s[0];$('iSt').className='badge-s '+s[1];var n=document.querySelector('.note');n.hidden=!d.mock;n.textContent='Mock data from the frontend test layer, not from the AI backend.';
 function fld(g,list){return list.map(function(x){var p=x.split('|');return '<input data-s="'+g+'.'+p[0]+'" placeholder="'+p[1]+'" value="'+esc((g==='cust'?C:T)[p[0]])+'">'}).join('')}
 $('iCust').innerHTML=ed?fld('cust',['name|Customer name','contact|Contact person','tel|Phone','email|Email']):([C.name,C.contact&&'Contact: '+C.contact,C.tel&&'Tel: '+C.tel,C.email].filter(Boolean).map(esc).join('<br>')||'-');
 $('iTruck').innerHTML=ed?fld('truck',['plate|Plate number','model|Truck model']):([T.plate&&'Plate: '+T.plate,T.model].filter(Boolean).map(esc).join('<br>')||'-');
 $('iRows').parentNode.tHead.innerHTML='<tr><th>Description</th><th>Type</th><th class="r">Qty</th><th class="r">Unit price (USD)</th><th class="r">Total (USD)</th>'+(ed?'<th></th>':'')+'</tr>';
 d.items.forEach(function(it,i){
  h+=ed?'<tr><td><input data-i="'+i+'" data-k="d" value="'+esc(it.d)+'"></td><td><input data-i="'+i+'" data-k="t" value="'+esc(it.t)+'"></td><td><input data-i="'+i+'" data-k="q" type="number" min="0" step="any" value="'+it.q+'"></td><td><input data-i="'+i+'" data-k="p" type="number" min="0" step="any" value="'+it.p+'"></td><td class="r rt"></td><td><button class="x" data-del="'+i+'" aria-label="Remove row">&times;</button></td></tr>'
  :'<tr><td>'+esc(it.d)+'</td><td>'+esc(it.t)+'</td><td class="r">'+it.q+'</td><td class="r">'+usd(it.p)+'</td><td class="r rt"></td></tr>'});
 $('iRows').innerHTML=h;$('iEd').hidden=!ed;
 $('iEd').innerHTML=ed?'<button class="btn sm" id="addRow">+ Add row</button><select id="catSel"><option value="">Add from catalog...</option>'+DB.catalog.map(function(c,i){return '<option value="'+i+'">'+esc(c[0])+' ('+usd(c[2])+')</option>'}).join('')+'</select>':'';
 totals();btns()}
function show(c,ni){cur=c;editing=false;render();msg('');view('inv',ni||1);inv.scrollIntoView()}
function showInvoice(d){var c=clone(d);c.status=c.status||'draft';show(c,1)}
function dirty(){cur._dirty=true}
paper.addEventListener('input',function(e){var t=e.target,d=t.dataset;if(d.k){cur.items[+d.i][d.k]=(d.k==='q'||d.k==='p')?(parseFloat(t.value)||0):t.value;if(d.k==='q'||d.k==='p')dirty();totals()}else if(d.s){var a=d.s.split('.');cur[a[0]][a[1]]=t.value}});
paper.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;if(b.id==='addRow'){cur.items.push({d:'',t:'Service',q:1,p:0});dirty();render()}else if(b.dataset.del!=null){cur.items.splice(+b.dataset.del,1);dirty();render()}});
paper.addEventListener('change',function(e){if(e.target.id==='catSel'&&e.target.value!==''){var c=DB.catalog[+e.target.value];cur.items.push({d:c[0],t:c[1],q:1,p:c[2]});dirty();render()}});
function payload(){var p=clone(cur);delete p._dirty;delete p.totals;delete p.mock;p.items.forEach(function(i){delete i.total_usd});return p}
async function run(fn,ok){if(busy)return;busy=true;try{await fn();if(ok)msg(ok);refresh().catch(function(){})}catch(e){fail(e,msg)}finally{busy=false}}
$('aNew').onclick=resetChat;
$('aEdit').onclick=function(){editing=!editing;render();msg('')};
$('aDraft').onclick=function(){run(async function(){cur=await API.saveInvoice(payload());editing=false;render()},'Draft saved. Totals were recalculated by the server.')};
$('aSubmit').onclick=function(){run(async function(){if(!cur.items.length)throw Error('Add at least one item first.');var s=await API.saveInvoice(payload());cur=await API.submitInvoice(ref(s));editing=false;render()},'Submitted. An authorized owner must approve it.')};
$('aPrint').onclick=function(){run(async function(){await API.downloadPdf(ref(cur))},'Approved PDF downloaded.')};
$('aMail').onclick=function(){run(async function(){var to=cur.cust.email||prompt('Customer email address:');if(!to)return;var r=await API.sendEmail(ref(cur),to);msg(r.message||'Email request sent.')})};
/* ---- pages ---- */
function table(hd,rows){return '<div class="tw"><table><thead><tr>'+hd.map(function(x){return '<th>'+x+'</th>'}).join('')+'</tr></thead><tbody>'+(rows||'<tr><td colspan="'+hd.length+'" class="muted">Nothing here yet.</td></tr>')+'</tbody></table></div>'}
function badge(s){return '<span class="badge-s '+LBL[s][1]+'">'+LBL[s][0]+'</span>'}
function totCell(c){var t=c.totals;return t?usd(t.total_usd)+'<small class="lbp-s">'+lbp(t.total_lbp)+'</small>':'—'}
function invRows(L,acts){return L.map(function(c){return '<tr><td>'+esc(c.no)+'</td><td>'+esc(c.cust.name||'-')+'</td><td>'+esc(c.truck.plate||'-')+'</td><td class="r">'+totCell(c)+'</td><td>'+badge(c.status)+'</td><td class="r">'+acts(c)+'</td></tr>'}).join('')}
var IH=['No.','Customer','Truck','Total','Status',''];
function op(c){return '<button class="btn sm" data-open="'+esc(ref(c))+'">Open</button>'}
function histRows(){var q=($('q')||{value:''}).value.toLowerCase(),f=($('fs')||{value:''}).value;return invRows(DB.invoices.slice().reverse().filter(function(c){return(!f||c.status===f)&&(!q||(c.no+' '+c.cust.name+' '+c.truck.plate).toLowerCase().indexOf(q)>=0)}),op)}
async function openPage(i){curPage=i;view('pg',{0:0,3:2,4:3,7:4}[i]);
 if(i===4&&!can('invoice.approve')){pg.innerHTML=denied('Pending Approvals');return}
 pg.innerHTML='<p class="muted">Loading...</p>';
 try{await refresh()}catch(e){pg.innerHTML='<h2>Backend unavailable</h2><p>'+esc(e.message)+'</p>';return}
 var L=DB.invoices.slice().reverse(),h='',n=function(s){return L.filter(function(c){return c.status===s}).length};
 if(i===0){var td=new Date().toDateString();h='<div class="dash-wel"><h2>Welcome to '+esc(DB.company.name||'your garage')+'</h2><p>Your AI-powered invoice assistant is ready.</p></div><div class="qa"><button class="btn pri sm" data-go="1">Talk with AI</button>'+(can('invoice.approve')?'<button class="btn sm" data-go="3">Pending approvals</button>':'')+'<button class="btn sm" data-go="2">Invoice history</button></div><div class="stats"><div><h3>Today</h3><b>'+L.filter(function(c){return new Date(c.date).toDateString()===td}).length+'</b></div><div><h3>Pending</h3><b>'+n('pending')+'</b></div><div><h3>Approved</h3><b>'+n('approved')+'</b></div></div><h3>Recent invoices</h3>'+table(IH,invRows(L.slice(0,5),op))}
 else if(i===3)h='<h2>Invoice History</h2><div class="bar"><input id="q" placeholder="Search by number, customer or plate..."><select id="fs"><option value="">All statuses</option><option value="draft">Draft</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div><div id="list">'+table(IH,histRows())+'</div>';
 else if(i===4)h='<h2>Pending Approvals</h2>'+table(IH,invRows(L.filter(function(c){return c.status==='pending'}),function(c){return op(c)+' <button class="btn sm pri" data-ap="'+esc(ref(c))+'">Approve</button> <button class="btn sm" data-rj="'+esc(ref(c))+'">Reject</button>'}))+'<div class="pmsg" role="status"></div>';
 else if(i===5)h='<h2>Customers</h2>'+table(['Name','Contact','Phone','Email'],DB.customers.map(function(c){return '<tr><td>'+esc(c.name)+'</td><td>'+esc(c.contact)+'</td><td>'+esc(c.tel)+'</td><td>'+esc(c.email)+'</td></tr>'}).join(''));
 else if(i===6)h='<h2>Garage Catalog</h2><p class="muted">Read from the backend. Prices are validated there.</p>'+table(['Item','Type','Price (USD)'],DB.catalog.map(function(c){return '<tr><td>'+esc(c[0])+'</td><td>'+esc(c[1])+'</td><td>'+usd(c[2])+'</td></tr>'}).join(''));
 else {pg.innerHTML=Settings.html();Settings.init();icons();return}
 pg.innerHTML=h}
function find(r){return DB.invoices.find(function(c){return String(ref(c))===String(r)})}
pg.addEventListener('input',function(e){if(e.target.id==='q'||e.target.id==='fs')$('list').innerHTML=table(IH,histRows())});
pg.addEventListener('click',async function(e){var b=e.target.closest('button');if(!b)return;var d=b.dataset;
 if(d.go)NB[+d.go].click();
 else if(d.open){b.disabled=true;try{show(clone(await API.getInvoice(d.open)),1)}catch(er){var c=find(d.open);if(c)show(clone(c),1);else alert(er.message)}finally{b.disabled=false}}
 else if(d.ap||d.rj){var m=pg.querySelector('.pmsg');try{if(d.ap){var reviewed=await API.getInvoice(d.ap);if(!confirm('Approve '+reviewed.no+' for '+reviewed.cust.name+'?\nTotal: '+usd(reviewed.totals.total_usd)+' / '+lbp(reviewed.totals.total_lbp)+'\n'+(reviewed.warnings||[]).join('\n')))return;await API.approveInvoice(d.ap,reviewed);}else await API.rejectInvoice(d.rj);await openPage(curPage)}catch(er){m.textContent=er.message}}});
NB.forEach(function(b,i){b.onclick=function(){if(i===1)view('ai',1);else openPage([0,1,3,4,7][i])}});

/* ---- Settings: personal info, password, company profile ---- */
var Settings=(function(){
 var LOGO_TYPES=['image/png','image/jpeg','image/webp'],LOGO_MAX=2*1024*1024,unTimer=0,unOk=true,logoFile=null,removeLogo=false;
 function f(id,label,val,attrs){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><input id="'+id+'" value="'+esc(val)+'" '+(attrs||'')+'><small class="ferr2" id="'+id+'Err"></small></label>'}
 function phone(id,label,e164,dis){var p=Phone.split(e164);return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="ph"><select id="'+id+'Cc" '+dis+'></select><input id="'+id+'" type="tel" inputmode="tel" value="'+esc(p.national)+'" placeholder="71 123 456" '+dis+'></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function pw(id,label,ac){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="pwbox"><input id="'+id+'" type="password" autocomplete="'+ac+'"><button type="button" class="eye2" data-eye="'+id+'" aria-label="Show password"><i data-lucide="eye"></i></button></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function html(){var C=DB.company,own=can('company.manage'),dis=own?'':'disabled';
  return '<h2>Settings</h2>'+
  '<form class="sform" id="fMe" novalidate><h3>Personal information</h3><div class="sgrid">'+
   f('sFirst','First name',USER.firstName,'autocomplete="given-name" maxlength="50"')+f('sLast','Last name',USER.lastName,'autocomplete="family-name" maxlength="50"')+
   f('sUser','Username',USER.username,'autocomplete="username" maxlength="30" autocapitalize="none" spellcheck="false"')+phone('sPhone','Phone number',USER.phone,'')+
  '</div><div class="srow"><button class="btn pri sm" id="bMe">Save personal info</button><span class="smsg" id="mMe" role="status"></span></div></form>'+
  '<form class="sform" id="fPw" novalidate><h3>Change password</h3><div class="sgrid">'+
   pw('sCur','Current password','current-password')+'<span></span>'+pw('sNew','New password','new-password')+pw('sNew2','Confirm new password','new-password')+
  '</div><p class="muted small">At least 8 characters with an uppercase letter, a lowercase letter and a number.</p><div class="srow"><button class="btn pri sm" id="bPw">Change password</button><span class="smsg" id="mPw" role="status"></span></div></form>'+
  '<form class="sform" id="fCo" novalidate><h3>Company information</h3>'+(own?'':'<p class="muted small">Only the garage owner can change company information.</p>')+'<div class="sgrid">'+
   f('cName','Company name',C.name,'maxlength="120" '+dis)+phone('cPhone','Company phone number',C.phone,dis)+
  '</div><div class="logo-row"><div class="logo-prev" id="cLogoPrev">'+(C.logo?'<img src="'+esc(C.logo)+'" alt="Company logo">':'<span>No logo</span>')+'</div>'+
   (own?'<div><label class="btn sm file-btn"><input type="file" id="cLogo" accept="image/png,image/jpeg,image/webp" hidden>Upload logo</label> <button type="button" class="btn sm" id="cLogoRm"'+(C.logo?'':' hidden')+'>Remove</button><small class="muted small block">PNG, JPG or WebP, up to 2 MB. Shown on every invoice.</small><small class="ferr2" id="cLogoErr"></small></div>':'')+
  '</div><dl class="dl"><dt>VAT rate</dt><dd>'+(C.vat!=null?esc(C.vat)+'%':'Set by the backend')+'</dd><dt>Exchange rate</dt><dd>'+(C.rate?'1 USD = '+num(C.rate,0)+' LBP':'Set by the backend')+'</dd></dl>'+
  (own?'<div class="srow"><button class="btn pri sm" id="bCo">Save company info</button><span class="smsg" id="mCo" role="status"></span></div>':'')+'</form>'}
 function err(id,t){var e=$(id+'Err');if(e)e.textContent=t||'';var l=pg.querySelector('[data-f="'+id+'"]');if(l)l.classList.toggle('bad',!!t)}
 function note(id,t,ok){var m=$(id);m.textContent=t||'';m.className='smsg'+(ok?' ok':'')}
 function load(btn,on){btn.disabled=on;btn.classList.toggle('busy',on)}
 function serverErr(e,map,box){Object.keys(e.fields||{}).forEach(function(k){if(map[k])err(map[k],e.fields[k])});note(box,e.message)}
 var NAME=/^[\p{L}\p{M}][\p{L}\p{M}' .-]*$/u,PWR=function(p){return p.length>=8&&/[A-Z]/.test(p)&&/[a-z]/.test(p)&&/\d/.test(p)};
 function init(){unOk=true;logoFile=null;removeLogo=false;
  Phone.fillSelect($('sPhoneCc'),Phone.split(USER.phone).cc);Phone.fillSelect($('cPhoneCc'),Phone.split(DB.company.phone).cc);
  pg.querySelectorAll('[data-eye]').forEach(function(b){b.onclick=function(){var i=$(b.dataset.eye),s=i.type==='password';i.type=s?'text':'password';b.setAttribute('aria-label',s?'Hide password':'Show password');b.innerHTML='<i data-lucide="'+(s?'eye-off':'eye')+'"></i>';icons()}});
  /* username availability (only when it differs from the current one) */
  $('sUser').oninput=function(){var u=this;u.value=u.value.toLowerCase().replace(/\s/g,'');clearTimeout(unTimer);var v=u.value;
   if(v===USER.username){unOk=true;err('sUser','');return}
   if(!Auth.USERNAME_RE.test(v)){unOk=false;err('sUser','Use 3–30 letters, numbers, "_" or "." — start with a letter.');return}
   unOk=false;err('sUser','');$('sUserErr').textContent='Checking availability…';
   unTimer=setTimeout(async function(){try{var r=await Auth.checkUsername(v);if($('sUser').value!==v)return;unOk=r.available;
    if(r.available){$('sUserErr').innerHTML='<span class="okc">✓ Username is available</span>'}else err('sUser','⚠ Username is already taken'+(r.suggestions.length?' — try '+r.suggestions.slice(0,3).join(', '):''))}
    catch(e){unOk=true;$('sUserErr').textContent='Couldn’t check now; the server will confirm on save.'}},450)};
  $('fMe').onsubmit=async function(e){e.preventDefault();var b=$('bMe'),ok=true;note('mMe','');
   [['sFirst','first name'],['sLast','last name']].forEach(function(x){var v=$(x[0]).value.trim();var m=!v?'Please enter your '+x[1]+'.':!NAME.test(v)?'Use letters only.':'';err(x[0],m);if(m)ok=false});
   var ph=Phone.validate($('sPhoneCc').value,$('sPhone').value);err('sPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;
   if(!unOk){ok=false;if(!$('sUserErr').textContent)err('sUser','Choose an available username.')}
   if(!ok)return;load(b,true);
   try{await Auth.updateMe({first_name:$('sFirst').value.trim(),last_name:$('sLast').value.trim(),username:$('sUser').value.trim(),phone:ph.e164});applyUser();note('mMe','Saved.',true)}
   catch(er){if(er.status===409)err('sUser','⚠ Username is already taken');serverErr(er,{first_name:'sFirst',last_name:'sLast',username:'sUser',phone:'sPhone'},'mMe')}finally{load(b,false)}};
  $('fPw').onsubmit=async function(e){e.preventDefault();var b=$('bPw'),c=$('sCur').value,n=$('sNew').value,n2=$('sNew2').value,ok=true;note('mPw','');
   err('sCur',c?'':'Enter your current password.');if(!c)ok=false;
   var m=!n?'Enter a new password.':!PWR(n)?'Doesn’t meet the requirements below.':n===c?'Choose a different password.':'';err('sNew',m);if(m)ok=false;
   err('sNew2',n2===n?'':'Passwords don’t match.');if(n2!==n)ok=false;if(!ok)return;load(b,true);
   try{await Auth.changePassword(c,n);['sCur','sNew','sNew2'].forEach(function(i){$(i).value=''});note('mPw','Password changed. Other devices were signed out.',true)}
   catch(er){if(er.status===400||er.status===401&&er.code)err('sCur','Current password is incorrect.');serverErr(er,{current_password:'sCur',new_password:'sNew'},'mPw')}finally{load(b,false)}};
  if(!can('company.manage'))return;
  $('cLogo').onchange=function(){var fl=this.files[0];err('cLogo','');if(!fl)return;
   if(LOGO_TYPES.indexOf(fl.type)<0){err('cLogo','Please choose a PNG, JPG or WebP image.');this.value='';return}
   if(fl.size>LOGO_MAX){err('cLogo','The logo must be 2 MB or smaller.');this.value='';return}
   logoFile=fl;removeLogo=false;var u=URL.createObjectURL(fl);$('cLogoPrev').innerHTML='<img src="'+u+'" alt="New logo preview">';$('cLogoRm').hidden=false};
  $('cLogoRm').onclick=function(){logoFile=null;removeLogo=true;$('cLogo').value='';$('cLogoPrev').innerHTML='<span>No logo</span>';this.hidden=true};
  $('fCo').onsubmit=async function(e){e.preventDefault();var b=$('bCo'),nm=$('cName').value.trim().replace(/\s+/g,' '),ok=true;note('mCo','');
   err('cName',nm.length<2?'Please enter the company name.':'');if(nm.length<2)ok=false;
   var ph=Phone.validate($('cPhoneCc').value,$('cPhone').value);err('cPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;if(!ok)return;
   var fd=new FormData();fd.append('name',nm);fd.append('phone',ph.e164);if(logoFile)fd.append('logo',logoFile);if(removeLogo)fd.append('remove_logo','1');
   load(b,true);try{DB.company=normCo(await API.updateCompany(fd));applyCompany();logoFile=null;removeLogo=false;note('mCo','Saved. The homepage and new invoices now use this information.',true)}
   catch(er){serverErr(er,{name:'cName',phone:'cPhone',logo:'cLogo'},'mCo')}finally{load(b,false)}}}
 return {html:html,init:init}})();

loadCompany().catch(function(e){say(e.message)});refresh().catch(function(e){say(e.message)});resetChat();icons();
});
