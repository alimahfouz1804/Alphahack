import os
os.environ.setdefault('GEMINI_API_KEY', 'test-only')
import unittest
import tempfile
from unittest.mock import patch, Mock
from google.genai import errors
import ai_agent
from app import app
from invoice_engine import create_invoice

ORDER = dict(customer='Ali', parts=[dict(name='oil filter', quantity=2, unit_price=25, price_currency='USD'), dict(name='fuel filter',quantity=1, unit_price=30, price_currency='USD')], labor_amount=30, labor_currency='USD', notes='')
class BackendTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.config["INVOICE_DB"]
        app.config["INVOICE_DB"] = self.temp.name + "/test.db"
    def tearDown(self):
        app.config["INVOICE_DB"] = self.old_db
        self.temp.cleanup()
    def test_routes(self):
        c=app.test_client()
        self.assertEqual(c.get('/api/health').status_code,200)
        self.assertEqual(len(c.get('/api/products').json['products']),20)
        self.assertEqual(c.get('/api/products/search?q=oil%20filter').json['products'][0]['id'],'P003')
        for body in [None, [], {}, {'message':''}, {'message':3}, {'message':'x'*5001}]:
            self.assertEqual(c.post('/api/invoice/draft',json=body).status_code,400)
    def test_invoice(self):
        with patch('invoice_engine.understand_message',return_value=ORDER):
            r=app.test_client().post('/api/invoice/draft',json={'message':'test'})
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json['subtotal_usd'],'110.00')
        self.assertEqual(r.json['subtotal_lbp'],'9900000')
        self.assertFalse(r.json['approved'])
    def test_fallback(self):
        for code in (404,429,503):
            with patch.object(ai_agent.client.models,'generate_content',side_effect=[errors.APIError(code,{}),Mock(parsed=ai_agent.RepairOrder(**ORDER))]) as call:
                self.assertEqual(ai_agent.understand_message('test')['customer'],'Ali')
                self.assertEqual(call.call_count,2)
    def test_all_failed(self):
        with patch.object(ai_agent.client.models,'generate_content',side_effect=errors.APIError(503,{})):
            r=app.test_client().post('/api/invoice/draft',json={'message':'test'})
        self.assertEqual(r.status_code,503)

    def test_temporary_backup_failure_is_retried_once(self):
        response = Mock(parsed=ai_agent.RepairOrder(**ORDER))
        with patch.dict(os.environ, {'GEMINI_MODEL':'primary','GEMINI_BACKUP_MODEL':'backup'}), patch.object(ai_agent.time,'sleep'), patch.object(ai_agent.client.models,'generate_content',side_effect=[errors.APIError(429,{}),errors.APIError(503,{}),response]) as call:
            self.assertEqual(ai_agent.understand_message('test')['customer'],'Ali')
        self.assertEqual([x.kwargs['model'] for x in call.call_args_list], ['primary','backup','backup'])

    def test_arabic_container_names_preserve_size_and_ambiguity(self):
        from database import search_products
        for query in ('عبوة زيت موتور 20 ليتر','علبة زيت موتور ٢٠ لتر','container of engine oil 20 liters'):
            self.assertEqual([p['id'] for p in search_products(query)],['P002'])
        self.assertEqual([p['id'] for p in search_products('Engine Oil 5L')],['P001'])
        self.assertEqual(search_products('Engine Oil 200L'),[])
        self.assertGreater(len(search_products('engine oil')),1)
        self.assertEqual([p['id'] for p in search_products('ماء رادياتور حجم العبوة 5 ليتر')],['P013'])
        for query in ('brake pad set', 'brake pads set', 'brake pad'):
            self.assertEqual([p['id'] for p in search_products(query)],['P006'])
        with patch('invoice_engine.understand_message',return_value={**ORDER,'parts':[dict(name='عبوة زيت موتور 20 ليتر',quantity=1,unit_price=140,price_currency='USD')],'labor_amount':45}):
            result=create_invoice('test')
        self.assertEqual(result['items'][0]['name'],'Engine Oil 20L')
        self.assertEqual(result['subtotal_usd'],'185.00')

    def test_quantity_must_have_explicit_non_price_evidence(self):
        for evidence, message, expected in [
            ('', 'replaced oil filters at 25 USD each', False),
            ('oil filters', 'replaced oil filters at 25 USD each', False),
            ('25 USD', 'replaced oil filters at 25 USD each', False),
            ('20L', 'engine oil 20L', False),
            ('2 oil filters', 'replaced oil filters at 25 USD each', False),
            ('2 oil filters', 'replaced 2 oil filters at 25 USD each', True),
            ('عبوتين', 'غيرنا عبوتين ماء رادياتور', True),
            ('عدد اتنين', 'فلتر زيت عدد اتنين', True),
        ]:
            self.assertEqual(ai_agent.has_quantity_evidence({'quantity_evidence':evidence},message), expected)
        self.assertFalse(ai_agent.has_quantity_evidence({'quantity':1,'quantity_evidence':'2 oil filters'},'2 oil filters'))
        self.assertTrue(ai_agent.has_quantity_evidence({'quantity':1,'quantity_evidence':'1 engine oil 20L at 140 USD'},'1 engine oil 20L at 140 USD'))
        response=Mock(parsed=ai_agent.RepairOrder(customer='Demo',parts=[ai_agent.Part(name='oil filter',quantity=1,unit_price=25,price_currency='USD')]))
        with patch.object(ai_agent.client.models,'generate_content',return_value=response):
            order=ai_agent.understand_message('replaced oil filters at 25 USD each')
        self.assertEqual(order['parts'][0]['quantity'],0)
    def test_missing_structured_data(self):
        with patch.object(ai_agent.client.models,'generate_content',side_effect=[Mock(parsed=None),Mock(parsed=ai_agent.RepairOrder(**ORDER))]):
            self.assertEqual(ai_agent.understand_message('test')['customer'],'Ali')
    def test_invalid_labor(self):
        with patch('invoice_engine.understand_message',return_value={**ORDER,'labor_amount':'bad'}):
            self.assertIn('Invalid labor amount',create_invoice('test')['warnings'])
    def test_unknown_and_ambiguous(self):
        with patch('invoice_engine.understand_message',return_value={**ORDER,'parts':[{'name':'unknown thing','quantity':1},{'name':'filter','quantity':1},{'name':'oil filter','quantity':0}]}):
            result=create_invoice('test')
        self.assertEqual(len(result['warnings']),3)
        self.assertEqual(result['items'],[])
    def test_notes_and_missing_labor(self):
        order = {**ORDER, 'notes': 'Check next week', 'labor_amount': None, 'labor_currency': None}
        with patch('invoice_engine.understand_message', return_value=order):
            result = app.test_client().post('/api/invoice/draft', json={'message': 'test'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json['notes'], 'Check next week')
        self.assertIn('Labor amount is missing', result.json['warnings'])
        self.assertIsNone(result.json['labor_amount'])
        self.assertIsNone(result.json['subtotal_usd'])
        self.assertTrue(result.json['incomplete'])

    def test_lbp_labor(self):
        with patch('invoice_engine.understand_message', return_value={**ORDER, 'labor_amount': 900000, 'labor_currency': 'LBP'}):
            result = create_invoice('test')
        self.assertEqual(result['subtotal_usd'], '90.00')
        self.assertEqual(result['subtotal_lbp'], '8100000')

    def test_explicit_zero_labor(self):
        with patch('invoice_engine.understand_message', return_value={**ORDER, 'labor_amount': 0}):
            result = create_invoice('test')
        self.assertNotIn('Labor amount is missing', result['warnings'])
        self.assertEqual(result['subtotal_usd'], '80.00')

    def test_missing_part_price_is_not_taken_from_catalog(self):
        order = {**ORDER, 'parts': [dict(name='oil filter', quantity=2)]}
        with patch('invoice_engine.understand_message', return_value=order):
            result = create_invoice('test')
        self.assertEqual(result['items'][0]['name'], 'Oil Filter')
        for key in ('price_usd', 'price_lbp', 'total_usd', 'total_lbp'):
            self.assertIsNone(result['items'][0][key])
        self.assertIsNone(result['subtotal_usd'])
        self.assertTrue(result['incomplete'])

    def test_explicit_price_overrides_catalog_and_converts_lbp(self):
        for amount, currency in [(27, 'USD'), (2430000, 'LBP')]:
            with self.subTest(currency=currency), patch('invoice_engine.understand_message', return_value={
                    **ORDER, 'parts': [dict(name='oil filter', quantity=2, unit_price=amount, price_currency=currency)]}):
                result = create_invoice('test')
            self.assertEqual(result['subtotal_usd'], '84.00')
            self.assertEqual(result['subtotal_lbp'], '7560000')

    def test_invalid_or_unspecified_price_currency_stays_blank(self):
        for price, currency in [(25, None), (-1, 'USD'), ('bad', 'USD'), (float('inf'), 'USD')]:
            with self.subTest(price=price), patch('invoice_engine.understand_message', return_value={
                    **ORDER, 'parts': [dict(name='oil filter', quantity=2, unit_price=price, price_currency=currency)]}):
                result = create_invoice('test')
            self.assertIsNone(result['items'][0]['price_usd'])
            self.assertIsNone(result['subtotal_usd'])

    def test_explicit_free_part_is_zero_not_missing(self):
        with patch('invoice_engine.understand_message', return_value={
                **ORDER, 'parts': [dict(name='oil filter', quantity=2, unit_price=0, price_currency='USD')]}):
            result = create_invoice('test')
        self.assertEqual(result['items'][0]['price_usd'], '0')
        self.assertEqual(result['subtotal_usd'], '30.00')

if __name__=='__main__': unittest.main()

