"""Web-app API for the InvoiceFlow AI frontend (frontend/ folder).

Adds, next to the existing Flask routes:
  - username + password accounts with HttpOnly cookie sessions and a CSRF token
  - companies (name, phone, logo, VAT) - each signup creates its own company
  - invoices in the frontend's shape with server-side USD + LBP totals
  - POST /api/invoices/generate: runs the existing Gemini agent (invoice_engine.create_invoice)
  - serves the frontend pages from frontend/ so everything runs on one origin

The existing Bearer-token employee routes (workflow_routes.py) keep working unchanged.
"""
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path

from flask import request, jsonify, current_app, g, send_from_directory, redirect, Response, abort, send_file
from io import BytesIO
from pdf_invoice import invoice_pdf
from werkzeug.security import generate_password_hash, check_password_hash

from ai_agent import GeminiUnavailable
from database import load_products

BASE = Path(__file__).parent
FRONTEND = BASE / "frontend"

# Fixed project exchange rate (not a market rate). Override with EXCHANGE_RATE_LBP in .env.
EXCHANGE_RATE = Decimal(str(json.loads((BASE / "products.json").read_text(encoding="utf-8"))["currency"]["sample_exchange_rate_lbp_per_usd"]))
DEFAULT_VAT = Decimal("0")

SESSION_COOKIE, CSRF_COOKIE, CSRF_HEADER = "if_session", "if_csrf", "X-CSRF-Token"
REMEMBER_SECONDS, SESSION_SECONDS = 30 * 24 * 3600, 12 * 3600

USERNAME_RE = re.compile(r"^[a-z](?!.*[_.]{2})[a-z0-9_.]{1,28}[a-z0-9]$")
NAME_RE = re.compile(r"^[^\W\d_]+(?:[ '\-.][^\W\d_]+)*\.?$", re.UNICODE)
LB_PHONE_RE = re.compile(r"^\+961(3\d{6}|(70|71|76|78|79|81)\d{6}|[14-9]\d{6})$")
E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")

OWNER_PERMS = ["ai.chat", "invoice.create", "invoice.edit", "invoice.submit", "invoice.history", "account.edit",
               "invoice.history.all", "invoice.approve", "invoice.reject", "invoice.send", "company.manage"]
EMPLOYEE_PERMS = OWNER_PERMS[:6]
CSRF_EXEMPT = {"/api/auth/login", "/api/auth/register", "/api/auth/password/forgot", "/api/auth/password/reset"}

_failures = {}  # simple in-memory login limiter: key -> (count, reset_at)


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS companies(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
  logo BLOB, logo_type TEXT, logo_ver TEXT, vat_rate TEXT NOT NULL DEFAULT '0', created_at REAL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  first_name TEXT NOT NULL, last_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'employee',
  is_active INTEGER NOT NULL DEFAULT 1, created_at REAL);
CREATE TABLE IF NOT EXISTS web_sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires REAL NOT NULL, remember INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS reset_codes(
  user_id INTEGER PRIMARY KEY, code_hash TEXT NOT NULL, expires REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS web_invoices(
  id TEXT PRIMARY KEY, company_id INTEGER NOT NULL, seq INTEGER NOT NULL, no TEXT NOT NULL,
  created_by INTEGER NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL,
  created_at REAL NOT NULL, updated_at REAL NOT NULL, approved_by INTEGER, approved_at REAL,
  UNIQUE(company_id, seq));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, invoice_id TEXT, employee TEXT, action TEXT, at REAL);
"""


def db_path():
    return current_app.config["INVOICE_DB"]


@contextmanager
def connect(path=None):
    db = sqlite3.connect(path or db_path(), timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA)
    try:
        with db:
            yield db
    finally:
        db.close()


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


# ---------------------------------------------------------------- helpers
def err(status, message, fields=None, code=None):
    detail = message if not (fields or code) else {"message": message, "fields": fields or {}, "code": code or ""}
    return jsonify(detail=detail), status


def err_response(status, message, code=None):
    response, _ = err(status, message, code=code)
    response.status_code = status
    return response


def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def text(value, limit):
    return value.strip()[:limit] if isinstance(value, str) else ""


def money(value):
    return float(value)


def q2(value):
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def valid_phone(phone):
    return isinstance(phone, str) and (LB_PHONE_RE.match(phone) if phone.startswith("+961") else E164_RE.match(phone))


def check_password_rules(password, username=""):
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        return "Password must be 8-128 characters."
    if not (re.search(r"[A-Z]", password) and re.search(r"[a-z]", password) and re.search(r"\d", password)):
        return "Password needs an uppercase letter, a lowercase letter and a number."
    if username and len(username) >= 3 and username.lower() in password.lower():
        return "Password must not contain the username."
    return ""


def user_json(row, company):
    role = "owner" if row["role"] == "owner" else "employee"
    return {"user": {
        "id": row["id"], "first_name": row["first_name"], "last_name": row["last_name"],
        "username": row["username"], "phone": row["phone"], "role": role,
        "permissions": OWNER_PERMS if role == "owner" else EMPLOYEE_PERMS,
        "company": {"id": company["id"], "name": company["name"]}}}


def company_json(c):
    return {"id": c["id"], "name": c["name"], "phone": c["phone"],
            "logo_url": "/media/logo/%d?v=%s" % (c["id"], c["logo_ver"]) if c["logo"] else "",
            "vat_rate": money(Decimal(c["vat_rate"])), "exchange_rate": int(EXCHANGE_RATE)}


def limited(key):
    count, reset = _failures.get(key, (0, 0))
    return reset > time.time() and count >= 5


def fail(key):
    count, reset = _failures.get(key, (0, 0))
    now = time.time()
    _failures[key] = (count + 1, reset) if reset > now else (1, now + 300)


# ---------------------------------------------------------------- sessions
def session_user():
    """The signed-in web user (sqlite Row joined with company) or None."""
    if "web_user" in g:
        return g.web_user
    g.web_user = None
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as db:
            row = db.execute(
                "SELECT u.*, s.expires, s.remember FROM web_sessions s JOIN users u ON u.id=s.user_id "
                "WHERE s.token_hash=? AND s.expires>? AND u.is_active=1", (sha(token), time.time())).fetchone()
        g.web_user = row
    return g.web_user


def company_of(db, user):
    return db.execute("SELECT * FROM companies WHERE id=?", (user["company_id"],)).fetchone()


def start_session(response, user_id, remember):
    token = secrets.token_urlsafe(32)
    age = REMEMBER_SECONDS if remember else SESSION_SECONDS
    with connect() as db:
        db.execute("DELETE FROM web_sessions WHERE expires<?", (time.time(),))
        db.execute("INSERT INTO web_sessions VALUES (?,?,?,?)", (sha(token), user_id, time.time() + age, int(bool(remember))))
    secure = request.is_secure
    max_age = age if remember else None
    response.set_cookie(SESSION_COOKIE, token, max_age=max_age, httponly=True, secure=secure, samesite="Lax", path="/")
    response.set_cookie(CSRF_COOKIE, secrets.token_urlsafe(24), max_age=max_age, httponly=False, secure=secure, samesite="Lax", path="/")
    return response


def clear_session(response):
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")
    return response


def web_login(username, password, remember):
    """Called by the shared /api/auth/login route. Returns a response, or None if the
    username is not a web account (then the older employee-token login is tried)."""
    uname = username.strip().lower()
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE username=?", (uname,)).fetchone()
        if not row:
            return None
        key = "web:" + uname
        if limited(key) or limited("ip:" + (request.remote_addr or "")):
            return err(429, "Too many attempts. Please wait 5 minutes and try again.")
        if not check_password_hash(row["password_hash"], password):
            fail(key); fail("ip:" + (request.remote_addr or ""))
            return err(401, "Incorrect username or password.")
        if not row["is_active"]:
            return err(403, "This account has been disabled. Please contact your garage owner.", code="account_disabled")
        _failures.pop(key, None)
        company = company_of(db, row)
    return start_session(jsonify(user_json(row, company)), row["id"], remember)


def web_logout():
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as db:
            db.execute("DELETE FROM web_sessions WHERE token_hash=?", (sha(token),))
    return clear_session(Response(status=204))


def require_user(perm=None):
    user = session_user()
    if not user:
        abort(err_response(401, "Please sign in again."))
    perms = OWNER_PERMS if user["role"] == "owner" else EMPLOYEE_PERMS
    if perm and perm not in perms:
        abort(err_response(403, "Your account is not allowed to do this. Ask the garage owner if you need access."))
    return user


# ---------------------------------------------------------------- invoices
def compute(payload, vat_rate):
    items, sub = [], Decimal("0")
    incomplete = False
    if not isinstance(payload.get("items", []), list): raise ValueError("Items must be a list")
    for raw in payload.get("items", [])[:100]:
        try:
            qty = None if raw.get("q") in (None, "") else Decimal(str(raw["q"]))
            price = None if raw.get("p") in (None, "") else Decimal(str(raw["p"]))
        except (InvalidOperation, AttributeError):
            raise ValueError("Each item needs a numeric quantity and price.")
        if any(v is not None and (not v.is_finite() or v < 0 or v > limit) for v, limit in ((qty, 10000), (price, 10000000))):
            raise ValueError("Quantities and prices must be positive numbers.")
        line = None if qty is None or price is None else q2(qty * price)
        if line is None:
            incomplete = True
        else:
            sub += qty * price
        items.append({"d": text(raw.get("d"), 200), "t": text(raw.get("t"), 40) or "Service",
                      "q": money(qty) if qty is not None else None,
                      "p": money(price) if price is not None else None,
                      "total_usd": money(line) if line is not None else None})
    if incomplete:
        return items, {"subtotal_usd": None, "vat_rate": money(vat_rate), "vat_usd": None,
                       "total_usd": None, "total_lbp": None, "exchange_rate": int(EXCHANGE_RATE), "incomplete": True}
    raw_sub = sub
    sub = q2(sub)
    vat = q2(sub * vat_rate / 100)
    total = sub + vat
    lbp = ((raw_sub + vat) * EXCHANGE_RATE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return items, {"subtotal_usd": money(sub), "vat_rate": money(vat_rate), "vat_usd": money(vat),
                   "total_usd": money(total), "total_lbp": int(lbp), "exchange_rate": int(EXCHANGE_RATE), "incomplete": False}


def clean_payload(data, company):
    cust = data.get("cust") if isinstance(data.get("cust"), dict) else {}
    truck = data.get("truck") if isinstance(data.get("truck"), dict) else {}
    out = {
        "cust": {k: text(cust.get(k), 200) for k in ("name", "contact", "tel", "email")},
        "truck": {k: text(truck.get(k), 100) for k in ("plate", "model")},
        "notes": text(data.get("notes"), 2000),
        "warnings": [text(w, 500) for w in data.get("warnings", [])[:30] if isinstance(w, str)] if isinstance(data.get("warnings"), list) else [],
        "items": data.get("items") if isinstance(data.get("items"), list) else [],
    }
    if out["cust"]["email"] and not EMAIL_RE.match(out["cust"]["email"]):
        raise ValueError("Customer email address is not valid.")
    out["items"], out["totals"] = compute(out, Decimal(company["vat_rate"]))
    out["company"] = company_json(company)
    out["company"].pop("id", None)
    return out


def invoice_out(row):
    data = json.loads(row["payload"])
    data.update(id=row["id"], no=row["no"], status=row["status"], review_digest=sha(row["payload"]),
                date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(row["created_at"])))
    return data


def find_invoice(db, user, ident):
    row = db.execute("SELECT * FROM web_invoices WHERE id=? AND company_id=?", (ident, user["company_id"])).fetchone()
    if row and user["role"] != "owner" and row["created_by"] != user["id"]:
        return None
    return row


def is_web_invoice(ident):
    with connect() as db:
        return db.execute("SELECT 1 FROM web_invoices WHERE id=?", (ident,)).fetchone() is not None


def web_get_invoice(ident):
    user = require_user("invoice.history")
    with connect() as db:
        row = find_invoice(db, user, ident)
    return jsonify(invoice_out(row)) if row else err(404, "Invoice not found.")


def move(ident, allowed_from, to, perm, who_ok=None):
    user = require_user(perm)
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        row = find_invoice(db, user, ident)
        if not row:
            return err(404, "Invoice not found.")
        if row["status"] not in allowed_from:
            return err(409, "This invoice is %s and cannot be changed that way." % row["status"])
        payload = json.loads(row["payload"])
        if to in ("pending", "approved") and (payload.get("totals", {}).get("incomplete") or
                any(i.get("p") is None or i.get("q") is None for i in payload.get("items", []))):
            return err(409, "Fill in all missing quantities and prices before submitting or approving.")
        now = time.time()
        if to == "approved":
            approval = body()
            if approval.get("confirm") is not True or approval.get("review_digest") != sha(row["payload"]):
                return err(409, "Review the saved invoice and explicitly confirm approval.")
            if json.loads(row["payload"]).get("warnings") and approval.get("acknowledge_warnings") is not True:
                return err(409, "Acknowledge the invoice warnings before approval.")
            db.execute("UPDATE web_invoices SET status=?, updated_at=?, approved_by=?, approved_at=? WHERE id=?",
                       (to, now, user["id"], now, ident))
        else:
            db.execute("UPDATE web_invoices SET status=?, updated_at=? WHERE id=?", (to, now, ident))
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)", (ident, user["username"], to, now))
        row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
    return jsonify(invoice_out(row))


def web_approve_invoice(ident):
    return move(ident, ("pending",), "approved", "invoice.approve")


# ---------------------------------------------------------------- AI draft
def ai_draft(message, company):
    from invoice_engine import create_invoice  # the teammate's Gemini pipeline
    result = create_invoice(message)
    items = [{"d": it["name"], "t": "Part", "q": it["quantity"],
              "p": float(it["price_usd"]) if it["price_usd"] is not None else None} for it in result["items"]]
    warnings = list(result.get("warnings", []))
    # Never offer a partial invoice after dropping an unresolved repair item.
    questions = []
    for warning in warnings:
        if warning.startswith("Unknown product: "):
            name = warning.split(": ", 1)[1]
            questions.append(f'I could not match "{name}" to the catalog. What is its catalog name?')
        elif warning.startswith("Ambiguous product: "):
            from database import search_products
            name = warning.split(": ", 1)[1]
            options = ", ".join(p['name_en'] for p in search_products(name))
            questions.append(f'Which "{name}" do you mean: {options}?')
        elif warning.startswith("Invalid quantity: "):
            name = warning.split(": ", 1)[1]
            questions.append(f'How many "{name}" were used? Please give the quantity.')
    if questions:
        return {"question": " ".join(questions)}
    labor = Decimal(str(result["labor_amount"])) if result.get("labor_amount") is not None else None
    cur = result.get("labor_currency")
    if labor is not None and cur in ("USD", "LBP"):
        usd = labor if cur == "USD" else labor / EXCHANGE_RATE
        items.append({"d": "Labor" + (" (%s LBP)" % format(int(labor), ",") if cur == "LBP" else ""), "t": "Service", "q": 1, "p": float(usd)})
    if not items:
        unknown = [w.split(": ", 1)[1] for w in warnings if w.startswith(("Unknown product", "Ambiguous product"))]
        q = ("I couldn't match %s to the garage catalog. " % ", ".join('"%s"' % u for u in unknown)) if unknown else ""
        return {"question": q + "Which parts were replaced (and how many), and what was the labour cost?"}
    if labor is None or cur not in ("USD", "LBP"):
        items.append({"d": "Labor", "t": "Service", "q": 1, "p": None})
    draft = {"status": "draft", "cust": {"name": result.get("customer", ""), "contact": "", "tel": "", "email": ""},
             "truck": {"plate": result.get("truck_plate", "") or "", "model": result.get("truck_model", "") or ""},
             "notes": result.get("notes", ""), "items": items}
    payload = clean_payload(draft, company)
    payload.update(status="draft", date=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   warnings=[friendly(w) for w in warnings])
    return payload


def friendly(w):
    return {"Customer name is missing": "Customer name wasn't mentioned - add it before submitting.",
            "Labor amount is missing": "No labour cost was mentioned.",
            "Labor currency is unclear": "Labour currency wasn't clear (USD or LBP?), so its price is blank."}.get(w, w)


# ---------------------------------------------------------------- routes
def register_web(app):
    app.config.setdefault("INVOICE_DB", str(BASE / "garage.db"))

    @app.before_request
    def csrf_guard():
        if not request.path.startswith("/api/") or request.method in ("GET", "HEAD", "OPTIONS"):
            return None
        if request.path in CSRF_EXEMPT or not request.cookies.get(SESSION_COOKIE):
            return None
        sent, expected = request.headers.get(CSRF_HEADER, ""), request.cookies.get(CSRF_COOKIE, "")
        if not expected or not secrets.compare_digest(sent, expected):
            return err(403, "Security check failed. Refresh the page and try again.", code="csrf")
        return None

    # ---- accounts
    @app.post("/api/auth/register")
    def register():
        d = body()
        f = {k: text(d.get(k), 130) for k in ("first_name", "last_name", "username", "phone", "company_name")}
        f["username"] = f["username"].lower()
        password = d.get("password") if isinstance(d.get("password"), str) else ""
        errors = {}
        for k in ("first_name", "last_name"):
            if not f[k] or len(f[k]) > 50 or not NAME_RE.match(f[k]):
                errors[k] = "Use letters only (1-50 characters)."
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "3-30 characters: letters, numbers, '_' or '.'; start with a letter."
        msg = check_password_rules(password, f["username"])
        if msg:
            errors["password"] = msg
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        company_name = re.sub(r"\s+", " ", f["company_name"])
        if not 2 <= len(company_name) <= 120:
            errors["company_name"] = "Company name must be 2-120 characters."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        if limited("reg:" + (request.remote_addr or "")):
            return err(429, "Too many attempts. Please wait a few minutes.")
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to an existing terminal account. Choose a different web username.")
        try:
            with connect() as db:
                now = time.time()
                cid = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                 (company_name, f["phone"], str(DEFAULT_VAT), now)).lastrowid
                # The person who registers a new company is its owner. Nobody can join an existing company this way.
                uid = db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                                 "VALUES (?,?,?,?,?,?,?,?)", (cid, f["first_name"], f["last_name"], f["username"],
                                                              generate_password_hash(password), f["phone"], "owner", now)).lastrowid
                row = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
                company = company_of(db, row)
        except sqlite3.IntegrityError:
            fail("reg:" + (request.remote_addr or ""))
            return err(409, "Username is already taken.")
        resp = jsonify(user_json(row, company))
        resp.status_code = 201
        return start_session(resp, uid, True)

    @app.get("/api/auth/check-username")
    def check_username():
        name = text(request.args.get("username"), 40).lower()
        if not USERNAME_RE.match(name):
            return jsonify(available=False, suggestions=[], message="Invalid username format.")
        with connect() as db:
            taken = lambda n: db.execute("SELECT 1 FROM users WHERE username=?", (n,)).fetchone() is not None
            if not taken(name):
                return jsonify(available=True, suggestions=[])
            base = re.sub(r"[^a-z0-9]", "", name)[:20] or "user"
            cands = [base + "_garage", base + time.strftime("%Y"), base + "_trucks", base + "_auto", "%s.%d" % (base, secrets.randbelow(90) + 10)]
            free = [c for c in cands if USERNAME_RE.match(c) and not taken(c)][:3]
        return jsonify(available=False, suggestions=free)

    @app.get("/api/auth/me")
    def me():
        user = require_user()
        with connect() as db:
            return jsonify(user_json(user, company_of(db, user)))

    @app.put("/api/auth/me")
    def update_me():
        user = require_user("account.edit")
        d = body()
        f = {k: text(d.get(k), 60) for k in ("first_name", "last_name", "username", "phone")}
        f["username"] = f["username"].lower()
        errors = {k: "Use letters only." for k in ("first_name", "last_name") if not f[k] or not NAME_RE.match(f[k])}
        if not USERNAME_RE.match(f["username"]):
            errors["username"] = "Invalid username."
        if not valid_phone(f["phone"]):
            errors["phone"] = "Enter a valid phone number."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        from approval_store import connect as legacy_connect
        with legacy_connect(db_path()) as legacy:
            if legacy.execute("SELECT 1 FROM employees WHERE lower(username)=?", (f["username"],)).fetchone():
                return err(409, "This username belongs to a terminal employee account. Choose a different website username.")
        try:
            with connect() as db:
                db.execute("UPDATE users SET first_name=?, last_name=?, username=?, phone=? WHERE id=?",
                           (f["first_name"], f["last_name"], f["username"], f["phone"], user["id"]))
                row = db.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
                return jsonify(user_json(row, company_of(db, row)))
        except sqlite3.IntegrityError:
            return err(409, "Username is already taken.")

    @app.post("/api/auth/password/change")
    def change_password():
        user = require_user("account.edit")
        d = body()
        if not check_password_hash(user["password_hash"], str(d.get("current_password", ""))):
            return err(400, "Current password is incorrect.", {"current_password": "Current password is incorrect."})
        msg = check_password_rules(d.get("new_password"), user["username"])
        if msg:
            return err(422, msg, {"new_password": msg})
        token = request.cookies.get(SESSION_COOKIE, "")
        with connect() as db:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(d["new_password"]), user["id"]))
            db.execute("DELETE FROM web_sessions WHERE user_id=? AND token_hash<>?", (user["id"], sha(token)))
        return Response(status=204)

    @app.post("/api/auth/password/forgot")
    def forgot():
        return err(501, "SMS password recovery is not configured. Contact the laptop administrator.")

    @app.post("/api/auth/password/reset")
    def reset():
        d = body()
        name = text(d.get("username"), 40).lower()
        code = text(d.get("code"), 10)
        with connect() as db:
            row = db.execute("SELECT u.*, r.code_hash, r.expires AS r_exp, r.attempts FROM users u JOIN reset_codes r ON r.user_id=u.id "
                             "WHERE u.username=?", (name,)).fetchone()
            if not row or row["r_exp"] < time.time() or row["attempts"] >= 5:
                return err(400, "This code is wrong or has expired.")
            if not secrets.compare_digest(row["code_hash"], sha(code)):
                db.execute("UPDATE reset_codes SET attempts=attempts+1 WHERE user_id=?", (row["id"],))
                return err(400, "This code is wrong or has expired.")
            msg = check_password_rules(d.get("password"), name)
            if msg:
                return err(422, msg, {"password": msg})
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(d["password"]), row["id"]))
            db.execute("DELETE FROM reset_codes WHERE user_id=?", (row["id"],))
            db.execute("DELETE FROM web_sessions WHERE user_id=?", (row["id"],))
        return jsonify(message="Password updated.")

    # ---- company
    @app.get("/api/company")
    def get_company():
        user = require_user()
        with connect() as db:
            return jsonify(company_json(company_of(db, user)))

    @app.put("/api/company")
    def put_company():
        user = require_user("company.manage")
        name = re.sub(r"\s+", " ", text(request.form.get("name"), 130))
        phone = text(request.form.get("phone"), 20)
        errors = {}
        if not 2 <= len(name) <= 120:
            errors["name"] = "Company name must be 2-120 characters."
        if not valid_phone(phone):
            errors["phone"] = "Enter a valid phone number."
        logo = request.files.get("logo")
        data = ctype = None
        if logo:
            data = logo.read(2 * 1024 * 1024 + 1)
            if len(data) > 2 * 1024 * 1024:
                errors["logo"] = "The logo must be 2 MB or smaller."
            elif data[:8] == b"\x89PNG\r\n\x1a\n":
                ctype = "image/png"
            elif data[:3] == b"\xff\xd8\xff":
                ctype = "image/jpeg"
            elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
                ctype = "image/webp"
            else:
                errors["logo"] = "Please upload a PNG, JPG or WebP image."
        if errors:
            return err(422, "Please check the highlighted fields.", errors)
        with connect() as db:
            db.execute("UPDATE companies SET name=?, phone=? WHERE id=?", (name, phone, user["company_id"]))
            if data:
                db.execute("UPDATE companies SET logo=?, logo_type=?, logo_ver=? WHERE id=?",
                           (data, ctype, secrets.token_hex(4), user["company_id"]))
            elif request.form.get("remove_logo") == "1":
                db.execute("UPDATE companies SET logo=NULL, logo_type=NULL, logo_ver=NULL WHERE id=?", (user["company_id"],))
            return jsonify(company_json(company_of(db, user)))

    @app.get("/media/logo/<int:cid>")
    def logo(cid):
        user = require_user()
        if user["company_id"] != cid:
            return err(404, "Not found.")
        with connect() as db:
            c = db.execute("SELECT logo, logo_type FROM companies WHERE id=?", (cid,)).fetchone()
        if not c or not c["logo"]:
            return err(404, "No logo.")
        resp = Response(c["logo"], mimetype=c["logo_type"])
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "private, max-age=86400"
        return resp

    # ---- catalog & customers
    @app.get("/api/catalog")
    def catalog():
        require_user()
        return jsonify([[p["name_en"], "Part", p["price_usd"]] for p in load_products()])

    @app.get("/api/customers")
    def customers():
        user = require_user("invoice.history")
        out, seen = [], set()
        for inv in _list(user):
            c = inv.get("cust", {})
            if c.get("name") and c["name"].lower() not in seen:
                seen.add(c["name"].lower())
                out.append(c)
        return jsonify(out)

    def _list(user):
        sql, args = "SELECT * FROM web_invoices WHERE company_id=?", [user["company_id"]]
        if user["role"] != "owner":
            sql += " AND created_by=?"
            args.append(user["id"])
        with connect() as db:
            return [invoice_out(r) for r in db.execute(sql + " ORDER BY seq", args).fetchall()]

    # ---- invoices
    @app.get("/api/invoices")
    def list_invoices():
        return jsonify(_list(require_user("invoice.history")))

    @app.post("/api/invoices/generate")
    def generate():
        user = require_user("ai.chat")
        d = body()
        history = d.get("history") if isinstance(d.get("history"), list) else []
        parts = [h.get("text", "") for h in history if isinstance(h, dict) and h.get("role") == "user" and isinstance(h.get("text"), str)]
        message = "\n".join(p.strip() for p in parts if p.strip()) or text(d.get("text"), 5000)
        if not message:
            return err(400, "Describe the repair first.")
        if len(message) > 5000:
            return err(400, "That description is too long. Please keep it under 5000 characters.")
        try:
            with connect() as db:
                company = company_of(db, user)
            return jsonify(ai_draft(message, company))
        except GeminiUnavailable:
            return err(503, "The AI service is busy right now. Please try again in a moment.")
        except Exception:
            current_app.logger.error("AI invoice generation failed")
            return err(500, "The AI couldn't prepare this invoice. Please try again or rephrase the repair.")

    @app.post("/api/invoices")
    def create():
        user = require_user("invoice.create")
        try:
            with connect() as db:
                company = company_of(db, user)
                payload = clean_payload(body(), company)
                db.execute("BEGIN IMMEDIATE")
                seq = db.execute("SELECT COALESCE(MAX(seq),0)+1 FROM web_invoices WHERE company_id=?", (user["company_id"],)).fetchone()[0]
                ident, now = uuid.uuid4().hex, time.time()
                db.execute("INSERT INTO web_invoices(id, company_id, seq, no, created_by, status, payload, created_at, updated_at) "
                           "VALUES (?,?,?,?,?,?,?,?,?)", (ident, user["company_id"], seq, "INV-%04d" % seq, user["id"], "draft",
                                                          json.dumps(payload, ensure_ascii=False), now, now))
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row)), 201

    @app.put("/api/invoices/<ident>")
    def update(ident):
        user = require_user("invoice.edit")
        try:
            with connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row = find_invoice(db, user, ident)
                if not row:
                    return err(404, "Invoice not found.")
                if row["status"] not in ("draft", "rejected"):
                    return err(409, "Only draft or rejected invoices can be edited.")
                payload = clean_payload(body(), company_of(db, user))
                db.execute("UPDATE web_invoices SET payload=?, status='draft', updated_at=? WHERE id=?",
                           (json.dumps(payload, ensure_ascii=False), time.time(), ident))
                row = db.execute("SELECT * FROM web_invoices WHERE id=?", (ident,)).fetchone()
        except ValueError as e:
            return err(422, str(e))
        return jsonify(invoice_out(row))

    @app.post("/api/invoices/<ident>/submit")
    def submit(ident):
        return move(ident, ("draft", "rejected"), "pending", "invoice.submit")

    @app.post("/api/invoices/<ident>/reject")
    def reject(ident):
        return move(ident, ("pending",), "rejected", "invoice.reject")

    @app.post("/api/invoices/<ident>/email")
    def email(ident):
        user = require_user("invoice.send")
        with connect() as db:
            row = find_invoice(db, user, ident)
        if not row:
            return err(404, "Invoice not found.")
        if row["status"] != "approved":
            return err(409, "Only approved invoices can be sent.")
        return err(501, "Email sending isn't set up on the server yet. Download the approved PDF and send it yourself.")

    # ---- frontend pages (same origin as the API)
    @app.get("/")
    def home():
        return redirect("/signin.html")

    @app.get("/<path:filename>")
    def frontend(filename):
        if filename.startswith(("api/", "media/")):
            return err(404, "Not found.")
        target = (FRONTEND / filename).resolve()
        if FRONTEND.resolve() not in target.parents or not target.is_file() or target.suffix == ".md":
            abort(404)
        resp = send_from_directory(FRONTEND, filename)
        resp.headers["Cache-Control"] = "no-cache"
        return resp


def create_user(username, password, first, last, company_name, phone="+96171123456", role="owner", company_id=None, path=None):
    """Helper for scripts: create a web account (and a company if company_id is None)."""
    with connect(path) as db:
        now = time.time()
        if company_id is None:
            company_id = db.execute("INSERT INTO companies(name, phone, vat_rate, created_at) VALUES (?,?,?,?)",
                                    (company_name, phone, str(DEFAULT_VAT), now)).lastrowid
        db.execute("INSERT INTO users(company_id, first_name, last_name, username, password_hash, phone, role, created_at) "
                   "VALUES (?,?,?,?,?,?,?,?)", (company_id, first, last, username.lower(), generate_password_hash(password), phone, role, now))
        return company_id


def web_pdf(ident):
    user = require_user("invoice.history")
    with connect() as db:
        row = find_invoice(db, user, ident)
        if not row: return err(404, "Invoice not found.")
        if row["status"] != "approved": return err(409, "Approve this invoice before downloading its final PDF.")
        payload = json.loads(row["payload"])
        approver = db.execute("SELECT username FROM users WHERE id=?", (row["approved_by"],)).fetchone()
        rate = Decimal(str(payload["totals"]["exchange_rate"]))
        invoice = {
            "invoice_id": row["no"], "customer": payload["cust"]["name"],
            "items": [{"name": i["d"], "quantity": i["q"], "price_usd": str(i["p"]),
                       "total_usd": str(i["total_usd"]), "total_lbp": str((Decimal(str(i["total_usd"]))*rate).quantize(Decimal("1")))} for i in payload["items"]],
            "labor_amount": "Included in item rows", "labor_currency": "USD",
            "subtotal_usd": format(Decimal(str(payload["totals"]["total_usd"])), ".2f"),
            "subtotal_lbp": str(payload["totals"]["total_lbp"]), "notes": payload.get("notes", ""),
            "warnings": payload.get("warnings", []), "approved": True,
            "approved_by": approver["username"] if approver else "Owner"}
        content = invoice_pdf(invoice)
        db.execute("INSERT INTO audit(invoice_id,employee,action,at) VALUES (?,?,?,?)",(ident,user["username"],"pdf_released",time.time()))
    return send_file(BytesIO(content),mimetype="application/pdf",as_attachment=True,download_name=row["no"]+".pdf")
