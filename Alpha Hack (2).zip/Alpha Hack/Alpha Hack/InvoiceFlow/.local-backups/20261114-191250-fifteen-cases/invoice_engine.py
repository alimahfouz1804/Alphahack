
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

from database import search_products
from ai_agent import understand_message

BASE = Path(__file__).parent


def create_invoice(message):
    # Step 1: Gemini understands the message
    order = understand_message(message)

    # Step 2: Read exchange rate from JSON
    with open(BASE / "products.json", encoding="utf-8") as file:
        settings = json.load(file)["currency"]

    rate = Decimal(str(
        settings["sample_exchange_rate_lbp_per_usd"]
    ))

    items = []
    warnings = []
    total_usd = Decimal("0")
    total_lbp = Decimal("0")
    incomplete = False

    # Step 3: Look up products in database
    for part in order["parts"]:
        matches = search_products(part["name"])
        quantity = part["quantity"]

        if type(quantity) is not int or quantity <= 0:
            warnings.append(
                f"Invalid quantity: {part['name']}"
            )
            continue

        if len(matches) == 0:
            warnings.append(
                f"Unknown product: {part['name']}"
            )
            continue

        if len(matches) > 1:
            warnings.append(
                f"Ambiguous product: {part['name']}"
            )
            continue

        product = matches[0]

        # The catalog identifies the product; prices must be explicitly supplied.
        price_usd = price_lbp = line_usd = line_lbp = None
        amount = part.get("unit_price")
        currency = part.get("price_currency")
        if amount is None:
            warnings.append(f"Unit price is missing: {product['name_en']}")
        else:
            try:
                amount = Decimal(str(amount))
                if not amount.is_finite() or amount < 0 or amount > 10000000:
                    raise ValueError("Invalid unit price")
                if currency not in ("USD", "LBP"):
                    warnings.append(f"Price currency is unclear: {product['name_en']}")
                else:
                    price_usd = amount if currency == "USD" else amount / rate
                    price_lbp = amount if currency == "LBP" else amount * rate
                    line_usd, line_lbp = price_usd * quantity, price_lbp * quantity
                    total_usd += line_usd
                    total_lbp += line_lbp
            except (ValueError, TypeError, InvalidOperation):
                warnings.append(f"Invalid unit price: {product['name_en']}")
        if price_usd is None:
            incomplete = True

        items.append({
            "id": product["id"],
            "name": product["name_en"],
            "quantity": quantity,
            "price_usd": str(price_usd) if price_usd is not None else None,
            "price_lbp": str(price_lbp) if price_lbp is not None else None,
            "total_usd": str(line_usd) if line_usd is not None else None,
            "total_lbp": str(line_lbp) if line_lbp is not None else None
        })

    # Step 4: Calculate labor
    labor = None
    labor_currency = order.get("labor_currency")

    if order.get("labor_amount") is not None:
        try:
            labor = Decimal(str(order["labor_amount"]))
            if not labor.is_finite() or labor < 0:
                raise ValueError("Invalid labor amount")
        except (ValueError, TypeError, InvalidOperation):
            warnings.append("Invalid labor amount")
            labor = None
            labor_currency = None

        if labor is not None and labor_currency == "USD":
            total_usd += labor
            total_lbp += labor * rate

        elif labor is not None and labor_currency == "LBP":
            total_lbp += labor
            total_usd += labor / rate

        else:
            warnings.append("Labor currency is unclear")

    if order.get("labor_amount") is None:
        warnings.append("Labor amount is missing")
    if labor is None or labor_currency not in ("USD", "LBP"):
        incomplete = True

    if not order.get("customer"):
        warnings.append("Customer name is missing")

    # Step 5: Return invoice draft
    return {
        "status": "needs_review",
        "customer": order.get("customer", ""),
        "items": items,
        "notes": order.get("notes", ""),
        "truck_plate": order.get("truck_plate", ""),
        "truck_model": order.get("truck_model", ""),
        "labor_amount": str(labor) if labor is not None else None,
        "labor_currency": labor_currency,
        "incomplete": incomplete,
        "subtotal_usd": None if incomplete else str(
            total_usd.quantize(Decimal("0.01"))
        ),
        "subtotal_lbp": None if incomplete else str(
            total_lbp.quantize(Decimal("1"))
        ),
        "warnings": warnings,
        "approved": False
    }


if __name__ == "__main__":
    message = (
        "غيرنا فلتر زيت عدد اتنين "
        "وفلتر مازوت واحد وأجرة إيد 30 دولار"
    )

    invoice = create_invoice(message)

    print(json.dumps(
        invoice,
        ensure_ascii=False,
        indent=2
    ))
