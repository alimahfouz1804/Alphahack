
import json
import re
from pathlib import Path

BASE = Path(__file__).parent

def load_products():
    with open(BASE / "products.json", "r", encoding="utf-8") as f:
        return json.load(f)["products"]

def normalized_name(value):
    value = value.strip().casefold().translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    # Packaging words do not change the product; preserve the size/variant.
    value = re.sub(r'^(?:عبوة|علبة|container|bottle|can)\s+(?:of\s+)?', '', value)
    value = re.sub(r'(\d)\s*(?:ليتر|لتر|litres?|liters?|l)\b', r'\1l', value)
    return ' '.join(value.split())


def search_products(query):
    query = normalized_name(query)

    if not query:
        return []

    results = []

    for product in load_products():
        names = [
            product["id"],
            product["name_en"],
            product["name_ar"],
            *product["aliases"]
        ]

        names = [normalized_name(name) for name in names]
        if any(query in name for name in names):
            results.append(product)

    return results

def get_product_by_id(product_id):
    for product in load_products():
        if product["id"] == product_id:
            return product
    return None

if __name__ == "__main__":
    for query in ["فلتر زيت", "oil filter", "زيت موتور"]:
        print(query, search_products(query))
