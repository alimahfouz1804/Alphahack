"""Additive SQLite storage for customer records, approved PDFs and delivery attempts.

Invoice payloads and numbering remain owned by web_api. Approved PDF bytes are stored
inside the same database transaction as approval, not in a publicly served folder.
"""
import hashlib
import json
import time
import uuid
from decimal import Decimal
from flask import jsonify, request
import delivery_providers as providers

SCHEMA = """
CREATE TABLE IF NOT EXISTS web_customers(
 id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, name TEXT NOT NULL,
 name_key TEXT NOT NULL, contact TEXT NOT NULL DEFAULT '', tel TEXT NOT NULL DEFAULT '',
 email TEXT NOT NULL DEFAULT '', updated_at REAL NOT NULL,
 UNIQUE(company_id,name_key,tel,email));
CREATE TABLE IF NOT EXISTS invoice_customers(
 invoice_id TEXT PRIMARY KEY REFERENCES web_invoices(id), customer_id INTEGER REFERENCES web_customers(id));
CREATE TABLE IF NOT EXISTS invoice_files(
 invoice_id TEXT PRIMARY KEY REFERENCES web_invoices(id), pdf BLOB NOT NULL,
 sha256 TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS invoice_create_requests(
 company_id INTEGER NOT NULL, user_id INTEGER NOT NULL, request_key TEXT NOT NULL,
 digest TEXT NOT NULL, invoice_id TEXT NOT NULL REFERENCES web_invoices(id),
 PRIMARY KEY(company_id,user_id,request_key));
CREATE TABLE IF NOT EXISTS delivery_attempts(
 id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES web_invoices(id),
 method TEXT NOT NULL, recipient TEXT NOT NULL, status TEXT NOT NULL,
 request_key TEXT NOT NULL, requested_by INTEGER NOT NULL, attempted_at REAL NOT NULL,
 finished_at REAL, provider_id TEXT, error TEXT, pdf_sha256 TEXT NOT NULL,
 UNIQUE(invoice_id,method,request_key));
CREATE INDEX IF NOT EXISTS delivery_invoice_idx ON delivery_attempts(invoice_id,attempted_at);
CREATE TABLE IF NOT EXISTS print_events(
 id INTEGER PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES web_invoices(id),
 user_id INTEGER NOT NULL, initiated_at REAL NOT NULL);
"""


def customer_out(row):
    return {k: row[k] for k in ('id', 'name', 'contact', 'tel', 'email')}


def save_customer(db, company_id, customer):
    """Only update an explicitly selected customer. Never merge unrelated namesakes."""
    name = customer.get('name', '').strip()
    if not name:
        return None
    key = ' '.join(name.casefold().split())
    fields = (name, key, customer.get('contact',''), customer.get('tel',''), customer.get('email',''), time.time())
    existing = db.execute('SELECT * FROM web_customers WHERE company_id=? AND name_key=? AND tel=? AND email=?',
                          (company_id, key, fields[3], fields[4])).fetchone()
    if existing:
        return existing['id']
    cid = customer.get('id')
    if cid:
        row = db.execute('SELECT id FROM web_customers WHERE company_id=? AND id=?', (company_id,cid)).fetchone()
        if not row:
            raise ValueError('Customer not found in this company.')
        db.execute('UPDATE web_customers SET name=?,name_key=?,contact=?,tel=?,email=?,updated_at=? WHERE id=?', fields+(cid,))
        return cid
    return db.execute('INSERT INTO web_customers(name,name_key,contact,tel,email,updated_at,company_id) VALUES (?,?,?,?,?,?,?)',
                      fields+(company_id,)).lastrowid


def render_pdf(db, row, approved_by=''):
    """The professional invoice layout (pdf_invoice.web_invoice_pdf). Pending rows get a PREVIEW stamp."""
    import web_api as web
    from pdf_invoice import web_invoice_pdf
    inv = web.invoice_out(row)
    company = db.execute('SELECT * FROM companies WHERE id=?', (row['company_id'],)).fetchone()
    if company:
        inv['company'] = web.company_json(company)
    y, m, d = (int(x) for x in web.local_day(row['created_at']).split('-'))
    inv['date_text'] = '%d %s %d' % (d, ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
                                         'September', 'October', 'November', 'December'][m - 1], y)
    if approved_by:
        u = db.execute('SELECT first_name, last_name FROM users WHERE username=?', (approved_by,)).fetchone()
        inv['approved_by'] = ('%s %s' % (u['first_name'], u['last_name'])).strip() if u else approved_by
    return web_invoice_pdf(inv, company['logo'] if company else None)


def store_approved_pdf(db, row, username):
    """Called only after validation inside the approval transaction. Lazy for old approvals."""
    existing = db.execute('SELECT pdf FROM invoice_files WHERE invoice_id=?', (row['id'],)).fetchone()
    if existing:
        return bytes(existing['pdf'])
    content = render_pdf(db, dict(row, status='approved'), username)
    db.execute('INSERT INTO invoice_files VALUES (?,?,?,?)',
               (row['id'], content, hashlib.sha256(content).hexdigest(), time.time()))
    return content


def attempt_out(row):
    result = dict(row)
    result['submission_status'] = result['status']
    result['delivery_confirmed'] = False  # no receipt webhook configured
    return result


def deliver(ident, method):
    import web_api as web
    user = web.require_user('invoice.send')
    data = web.body()
    if data.get('confirm') is not True:
        return web.err(409, 'Review the recipient and explicitly confirm sending.')
    key = data.get('request_key')
    if not isinstance(key,str) or not 8 <= len(key) <= 100:
        return web.err(422, 'A delivery request key is required.')
    with web.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row = web.find_invoice(db,user,ident)
        if not row: return web.err(404,'Invoice not found.')
        if row['status'] != 'approved': return web.err(409,'Only approved invoices can be sent.')
        payload = json.loads(row['payload'])
        recipient = web.text(data.get('to') or payload['cust'].get('email' if method=='email' else 'tel'),200)
        if not (web.EMAIL_RE.fullmatch(recipient) if method=='email' else web.valid_phone(recipient)):
            return web.err(422,'Enter a valid customer email.' if method=='email' else 'Enter the customer phone in international format, e.g. +961...')
        prior = db.execute('SELECT * FROM delivery_attempts WHERE invoice_id=? AND method=? AND request_key=?', (ident,method,key)).fetchone()
        if prior:
            if prior['recipient'] != recipient: return web.err(409,'That request key was used for a different recipient.')
            return jsonify(attempt_out(prior))
        # Recover interrupted synchronous attempts without pretending they were delivered.
        db.execute("UPDATE delivery_attempts SET status='failed',finished_at=?,error=? WHERE invoice_id=? AND method=? AND status='sending' AND attempted_at<?",
                   (time.time(),'Submission outcome unknown after interruption. Check the provider before retrying.',ident,method,time.time()-180))
        if db.execute("SELECT 1 FROM delivery_attempts WHERE invoice_id=? AND method=? AND status='sending'",(ident,method)).fetchone():
            return web.err(409,'A delivery is already in progress. Refresh its status.')
        sent = db.execute("SELECT 1 FROM delivery_attempts WHERE invoice_id=? AND method=? AND recipient=? AND status='sent'",(ident,method,recipient)).fetchone()
        if sent and data.get('resend') is not True:
            return web.err(409,'Already submitted to this recipient. Explicitly confirm a resend.')
        content = store_approved_pdf(db,row,user['username'])
        attempt = uuid.uuid4().hex
        db.execute('INSERT INTO delivery_attempts(id,invoice_id,method,recipient,status,request_key,requested_by,attempted_at,pdf_sha256) VALUES (?,?,?,?,?,?,?,?,?)',
                   (attempt,ident,method,recipient,'sending',key,user['id'],time.time(),hashlib.sha256(content).hexdigest()))
        invoice = web.invoice_out(row)
        # optional subject/message the employee reviewed in the email popup
        invoice['email_subject'] = web.text(data.get('subject'), 200)
        invoice['email_body'] = str(data.get('message') or '')[:6000]
    # Provider I/O is outside the DB lock. Never log credentials or message bodies.
    provider_id, error = None, None
    try:
        provider_id = (providers.send_email if method=='email' else providers.send_whatsapp)(recipient,content,invoice)
    except providers.DeliveryError as exc:
        error = str(exc)
    except Exception:
        error = 'Delivery outcome could not be confirmed. Check the provider before retrying.'
    with web.connect() as db:
        db.execute('UPDATE delivery_attempts SET status=?,finished_at=?,provider_id=?,error=? WHERE id=?',
                   ('failed' if error else 'sent',time.time(),provider_id,error,attempt))
        result = db.execute('SELECT * FROM delivery_attempts WHERE id=?',(attempt,)).fetchone()
    return jsonify(attempt_out(result))


def register(app):
    import web_api as web

    @app.get('/api/delivery/config')
    def delivery_config():
        web.require_user()
        return jsonify(providers.configuration())

    @app.post('/api/customers')
    def customer_save():
        user = web.require_user('invoice.create')
        try:
            with web.connect() as db:
                cleaned = web.clean_payload({'cust':web.body()},web.company_of(db,user))['cust']
                if not cleaned['name']: return web.err(422,'Customer name is required.')
                cid = save_customer(db,user['company_id'],cleaned)
                row = db.execute('SELECT * FROM web_customers WHERE id=?',(cid,)).fetchone()
                return jsonify(customer_out(row))
        except ValueError as exc:
            return web.err(422,str(exc))

    @app.post('/api/invoices/<ident>/whatsapp')
    def whatsapp(ident):
        return deliver(ident,'whatsapp')

    @app.get('/api/invoices/<ident>/activity')
    def activity(ident):
        user = web.require_user('invoice.history')
        with web.connect() as db:
            if not web.find_invoice(db,user,ident): return web.err(404,'Invoice not found.')
            attempts = db.execute('SELECT * FROM delivery_attempts WHERE invoice_id=? ORDER BY attempted_at DESC',(ident,)).fetchall()
            prints = db.execute('SELECT initiated_at FROM print_events WHERE invoice_id=? ORDER BY initiated_at DESC',(ident,)).fetchall()
        return jsonify(deliveries=[attempt_out(r) for r in attempts],prints=[dict(r) for r in prints])

    @app.post('/api/invoices/<ident>/print')
    def print_started(ident):
        user = web.require_user('invoice.history')
        with web.connect() as db:
            row = web.find_invoice(db,user,ident)
            if not row: return web.err(404,'Invoice not found.')
            if row['status']!='approved': return web.err(409,'Approve the invoice before printing.')
            db.execute('INSERT INTO print_events(invoice_id,user_id,initiated_at) VALUES (?,?,?)',(ident,user['id'],time.time()))
        return jsonify(status='initiated',physical_print_confirmed=False)
