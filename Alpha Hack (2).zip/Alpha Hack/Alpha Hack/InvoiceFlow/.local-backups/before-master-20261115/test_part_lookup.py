"""Grounding and invoice scope tests. Search responses below are fixtures, not live evidence."""
import copy
import json
import os
import tempfile
import unittest
from types import SimpleNamespace as N
from unittest.mock import patch
import part_lookup as lookup


def fixture_lookup(name, description=''):
    if 'coupling' in name.lower():
        data=lookup.result('supported')
        data.update(name_ar='وصلة',name_en='Coupling',sources=[{'title':'Test fixture supplier','url':'https://supplier.example.test/coupling'}])
        return data
    return lookup.result('unclear')


def search_response(url='https://example.test/parts/clamp',queries=True,cited=True):
    answer={'status':'supported','name_ar':'مشبك خرطوم','name_en':'Hose clamp','explanation_ar':'ترجمة وصفية مقترحة'}
    return N(text=json.dumps(answer,ensure_ascii=False),candidates=[N(grounding_metadata=N(
        web_search_queries=['truck hose clamp'] if queries else [],
        grounding_chunks=[N(web=N(uri=url,title='Fixture supplier'))],
        grounding_supports=[N(segment=N(text='Hose clamp is an automotive component'),grounding_chunk_indices=[0])] if cited else [],
        search_entry_point=N(rendered_content='<div>Google search suggestions</div>')))])


class LookupTests(unittest.TestCase):
    def test_supported_name_requires_search_and_identity_citation(self):
        data=lookup.parse_response(search_response());self.assertEqual(data['status'],'supported')
        self.assertEqual(data['name_ar'],'مشبك خرطوم');self.assertFalse(data['compatibility_verified'])
        self.assertEqual(lookup.parse_response(search_response(queries=False))['status'],'unclear')
        self.assertEqual(lookup.parse_response(search_response(cited=False))['status'],'unclear')
    def test_unsafe_or_uncited_links_are_never_sources(self):
        for url in ['javascript:alert(1)','http://localhost/x','https://127.0.0.1/x','https://user:pass@example.com/x']:
            self.assertEqual(lookup.parse_response(search_response(url))['status'],'unclear')
        response=search_response();response.candidates[0].grounding_metadata.grounding_supports[0].segment.text='unrelated item'
        self.assertEqual(lookup.parse_response(response)['status'],'unclear')
    def test_potatoes_rejected_without_provider(self):
        self.assertEqual(lookup.lookup_part('كيس بطاطا')['status'],'out_of_scope')
        self.assertEqual(lookup.lookup_part('bag of potatoes')['status'],'out_of_scope')
        self.assertFalse(lookup.obvious_non_part('brake hose clamp'))
    def test_unclear_slang_does_not_get_a_guessed_name(self):
        response=N(text='{"status":"unclear","question_ar":"شو بتعمل هالقطعة؟"}',candidates=[])
        data=lookup.parse_response(response);self.assertEqual(data['status'],'unclear');self.assertEqual(data['name_ar'],'');self.assertEqual(data['sources'],[])
    def test_backend_rejects_food_and_custom_confirmation_bypass(self):
        from app import app
        from test_web import SIGNUP
        import web_api
        old=app.config['INVOICE_DB']
        with tempfile.TemporaryDirectory() as temp:
            app.config['INVOICE_DB']=temp+'/test.db'
            try:
                c=app.test_client();c.post('/api/auth/register',json=SIGNUP);h={'X-CSRF-Token':c.get_cookie('if_csrf').value}
                food={'customer':'Demo','parts':[{'name':'كيس بطاطا','quantity':1,'unit_price':5,'price_currency':'USD'}]}
                with patch('invoice_engine.understand_message',return_value=food),patch('part_lookup.lookup_part') as search:
                    d=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
                    self.assertIn('blocked_items',d);self.assertNotIn('items',d);search.assert_not_called()
                self.assertEqual(c.post('/api/invoices',json={'cust':{'name':'Demo'},'items':[{'d':'bag of potatoes','q':1,'p':5}]},headers=h).status_code,422)
                unknown={'customer':'Demo','parts':[{'name':'لاتشو','quantity':2,'unit_price':8,'price_currency':'USD'}]}
                with patch('invoice_engine.understand_message',return_value=unknown),patch('part_lookup.lookup_part',return_value=lookup.result('unavailable')):
                    d=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
                self.assertFalse(d['suggestions'][0]['custom_allowed'])
                forged={'confirm':True,'confirmation_token':d['confirmation_token'],'selections':{'0':{'custom':True,'name':'Whatever','quantity':2,'unit_price':8,'currency':'USD'}}}
                self.assertEqual(c.post('/api/invoices/confirm-parts',json=forged,headers=h).status_code,422)
                with patch('invoice_engine.understand_message',return_value=unknown),patch('part_lookup.lookup_part',return_value=fixture_lookup('coupling')):
                    d=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
                forged['confirmation_token']=d['confirmation_token']
                self.assertEqual(c.post('/api/invoices/confirm-parts',json=forged,headers=h).status_code,422)
                forged['selections']['0']['name']='وصلة'
                r=c.post('/api/invoices/confirm-parts',json=forged,headers=h)
                self.assertEqual(r.json['totals']['total_usd'],16)
                self.assertTrue(r.json['items'][0]['is_custom']);self.assertEqual(r.json['items'][0]['d'],'وصلة')
            finally:app.config['INVOICE_DB']=old

if __name__=='__main__':unittest.main()
