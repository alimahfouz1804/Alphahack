"""Tests for web_api.py (the frontend's API). No live Gemini calls: the AI is mocked."""
import os
os.environ.setdefault('GEMINI_API_KEY', 'test-only')
import tempfile
import unittest
from unittest.mock import patch

from app import app
import web_api

ORDER = dict(customer='Ali', parts=[dict(name='oil filter', quantity=2, unit_price=25, price_currency='USD'), dict(name='fuel filter', quantity=1, unit_price=30, price_currency='USD')],
             labor_amount=30, labor_currency='USD', notes='', truck_plate='452187', truck_model='Volvo FH')
SIGNUP = dict(first_name='Karim', last_name='Haddad', username='karim_garage', password='Garage2026',
              phone='+96171123456', company_name='Cedar Truck Garage')


class WebTests(unittest.TestCase):
    def setUp(self):
        from test_part_lookup import fixture_lookup
        lookup_mock=patch('part_lookup.lookup_part',side_effect=fixture_lookup);lookup_mock.start();self.addCleanup(lookup_mock.stop)
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.temp.name + '/test.db'
        web_api._failures.clear()

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old_db
        self.temp.cleanup()

    def client(self, signup=None):
        c = app.test_client()
        r = c.post('/api/auth/register', json=signup or SIGNUP)
        self.assertEqual(r.status_code, 201, r.json)
        return c

    def csrf(self, c):
        cookie = c.get_cookie('if_csrf')
        return {'X-CSRF-Token': cookie.value}

    def test_frontend_is_served(self):
        c = app.test_client()
        self.assertEqual(c.get('/').status_code, 302)
        r = c.get('/signin.html')
        self.assertEqual(r.status_code, 200)
        self.assertIn(b'InvoiceFlow', r.data)
        r.close()
        self.assertEqual(c.get('/../app.py').status_code, 404)
        self.assertEqual(c.get('/AUTH_BACKEND.md').status_code, 404)

    def test_register_login_me_logout(self):
        c = self.client()
        me = c.get('/api/auth/me').json['user']
        self.assertEqual(me['username'], 'karim_garage')
        self.assertEqual(me['role'], 'owner')
        self.assertEqual(me['company']['name'], 'Cedar Truck Garage')
        self.assertEqual(c.post('/api/auth/logout', headers=self.csrf(c)).status_code, 204)
        self.assertEqual(c.get('/api/auth/me').status_code, 401)
        bad = c.post('/api/auth/login', json={'username': 'karim_garage', 'password': 'nope'})
        self.assertEqual(bad.status_code, 401)
        ok = c.post('/api/auth/login', json={'username': 'Karim_Garage', 'password': 'Garage2026', 'remember_me': True})
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(c.get('/api/auth/me').status_code, 200)

    def test_duplicate_username_and_suggestions(self):
        self.client()
        r = app.test_client().post('/api/auth/register', json=dict(SIGNUP, company_name='Other'))
        self.assertEqual(r.status_code, 409)
        chk = app.test_client().get('/api/auth/check-username?username=karim_garage').json
        self.assertFalse(chk['available'])
        self.assertTrue(chk['suggestions'])
        self.assertTrue(app.test_client().get('/api/auth/check-username?username=newname').json['available'])

    def test_validation(self):
        bad = dict(SIGNUP, username='1x', password='short', phone='+9617012', company_name='')
        r = app.test_client().post('/api/auth/register', json=bad)
        self.assertEqual(r.status_code, 422)
        self.assertEqual(set(r.json['detail']['fields']), {'username', 'password', 'phone', 'company_name'})
        for phone in ('+9613123456', '+96171123456', '+9611234567'):
            self.assertTrue(web_api.valid_phone(phone), phone)

    def test_csrf_required(self):
        c = self.client()
        self.assertEqual(c.post('/api/invoices', json={'items': []}).status_code, 403)

    def test_ai_generate_save_submit_approve(self):
        c = self.client()
        h = self.csrf(c)
        with patch('invoice_engine.understand_message', return_value=ORDER):
            d = c.post('/api/invoices/generate', json={'text': 'x', 'history': [{'role': 'user', 'text': 'x'}]}, headers=h).json
        self.assertEqual(d['truck']['plate'], '452187')
        self.assertEqual([i['d'] for i in d['items']], ['Oil Filter', 'Fuel Filter', 'Labor'])
        self.assertEqual(d['totals']['subtotal_usd'], 110.0)
        self.assertEqual(d['totals']['vat_usd'], 0)
        self.assertEqual(d['totals']['total_usd'], 110.0)
        self.assertEqual(d['totals']['total_lbp'], 9845000)  # catalog rate: 89,500
        self.assertEqual(d['company']['name'], 'Cedar Truck Garage')
        saved = c.post('/api/invoices', json=d, headers=h)
        self.assertEqual(saved.status_code, 201)
        inv = saved.json
        self.assertEqual(inv['no'], 'INV-0001')
        self.assertEqual(c.post('/api/invoices/%s/submit' % inv['id'], json={}, headers=h).json['status'], 'pending')
        self.assertEqual(c.post('/api/invoices/%s/approve' % inv['id'], json={'confirm':True,'review_digest':inv['review_digest'],'acknowledge_warnings':True}, headers=h).json['status'], 'approved')
        self.assertEqual(c.get('/api/invoices/%s' % inv['id']).json['status'], 'approved')
        pdf=c.get('/api/invoices/%s/pdf' % inv['id'])
        self.assertEqual(pdf.status_code,200)
        self.assertTrue(pdf.data.startswith(b'%PDF'))
        self.assertEqual(c.put('/api/invoices/%s' % inv['id'], json=d, headers=h).status_code, 409)
        self.assertEqual(len(c.get('/api/invoices').json), 1)

    def test_pdf_approval_and_csrf_cannot_be_bypassed(self):
        c=self.client(); h=self.csrf(c)
        inv=c.post('/api/invoices',json={'items':[{'d':'Oil Filter','q':2,'p':25}]},headers=h).json
        self.assertEqual(c.get('/api/invoices/%s/pdf' % inv['id']).status_code,409)
        self.assertEqual(c.post('/api/invoices/%s/submit' % inv['id'],json={},headers={'Authorization':'Bearer fake'}).status_code,403)
        c.post('/api/invoices/%s/submit' % inv['id'],json={},headers=h)
        self.assertEqual(c.post('/api/invoices/%s/approve' % inv['id'],json={},headers=h).status_code,409)
        other=self.client(dict(SIGNUP,username='another_owner'))
        self.assertEqual(other.get('/api/invoices/%s/pdf' % inv['id']).status_code,404)

    def test_legacy_invoices_not_accessible_by_web_cookie(self):
        import approval_store
        inv=approval_store.save_draft({'items':[],'warnings':[]},app.config['INVOICE_DB'])
        c=self.client()
        for suffix in ['', '/pdf']:
            self.assertEqual(c.get('/api/invoices/'+inv['invoice_id']+suffix).status_code,401)
        self.assertEqual(c.post('/api/invoices/'+inv['invoice_id']+'/approve',json={'confirm':True,'review_digest':inv['review_digest']},headers=self.csrf(c)).status_code,401)

    def test_legacy_username_reserved(self):
        import approval_store
        approval_store.create_employee('AliTaam','sample-password-only',app.config['INVOICE_DB'])
        r=app.test_client().post('/api/auth/register',json=dict(SIGNUP,username='alitaam'))
        self.assertEqual(r.status_code,409)

    def test_lbp_labor_preserves_original_engine_total(self):
        c=self.client()
        order=dict(ORDER,labor_amount=89501,labor_currency='LBP')
        with patch('invoice_engine.understand_message',return_value=order):
            r=c.post('/api/invoices/generate',json={'text':'x'},headers=self.csrf(c))
        self.assertEqual(r.json['totals']['total_lbp'],7249501)
        self.assertEqual(r.json['totals']['total_usd'],81.0)
        saved=c.post('/api/invoices',json=r.json,headers=self.csrf(c))
        self.assertEqual(saved.json['totals']['total_lbp'],7249501)

    def test_example_totals(self):
        items, totals = web_api.compute({'items': [{'q': 1, 'p': 100}]}, web_api.Decimal('11'))
        self.assertEqual((totals['total_usd'], totals['total_lbp']), (111.0, 9934500))

    def test_missing_price_round_trip_and_approval_guard(self):
        c = self.client(); h = self.csrf(c)
        order = dict(ORDER, parts=[dict(name='oil filter', quantity=2)], labor_amount=None, labor_currency=None)
        with patch('invoice_engine.understand_message', return_value=order):
            draft = c.post('/api/invoices/generate', json={'text': 'x'}, headers=h).json
        self.assertEqual([i['p'] for i in draft['items']], [None])     # labor is optional: no labor line
        self.assertIsNone(draft['totals']['total_usd'])
        saved = c.post('/api/invoices', json=draft, headers=h)
        self.assertEqual(saved.status_code, 201)
        path = '/api/invoices/' + saved.json['id']
        self.assertIsNone(c.get(path).json['items'][0]['p'])
        # New invoices start as Pending, even when prices are missing; approval stays blocked.
        self.assertEqual(saved.json['status'], 'pending')
        self.assertEqual(c.post(path+'/pending', json={}, headers=h).json['status'], 'pending')
        approval = {'confirm': True, 'review_digest': saved.json['review_digest'], 'acknowledge_warnings': True}
        self.assertEqual(c.post(path+'/approve', json=approval, headers=h).status_code, 409)
        draft['items'][0]['p'] = 25
        updated = c.put(path, json=draft, headers=h)
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.json['totals']['total_usd'], 50)
        self.assertEqual(len(updated.json['items']), 1)
        self.assertEqual(updated.json['status'], 'pending')
        self.assertEqual(c.post(path+'/submit', json={}, headers=h).status_code, 200)
        # Approve, then the Pending button moves it back (and it becomes editable again).
        inv = c.get(path).json
        ok = c.post(path+'/approve', json={'confirm': True, 'review_digest': inv['review_digest'], 'acknowledge_warnings': True}, headers=h)
        self.assertEqual(ok.json['status'], 'approved')
        self.assertEqual(c.put(path, json=draft, headers=h).status_code, 409)
        self.assertEqual(c.post(path+'/pending', json={}, headers=h).json['status'], 'pending')
        self.assertEqual(c.put(path, json=draft, headers=h).status_code, 200)

    def test_blank_vs_zero_and_invalid_manual_prices(self):
        for value in (None, ''):
            items, total = web_api.compute({'items': [{'d': 'Filter', 'q': 1, 'p': value}]}, web_api.Decimal('0'))
            self.assertIsNone(items[0]['p'])
            self.assertIsNone(total['total_usd'])
        for value in (-1, 'NaN', 'Infinity', 'abc'):
            with self.assertRaises(ValueError):
                web_api.compute({'items': [{'q': 1, 'p': value}]}, web_api.Decimal('0'))
        items, total = web_api.compute({'items': [{'q': 1, 'p': 0}]}, web_api.Decimal('0'))
        self.assertEqual(total['total_usd'], 0)

    def test_optional_labor_screenshot_case_and_approval(self):
        c=self.client(); h=self.csrf(c)
        order=dict(ORDER,parts=[dict(name='engine oil 5L',quantity=1,unit_price=150,price_currency='USD'),dict(name='fuel filter',quantity=2,unit_price=50,price_currency='USD')],labor_amount=None,labor_currency=None)
        with patch('invoice_engine.understand_message',return_value=order):
            draft=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
        self.assertEqual([i['d'] for i in draft['items']],['Engine Oil 5L','Fuel Filter'])
        self.assertEqual(draft['warnings'],[])
        self.assertEqual(draft['totals']['total_usd'],250)
        self.assertEqual(draft['totals']['total_lbp'],22375000)  # 250 USD x 89,500
        saved=c.post('/api/invoices',json=draft,headers=h).json
        path='/api/invoices/'+saved['id']
        self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,200)
        self.assertEqual(c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h).status_code,200)
        pdf=c.get(path+'/pdf')
        self.assertEqual(pdf.status_code,200)
        self.assertTrue(pdf.data.startswith(b'%PDF'))

    def test_invalid_explicit_labor_still_blocks(self):
        c=self.client(); h=self.csrf(c)
        for amount,currency in [('bad','USD'),(30,None)]:
            with patch('invoice_engine.understand_message',return_value=dict(ORDER,labor_amount=amount,labor_currency=currency)):
                draft=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
            self.assertIsNone(draft['items'][-1]['p'])
            self.assertTrue(draft['totals']['incomplete'])

    def test_zero_labor_is_optional_and_hidden(self):
        c = self.client()
        with patch('invoice_engine.understand_message', return_value=dict(ORDER, labor_amount=0)):
            draft = c.post('/api/invoices/generate', json={'text': 'x'}, headers=self.csrf(c)).json
        self.assertFalse(any(i['d']=='Labor' for i in draft['items']))
        self.assertEqual(draft['totals']['total_usd'], 80)

    def test_ai_question_when_nothing_understood(self):
        c = self.client()
        order = dict(ORDER, parts=[dict(name='flux capacitor', quantity=1)], labor_amount=None)
        with patch('invoice_engine.understand_message', return_value=order):
            r = c.post('/api/invoices/generate', json={'text': 'x', 'history': [{'role': 'user', 'text': 'x'}]}, headers=self.csrf(c))
        self.assertIn('question', r.json)
        self.assertIn('flux capacitor', r.json['question'])

    def test_unresolved_parts_do_not_become_partial_invoices(self):
        c=self.client(); h=self.csrf(c)
        for part, expected in [
                (dict(name='flux capacitor',quantity=1,unit_price=50,price_currency='USD'),'describe'),
                (dict(name='engine oil',quantity=1,unit_price=40,price_currency='USD'),'Engine Oil 20L'),
                (dict(name='oil filter',quantity=0,unit_price=25,price_currency='USD'),'How many')]:
            order=dict(ORDER,parts=[ORDER['parts'][1],part],labor_amount=30)
            with patch('invoice_engine.understand_message',return_value=order):
                r=c.post('/api/invoices/generate',json={'text':'test'},headers=h)
            self.assertEqual(r.status_code,200)
            self.assertIn(expected,r.json['question'])
            self.assertNotIn('items',r.json)

    def test_arabic_questions_and_conversation_context(self):
        c=self.client(); h=self.csrf(c)
        order=dict(ORDER,parts=[dict(name='فلتر الهواء',quantity=0,unit_price=35,price_currency='USD')])
        with patch('invoice_engine.understand_message',return_value=order):
            r=c.post('/api/invoices/generate',json={'text':'غيرنا فلتر الهواء'},headers=h)
        self.assertIn('قدّيش',r.json['question'])
        self.assertIn('فلتر هوا',r.json['question'])
        history=[{'role':'user','text':'غيرنا فلتر الهواء'},{'role':'assistant','text':r.json['question']}]
        with patch('invoice_engine.understand_message',return_value=ORDER) as parse:
            r=c.post('/api/invoices/generate',json={'text':'اتنين','history':history},headers=h)
        self.assertEqual(r.status_code,200)
        self.assertIn('Assistant question:',parse.call_args.args[0])
        self.assertIn('Mechanic: اتنين',parse.call_args.args[0])

    def test_unknown_size_suggests_product_without_demanding_catalog_name(self):
        c=self.client(); h=self.csrf(c)
        order=dict(ORDER,parts=[dict(name='فلتر الهواء 3 لتر',quantity=2,unit_price=35,price_currency='USD')])
        with patch('invoice_engine.understand_message',return_value=order):
            r=c.post('/api/invoices/generate',json={'text':'فلتر الهواء 3 لتر'},headers=h)
        self.assertIn('فلتر هوا',r.json['question'])
        self.assertIn('سعرها',r.json['question'])
        self.assertNotIn('catalog',r.json['question'])
        self.assertNotIn('items',r.json)

    def test_companies_are_isolated_and_employee_limits(self):
        a = self.client()
        h = self.csrf(a)
        inv = a.post('/api/invoices', json={'items': [{'d': 'x', 't': 'Part', 'q': 1, 'p': 10}]}, headers=h).json
        b = self.client(dict(SIGNUP, username='other_owner', company_name='Other Garage'))
        self.assertEqual(b.get('/api/invoices/%s' % inv['id']).status_code, 404)
        self.assertEqual(b.get('/api/invoices').json, [])
        # employee of company A
        cid = a.get('/api/company').json['id']
        with app.app_context():
            web_api.create_user('emp_one', 'Employee2026', 'Emp', 'One', '', role='employee', company_id=cid)
        e = app.test_client()
        e.post('/api/auth/login', json={'username': 'emp_one', 'password': 'Employee2026'})
        a.post('/api/invoices/%s/submit' % inv['id'], json={}, headers=h)
        self.assertEqual(e.post('/api/invoices/%s/approve' % inv['id'], json={}, headers=self.csrf(e)).status_code, 403)
        self.assertEqual(e.put('/api/company', data={'name': 'x', 'phone': '+96171123456'}, headers=self.csrf(e)).status_code, 403)
        self.assertEqual(e.get('/api/invoices').json, [])  # employees only see their own

    def test_company_update_and_logo(self):
        c = self.client()
        png = b'\x89PNG\r\n\x1a\n' + b'0' * 50
        from io import BytesIO
        r = c.put('/api/company', data={'name': 'New Name', 'phone': '+9613123456', 'logo': (BytesIO(png), 'l.png')},
                  headers=self.csrf(c), content_type='multipart/form-data')
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json['name'], 'New Name')
        self.assertEqual(c.get(r.json['logo_url']).status_code, 200)
        svg = c.put('/api/company', data={'name': 'New Name', 'phone': '+9613123456', 'logo': (BytesIO(b'<svg/>'), 'x.svg')},
                    headers=self.csrf(c), content_type='multipart/form-data')
        self.assertEqual(svg.status_code, 422)


if __name__ == '__main__':
    unittest.main()
