
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

from invoice_identity import has_identity
from part_lookup import obvious_non_part
from database import search_products, suggest_products
from ai_agent import understand_message

BASE = Path(__file__).parent


def create_invoice(message, confirmed_order=None):
    # Step 1: Gemini understands the message
    order = confirmed_order if confirmed_order is not None else understand_message(message)

    # Step 2: Read exchange rate from JSON
    with open(BASE / "products.json", encoding="utf-8") as file:
        settings = json.load(file)["currency"]

    rate = Decimal(str(
        settings["sample_exchange_rate_lbp_per_usd"]
    ))

    items = []
    warnings = []
    total_usd = Decimal("0")
    total_lbp = Decimal("0")
    incomplete = False

    suggestions = []
    blocked_items = []
    # Step 3: Look up products in database
    for index, part in enumerate(order["parts"]):
        if part.get('scope') == 'out_of_scope' or obvious_non_part(part['name']+' '+part.get('original_name','')):
            blocked_items.append(part.get('original_name') or part['name'])
            incomplete = True
            warnings.append('Outside garage scope: '+part['name'])
            continue
        if part.get('match_type') == 'description':
            from database import get_product_by_id
            candidates = []
            for ident in dict.fromkeys(part.get('candidate_ids', [])):
                product = get_product_by_id(ident)
                if product:
                    candidates.append({k:product[k] for k in ('id','name_en','name_ar')})
            suggestions.append({'index':index,'description':part.get('description') or part['name'],'candidates':candidates[:3], 'quantity':part.get('quantity') or None, 'unit_price':part.get('unit_price'), 'price_currency':part.get('price_currency'), 'custom_allowed':True})
            incomplete = True
            warnings.append('Product confirmation required: '+part['name'])
            continue
        if part.get('clarification'):
            incomplete = True
            warnings.append('Part detail needs review: '+str(part['clarification']))
            continue
        custom = part.get('_custom_confirmed') is True and confirmed_order is not None
        matches = ([{'id':None,'name_en':part['name']}] if custom else search_products(part["name"]))
        if not matches or len(matches) > 1:
            suggestions.append({'index':index,'description':part['name'],
                'candidates':[{k:prod[k] for k in ('id','name_en','name_ar')} for prod in (matches or suggest_products(part['name']))[:3]],
                'quantity':part.get('quantity') or None,'unit_price':part.get('unit_price'),
                'price_currency':part.get('price_currency'),'custom_allowed':True})

        quantity = part["quantity"]

        if type(quantity) is not int or quantity <= 0:
            incomplete = True
            warnings.append(
                f"Invalid quantity: {part['name']}"
            )
            continue

        if len(matches) == 0:
            incomplete = True
            warnings.append(
                f"Unknown product: {part['name']}"
            )
            continue

        if len(matches) > 1:
            incomplete = True
            warnings.append(
                f"Ambiguous product: {part['name']}"
            )
            continue

        product = matches[0]

        # The catalog identifies the product; prices must be explicitly supplied.
        price_usd = price_lbp = line_usd = line_lbp = None
        amount = part.get("unit_price")
        line_amount = part.get("line_price")
        currency = part.get("price_currency")
        if line_amount is not None:
            try:
                line_amount = Decimal(str(line_amount))
                if not line_amount.is_finite() or line_amount < 0 or line_amount > 10000000:
                    raise ValueError('Invalid line price')
                if amount is not None and abs(Decimal(str(amount))*quantity-line_amount) > Decimal('0.01'):
                    warnings.append(f'Conflicting price: {product["name_en"]}')
                    incomplete = True
                    continue
                if amount is None:
                    amount = line_amount / quantity
            except (ValueError, TypeError, InvalidOperation):
                warnings.append(f'Invalid unit price: {product["name_en"]}')
                incomplete = True
                amount = None
        if amount is None:
            warnings.append(f"Unit price is missing: {product['name_en']}")
        else:
            try:
                amount = Decimal(str(amount))
                if not amount.is_finite() or amount < 0 or amount > 10000000:
                    raise ValueError("Invalid unit price")
                if currency not in ("USD", "LBP"):
                    warnings.append(f"Price currency is unclear: {product['name_en']}")
                else:
                    price_usd = amount if currency == "USD" else amount / rate
                    price_lbp = amount if currency == "LBP" else amount * rate
                    line_usd, line_lbp = price_usd * quantity, price_lbp * quantity
                    total_usd += line_usd
                    total_lbp += line_lbp
            except (ValueError, TypeError, InvalidOperation):
                warnings.append(f"Invalid unit price: {product['name_en']}")
        if price_usd is None:
            incomplete = True

        items.append({
            "id": product["id"],
            "is_custom": custom,
            "name": product["name_en"],
            "quantity": quantity,
            "price_usd": str(price_usd) if price_usd is not None else None,
            "price_lbp": str(price_lbp) if price_lbp is not None else None,
            "total_usd": str(line_usd) if line_usd is not None else None,
            "total_lbp": str(line_lbp) if line_lbp is not None else None
        })

    # Step 4: Calculate labor
    labor = None
    labor_currency = order.get("labor_currency")

    if order.get("labor_amount") is not None:
        try:
            labor = Decimal(str(order["labor_amount"]))
            if not labor.is_finite() or labor < 0:
                raise ValueError("Invalid labor amount")
        except (ValueError, TypeError, InvalidOperation):
            warnings.append("Invalid labor amount")
            labor = None
            labor_currency = None

        if labor is not None and labor_currency == "USD":
            total_usd += labor
            total_lbp += labor * rate

        elif labor is not None and labor_currency == "LBP":
            total_lbp += labor
            total_usd += labor / rate

        else:
            warnings.append("Labor currency is unclear")

    # Labor is optional. Only an explicitly supplied but invalid charge blocks completion.
    if order.get("labor_amount") is not None and (labor is None or labor_currency not in ("USD", "LBP")):
        incomplete = True

    if not has_identity(order):
        warnings.append("Customer name or truck ID is required")
        incomplete = True

    # Step 5: Return invoice draft
    return {
        **({'suggestions':suggestions, '_pending_order':order} if suggestions else {}),
        "status": "needs_review",
        "blocked_items": blocked_items,
        "customer": order.get("customer", ""),
        "customer_phone": order.get("customer_phone", ""),
        "customer_email": order.get("customer_email", ""),
        "items": items,
        "notes": order.get("notes", ""),
        "truck_plate": order.get("truck_plate", ""),
        "truck_model": order.get("truck_model", ""),
        "labor_amount": str(labor) if labor is not None else None,
        "labor_currency": labor_currency,
        "incomplete": incomplete,
        "subtotal_usd": None if incomplete else str(
            total_usd.quantize(Decimal("0.01"))
        ),
        "subtotal_lbp": None if incomplete else str(
            total_lbp.quantize(Decimal("1"))
        ),
        "warnings": warnings,
        "approved": False
    }


if __name__ == "__main__":
    message = (
        "غيرنا فلتر زيت عدد اتنين "
        "وفلتر مازوت واحد وأجرة إيد 30 دولار"
    )

    invoice = create_invoice(message)

    print(json.dumps(
        invoice,
        ensure_ascii=False,
        indent=2
    ))
