// MA's voice: one natural voice, chosen once and kept (mock voice lists like Edge / Chrome on Windows).
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('frontend/js/app.js','utf8');
const part=src.slice(src.indexOf('/* MA\'s voice'),src.indexOf('function setVoiceToggle'));
function run(voices){
 const store={},spoken=[];
 const ctx={window:{},localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)}},vstate(){},
  speechSynthesis:{getVoices:()=>voices,cancel(){},speak(u){spoken.push(u);setTimeout(()=>u.onend&&u.onend(),0)},onvoiceschanged:null},
  SpeechSynthesisUtterance:class{constructor(t){this.text=t}},voiceTurn:true,lastArabic:false,speaking:false};
 ctx.window.speechSynthesis=ctx.speechSynthesis;ctx.window.SpeechSynthesisUtterance=ctx.SpeechSynthesisUtterance;
 vm.createContext(ctx);vm.runInContext('var speaking=false,voiceTurn=true,lastArabic=false;'+part,ctx);return {ctx,store,spoken}}
const edge=[{name:'Microsoft David - English (United States)',lang:'en-US'},{name:'Microsoft Zira - English (United States)',lang:'en-US'},
 {name:'Microsoft Aria Online (Natural) - English (United States)',lang:'en-US'},{name:'Microsoft AvaMultilingual Online (Natural) - English (United States)',lang:'en-US'},
 {name:'Microsoft Layla Online (Natural) - Arabic (Lebanon)',lang:'ar-LB'},{name:'Microsoft Hoda - Arabic (Egypt)',lang:'ar-EG'}];
let {ctx,store}=run(edge);
assert.equal(vm.runInContext('pickVoice(false).name',ctx),'Microsoft AvaMultilingual Online (Natural) - English (United States)');
assert.equal(vm.runInContext('pickVoice(true).name',ctx),'Microsoft AvaMultilingual Online (Natural) - English (United States)','same voice for Arabic');
// no multilingual voice: most natural per language, Lebanese Arabic preferred
const chrome=[{name:'Microsoft David - English (United States)',lang:'en-US'},{name:'Google US English',lang:'en-US'},{name:'Google UK English Female',lang:'en-GB'},
 {name:'Microsoft Hoda - Arabic (Egypt)',lang:'ar-EG'},{name:'Microsoft Layla Online (Natural) - Arabic (Lebanon)',lang:'ar-LB'}];
({ctx,store}=run(chrome));
assert.equal(vm.runInContext('pickVoice(false).name',ctx),'Google US English');
assert.equal(vm.runInContext('pickVoice(true).name',ctx),'Microsoft Layla Online (Natural) - Arabic (Lebanon)');
// consistency: once chosen, the same voice is kept even if the list order changes
vm.runInContext('speechSynthesis.getVoices=()=>'+JSON.stringify(chrome.slice().reverse()),ctx);
assert.equal(vm.runInContext('pickVoice(false).name',ctx),'Google US English');
// speech: long answers split into sentences, all with the same voice; no voices installed -> no crash
let r=run(edge);vm.runInContext("speak('Of course. Tell me what you need to organize, and we will work through it together. '+'This is a third sentence that makes the answer long enough to be split into parts for the browser.')",r.ctx);
assert(r.spoken.length>=1);assert(r.spoken.every(u=>u.voice&&u.voice.name===r.spoken[0].voice.name));
r=run([]);vm.runInContext("speak('Hello')",r.ctx);assert.equal(r.spoken.length,1);
// muted (not a voice turn and not forced) -> silent
r=run(edge);vm.runInContext("voiceTurn=false;speak('Hello')",r.ctx);assert.equal(r.spoken.length,0);
vm.runInContext("speak('Hello',true)",r.ctx);assert.equal(r.spoken.length,1,'listen button always speaks');
console.log('PASS: natural voice chosen, multilingual voice used for both languages, Lebanese Arabic preferred, choice kept, sentences share one voice, muted stays silent.')
