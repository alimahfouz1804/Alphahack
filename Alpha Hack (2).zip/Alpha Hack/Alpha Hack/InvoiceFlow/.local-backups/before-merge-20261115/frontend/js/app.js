
/* The workspace only starts after the backend confirms the session (GET /api/auth/me).
   No session -> Auth.requireUser() sends the visitor to signin.html. */
Auth.requireUser().then(function(USER){
document.body.classList.remove('auth-pending');
var $=function(i){return document.getElementById(i)};
/* clock */
function tick(){var d=new Date();$('clock').textContent=d.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'})+' · '+d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}
tick();setInterval(tick,30000);
/* mobile menu */
function setMenu(o){document.body.classList.toggle('menu',o);$('menuBtn').setAttribute('aria-expanded',o)}
$('menuBtn').setAttribute('aria-expanded','false');
$('menuBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('scrim').onclick=function(){setMenu(false)};
document.addEventListener('click',function(e){if(document.body.classList.contains('menu')&&!e.target.closest('nav'))setMenu(false)});
document.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});
/* intro: once per session, skippable, reduced-motion aware */
var intro=$('intro'),seen=false;
try{seen=sessionStorage.getItem('ifIntro')==='1'}catch(e){}
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function finish(){document.body.classList.add('ready');intro.classList.add('done');try{sessionStorage.setItem('ifIntro','1')}catch(e){}setTimeout(function(){intro.style.display='none'},700)}
if(seen||reduce){intro.style.display='none';document.body.classList.add('ready')}
else{var t1=setTimeout(function(){intro.classList.add('open')},500),t2=setTimeout(finish,2500);
$('skip').onclick=function(){clearTimeout(t1);clearTimeout(t2);intro.style.display='none';document.body.classList.add('ready');try{sessionStorage.setItem('ifIntro','1')}catch(e){}}}
/* recording */
var mic=$('mic'),st=$('status'),rec=null,chunks=[],stream=null,ac=null,an=null,raf=0,t0=0,ti=0,url=null;
var cv=$('wave'),cx=cv.getContext('2d');
function say(m){st.textContent=m}
function fmt(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function draw(){
 var w=cv.width,h=cv.height;cx.clearRect(0,0,w,h);
 if(an){var d=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(d);var n=48,bw=w/n;
  for(var i=0;i<n;i++){var v=d[Math.floor(i*d.length/n/2)]/255,bh=Math.max(3,v*h);cx.fillStyle=i%2?'#06B6D4':'#2563EB';cx.fillRect(i*bw+1,(h-bh)/2,bw-3,bh)}}
 else{cx.fillStyle='#334155';for(var j=0;j<48;j++)cx.fillRect(j*(w/48)+1,h/2-2,w/48-3,4)}
 raf=requestAnimationFrame(draw)}
draw();
/* voice conversation: listening -> (paused) -> thinking -> speaking; Stop cancels everything */
var paused=false,elapsed=0,discard=false,runId=0,voiceTurn=false,speaking=false,inflight=null,lastArabic=false;
var VL={listening:['MA is listening…','MA عم يسمعك…'],paused:['Paused','موقّف مؤقتاً'],thinking:['MA is thinking…','MA عم يفكّر…'],speaking:['MA is speaking…','MA عم يحكي…']};
function vstate(s){var vb=$('vbar');vb.hidden=!s;vb.dataset.s=s||'';
 $('vText').textContent=s?VL[s][0]+' / '+VL[s][1]:'';
 $('vPause').hidden=!(s==='listening'||s==='speaking');$('vResume').hidden=s!=='paused';
 $('timer').hidden=$('wave').hidden=!(s==='listening'||(s==='paused'&&rec));
 $('aiState').textContent=s?VL[s][0]:'Ready'}
function recSecs(){return Math.floor((elapsed+(paused?0:Date.now()-t0))/1000)}
async function start(){
 if(rec||busy)return;
 stopSpeaking();
 try{stream=await navigator.mediaDevices.getUserMedia({audio:true})}
 catch(e){say('Microphone not available. You can type the repair details instead.');return}
 try{ac=new (window.AudioContext||window.webkitAudioContext)();an=ac.createAnalyser();an.fftSize=256;ac.createMediaStreamSource(stream).connect(an);
  rec=new MediaRecorder(stream);chunks=[];rec.ondataavailable=function(e){chunks.push(e.data)};rec.onstop=onStop;rec.start()}
 catch(e){say('Recording is not supported in this browser. Please type instead.');cleanup();return}
 discard=false;paused=false;elapsed=0;voiceTurn=true;
 mic.classList.add('rec');mic.setAttribute('aria-label','Stop recording and send');$('gen').disabled=true;
 t0=Date.now();$('timer').textContent='00:00';ti=setInterval(function(){$('timer').textContent=fmt(recSecs())},500);
 vstate('listening');say('Tap the mic again when finished. اضغط المايك لما تخلص.')}
function cleanup(){clearInterval(ti);if(stream)stream.getTracks().forEach(function(t){t.stop()});if(ac)ac.close();an=null;ac=null;stream=null}
function stop(){if(rec&&rec.state!=='inactive')rec.stop()}
function onStop(){
 cleanup();rec=null;paused=false;mic.classList.remove('rec');mic.setAttribute('aria-label','Start recording');$('gen').disabled=busy;
 if(discard){discard=false;chunks=[];return}
 var b=new Blob(chunks,{type:chunks[0]&&chunks[0].type||'audio/webm'});if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(b);
 var a=$('play');a.src=url;a.hidden=false;
 transcribe(b)}
function pauseVoice(){
 if(rec&&rec.state==='recording'){rec.pause();elapsed+=Date.now()-t0;paused=true;vstate('paused');say('Paused. Tap Resume to continue. اضغط Resume لتكمّل.')}
 else if(speaking&&window.speechSynthesis){speechSynthesis.pause();paused=true;vstate('paused')}}
function resumeVoice(){
 if(rec&&rec.state==='paused'){rec.resume();t0=Date.now();paused=false;vstate('listening');say('')}
 else if(speaking&&window.speechSynthesis){speechSynthesis.resume();paused=false;vstate('speaking')}}
function stopSpeaking(){if(window.speechSynthesis)speechSynthesis.cancel();speaking=false}
/* Stop: ends recording (discarding it), cancels any request in progress, stops playback and speech */
function cancelVoice(quiet){
 if(rec&&rec.state!=='inactive'){discard=true;rec.stop()}
 runId++;
 if(inflight){convo.pop();var lc=$('chat').lastElementChild;if(lc&&lc.classList.contains('user'))lc.remove();if(!quiet)tx.value=inflight;inflight=null}
 var a=$('play');a.pause();stopSpeaking();paused=false;voiceTurn=false;
 lockInput(false);vstate('');if(!quiet)say('Stopped. / وقّفنا.')}
/* MA reads the answer aloud only when you spoke to him (browser voice; Arabic depends on installed voices) */
function speak(t){
 if(!voiceTurn||!t||!window.speechSynthesis||!window.SpeechSynthesisUtterance)return;
 var lines=String(t).split('\n').filter(function(l){return l.trim()}),pick=lines.filter(function(l){return /[؀-ۿ]/.test(l)===lastArabic});
 var u=new SpeechSynthesisUtterance((pick.length?pick:lines).join('. ').replace(/[•✔]/g,''));
 u.lang=lastArabic?'ar-LB':'en-US';
 u.onend=u.onerror=function(){if(!speaking)return;speaking=false;paused=false;vstate('')};
 speechSynthesis.cancel();speaking=true;vstate('speaking');speechSynthesis.speak(u)}
$('vPause').onclick=pauseVoice;$('vResume').onclick=resumeVoice;$('vStop').onclick=function(){cancelVoice(false)};
var tx=$('tx');tx.addEventListener('input',function(){tx.style.height='auto';tx.style.height=tx.scrollHeight+'px'});
tx.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('gen').click()}});
mic.onclick=function(){rec?stop():start()};
/* ---- app state: cache of what the backend returned ---- */
var DB={invoices:[],customers:[],catalog:[],company:{name:USER.company.name||'',phone:'',logo:''}},convo=[],convoId=0,busy=false;
var productArabic={};
var inv=$('inv'),ai=$('ai'),pg=$('page'),paper=$('paper'),NB=document.querySelectorAll('nav > button'),cur=null,editing=false,curPage=0;
var LBL={draft:['DRAFT','s-draft'],pending:['PENDING','s-pending'],approved:['APPROVED','s-appr'],rejected:['REJECTED','s-rej']};
/* money: display only. Totals always come from the backend (invoice.totals). */
function num(n,d){return (+n||0).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d})}
function missing(n){return n==null||n===''||!Number.isFinite(Number(n))}
function usd(n){return missing(n)?'—':'$'+num(n,2)}
function invoiceUsd(n){return missing(n)?'—':'$'+num(n,Number.isInteger(Number(n))?0:2)}
function lbp(n){return missing(n)?'—':num(Math.round(+n),0)+' LBP'}
function isLabor(it){return /^labou?r\b/i.test(it.d||'')}
function itemLabel(it){var ar=isLabor(it)?'أجرة اليد':productArabic[(it.d||'').toLowerCase()];return esc(it.d)+(ar?' / <bdi lang="ar">'+esc(ar)+'</bdi>':'')}
function incomplete(){return cur.items.some(function(it){return missing(it.q)||missing(it.p)})}
function money(n){return usd(n)}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function clone(o){return JSON.parse(JSON.stringify(o))}
function ref(c){return c.id!=null?c.id:c.no}
function canEdit(d){return d.status!=='approved'}
function msg(t){$('aMsg').textContent=t}
function fail(e,fn){(fn||say)(e&&e.message?e.message:'Something went wrong.')}
function icons(){if(window.lucide)lucide.createIcons()}
function normCo(c){c=c||{};return {id:c.id,name:c.name||USER.company.name||'',phone:c.phone||'',logo:c.logo_url||'',vat:c.vat_rate,rate:c.exchange_rate}}
function applyCompany(){var n=DB.company.name||'your garage';
 $('hdrCompany').innerHTML=DB.company.name?'<span class="cl">Company Name: </span>'+esc(DB.company.name):'';$('hdrCompany2').textContent=DB.company.name||'—';
 var wl=$('welcome');if(wl)document.documentElement.style.setProperty('--welH',(wl.offsetHeight+20)+'px');
 document.title=(DB.company.name?DB.company.name+' · ':'')+'InvoiceFlow AI';$('modePill').hidden=API.mode()!=='mock'}
async function loadCompany(){DB.company=normCo(await API.getCompany());applyCompany()}
async function refresh(){var r=await Promise.all([API.listInvoices(),API.getCustomers(),API.getCatalog(),API.getCompany(),API.getProducts()]);DB.invoices=r[0];DB.customers=r[1];DB.catalog=r[2];DB.company=normCo(r[3]);(r[4].products||[]).forEach(function(p){productArabic[p.name_en.toLowerCase()]=p.name_ar});applyCompany();if(cur)render()}
function view(v,ni){$('work').hidden=v==='pg';pg.hidden=v!=='pg';inv.hidden=!cur;$('invEmpty').hidden=!!cur;NB.forEach(function(b,i){b.classList.toggle('on',i===ni)});setMenu(false)}
/* ---- signed-in user + role-based UI (display only: the backend re-checks every permission) ---- */
var can=Auth.can;
function initials(n){return (n||'?').trim().split(/\s+/).slice(0,2).map(function(w){return w[0]}).join('').toUpperCase()}
function avatar(el){el.textContent='';if(USER.picture){var im=new Image();im.alt='';im.src=USER.picture;im.onerror=function(){el.textContent=initials(USER.name)};el.appendChild(im)}else el.textContent=initials(USER.name||USER.username)}
function applyUser(){USER=Auth.user||USER;
 $('hdrName').textContent=USER.name||USER.username;$('hdrRole').textContent=USER.roleLabel;
 $('navName').textContent=USER.name||'Signed in';$('navUsername').textContent='@'+USER.username;
 $('navRole').textContent=USER.roleLabel;$('navRole').className='role-b '+USER.role;
 avatar($('hdrAv'));avatar($('navAv'));
 [].forEach.call(document.querySelectorAll('nav [data-perm]'),function(b){b.hidden=!can(b.dataset.perm)});
 }
applyUser();applyCompany();
$('profileBtn').onclick=function(e){e.stopPropagation();setMenu(!document.body.classList.contains('menu'))};
$('logoutBtn').onclick=async function(){var b=this;if(b.disabled)return;b.disabled=true;b.querySelector('span').textContent='Signing out...';try{await Auth.logout()}catch(e){b.disabled=false;b.querySelector('span').textContent='Log out';alert(e.message)}};
function denied(t){return '<h2>'+t+'</h2><p class="muted">Your account ('+esc(USER.roleLabel)+') does not have access to this page. Ask the garage owner if you need it.</p>'}
/* ---- voice + AI conversation ---- */
function lockInput(value){busy=value;$('gen').disabled=value||!!rec;mic.disabled=value;tx.disabled=value}
async function transcribe(b){
 var run=++runId,transcript='';lockInput(true);vstate('thinking');say('Understanding your recording… عم إفهم التسجيل.');
 try{var r=await API.transcribe(b);if(run!==runId)return;transcript=(r.text||r.transcript||'').trim();if(!transcript)throw Error('No clear speech found. Please record again.');tx.value=(tx.value+' '+transcript).trim();tx.dispatchEvent(new Event('input'))}
 catch(e){if(run!==runId)return;fail(e)}finally{if(run===runId){lockInput(false);vstate('')}}
 if(transcript&&run===runId){lastArabic=/[؀-ۿ]/.test(transcript);await sendMessage(true)}
}
function bubble(r,t){var d=document.createElement('div');d.className='msg '+r;d.dir='auto';d.textContent=t;$('chat').appendChild(d);$('chat').scrollTop=$('chat').scrollHeight}
function resetChat(){$('chat').innerHTML='';convo=[];convoId++;cur=null;editing=false;tx.value='';tx.style.height='auto';msg('');$('play').hidden=true;closeModal();tx.placeholder='Describe the repair or tap the mic...';say('');bubble('ai','أهلا، أنا MA. احكيلي اسم الزبون، القطع، العدد والأسعار. اضغط المايك لتسجّل، واضغط مرة ثانية لتجهّز المسودة.\nHi, I\'m MA. Tell me the customer, parts, quantities and prices. Tap the mic to record, then tap again to prepare your draft.');pendingShare=null;view('ai',1)}
async function sendMessage(fromVoice){
 if(busy)return;var txt=tx.value.trim();
 if(!txt){say('Tap the microphone or type what was repaired.');return}
 if(fromVoice!==true){voiceTurn=false;stopSpeaking()}
 var run=++runId;inflight=txt;
 bubble('user',txt);tx.value='';tx.style.height='auto';say('');lockInput(true);vstate('thinking');st.innerHTML='<span class="dots"><i></i><i></i><i></i></span>Working on it… عم إشتغل عليها';
 try{convo.push({role:'user',text:txt});var r=await API.generateInvoice({text:txt,history:convo});
  if(run!==runId)return;inflight=null;
  if(r.reply!==undefined){convo.push({role:'assistant',text:r.reply,kind:'answer',ask:r.ask||''});answer(r);say('');speak(r.reply);if(r.action)share(r.action,/[\u0600-\u06ff]/.test(txt))}
  else if(r.question){convo.push({role:'assistant',text:r.question,kind:'question'});bubble('ai',r.question);say('');speak(r.question)}
  else{var ready='المسودة جاهزة على اليمين. فيك تحكي أي تصحيح، أو تراجعها وتوافق عليها.\nYour invoice is ready on the right. Speak any correction, or review and approve it.';bubble('ai',ready);if(r.warnings&&r.warnings.length)bubble('ai','Please check:\n\u2022 '+r.warnings.join('\n\u2022 '));say('');showInvoice(r);speak(ready)}}
 catch(e){if(run!==runId)return;inflight=null;convo.pop();var lc=$('chat').lastElementChild;if(lc&&lc.classList.contains('user'))lc.remove();tx.value=txt;fail(e)}
 finally{if(run===runId){lockInput(false);if(!speaking)vstate('')}}}
/* answers to questions about invoices, help, or "open invoice N" */
function answer(r){
 if(r.understood){var u=document.createElement('div');u.className='msg-und';u.dir='auto';u.textContent='\u2714 '+r.understood;$('chat').appendChild(u)}
 bubble('ai',r.reply);
 if(r.invoices&&r.invoices.length){var box=document.createElement('div');box.className='msg-list';
  r.invoices.forEach(function(c){var b=document.createElement('button');b.type='button';b.dataset.open=c.id;b.dir='auto';
   b.innerHTML='<b>'+esc(c.no)+'</b><span>'+esc(c.customer||'-')+(c.plate?' · '+esc(c.plate):'')+'</span><span>'+esc(c.date)+'</span><span class="r">'+(c.total_usd!=null?invoiceUsd(c.total_usd):'—')+'</span>'+badge(c.status);
   box.appendChild(b)});
  $('chat').appendChild(box)}
 $('chat').scrollTop=$('chat').scrollHeight;
 if(r.open)show(clone(r.open),1)}
$('chat').addEventListener('click',async function(e){var b=e.target.closest('button[data-open]');if(!b)return;b.disabled=true;
 try{show(clone(await API.getInvoice(b.dataset.open)),1)}catch(er){say(er.message)}finally{b.disabled=false}});
$('gen').onclick=sendMessage;
/* ---- invoice preview / editing ---- */
function coOf(d){var c=d.company||{};return {name:c.name||DB.company.name,phone:c.phone||DB.company.phone,logo:c.logo_url||DB.company.logo}}
function totals(){
 var t=cur.totals,dirty=!!cur._dirty;
 [].forEach.call($('iRows').rows,function(r,i){var it=cur.items[i],c=r.querySelector('.rt');if(!it||!c)return;var bk=!dirty&&it.total_usd!=null;c.textContent=invoiceUsd(missing(it.q)||missing(it.p)?null:(bk?it.total_usd:it.q*it.p));c.classList.toggle('pv',!bk)});
 var ok=t&&!dirty;
 $('iSub').textContent=ok?invoiceUsd(t.subtotal_usd):'—';$('iVatL').textContent='VAT'+(t&&t.vat_rate!=null?' ('+t.vat_rate+'%)':'');
 $('iVat').textContent=ok?invoiceUsd(t.vat_usd):'—';$('iTot').textContent=ok&&!incomplete()?invoiceUsd(t.total_usd):'—';$('iTotL').textContent=ok&&!incomplete()?lbp(t.total_lbp):'—';
 $('iSubRow').hidden=$('iVatRow').hidden=!t||!t.vat_rate;
 $('iMissing').hidden=!incomplete();
 $('iTotals').classList.toggle('stale',!ok);$('iStale').hidden=ok;
 $('iStale').textContent=t?'You changed items — the server recalculates the USD and LBP totals when you save.':'Totals will be calculated by the server when you save the invoice.';
 var rate=(t&&t.exchange_rate)||DB.company.rate;$('iFx').textContent=rate?'Exchange rate: 1 USD = '+num(rate,0)+' LBP (fixed rate used by InvoiceFlow AI).':''}
function btns(){var ce=canEdit(cur),ap=cur.status==='approved';$('aEdit').disabled=!ce;$('aEdit').textContent=editing&&ce?'Done Editing':'Edit Invoice';$('aDraft').disabled=!ce;$('sPend').classList.toggle('on',!ap);$('sAppr').classList.toggle('on',ap);$('sPend').setAttribute('aria-pressed',String(!ap));$('sAppr').setAttribute('aria-pressed',String(ap));$('sAppr').querySelector('span').textContent=ap?'Approved':'Approve';$('aWa').classList.toggle('locked',!ap);$('aWa').title=ap?'Send this invoice by WhatsApp':'Approve the invoice first';$('aMail').classList.toggle('locked',!ap);$('aMail').title=ap?'Send this invoice by email':'Approve the invoice first';$('aPrint').disabled=!cur.items.length;$('aMail').disabled=false;$('aPrint').title=ap?'Download the final PDF':'Download a preview PDF (marked PENDING)'}
function render(){
 var d=cur,ed=editing&&canEdit(d),C=d.cust,T=d.truck,co=coOf(d),h='',s=LBL[d.status];
 $('iCo').textContent=(co.name||'').toUpperCase();$('iCoPhone').textContent=co.phone?'Phone: '+Phone.pretty(co.phone):'';
 var lg=$('iLogo');lg.hidden=!co.logo;if(co.logo)lg.src=co.logo;else lg.removeAttribute('src');
 $('iNo').textContent=d.no?'INVOICE #'+d.no:'INVOICE — not saved yet';$('iDate').textContent=new Date(d.date||Date.now()).toLocaleDateString([], {year:'numeric',month:'long',day:'numeric'});
 $('iSt').textContent=s[0];$('iSt').className='badge-s '+s[1];var n=document.querySelector('.note');n.hidden=!d.mock;n.textContent='Mock data from the frontend test layer, not from the AI backend.';
 function fld(g,list){return list.map(function(x){var p=x.split('|');return '<input data-s="'+g+'.'+p[0]+'" placeholder="'+p[1]+'" value="'+esc((g==='cust'?C:T)[p[0]])+'">'}).join('')}
 $('iCust').innerHTML=ed?fld('cust',['name|Customer name','contact|Contact person','tel|Phone','email|Email']):([C.name,C.contact&&'Contact: '+C.contact,C.tel&&'Tel: '+C.tel,C.email].filter(Boolean).map(esc).join('<br>')||'-');
 $('iTruck').innerHTML=ed?fld('truck',['plate|Plate number','model|Truck model']):([T.plate&&'Plate: '+T.plate,T.model].filter(Boolean).map(esc).join('<br>')||'-');
 $('invoiceItems').classList.toggle('editing',ed);$('iTotalLabel').colSpan=ed?5:3;
 $('iRows').parentNode.tHead.innerHTML=ed?'<tr><th>Item / البند</th><th>Type</th><th class="r">Qty / الكمية</th><th class="r">Unit USD / سعر الوحدة</th><th class="r">Total / المجموع</th><th></th></tr>':'<tr><th>Item / <bdi lang="ar">البند</bdi></th><th class="r">Quantity / <bdi lang="ar">الكمية</bdi></th><th class="r">Unit price / <bdi lang="ar">سعر الوحدة</bdi></th><th class="r">Total / <bdi lang="ar">المجموع</bdi></th></tr>';
 d.items.forEach(function(it,i){
  h+=ed?'<tr><td><input aria-label="Item '+(i+1)+' description" data-i="'+i+'" data-k="d" value="'+esc(it.d)+'"></td><td><input aria-label="Item '+(i+1)+' type" data-i="'+i+'" data-k="t" value="'+esc(it.t)+'"></td><td><input aria-label="Item '+(i+1)+' quantity" data-i="'+i+'" data-k="q" type="number" min="0" step="any" placeholder="—" value="'+(missing(it.q)?'':it.q)+'"></td><td><input aria-label="Item '+(i+1)+' unit price USD" data-i="'+i+'" data-k="p" type="number" min="0" step="any" placeholder="—" value="'+(missing(it.p)?'':it.p)+'"></td><td class="r rt"></td><td><button class="x" data-del="'+i+'" aria-label="Remove row">&times;</button></td></tr>'
  :'<tr><td>'+itemLabel(it)+'</td><td class="r">'+(isLabor(it)||missing(it.q)?'—':it.q)+'</td><td class="r">'+(isLabor(it)?'—':invoiceUsd(it.p))+'</td><td class="r rt"></td></tr>'});
 $('iRows').innerHTML=h;$('iEd').hidden=!ed;
 $('iRepairNotes').hidden=!d.notes;$('iRepairNotes').textContent=d.notes||'';
 $('iEd').innerHTML=ed?'<button class="btn sm" id="addRow">+ Add row</button><select id="catSel"><option value="">Add product (enter price)...</option>'+DB.catalog.map(function(c,i){return '<option value="'+i+'">'+esc(c[0])+'</option>'}).join('')+'</select>':'';
 totals();btns()}
function show(c,ni){cur=c;editing=false;render();msg('');view('inv',ni||1);if(window.innerWidth<1100)inv.scrollIntoView({behavior:'smooth',block:'start'})}
function showInvoice(d){var c=clone(d);c.status='pending';c._convo=convoId;
 if(cur&&cur._convo===convoId&&cur.id!=null&&canEdit(cur)){c.id=cur.id;c.no=cur.no}
 show(c,1)}
function dirty(){cur._dirty=true}
paper.addEventListener('input',function(e){var t=e.target,d=t.dataset;if(d.k){cur.items[+d.i][d.k]=(d.k==='q'||d.k==='p')?(t.value.trim()===''?null:Number(t.value)):t.value;if(d.k==='q'||d.k==='p')dirty();totals()}else if(d.s){var a=d.s.split('.');cur[a[0]][a[1]]=t.value}});
paper.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;if(b.id==='addRow'){cur.items.push({d:'',t:'Service',q:1,p:null});dirty();render()}else if(b.dataset.del!=null){cur.items.splice(+b.dataset.del,1);dirty();render()}});
paper.addEventListener('change',function(e){if(e.target.id==='catSel'&&e.target.value!==''){var c=DB.catalog[+e.target.value];cur.items.push({d:c[0],t:c[1],q:1,p:null});dirty();render()}});
function payload(){var p=clone(cur);delete p._dirty;delete p._convo;delete p.totals;delete p.mock;p.items.forEach(function(i){delete i.total_usd});return p}
async function run(fn,ok){if(busy)return;busy=true;try{var r=await fn();if(ok&&r!==false)msg(ok);refresh().catch(function(){})}catch(e){fail(e,msg)}finally{busy=false}}
window.addEventListener('resize',function(){var wl=$('welcome');if(wl&&wl.offsetHeight)document.documentElement.style.setProperty('--welH',(wl.offsetHeight+20)+'px')});
$('newChat').onclick=function(){cancelVoice(true);resetChat();say('');tx.focus()};
$('expand').onclick=function(){var big=document.body.classList.toggle('chat-big');this.setAttribute('aria-pressed',String(big));
 this.setAttribute('aria-label',big?'Restore chat size':'Expand chat');this.title=big?'Restore chat size':'Expand chat';
 this.innerHTML='<i data-lucide="'+(big?'minimize-2':'maximize-2')+'"></i>';icons();$('chat').scrollTop=$('chat').scrollHeight};
/* save the current invoice (new invoices are saved as Pending) */
async function persist(){if(!cur.items.length)throw Error('Add at least one item first.');var c=cur._convo;cur=await API.saveInvoice(payload());cur._convo=c;editing=false;render();return cur}
$('aEdit').onclick=function(){editing=!editing;render();msg('')};
$('aDraft').onclick=function(){run(persist,'Saved as Pending. Totals were recalculated by the server.')};
/* Status: Pending / Approve. Only a person can approve, never the AI. */
$('sPend').onclick=function(){run(async function(){
 if(cur.status==='approved'){
  var ok=await ask({title:'Move '+cur.no+' back to Pending?',body:'<p>It can be edited again, and it must be approved again before it is sent.</p><p dir="rtl">رح ترجع قيد الانتظار وبتنعدّل، ولازم توافق عليها من جديد قبل ما تنبعت.</p>',ok:'Move to Pending'});
  if(!ok)return false;cur=Object.assign(await API.markPending(ref(cur)),{_convo:cur._convo});render();return}
 await persist();if(cur.status!=='pending'){cur=Object.assign(await API.markPending(ref(cur)),{_convo:cur._convo});render()}
},'Status: Pending. / الحالة: قيد الانتظار.')};
$('sAppr').onclick=function(){if(cur.status==='approved'){msg('This invoice is already approved.');return}
 if(!can('invoice.approve')){msg('Only the garage owner can approve invoices. / بس صاحب الكاراج فيه يوافق على الفواتير.');return}
 if(!cur.items.length){msg('Add at least one item first.');return}
 if(incomplete()){msg('Fill in the missing quantities and prices before approving (Edit Invoice). / عبّي الأسعار والكميات الناقصة قبل الموافقة.');return}
 run(async function(){
  var saved=await persist(),reviewed=await API.getInvoice(ref(saved)),t=reviewed.totals||{};
  var ok=await ask({title:'Approve invoice '+reviewed.no+'?',ok:'Approve',
   body:'<dl class="mdl"><dt>Customer</dt><dd>'+esc(reviewed.cust.name||'-')+'</dd><dt>Items</dt><dd>'+reviewed.items.length+'</dd><dt>Total</dt><dd><b>'+invoiceUsd(t.total_usd)+'</b> / '+lbp(t.total_lbp)+'</dd></dl>'+
    ((reviewed.warnings||[]).length?'<p class="mwarn">'+reviewed.warnings.map(esc).join('<br>')+'</p>':'')+'<p class="muted small">Check the invoice before approving. Approved invoices can be downloaded as PDF and sent by WhatsApp.</p>'});
  if(!ok){cur=Object.assign(reviewed,{_convo:saved._convo});render();return false}
  cur=Object.assign(await API.approveInvoice(ref(reviewed),reviewed),{_convo:saved._convo});render();
  if(pendingShare){var a=pendingShare;pendingShare=null;setTimeout(function(){share(a,false)},150)}},'Approved. You can now download the PDF or send it by WhatsApp. / تمت الموافقة.')};
$('aPrint').onclick=function(){var ap=cur.status==='approved';run(async function(){
 if(!cur.items.length)throw Error('Add at least one item first.');
 if(!ap)await persist();   /* the PDF always shows the latest saved information */
 await API.downloadPdf(ref(cur),!ap)},ap?'PDF downloaded. / تنزّل الـ PDF.':'Preview PDF downloaded (marked PENDING). Approve the invoice for the final PDF. / تنزّلت نسخة أولية.')};
$('aMail').onclick=function(){
 if(cur.status!=='approved'){msg('Approve this invoice first, then send it by email. / وافق على الفاتورة أوّل، بعدين ابعتها عالإيميل.');$('sAppr').focus();return}
 emailAddress(lastEmail||cur.cust.email||'')};
/* ---- WhatsApp: number -> preview -> confirm -> open wa.me (free Click-to-Chat). Never sends by itself. ---- */
$('aWa').onclick=function(){
 if(cur.status!=='approved'){msg('Approve this invoice first, then send it by WhatsApp. / وافق على الفاتورة أوّل، بعدين ابعتها عالواتساب.');$('sAppr').focus();return}
 waNumber(lastPhone||cur.cust.tel||'')};
function waNumber(pre){
 var p=/^\+/.test(pre)?Phone.split(pre):{cc:Phone.DEFAULT,national:pre};
 modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> Send via WhatsApp</h3><div class="msteps"><b class="on">1 Number</b><b>2 Preview</b><b>3 WhatsApp</b></div>'+
  '<label class="mlab" for="waNum">Customer WhatsApp number / <bdi lang="ar">رقم واتساب الزبون</bdi></label>'+
  '<div class="ph wa-ph"><select id="waCc" aria-label="Country code"></select><input id="waNum" type="tel" inputmode="tel" autocomplete="off" placeholder="71 123 456" value="'+esc(p.national)+'" aria-describedby="waErr"></div>'+
  '<small class="ferr2" id="waErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" data-m="no">Cancel</button><button class="btn pri" id="waNext">Next <i data-lucide="arrow-right"></i></button></div>');
 Phone.fillSelect($('waCc'),p.cc);$('waNum').focus();
 function next(){var v=Phone.validate($('waCc').value,$('waNum').value);
  if(v.ok&&$('waCc').value==='+961'&&v.type!=='mobile')v={ok:false,message:'WhatsApp needs a mobile number, e.g. 71 123 456 or 03 123 456 (not a landline).'};
  if(!v.ok){$('waErr').textContent=v.message;$('waNum').setAttribute('aria-invalid','true');$('waNum').focus();return}
  waPreview(v.e164)}
 $('waNext').onclick=next;$('waNum').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();next()}};
 $('waNum').oninput=function(){$('waErr').textContent='';this.removeAttribute('aria-invalid')}}
function waText(){var d=cur,t=d.totals||{},co=coOf(d),L=[];
 L.push('*INVOICE '+d.no+'*');L.push(co.name);if(co.phone)L.push('Phone: '+Phone.pretty(co.phone));
 L.push('Date: '+new Date(d.date||Date.now()).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}));
 if(d.cust.name)L.push('Customer: '+d.cust.name);if(d.truck.plate||d.truck.model)L.push('Truck: '+[d.truck.plate,d.truck.model].filter(Boolean).join(' - '));
 L.push('');L.push('*Items*');
 d.items.forEach(function(it){L.push('• '+it.d+(isLabor(it)?'':' × '+it.q)+' — '+invoiceUsd(it.total_usd!=null?it.total_usd:it.q*it.p))});
 L.push('');L.push('*Total: '+invoiceUsd(t.total_usd)+'*');L.push('*Total (LBP): '+lbp(t.total_lbp)+'*');
 if(t.exchange_rate)L.push('Exchange rate: 1 USD = '+num(t.exchange_rate,0)+' LBP');
 L.push('');L.push('Thank you for choosing '+co.name+'.');return L.join('\n')}
function waPreview(e164){var d=cur,t=d.totals||{},co=coOf(d);
 var rows=d.items.map(function(it){return '<tr><td>'+itemLabel(it)+'</td><td class="r">'+(isLabor(it)?'—':esc(it.q))+'</td><td class="r">'+invoiceUsd(it.total_usd)+'</td></tr>'}).join('');
 modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> Check before sending</h3><div class="msteps"><b class="done">1 Number</b><b class="on">2 Preview</b><b>3 WhatsApp</b></div>'+
  '<dl class="mdl"><dt>Customer WhatsApp</dt><dd dir="ltr">'+esc(Phone.pretty(e164))+'</dd><dt>Company</dt><dd>'+esc(co.name)+'</dd><dt>Company phone</dt><dd dir="ltr">'+esc(co.phone?Phone.pretty(co.phone):'—')+'</dd>'+
  '<dt>Invoice</dt><dd>'+esc(d.no)+'</dd><dt>Date</dt><dd>'+esc(new Date(d.date||Date.now()).toLocaleDateString([], {year:'numeric',month:'long',day:'numeric'}))+'</dd></dl>'+
  '<div class="tw mtab"><table><thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Total</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
  '<div class="mtot"><div><span>Total (USD)</span><b>'+invoiceUsd(t.total_usd)+'</b></div><div><span>Total (LBP)</span><b>'+lbp(t.total_lbp)+'</b></div>'+(t.exchange_rate?'<small>1 USD = '+num(t.exchange_rate,0)+' LBP</small>':'')+'</div>'+
  '<details class="mmsg"><summary>Message that will be prepared</summary><pre dir="auto">'+esc(waText())+'</pre></details>'+
  '<p class="muted small">WhatsApp will open with this message ready. You press Send inside WhatsApp. To attach the PDF, download it and add it in the chat.</p>'+
  '<div class="mact"><button class="btn" id="waBack"><i data-lucide="arrow-left"></i> Back</button><button class="btn" data-m="no">Cancel</button><button class="btn" id="waPdf"><i data-lucide="download"></i> PDF</button><button class="btn wa" id="waGo"><i data-lucide="send"></i> Confirm &amp; Send</button></div>');
 $('waBack').onclick=function(){waNumber(e164)};
 $('waPdf').onclick=pdfFromModal;
 $('waGo').onclick=function(){var link='https://wa.me/'+e164.replace(/\D/g,'')+'?text='+encodeURIComponent(waText());
  var a=document.createElement('a');a.href=link;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
  modal('<h3 id="mTitle"><i data-lucide="message-circle"></i> WhatsApp is opening</h3><div class="msteps"><b class="done">1 Number</b><b class="done">2 Preview</b><b class="on">3 WhatsApp</b></div>'+
   '<p>The message for <b dir="ltr">'+esc(Phone.pretty(e164))+'</b> is ready in WhatsApp. <b>Press Send in WhatsApp</b> to deliver it.</p><p dir="rtl">الرسالة جاهزة بالواتساب. اضغط «إرسال» جوّا الواتساب لتنبعت.</p>'+
   '<p class="muted small">InvoiceFlow can\'t see whether the message was delivered. If WhatsApp didn\'t open, use the button below.</p>'+
   '<div class="mact"><a class="btn wa" href="'+esc(link)+'" target="_blank" rel="noopener"><i data-lucide="external-link"></i> Open WhatsApp again</a><button class="btn" id="waPdf2"><i data-lucide="download"></i> Download PDF</button><button class="btn pri" data-m="no">Done</button></div>');
  $('waPdf2').onclick=pdfFromModal;
  msg('WhatsApp opened with the invoice message. Press Send there. / انفتح الواتساب، اضغط إرسال هونيك.')}}
/* ---- MA commands: "send it on WhatsApp to 03 123 456", "email it to name@gmail.com" ---- */
var pendingShare=null,lastPhone='',lastEmail='',EMAIL_OK=null;
function share(a,ar){
 if(a.phone)lastPhone=a.phone;if(a.email)lastEmail=a.email;
 if(!a.phone&&!a.email)return;                       /* MA asked for the missing number/email */
 var what=a.type==='email'?(ar?'الإيميل':'the email'):'WhatsApp',who=a.phone?Phone.pretty(a.phone):a.email;
 if(!cur){bubble('ai',ar?'ما في فاتورة مفتوحة. حضّر فاتورة أو افتح وحدة (مثلاً «افتحلي الفاتورة 3»)، وبعدين قلّي لوين إبعتها.':'There\'s no invoice open. Create or open one (e.g. "open invoice 3"), then tell me where to send it.');return}
 if(cur.status!=='approved'){pendingShare=a;
  bubble('ai',ar?'الفاتورة لسّا قيد الانتظار. وافق عليها (زر Approve على اليمين) وبفتحلك '+what+' لـ '+who+' مباشرة.':'This invoice is still Pending. Approve it (Approve button on the right) and I\'ll open '+what+' for '+who+' right away.');
  $('sAppr').classList.add('nudge');setTimeout(function(){$('sAppr').classList.remove('nudge')},2400);return}
 if(a.type==='whatsapp'){var p=Phone.split(a.phone),v=Phone.validate(p.cc,p.national);if(v.ok)waPreview(v.e164);else waNumber(a.phone)}
 else{if(EMAIL_RE.test(a.email))emailPreview(a.email);else emailAddress(a.email)}}
/* ---- Email: address -> preview -> confirm -> sent by the server (SMTP) or opened in your email app ---- */
var EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
API.emailStatus().then(function(r){EMAIL_OK=!!r.configured}).catch(function(){EMAIL_OK=false});
function emailText(){var d=cur,t=d.totals||{},co=coOf(d),L=[];
 L.push('Dear '+(d.cust.name||'Customer')+',','','Please find your invoice from '+co.name+' below.','');
 L.push('Invoice: '+d.no,'Date: '+new Date(d.date||Date.now()).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}));
 if(d.truck.plate||d.truck.model)L.push('Truck: '+[d.truck.plate,d.truck.model].filter(Boolean).join(' - '));
 L.push('','Items:');
 d.items.forEach(function(it){L.push('- '+it.d+(isLabor(it)?'':' x '+it.q)+': '+invoiceUsd(it.total_usd!=null?it.total_usd:it.q*it.p))});
 L.push('','Total: '+invoiceUsd(t.total_usd)+' ('+lbp(t.total_lbp)+')');if(t.exchange_rate)L.push('Exchange rate: 1 USD = '+num(t.exchange_rate,0)+' LBP');
 L.push('','The invoice PDF is attached.','','Thank you for your business,',co.name);if(co.phone)L.push('Phone: '+Phone.pretty(co.phone));
 return L.join('\n')}
function emailSubject(){return 'Invoice '+cur.no+' from '+coOf(cur).name}
function emailAddress(pre){
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Send via Email</h3><div class="msteps mail"><b class="on">1 Email</b><b>2 Preview</b><b>3 Send</b></div>'+
  '<label class="mlab" for="emTo">Customer email address / <bdi lang="ar">إيميل الزبون</bdi></label>'+
  '<div class="wa-ph"><input id="emTo" type="email" inputmode="email" autocomplete="off" placeholder="name@gmail.com" value="'+esc(pre)+'" aria-describedby="emErr"></div>'+
  '<small class="ferr2" id="emErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" data-m="no">Cancel</button><button class="btn pri" id="emNext">Next <i data-lucide="arrow-right"></i></button></div>');
 $('emTo').focus();
 function next(){var v=$('emTo').value.trim();
  if(!EMAIL_RE.test(v)){$('emErr').textContent='Enter a valid email address, e.g. name@gmail.com.';$('emTo').setAttribute('aria-invalid','true');$('emTo').focus();return}
  lastEmail=v;emailPreview(v)}
 $('emNext').onclick=next;$('emTo').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();next()}};
 $('emTo').oninput=function(){$('emErr').textContent='';this.removeAttribute('aria-invalid')}}
function emailPreview(to){var d=cur,t=d.totals||{},auto=EMAIL_OK===true;
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Check before sending</h3><div class="msteps mail"><b class="done">1 Email</b><b class="on">2 Preview</b><b>3 Send</b></div>'+
  '<dl class="mdl"><dt>To</dt><dd>'+esc(to)+'</dd><dt>Invoice</dt><dd>'+esc(d.no)+' · '+esc(d.cust.name||'—')+'</dd><dt>Total</dt><dd>'+invoiceUsd(t.total_usd)+' / '+lbp(t.total_lbp)+'</dd>'+
  '<dt>Attachment</dt><dd>'+(auto?'📎 '+esc(d.no)+'.pdf (attached automatically)':'You attach the PDF in your email app')+'</dd></dl>'+
  '<label class="mlab" for="emSub">Subject</label><div class="wa-ph"><input id="emSub" value="'+esc(emailSubject())+'"></div>'+
  '<label class="mlab" for="emBody" style="margin-top:10px">Message</label><textarea id="emBody" class="mtext" rows="9">'+esc(emailText())+'</textarea>'+
  '<p class="muted small">'+(auto?'InvoiceFlow sends this email with the PDF through your configured mail server.':'No mail server is set up, so your email app will open with this message ready. Download the PDF and attach it, then press Send.')+'</p>'+
  '<small class="ferr2" id="emSendErr" role="alert"></small>'+
  '<div class="mact"><button class="btn" id="emBack"><i data-lucide="arrow-left"></i> Back</button><button class="btn" data-m="no">Cancel</button><button class="btn" id="emPdf"><i data-lucide="download"></i> PDF</button><button class="btn pri" id="emGo"><i data-lucide="send"></i> Confirm &amp; Send</button></div>');
 $('emBack').onclick=function(){emailAddress(to)};
 $('emPdf').onclick=pdfFromModal;
 $('emGo').onclick=async function(){var b=this,sub=$('emSub').value.trim()||emailSubject(),body=$('emBody').value;
  if(EMAIL_OK!==true){mailApp(to,sub,body);return}
  b.disabled=true;b.classList.add('busy');$('emSendErr').textContent='';
  try{var r=await API.sendEmail(ref(cur),to,sub,body);emailDone(to,r.message||'The mail server accepted the email.')}
  catch(e){if(e.code==='email_not_configured'){EMAIL_OK=false;mailApp(to,sub,body);return}
   b.disabled=false;b.classList.remove('busy');
   $('emSendErr').innerHTML=esc(e.message||'The email could not be sent.')+' <button class="linkb" id="emApp" type="button">Use my email app instead</button>';
   $('emApp').onclick=function(){mailApp(to,sub,body)}}}}
function mailApp(to,sub,body){
 var link='mailto:'+to+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(body);
 var a=document.createElement('a');a.href=link;document.body.appendChild(a);a.click();a.remove();
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail"></i> Your email app is opening</h3><div class="msteps mail"><b class="done">1 Email</b><b class="done">2 Preview</b><b class="on">3 Send</b></div>'+
  '<p>The email to <b>'+esc(to)+'</b> is ready in your email app. <b>Attach the PDF</b> (download it below) and <b>press Send</b> there.</p><p dir="rtl">الإيميل جاهز ببرنامج الإيميل. نزّل الـ PDF وزيدو كمرفق، وبعدين اضغط إرسال.</p>'+
  '<p class="muted small">InvoiceFlow can\'t see whether the email was sent. If nothing opened, check that an email app is set up on this computer.</p>'+
  '<div class="mact"><a class="btn mailb" href="'+esc(link)+'"><i data-lucide="external-link"></i> Open email app again</a><button class="btn" id="emPdf2"><i data-lucide="download"></i> Download PDF</button><button class="btn pri" data-m="no">Done</button></div>');
 $('emPdf2').onclick=pdfFromModal;msg('Your email app opened with the invoice message. Attach the PDF and press Send there.')}
function emailDone(to,text){
 modal('<h3 id="mTitle" class="mail-h"><i data-lucide="mail-check"></i> Email sent</h3><div class="msteps mail"><b class="done">1 Email</b><b class="done">2 Preview</b><b class="done on">3 Send</b></div>'+
  '<p>'+esc(text)+'</p><p class="muted small">The mail server accepted it for <b>'+esc(to)+'</b>. Final delivery depends on the customer\'s email provider.</p>'+
  '<div class="mact"><button class="btn pri" data-m="no">Done</button></div>');
 msg('Email accepted by the mail server for '+to+'.')}
async function pdfFromModal(){var b=this;b.disabled=true;try{await API.downloadPdf(ref(cur),cur.status!=='approved')}catch(e){alert(e.message)}finally{b.disabled=false}}
/* ---- small modal used for confirmations and WhatsApp ---- */
var modalCancel=null,lastFocus=null;
function modal(html){var m=$('modal');if(m.hidden)lastFocus=document.activeElement;$('mbox').innerHTML=html;m.hidden=false;icons();
 $('mbox').onclick=function(e){var b=e.target.closest('[data-m="no"]');if(b)closeModal()}}
function closeModal(){var m=$('modal');if(m.hidden)return;m.hidden=true;$('mbox').innerHTML='';var c=modalCancel;modalCancel=null;if(c)c();if(lastFocus&&lastFocus.focus)lastFocus.focus()}
function ask(o){return new Promise(function(res){
 modal('<h3 id="mTitle">'+esc(o.title)+'</h3><div class="mbody">'+o.body+'</div><div class="mact"><button class="btn" data-m="no">'+(o.no||'Cancel')+'</button><button class="btn pri" id="mYes">'+esc(o.ok)+'</button></div>');
 modalCancel=function(){res(false)};$('mYes').focus();$('mYes').onclick=function(){modalCancel=null;closeModal();res(true)}})}
$('modal').addEventListener('mousedown',function(e){if(e.target===this)closeModal()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('modal').hidden){e.stopPropagation();closeModal()}},true);
/* ---- pages ---- */
function table(hd,rows){return '<div class="tw"><table><thead><tr>'+hd.map(function(x){return '<th>'+x+'</th>'}).join('')+'</tr></thead><tbody>'+(rows||'<tr><td colspan="'+hd.length+'" class="muted">Nothing here yet.</td></tr>')+'</tbody></table></div>'}
function badge(s){return '<span class="badge-s '+LBL[s][1]+'">'+LBL[s][0]+'</span>'}
function totCell(c){var t=c.totals;return t?usd(t.total_usd)+'<small class="lbp-s">'+lbp(t.total_lbp)+'</small>':'—'}
function invRows(L,acts){return L.map(function(c){return '<tr><td>'+esc(c.no)+'</td><td>'+esc(c.cust.name||'-')+'</td><td>'+esc(c.truck.plate||'-')+'</td><td class="r">'+totCell(c)+'</td><td>'+badge(c.status)+'</td><td class="r">'+acts(c)+'</td></tr>'}).join('')}
var IH=['No.','Customer','Truck','Total','Status',''];
function op(c){return '<button class="btn sm" data-open="'+esc(ref(c))+'">Open</button>'}
function histRows(){var q=($('q')||{value:''}).value.toLowerCase(),f=($('fs')||{value:''}).value;return invRows(DB.invoices.slice().reverse().filter(function(c){return(!f||c.status===f)&&(!q||(c.no+' '+c.cust.name+' '+c.truck.plate).toLowerCase().indexOf(q)>=0)}),op)}
async function openPage(i){curPage=i;view('pg',{0:0,3:2,4:3,7:4}[i]);
 if(i===4&&!can('invoice.approve')){pg.innerHTML=denied('Pending Approvals');return}
 pg.innerHTML='<p class="muted">Loading...</p>';
 try{await refresh()}catch(e){pg.innerHTML='<h2>Backend unavailable</h2><p>'+esc(e.message)+'</p>';return}
 var L=DB.invoices.slice().reverse(),h='',n=function(s){return L.filter(function(c){return c.status===s}).length};
 if(i===0){var td=new Date().toDateString();h='<div class="dash-wel"><h2>Welcome to MA</h2><p>Your AI-powered invoice assistant is ready.</p></div><div class="qa"><button class="btn pri sm" data-go="1">Talk with AI</button>'+(can('invoice.approve')?'<button class="btn sm" data-go="3">Pending approvals</button>':'')+'<button class="btn sm" data-go="2">Invoice history</button></div><div class="stats"><div><h3>Today</h3><b>'+L.filter(function(c){return new Date(c.date).toDateString()===td}).length+'</b></div><div><h3>Pending</h3><b>'+n('pending')+'</b></div><div><h3>Approved</h3><b>'+n('approved')+'</b></div></div><h3>Recent invoices</h3>'+table(IH,invRows(L.slice(0,5),op))}
 else if(i===3)h='<h2>Invoice History</h2><div class="bar"><input id="q" placeholder="Search by number, customer or plate..."><select id="fs"><option value="">All statuses</option><option value="draft">Draft</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div><div id="list">'+table(IH,histRows())+'</div>';
 else if(i===4)h='<h2>Pending Approvals</h2>'+table(IH,invRows(L.filter(function(c){return c.status==='pending'}),function(c){return op(c)+' <button class="btn sm pri" data-ap="'+esc(ref(c))+'">Approve</button> <button class="btn sm" data-rj="'+esc(ref(c))+'">Reject</button>'}))+'<div class="pmsg" role="status"></div>';
 else if(i===5)h='<h2>Customers</h2>'+table(['Name','Contact','Phone','Email'],DB.customers.map(function(c){return '<tr><td>'+esc(c.name)+'</td><td>'+esc(c.contact)+'</td><td>'+esc(c.tel)+'</td><td>'+esc(c.email)+'</td></tr>'}).join(''));
 else if(i===6)h='<h2>Garage Catalog</h2><p class="muted">Read from the backend. Prices are validated there.</p>'+table(['Item','Type','Price (USD)'],DB.catalog.map(function(c){return '<tr><td>'+esc(c[0])+'</td><td>'+esc(c[1])+'</td><td>'+usd(c[2])+'</td></tr>'}).join(''));
 else {pg.innerHTML=Settings.html();Settings.init();icons();return}
 pg.innerHTML=h}
function find(r){return DB.invoices.find(function(c){return String(ref(c))===String(r)})}
pg.addEventListener('input',function(e){if(e.target.id==='q'||e.target.id==='fs')$('list').innerHTML=table(IH,histRows())});
pg.addEventListener('click',async function(e){var b=e.target.closest('button');if(!b)return;var d=b.dataset;
 if(d.go)NB[+d.go].click();
 else if(d.open){b.disabled=true;try{show(clone(await API.getInvoice(d.open)),1)}catch(er){var c=find(d.open);if(c)show(clone(c),1);else alert(er.message)}finally{b.disabled=false}}
 else if(d.ap||d.rj){var m=pg.querySelector('.pmsg');try{if(d.ap){var reviewed=await API.getInvoice(d.ap);if(!confirm('Approve '+reviewed.no+' for '+reviewed.cust.name+'?\nTotal: '+usd(reviewed.totals.total_usd)+' / '+lbp(reviewed.totals.total_lbp)+'\n'+(reviewed.warnings||[]).join('\n')))return;await API.approveInvoice(d.ap,reviewed);}else await API.rejectInvoice(d.rj);await openPage(curPage)}catch(er){m.textContent=er.message}}});
NB.forEach(function(b,i){b.onclick=function(){if(i===1)view('ai',1);else openPage([0,1,3,4,7][i])}});

/* ---- Settings: personal info, password, company profile ---- */
var Settings=(function(){
 var LOGO_TYPES=['image/png','image/jpeg','image/webp'],LOGO_MAX=2*1024*1024,unTimer=0,unOk=true,logoFile=null,removeLogo=false;
 function f(id,label,val,attrs){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><input id="'+id+'" value="'+esc(val)+'" '+(attrs||'')+'><small class="ferr2" id="'+id+'Err"></small></label>'}
 function phone(id,label,e164,dis){var p=Phone.split(e164);return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="ph"><select id="'+id+'Cc" '+dis+'></select><input id="'+id+'" type="tel" inputmode="tel" value="'+esc(p.national)+'" placeholder="71 123 456" '+dis+'></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function pw(id,label,ac){return '<label class="fl" data-f="'+id+'"><span>'+label+'</span><div class="pwbox"><input id="'+id+'" type="password" autocomplete="'+ac+'"><button type="button" class="eye2" data-eye="'+id+'" aria-label="Show password"><i data-lucide="eye"></i></button></div><small class="ferr2" id="'+id+'Err"></small></label>'}
 function html(){var C=DB.company,own=can('company.manage'),dis=own?'':'disabled';
  return '<h2>Settings</h2>'+
  '<form class="sform" id="fMe" novalidate><h3>Personal information</h3><div class="sgrid">'+
   f('sFirst','First name',USER.firstName,'autocomplete="given-name" maxlength="50"')+f('sLast','Last name',USER.lastName,'autocomplete="family-name" maxlength="50"')+
   f('sUser','Username',USER.username,'autocomplete="username" maxlength="30" autocapitalize="none" spellcheck="false"')+phone('sPhone','Phone number',USER.phone,'')+
  '</div><div class="srow"><button class="btn pri sm" id="bMe">Save personal info</button><span class="smsg" id="mMe" role="status"></span></div></form>'+
  '<form class="sform" id="fPw" novalidate><h3>Change password</h3><div class="sgrid">'+
   pw('sCur','Current password','current-password')+'<span></span>'+pw('sNew','New password','new-password')+pw('sNew2','Confirm new password','new-password')+
  '</div><p class="muted small">At least 8 characters with an uppercase letter, a lowercase letter and a number.</p><div class="srow"><button class="btn pri sm" id="bPw">Change password</button><span class="smsg" id="mPw" role="status"></span></div></form>'+
  '<form class="sform" id="fCo" novalidate><h3>Company information</h3>'+(own?'':'<p class="muted small">Only the garage owner can change company information.</p>')+'<div class="sgrid">'+
   f('cName','Company name',C.name,'maxlength="120" '+dis)+phone('cPhone','Company phone number',C.phone,dis)+
  '</div><div class="logo-row"><div class="logo-prev" id="cLogoPrev">'+(C.logo?'<img src="'+esc(C.logo)+'" alt="Company logo">':'<span>No logo</span>')+'</div>'+
   (own?'<div><label class="btn sm file-btn"><input type="file" id="cLogo" accept="image/png,image/jpeg,image/webp" hidden>Upload logo</label> <button type="button" class="btn sm" id="cLogoRm"'+(C.logo?'':' hidden')+'>Remove</button><small class="muted small block">PNG, JPG or WebP, up to 2 MB. Shown on every invoice.</small><small class="ferr2" id="cLogoErr"></small></div>':'')+
  '</div><dl class="dl"><dt>VAT rate</dt><dd>'+(C.vat!=null?esc(C.vat)+'%':'Set by the backend')+'</dd><dt>Exchange rate</dt><dd>'+(C.rate?'1 USD = '+num(C.rate,0)+' LBP':'Set by the backend')+'</dd></dl>'+
  (own?'<div class="srow"><button class="btn pri sm" id="bCo">Save company info</button><span class="smsg" id="mCo" role="status"></span></div>':'')+'</form>'}
 function err(id,t){var e=$(id+'Err');if(e)e.textContent=t||'';var l=pg.querySelector('[data-f="'+id+'"]');if(l)l.classList.toggle('bad',!!t)}
 function note(id,t,ok){var m=$(id);m.textContent=t||'';m.className='smsg'+(ok?' ok':'')}
 function load(btn,on){btn.disabled=on;btn.classList.toggle('busy',on)}
 function serverErr(e,map,box){Object.keys(e.fields||{}).forEach(function(k){if(map[k])err(map[k],e.fields[k])});note(box,e.message)}
 var NAME=/^[\p{L}\p{M}][\p{L}\p{M}' .-]*$/u,PWR=function(p){return p.length>=8&&/[A-Z]/.test(p)&&/[a-z]/.test(p)&&/\d/.test(p)};
 function init(){unOk=true;logoFile=null;removeLogo=false;
  Phone.fillSelect($('sPhoneCc'),Phone.split(USER.phone).cc);Phone.fillSelect($('cPhoneCc'),Phone.split(DB.company.phone).cc);
  pg.querySelectorAll('[data-eye]').forEach(function(b){b.onclick=function(){var i=$(b.dataset.eye),s=i.type==='password';i.type=s?'text':'password';b.setAttribute('aria-label',s?'Hide password':'Show password');b.innerHTML='<i data-lucide="'+(s?'eye-off':'eye')+'"></i>';icons()}});
  /* username availability (only when it differs from the current one) */
  $('sUser').oninput=function(){var u=this;u.value=u.value.toLowerCase().replace(/\s/g,'');clearTimeout(unTimer);var v=u.value;
   if(v===USER.username){unOk=true;err('sUser','');return}
   if(!Auth.USERNAME_RE.test(v)){unOk=false;err('sUser','Use 3–30 letters, numbers, "_" or "." — start with a letter.');return}
   unOk=false;err('sUser','');$('sUserErr').textContent='Checking availability…';
   unTimer=setTimeout(async function(){try{var r=await Auth.checkUsername(v);if($('sUser').value!==v)return;unOk=r.available;
    if(r.available){$('sUserErr').innerHTML='<span class="okc">✓ Username is available</span>'}else err('sUser','⚠ Username is already taken'+(r.suggestions.length?' — try '+r.suggestions.slice(0,3).join(', '):''))}
    catch(e){unOk=true;$('sUserErr').textContent='Couldn’t check now; the server will confirm on save.'}},450)};
  $('fMe').onsubmit=async function(e){e.preventDefault();var b=$('bMe'),ok=true;note('mMe','');
   [['sFirst','first name'],['sLast','last name']].forEach(function(x){var v=$(x[0]).value.trim();var m=!v?'Please enter your '+x[1]+'.':!NAME.test(v)?'Use letters only.':'';err(x[0],m);if(m)ok=false});
   var ph=Phone.validate($('sPhoneCc').value,$('sPhone').value);err('sPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;
   if(!unOk){ok=false;if(!$('sUserErr').textContent)err('sUser','Choose an available username.')}
   if(!ok)return;load(b,true);
   try{await Auth.updateMe({first_name:$('sFirst').value.trim(),last_name:$('sLast').value.trim(),username:$('sUser').value.trim(),phone:ph.e164});applyUser();note('mMe','Saved.',true)}
   catch(er){if(er.status===409)err('sUser','⚠ Username is already taken');serverErr(er,{first_name:'sFirst',last_name:'sLast',username:'sUser',phone:'sPhone'},'mMe')}finally{load(b,false)}};
  $('fPw').onsubmit=async function(e){e.preventDefault();var b=$('bPw'),c=$('sCur').value,n=$('sNew').value,n2=$('sNew2').value,ok=true;note('mPw','');
   err('sCur',c?'':'Enter your current password.');if(!c)ok=false;
   var m=!n?'Enter a new password.':!PWR(n)?'Doesn’t meet the requirements below.':n===c?'Choose a different password.':'';err('sNew',m);if(m)ok=false;
   err('sNew2',n2===n?'':'Passwords don’t match.');if(n2!==n)ok=false;if(!ok)return;load(b,true);
   try{await Auth.changePassword(c,n);['sCur','sNew','sNew2'].forEach(function(i){$(i).value=''});note('mPw','Password changed. Other devices were signed out.',true)}
   catch(er){if(er.status===400||er.status===401&&er.code)err('sCur','Current password is incorrect.');serverErr(er,{current_password:'sCur',new_password:'sNew'},'mPw')}finally{load(b,false)}};
  if(!can('company.manage'))return;
  $('cLogo').onchange=function(){var fl=this.files[0];err('cLogo','');if(!fl)return;
   if(LOGO_TYPES.indexOf(fl.type)<0){err('cLogo','Please choose a PNG, JPG or WebP image.');this.value='';return}
   if(fl.size>LOGO_MAX){err('cLogo','The logo must be 2 MB or smaller.');this.value='';return}
   logoFile=fl;removeLogo=false;var u=URL.createObjectURL(fl);$('cLogoPrev').innerHTML='<img src="'+u+'" alt="New logo preview">';$('cLogoRm').hidden=false};
  $('cLogoRm').onclick=function(){logoFile=null;removeLogo=true;$('cLogo').value='';$('cLogoPrev').innerHTML='<span>No logo</span>';this.hidden=true};
  $('fCo').onsubmit=async function(e){e.preventDefault();var b=$('bCo'),nm=$('cName').value.trim().replace(/\s+/g,' '),ok=true;note('mCo','');
   err('cName',nm.length<2?'Please enter the company name.':'');if(nm.length<2)ok=false;
   var ph=Phone.validate($('cPhoneCc').value,$('cPhone').value);err('cPhone',ph.ok?'':ph.message);if(!ph.ok)ok=false;if(!ok)return;
   var fd=new FormData();fd.append('name',nm);fd.append('phone',ph.e164);if(logoFile)fd.append('logo',logoFile);if(removeLogo)fd.append('remove_logo','1');
   load(b,true);try{DB.company=normCo(await API.updateCompany(fd));applyCompany();logoFile=null;removeLogo=false;note('mCo','Saved. The homepage and new invoices now use this information.',true)}
   catch(er){serverErr(er,{name:'cName',phone:'cPhone',logo:'cLogo'},'mCo')}finally{load(b,false)}}}
 return {html:html,init:init}})();

loadCompany().catch(function(e){say(e.message)});refresh().catch(function(e){say(e.message)});resetChat();icons();
});
