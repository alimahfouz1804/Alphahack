/* api.js - ALL workspace backend communication lives here. Settings are in js/config.js.
   Expected endpoints (JSON unless noted; every call needs the session cookie - see AUTH_BACKEND.md):
   GET  /api/company                 -> company   (always live, never mocked)
   PUT  /api/company                 multipart: name, phone, logo (file, optional), remove_logo ("1") -> company   [owner only]
   GET  /api/catalog | /api/customers | /api/invoices      (employees: only their own invoices)
   GET  /api/invoices/{id}           -> invoice   (404 if it belongs to another company/user)
   POST /api/transcribe              multipart field "audio"       -> {text}
   POST /api/invoices/generate       {text, history:[{role,text}]} -> invoice (with totals) | {question}
   POST /api/invoices                invoice -> saved invoice (backend assigns id/no, company, prices, totals)
   PUT  /api/invoices/{id}           invoice -> saved invoice (totals recalculated)
   POST /api/invoices/{id}/submit | /pending | /approve | /reject -> invoice (backend checks the role)
   POST /api/invoices/{id}/email     {to}                         -> {message}
   {id} = invoice.id (falls back to invoice.no if the backend has no separate id).
   Errors: non-2xx with {"detail": "message"} (shown to the user as-is). 401 -> back to Sign In.
   Invoice shape: {id,no,date,status,company:{name,phone,logo_url},cust:{name,contact,tel,email},truck:{plate,model},
                   items:[{d,t,q,p,total_usd}],
                   totals:{subtotal_usd,vat_rate,vat_usd,total_usd,total_lbp,exchange_rate}}
   Company shape: {id,name,phone,logo_url,vat_rate,exchange_rate}
   The frontend NEVER computes money totals: it shows the totals object exactly as returned. */

/* Live calls go through Auth.request: session cookie (credentials:'include'), CSRF header, error parsing. */
async function http(path, opt) {
  opt = opt || {};
  const body = opt.body === undefined ? undefined : (opt.body instanceof FormData ? opt.body : JSON.parse(opt.body));
  try { return await Auth.request(path, { method: opt.method || 'GET', body, timeout: opt.timeout }); }
  catch (e) {
    if (e.status === 401) { Auth.goSignIn('session_expired'); return new Promise(() => {}); }
    throw e;
  }
}
const jsonOpt = (method, body, timeout) => ({ method, body: JSON.stringify(body || {}), timeout });
const AI_TIMEOUT = 90000; /* Gemini can take 30+ s when it falls back to the backup model */
const call = (fn, path, opt, ...args) => API_CONFIG.useMock ? MockBackend[fn](...args) : http(path, opt);
const invRef = (x) => encodeURIComponent(typeof x === 'object' ? (x.id != null ? x.id : x.no) : x);

const API = {
  mode: () => (API_CONFIG.useMock ? 'mock' : 'live'),
  getCompany: () => http('/api/company'),
  updateCompany: (form) => http('/api/company', { method: 'PUT', body: form }),
  getCatalog: () => call('getCatalog', '/api/catalog'),
  getProducts: () => http('/api/products'),
  getCustomers: () => call('getCustomers', '/api/customers'),
  listInvoices: () => call('listInvoices', '/api/invoices'),
  getInvoice: (ref) => call('getInvoice', '/api/invoices/' + invRef(ref), undefined, ref),
  transcribe(blob) { const f = new FormData(); f.append('audio', blob, 'recording.webm'); return call('transcribe', '/api/transcribe', { method: 'POST', body: f, timeout: AI_TIMEOUT }, blob); },
  generateInvoice(p) { return call('generateInvoice', '/api/invoices/generate', jsonOpt('POST', p, AI_TIMEOUT), p); },
  saveInvoice(inv) { const ex = inv.id != null || inv.no; return call('saveInvoice', ex ? '/api/invoices/' + invRef(inv) : '/api/invoices', jsonOpt(ex ? 'PUT' : 'POST', inv), inv); },
  submitInvoice: (ref) => call('submitInvoice', '/api/invoices/' + invRef(ref) + '/submit', jsonOpt('POST'), ref),
  markPending: (ref) => call('markPending', '/api/invoices/' + invRef(ref) + '/pending', jsonOpt('POST'), ref),
  approveInvoice: (ref, reviewed) => call('approveInvoice', '/api/invoices/' + invRef(ref) + '/approve', jsonOpt('POST', {confirm:true, review_digest:reviewed.review_digest, acknowledge_warnings:true}), ref),
  rejectInvoice: (ref) => call('rejectInvoice', '/api/invoices/' + invRef(ref) + '/reject', jsonOpt('POST'), ref),
  /* preview=true: pending invoice, PDF stamped PENDING - PREVIEW. Approved invoices get the final PDF. */
  downloadPdf: async (ref, preview) => { let r; try { r=await fetch(API_CONFIG.baseUrl+'/api/invoices/'+invRef(ref)+'/pdf'+(preview?'?preview=1':''),{credentials:'include',cache:'no-store'}); } catch (x) { throw Error('Cannot reach the InvoiceFlow server to create the PDF.'); }
    if(r.status===401){Auth.goSignIn('session_expired');return new Promise(()=>{});}
    if(!r.ok){let e={};try{e=await r.json()}catch(x){}const d=e.detail;throw Error((d&&d.message)||(typeof d==='string'&&d)||e.error||'The PDF could not be created ('+r.status+').');}
    const name=((r.headers.get('Content-Disposition')||'').match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i)||[])[1]||'invoice.pdf';
    const url=URL.createObjectURL(await r.blob()); const a=document.createElement('a');a.href=url;a.download=decodeURIComponent(name);document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000); },
  emailStatus: () => http('/api/email/status'),
  sendEmail: (ref, to, subject, message) => call('sendEmail', '/api/invoices/' + invRef(ref) + '/email', jsonOpt('POST', { to, subject, message }, 60000), ref, to)
};
