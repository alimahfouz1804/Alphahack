"""Tests for the chat assistant: understanding any request (invoice questions, open, help) before drafting.
No live Gemini calls: the intent router and the invoice extractor are mocked."""
import os
os.environ.setdefault('GEMINI_API_KEY', 'test-only')
import tempfile
import time
import unittest
from unittest.mock import patch

from app import app
import web_api
from ai_agent import GeminiUnavailable

SIGNUP = dict(first_name='Karim', last_name='Haddad', username='karim_garage', password='Garage2026',
              phone='+96171123456', company_name='Cedar Truck Garage')
ORDER = dict(customer='Ali', parts=[dict(name='oil filter', quantity=2, unit_price=25, price_currency='USD')],
             labor_amount=30, labor_currency='USD', notes='', truck_plate='452187', truck_model='Volvo FH')
TODAY = time.strftime('%Y-%m-%d')


def inv(customer, plate, price):
    return {'cust': {'name': customer}, 'truck': {'plate': plate},
            'items': [{'d': 'Oil Filter', 't': 'Part', 'q': 1, 'p': price}]}


class AssistantTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.temp.name + '/test.db'
        web_api._failures.clear()
        self.c = app.test_client()
        self.assertEqual(self.c.post('/api/auth/register', json=SIGNUP).status_code, 201)
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}
        for cust, plate, price in (('Ali Mahfouz', '452187', 100), ('Samir Khoury', 'B 99881', 50), ('Ali Mahfouz', '452187', None)):
            self.assertEqual(self.c.post('/api/invoices', json=inv(cust, plate, price), headers=self.h).status_code, 201)

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old_db
        self.temp.cleanup()

    def ask(self, text, route, history=None):
        with patch('ai_agent.route_message', return_value=dict(route)) as r:
            res = self.c.post('/api/invoices/generate', json={'text': text, 'history': history or [{'role': 'user', 'text': text}]}, headers=self.h)
        self.assertEqual(res.status_code, 200, res.json)
        return res.json, r

    def test_count_on_a_date_with_typos(self):
        d, r = self.ask('nb of invoice at date 14 nov 2026',
                        dict(intent='invoice_query', language='en', metric='count', date_from=TODAY, date_to=TODAY,
                             understood='Number of invoices today'))
        self.assertIn('There are 3 invoices on', d['reply'])
        self.assertEqual(len(d['invoices']), 3)
        self.assertEqual(d['understood'], 'Number of invoices today')
        self.assertIn('nb of invoice', r.call_args[0][0])  # the raw message (typos and all) reaches the AI

    def test_other_day_has_none(self):
        d, _ = self.ask('how many yesterday', dict(intent='invoice_query', metric='count', date_from='2020-01-01', date_to='2020-01-01'))
        self.assertTrue(d['reply'].startswith('There are no invoices on 1 Jan 2020'))
        self.assertEqual(d['invoices'], [])

    def test_total_with_misspelled_customer_skips_incomplete(self):
        d, _ = self.ask('total for ali mahfuz', dict(intent='invoice_query', language='en', metric='total', customer='ali mahfuz'))
        self.assertIn('There are 2 invoices', d['reply'])
        self.assertIn('Total: $100 / 8,950,000 LBP', d['reply'])
        self.assertIn('1 incomplete', d['reply'])

    def test_arabic_reply(self):
        d, _ = self.ask('كم فاتورة اليوم', dict(intent='invoice_query', language='ar', metric='count', date_from=TODAY, date_to=TODAY))
        self.assertIn('في 3 فواتير', d['reply'])

    def test_plate_and_status_filters(self):
        d, _ = self.ask('invoices plate b99881', dict(intent='invoice_query', metric='list', plate='b99881'))
        self.assertEqual([x['customer'] for x in d['invoices']], ['Samir Khoury'])
        d, _ = self.ask('pending ones?', dict(intent='invoice_query', status='pending'))
        self.assertIn('There are 3 invoices that are pending approval', d['reply'])
        d, _ = self.ask('approved ones?', dict(intent='invoice_query', status='approved'))
        self.assertIn('There are no invoices that are approved', d['reply'])

    def test_open_invoice_by_number(self):
        d, _ = self.ask('open inv 2', dict(intent='open_invoice', invoice_no='inv 2'))
        self.assertEqual(d['open']['no'], 'INV-0002')
        d, _ = self.ask('open 99', dict(intent='open_invoice', invoice_no='99'))
        self.assertNotIn('open', d)
        self.assertIn("couldn't find invoice INV-0099", d['reply'])

    def test_help_and_chat(self):
        d, _ = self.ask('hi', dict(intent='help', reply='Hi!'))
        self.assertIn('Describe a repair', d['reply'])
        d, _ = self.ask('asdkj', dict(intent='chat', reply='Did you mean to create an invoice?'))
        self.assertEqual(d['reply'], 'Did you mean to create an invoice?')

    def test_repair_still_drafts_and_ignores_earlier_questions(self):
        history = [{'role': 'user', 'text': 'how many invoices today'},
                   {'role': 'assistant', 'text': 'There are 3 invoices.', 'kind': 'answer'},
                   {'role': 'user', 'text': 'Ali: 2 oil filters at 25 USD each, labor 30 USD'}]
        with patch('invoice_engine.understand_message', return_value=ORDER) as parse:
            d, _ = self.ask(history[-1]['text'], dict(intent='invoice'), history)
        self.assertEqual(d['totals']['total_usd'], 80)
        sent = parse.call_args[0][0]
        self.assertIn('2 oil filters', sent)
        self.assertNotIn('how many invoices', sent)

    def test_ai_down_falls_back_to_drafting(self):
        with patch('ai_agent.route_message', side_effect=GeminiUnavailable('x')), \
             patch('invoice_engine.understand_message', return_value=ORDER):
            d = self.c.post('/api/invoices/generate', json={'text': 'x'}, headers=self.h).json
        self.assertEqual(d['totals']['total_usd'], 80)

    def test_employee_only_sees_own_invoices(self):
        web_api.create_user('emp_one', 'Garage2026', 'Emp', 'One', '', role='employee', company_id=1, path=app.config['INVOICE_DB'])
        e = app.test_client()
        self.assertEqual(e.post('/api/auth/login', json={'username': 'emp_one', 'password': 'Garage2026'}).status_code, 200)
        with patch('ai_agent.route_message', return_value=dict(intent='invoice_query')):
            d = e.post('/api/invoices/generate', json={'text': 'how many'}, headers={'X-CSRF-Token': e.get_cookie('if_csrf').value}).json
        self.assertIn('There are no invoices', d['reply'])
        self.assertIn('Only invoices you created', d['reply'])

    # ---- sending through MA: WhatsApp / email (contacts are never invented) ----
    def test_whatsapp_number_from_message_without_ai(self):
        with patch('ai_agent.route_message', side_effect=AssertionError('not needed')):
            d = self.c.post('/api/invoices/generate', json={'text': 'MA, send this invoice to WhatsApp number 03 123 456'}, headers=self.h).json
        self.assertEqual(d['action'], {'type': 'whatsapp', 'phone': '+9613123456'})
        self.assertIn('+961 3 123 456', d['reply'])

    def test_whatsapp_invented_number_is_rejected_and_ma_asks(self):
        d, _ = self.ask('send it on whatsapp please', dict(intent='send_whatsapp', phone='71 999 888'))
        self.assertNotIn('phone', d['action'])
        self.assertEqual(d['ask'], 'whatsapp')
        # the answer to MA's question is understood without the AI
        hist = [{'role': 'user', 'text': 'send it on whatsapp please'}, {'role': 'assistant', 'text': d['reply'], 'kind': 'answer', 'ask': 'whatsapp'},
                {'role': 'user', 'text': '٧١ ١٢٣ ٤٥٦'}]
        with patch('ai_agent.route_message', side_effect=AssertionError('not needed')):
            d = self.c.post('/api/invoices/generate', json={'text': hist[-1]['text'], 'history': hist}, headers=self.h).json
        self.assertEqual(d['action']['phone'], '+96171123456')

    def test_whatsapp_landline_or_bad_number(self):
        d, _ = self.ask('whatsapp it to 01 234 567', dict(intent='send_whatsapp', phone='01 234 567'))
        self.assertIn("doesn't look like a valid WhatsApp number", d['reply'])
        self.assertNotIn('phone', d['action'])
        self.assertEqual(web_api.normalize_phone('+44 7700 900123'), '+447700900123')
        self.assertEqual(web_api.normalize_phone('0096171123456'), '+96171123456')

    def test_email_spoken_and_invented(self):
        d, _ = self.ask('email this invoice to ali at gmail dot com', dict(intent='send_email', email='ali@gmail.com'))
        self.assertEqual(d['action'], {'type': 'email', 'email': 'ali@gmail.com'})
        d, _ = self.ask('email it to the customer', dict(intent='send_email', email='customer@gmail.com'))
        self.assertEqual(d['ask'], 'email')
        self.assertNotIn('email', d['action'])
        with patch('ai_agent.route_message', side_effect=AssertionError('not needed')):
            d = self.c.post('/api/invoices/generate', json={'text': 'MA, email this invoice to customer@gmail.com.'}, headers=self.h).json
        self.assertEqual(d['action']['email'], 'customer@gmail.com')

    def test_send_numbered_invoice_opens_it(self):
        d, _ = self.ask('send invoice 2 to whatsapp 70 123 456', dict(intent='send_whatsapp', phone='70 123 456', invoice_no='2'))
        self.assertEqual(d['open']['no'], 'INV-0002')
        self.assertEqual(d['action']['phone'], '+96170123456')

    def approve_first(self):
        inv = self.c.get('/api/invoices').json[0]
        self.c.post('/api/invoices/%s/approve' % inv['id'], json={'confirm': True, 'review_digest': inv['review_digest'], 'acknowledge_warnings': True}, headers=self.h)
        return inv['id']

    def test_email_endpoint(self):
        ident = self.c.get('/api/invoices').json[0]['id']
        url = '/api/invoices/%s/email' % ident
        send = lambda **k: self.c.post(url, json=dict(dict(to='customer@gmail.com', confirm=True, request_key='k'*12), **k), headers=self.h)
        self.assertFalse(self.c.get('/api/delivery/config').json['email']['configured'])
        self.assertEqual(send(confirm=False).status_code, 409)       # explicit confirmation required
        self.assertEqual(send().status_code, 409)                     # not approved
        self.approve_first()
        self.assertEqual(send(to='bad').status_code, 422)
        r = send(request_key='a'*12)                                  # no mail server: recorded as failed, never "sent"
        self.assertEqual(r.json['status'], 'failed')
        sent = []
        class FakeSMTP:
            def __init__(self, *a, **k): pass
            def __enter__(self): return self
            def __exit__(self, *a): pass
            def ehlo(self): pass
            def starttls(self, **k): pass
            def login(self, *a): pass
            def send_message(self, m): sent.append(m); return {}
        env = {'SMTP_HOST': 'smtp.test', 'SMTP_USER': 'garage@test.com', 'SMTP_PASSWORD': 'x', 'SMTP_FROM': 'garage@test.com'}
        with patch.dict(os.environ, env), patch('smtplib.SMTP', FakeSMTP):
            self.assertTrue(self.c.get('/api/delivery/config').json['email']['configured'])
            r = send(request_key='b'*12, subject='Invoice INV-0001\r\nBcc: x@y.z', message='Hello from the garage')
        self.assertEqual(r.json['status'], 'sent', r.json)
        m = sent[0]
        self.assertEqual(m['To'], 'customer@gmail.com')
        self.assertNotIn('Bcc', m.keys())                             # no header injection
        self.assertIn('Hello from the garage', m.get_body().get_content())
        self.assertEqual([a.get_filename() for a in m.iter_attachments()], ['INV-0001.pdf'])
        with patch.dict(os.environ, env), patch('smtplib.SMTP', FakeSMTP):
            self.assertEqual(send(request_key='c'*12).status_code, 409)              # same recipient needs resend:true
            self.assertEqual(send(request_key='d'*12, resend=True).json['status'], 'sent')

    def test_pdf_preview_for_pending_and_final_for_approved(self):
        ident = self.c.get('/api/invoices').json[0]['id']
        url = '/api/invoices/%s/pdf' % ident
        self.assertEqual(self.c.get(url).status_code, 409)
        r = self.c.get(url + '?preview=1')
        self.assertTrue(r.data.startswith(b'%PDF'))
        self.assertIn('PREVIEW', r.headers['Content-Disposition'])
        self.approve_first()
        r = self.c.get(url)
        self.assertTrue(r.data.startswith(b'%PDF'))
        self.assertNotIn('PREVIEW', r.headers['Content-Disposition'])


if __name__ == '__main__':
    unittest.main()
