"""An invoice needs a customer name or truck plate/identifier."""
def present(value):
    return isinstance(value, str) and any(c.isalnum() for c in value.strip())

def has_identity(invoice):
    customer = invoice.get('cust')
    truck = invoice.get('truck')
    name = customer.get('name') if isinstance(customer, dict) else invoice.get('customer')
    plate = truck.get('plate') if isinstance(truck, dict) else invoice.get('truck_plate')
    return present(name) or present(plate)
