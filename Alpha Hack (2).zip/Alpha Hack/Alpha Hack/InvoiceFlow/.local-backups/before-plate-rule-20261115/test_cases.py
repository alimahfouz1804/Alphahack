"""TC-01 ... TC-30: the documented software test cases (see TEST_CASES.md).

Each test name starts with its TC id. These exercise the real Flask app, database, PDF code and
delivery code. The AI model (Gemini) and speech-to-text are MOCKED here, so these tests check
the application, not the AI's understanding (that is ai_eval/run_eval.py, which uses the real model).
External providers (SMTP, WhatsApp Cloud API) are mocked; no real message is sent.

Run:  python -m unittest test_cases -v
"""
import hashlib
import io
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault('GEMINI_API_KEY', 'test-only')
from app import app
import web_api

BASE = Path(__file__).parent
SIGNUP = dict(first_name='Karim', last_name='Haddad', username='karim_tc', password='Garage2026',
              phone='+96171123456', company_name='Cedar Truck Garage')


def order(parts, customer='Ahmad', labor=None, **extra):
    return dict(dict(customer=customer, parts=parts, labor_amount=labor, labor_currency='USD' if labor is not None else None,
                     notes='', truck_plate='', truck_model=''), **extra)


def part(name, qty, price=None, currency='USD', **extra):
    return dict(dict(name=name, quantity=qty, quantity_evidence=str(qty), unit_price=price,
                     price_currency=currency if price is not None else None), **extra)


class FakeSMTP:
    sent = []
    fail = False
    def __init__(self, *a, **k): pass
    def __enter__(self): return self
    def __exit__(self, *a): pass
    def ehlo(self): pass
    def starttls(self, **k): pass
    def login(self, *a):
        if FakeSMTP.fail: raise OSError('mail server down')
    def send_message(self, m): FakeSMTP.sent.append(m); return {}


SMTP_ENV = {'SMTP_HOST': 'smtp.test', 'SMTP_USER': 'garage@test.com', 'SMTP_PASSWORD': 'x', 'SMTP_FROM': 'garage@test.com'}


class TestCases(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.config['INVOICE_DB']
        app.config['INVOICE_DB'] = self.temp.name + '/tc.db'
        web_api._failures.clear()
        self.c = app.test_client()
        r = self.c.post('/api/auth/register', json=SIGNUP)
        self.assertEqual(r.status_code, 201, r.json)
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}
        FakeSMTP.sent, FakeSMTP.fail = [], False
        lookup = patch('part_lookup.lookup_part', return_value={'status': 'unavailable', 'question': 'Describe it further.', 'sources': []})
        lookup.start(); self.addCleanup(lookup.stop)

    def tearDown(self):
        app.config['INVOICE_DB'] = self.old_db
        self.temp.cleanup()

    # ---------- helpers ----------
    def ask(self, text, model_order, history=None):
        """One chat message to MA with the AI model mocked to return model_order."""
        with patch('ai_agent.route_message', return_value={'intent': 'invoice', 'language': 'en'}), \
             patch('invoice_engine.understand_message', return_value=model_order) as parse:
            r = self.c.post('/api/invoices/generate', json={'text': text, 'history': history or [{'role': 'user', 'text': text}]}, headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        return r.json, parse

    def save(self, draft):
        r = self.c.post('/api/invoices', json=draft, headers=self.h)
        self.assertEqual(r.status_code, 201, r.json)
        return r.json

    def approve(self, inv):
        inv = self.c.get('/api/invoices/' + inv['id']).json
        return self.c.post('/api/invoices/%s/approve' % inv['id'], json={'confirm': True, 'review_digest': inv['review_digest'], 'acknowledge_warnings': True}, headers=self.h)

    def complete_invoice(self):
        draft, _ = self.ask('Ahmad: 2 oil filters at 25 USD and 1 air filter at 35 USD, labor 30 USD',
                            order([part('oil filter', 2, 25), part('air filter', 1, 35)], labor=30))
        return self.save(draft)

    def node_voice_test(self):
        if not shutil.which('node'):
            self.skipTest('Node.js is not installed: run "node test_voice_ui.cjs" where Node is available')
        r = subprocess.run(['node', 'test_voice_ui.cjs'], cwd=BASE, capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn('PASS', r.stdout)

    # ---------- Voice recording and input ----------
    def test_tc01_start_and_stop_recording(self):
        """Recording lifecycle in app.js with a mocked microphone (MediaRecorder), via Node."""
        self.node_voice_test()

    def test_tc02_preview_recording(self):
        """After stop, the preview is shown and nothing is sent automatically (same Node test)."""
        self.node_voice_test()

    def test_tc03_delete_and_record_again(self):
        """Delete clears blob/URL/duration, a deleted recording cannot be sent, recording again works."""
        self.node_voice_test()

    def test_tc04_submit_voice_recording_to_backend(self):
        with patch('workflow_routes.transcribe_audio', return_value='Ahmad 2 oil filters at 25 dollars each') as stt:
            r = self.c.post('/api/transcribe', data={'audio': (io.BytesIO(b'webm-audio-bytes'), 'recording.webm')}, content_type='multipart/form-data', headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json['transcript'], 'Ahmad 2 oil filters at 25 dollars each')
        self.assertEqual(stt.call_args[0][0], b'webm-audio-bytes')            # the real audio bytes reach the transcriber
        self.assertEqual(self.c.post('/api/transcribe', data={}, content_type='multipart/form-data', headers=self.h).status_code, 400)
        anon = app.test_client().post('/api/transcribe', data={'audio': (io.BytesIO(b'x'), 'x.webm')}, content_type='multipart/form-data')
        self.assertEqual(anon.status_code, 401)                                          # login required
        big = io.BytesIO(b'0' * (10 * 1024 * 1024 + 1))
        self.assertEqual(self.c.post('/api/transcribe', data={'audio': (big, 'x.webm')}, content_type='multipart/form-data', headers=self.h).status_code, 413)

    def test_tc05_submit_written_request(self):
        d, parse = self.ask('Ahmad: 2 oil filters at 25 USD', order([part('oil filter', 2, 25)]))
        self.assertIn('Ahmad: 2 oil filters at 25 USD', parse.call_args[0][0])
        self.assertEqual(d['items'][0]['d'], 'Oil Filter')

    # ---------- AI and catalog integration ----------
    def test_tc06_agent_processes_request(self):
        d, _ = self.ask('x', order([part('fuel filter', 1, 30)], labor=20))
        self.assertEqual(d['status'], 'draft')
        self.assertEqual([i['d'] for i in d['items']], ['Fuel Filter', 'Labor'])
        self.assertIn('review', d)

    def test_tc07_exact_catalog_match(self):
        d, _ = self.ask('x', order([part('فلتر زيت', 1, 25)]))
        self.assertEqual(d['items'][0]['catalog_id'], 'P003')
        self.assertFalse(d['items'][0]['is_custom'])

    def test_tc08_multiple_possible_matches(self):
        o = order([part('starting part', 1, 200, match_type='description', description='makes the truck start', candidate_ids=['P008', 'P010'])])
        d, _ = self.ask('x', o)
        self.assertNotIn('items', d)                                                     # no invoice until confirmed
        self.assertEqual([c['id'] for c in d['suggestions'][0]['candidates']], ['P008', 'P010'])
        self.assertIn('confirmation_token', d)

    def test_tc09_unknown_item_custom_description(self):
        d, _ = self.ask('x', order([part('hose coupling thing', 2, 8)]))
        self.assertIn('what name would you like to display on the invoice', d['question'].lower())
        sel = {'0': {'custom': True, 'name': 'Hose coupling', 'quantity': 2, 'unit_price': 8, 'currency': 'USD'}}
        r = self.c.post('/api/invoices/confirm-parts', json={'confirmation_token': d['confirmation_token'], 'selections': sel, 'confirm': True}, headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual((r.json['items'][0]['d'], r.json['items'][0]['is_custom'], r.json['totals']['total_usd']), ('Hose coupling', True, 16))

    def test_tc10_custom_item_not_added_to_catalog(self):
        before = hashlib.sha256((BASE / 'products.json').read_bytes()).hexdigest()
        self.test_tc09_unknown_item_custom_description()
        inv = self.save(dict(cust={'name': 'Ahmad'}, items=[{'d': 'Hose coupling', 'q': 2, 'p': 8}]))
        self.assertEqual(self.approve(inv).status_code, 200)
        self.assertEqual(before, hashlib.sha256((BASE / 'products.json').read_bytes()).hexdigest())
        self.assertNotIn('Hose coupling', [c[0] for c in self.c.get('/api/catalog').json])

    def test_tc11_context_preserved_across_messages(self):
        hist = [{'role': 'user', 'text': 'The customer is Ahmad.'},
                {'role': 'assistant', 'text': 'Which parts were replaced?', 'kind': 'question'},
                {'role': 'user', 'text': 'Brake pads set for the Mercedes.'},
                {'role': 'assistant', 'text': 'How many?', 'kind': 'question'},
                {'role': 'user', 'text': 'Quantity 2.'},
                {'role': 'assistant', 'text': 'What is the price?', 'kind': 'question'},
                {'role': 'user', 'text': '$35 each.'}]
        d, parse = self.ask(hist[-1]['text'], order([part('brake pads', 2, 35)], customer='Ahmad'), hist)
        sent = parse.call_args[0][0]
        for t in ('The customer is Ahmad.', 'Brake pads set for the Mercedes.', 'Quantity 2.', '$35 each.'):
            self.assertIn(t, sent)                                                       # every earlier message reaches the model
        self.assertEqual((d['cust']['name'], d['items'][0]['q'], d['totals']['total_usd']), ('Ahmad', 2, 70))
        # a new invoice after an answered question does not inherit the old conversation
        hist2 = hist + [{'role': 'assistant', 'text': 'Done.', 'kind': 'answer'}, {'role': 'user', 'text': 'New customer Samir: 1 radiator 350'}]
        _, parse = self.ask(hist2[-1]['text'], order([part('radiator', 1, 350)], customer='Samir'), hist2)
        self.assertNotIn('Ahmad', parse.call_args[0][0])
        # "new invoice" typed in the same chat (no answered question in between) also starts fresh
        hist3 = hist + [{'role': 'assistant', 'text': 'Your invoice is ready.', 'kind': 'draft'}, {'role': 'user', 'text': 'New invoice: customer Samir, 1 radiator 350 USD'}]
        d3, parse = self.ask(hist3[-1]['text'], order([part('radiator', 1, 350)], customer='Samir'), hist3)
        self.assertNotIn('Ahmad', parse.call_args[0][0])
        self.assertTrue(d3['new_invoice'])

    def test_tc22b_local_phone_numbers_normalized(self):
        d, _ = self.ask('x', order([part('air filter', 1, 35)], customer='Rita', customer_phone='71 234 567'))
        self.assertEqual(d['cust']['tel'], '+96171234567')
        d, _ = self.ask('x', order([part('air filter', 1, 35)], customer='Rita', customer_phone='03 123 456'))
        self.assertEqual(d['cust']['tel'], '+9613123456')

    def test_tc12_clarification_for_ambiguous_item(self):
        d, _ = self.ask('x', order([part('engine oil', 1, 40)]))
        self.assertNotIn('items', d)                                                     # never guesses 5L vs 20L
        self.assertTrue(d.get('question'))

    # ---------- Validation and calculations ----------
    def test_tc13_missing_quantity(self):
        d, _ = self.ask('x', order([part('oil filter', 0, 25)]))
        self.assertNotIn('items', d)
        self.assertIn('how many', d['question'].lower())

    def test_tc14_missing_unit_price(self):
        d, _ = self.ask('x', order([part('oil filter', 2, None)]))
        self.assertIsNone(d['items'][0]['p'])                                            # never filled with 0 or a catalog price
        self.assertIsNone(d['totals']['total_usd'])
        self.assertIn('unit_price', [m['field'] for m in d['review']['missing']])
        self.assertFalse(d['review']['ready'])

    def test_tc15_line_total(self):
        _, totals = web_api.compute({'items': [{'d': 'Oil Filter', 'q': 3, 'p': 12.5}]}, web_api.Decimal('0'))
        items, _ = web_api.compute({'items': [{'d': 'Oil Filter', 'q': 3, 'p': 12.5}]}, web_api.Decimal('0'))
        self.assertEqual(items[0]['total_usd'], 37.5)

    def test_tc16_subtotal_and_final_total(self):
        inv = self.complete_invoice()
        t = inv['totals']
        self.assertEqual(t['total_usd'], sum(i['total_usd'] for i in inv['items']))      # total = sum of line totals
        self.assertEqual((t['total_usd'], t['total_lbp'], t['exchange_rate']), (115, 115 * 89500, 89500))

    def test_tc17_duplicate_item_flagged(self):
        d, _ = self.ask('x', order([part('oil filter', 1, 25), part('oil filter', 1, 25)]))
        self.assertEqual(d['review']['duplicates'], ['Oil Filter'])                     # flagged for review, never silently merged

    def test_tc18_edit_and_remove_items(self):
        inv = self.complete_invoice()
        items = [i for i in inv['items'] if i['d'] != 'Air Filter']                        # remove one line
        items[0]['q'] = 4                                                                # change a quantity
        r = self.c.put('/api/invoices/' + inv['id'], json=dict(inv, items=items), headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(([i['d'] for i in r.json['items']], r.json['totals']['total_usd']), (['Oil Filter', 'Labor'], 130))

    def test_tc19_incomplete_invoice_cannot_be_approved(self):
        inv = self.save(dict(cust={'name': 'Ahmad'}, items=[{'d': 'Oil Filter', 'q': 2, 'p': None}]))
        self.assertEqual(self.approve(inv).status_code, 409)
        inv2 = self.save(dict(cust={'name': ''}, truck={'plate': ''}, items=[{'d': 'Oil Filter', 'q': 2, 'p': 25}]))
        self.assertEqual(self.approve(inv2).status_code, 409)                            # no customer and no truck

    def test_tc20_explicit_approval_required(self):
        inv = self.complete_invoice()
        self.assertEqual(inv['status'], 'pending')                                       # never approved automatically
        url = '/api/invoices/%s/approve' % inv['id']
        self.assertEqual(self.c.post(url, json={'review_digest': inv['review_digest']}, headers=self.h).status_code, 409)
        self.assertEqual(self.c.post(url, json={'confirm': True, 'review_digest': 'stale'}, headers=self.h).status_code, 409)
        self.assertEqual(self.approve(inv).json['status'], 'approved')

    # ---------- Customers and database ----------
    def test_tc21_existing_customer_lookup(self):
        self.c.post('/api/customers', json={'name': 'Ahmad Khalil', 'tel': '+96171123456'}, headers=self.h)
        names = [c['name'] for c in self.c.get('/api/customers').json]
        self.assertIn('Ahmad Khalil', names)

    def test_tc22_new_customer_creation(self):
        r = self.c.post('/api/customers', json={'name': 'Samir Haddad', 'tel': '+96170999888', 'email': 'samir@example.com'}, headers=self.h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json['email'], 'samir@example.com')
        self.assertEqual(self.c.post('/api/customers', json={'name': ''}, headers=self.h).status_code, 422)

    def test_tc23_duplicate_customer_prevention(self):
        a = self.c.post('/api/customers', json={'name': 'Ahmad', 'tel': '+96171123456'}, headers=self.h).json
        b = self.c.post('/api/customers', json={'name': ' ahmad ', 'tel': '+96171123456'}, headers=self.h).json
        self.assertEqual(a['id'], b['id'])
        other = self.c.post('/api/customers', json={'name': 'Ahmad', 'tel': '+96170111222'}, headers=self.h).json
        self.assertNotEqual(a['id'], other['id'])                                         # namesakes are not merged

    def test_tc24_approved_invoice_persists_after_restart(self):
        inv = self.complete_invoice()
        self.approve(inv)
        pdf = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        # a separate Python process opens the same database file, like a restarted server
        code = ("import sqlite3,json,hashlib,sys;db=sqlite3.connect(sys.argv[1]);"
                "r=db.execute('SELECT no,status,payload FROM web_invoices').fetchone();"
                "f=db.execute('SELECT sha256 FROM invoice_files').fetchone();"
                "print(json.dumps([r[0],r[1],json.loads(r[2])['totals']['total_usd'],f[0]]))")
        out = subprocess.run([sys.executable, '-c', code, app.config['INVOICE_DB']], capture_output=True, text=True, timeout=60)
        no, status, total, sha = json.loads(out.stdout)
        self.assertEqual((no, status, total, sha), (inv['no'], 'approved', 115, hashlib.sha256(pdf).hexdigest()))

    # ---------- PDF and invoice history ----------
    def test_tc25_pdf_generation(self):
        inv = self.complete_invoice()
        self.assertTrue(self.c.get('/api/invoices/%s/pdf?preview=1' % inv['id']).data.startswith(b'%PDF'))   # pending preview
        self.assertEqual(self.c.get('/api/invoices/%s/pdf' % inv['id']).status_code, 409)                   # no final PDF yet
        self.approve(inv)
        with web_api.connect(app.config['INVOICE_DB']) as db:
            stored = bytes(db.execute('SELECT pdf FROM invoice_files WHERE invoice_id=?', (inv['id'],)).fetchone()['pdf'])
        self.assertTrue(stored.startswith(b'%PDF') and len(stored) > 2000)

    def test_tc26_invoice_in_history(self):
        inv = self.complete_invoice()
        self.approve(inv)
        h = [x for x in self.c.get('/api/invoices').json if x['id'] == inv['id']][0]
        self.assertEqual((h['status'], h['no'], h['delivery']), ('approved', inv['no'], {'email': 'not_sent', 'whatsapp': 'not_sent'}))

    def test_tc27_pdf_download_is_the_approved_pdf(self):
        inv = self.complete_invoice()
        self.approve(inv)
        a = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        b = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        self.assertEqual(a, b)                                                           # same stored bytes every time
        stranger = app.test_client()
        self.assertEqual(stranger.get('/api/invoices/%s/pdf' % inv['id']).status_code, 401)
        stranger.post('/api/auth/register', json=dict(SIGNUP, username='other_co', company_name='Other'))
        self.assertEqual(stranger.get('/api/invoices/%s/pdf' % inv['id']).status_code, 404)   # other company cannot read it

    def test_tc28_printing(self):
        inv = self.complete_invoice()
        self.assertEqual(self.c.post('/api/invoices/%s/print' % inv['id'], json={}, headers=self.h).status_code, 409)
        self.approve(inv)
        r = self.c.get('/api/invoices/%s/pdf?inline=1' % inv['id'])
        self.assertTrue(r.headers['Content-Disposition'].startswith('inline'))
        p = self.c.post('/api/invoices/%s/print' % inv['id'], json={}, headers=self.h).json
        self.assertEqual(p, {'status': 'initiated', 'physical_print_confirmed': False})
        page = self.c.get('/print.html'); self.assertEqual(page.status_code, 200); page.close()

    # ---------- External delivery and reliability ----------
    def test_tc29_whatsapp_and_email_delivery_handling(self):
        inv = self.complete_invoice()
        self.approve(inv)
        url = '/api/invoices/%s/' % inv['id']
        send = lambda m, key, **k: self.c.post(url + m, json=dict(dict(to='customer@example.com' if m == 'email' else '+96171123456', confirm=True, request_key=key * 10), **k), headers=self.h).json
        # not configured: honest failure, never "sent"
        self.assertEqual(send('email', 'a')['status'], 'failed')
        self.assertEqual(send('whatsapp', 'b')['status'], 'failed')
        with patch.dict(os.environ, SMTP_ENV), patch('smtplib.SMTP', FakeSMTP):
            FakeSMTP.fail = True
            self.assertEqual(send('email', 'c')['status'], 'failed')                       # provider failure recorded
            FakeSMTP.fail = False
            ok = send('email', 'd')                                                       # retry with a new request key
            self.assertEqual(ok['status'], 'sent')
            self.assertFalse(ok['delivery_confirmed'])                                    # accepted, not confirmed delivered
            again = self.c.post(url + 'email', json=dict(to='customer@example.com', confirm=True, request_key='e' * 10), headers=self.h)
            self.assertEqual(again.status_code, 409)                                      # resend must be explicit
        self.assertEqual([a.get_filename() for a in FakeSMTP.sent[0].iter_attachments()], [inv['no'] + '.pdf'])
        pdf = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        self.assertEqual(FakeSMTP.sent[0].get_payload()[1].get_payload(decode=True), pdf)  # the same approved PDF is emailed
        h = self.c.post(url + 'handoff', json={'method': 'whatsapp', 'to': '+96171123456'}, headers=self.h).json
        self.assertEqual(h['status'], 'opened')                                           # wa.me hand-off is not "sent"
        statuses = [(d['method'], d['status']) for d in self.c.get(url + 'activity').json['deliveries']]
        self.assertIn(('email', 'sent'), statuses); self.assertIn(('whatsapp', 'failed'), statuses); self.assertIn(('whatsapp', 'opened'), statuses)

    def test_tc30_end_to_end(self):
        with patch('workflow_routes.transcribe_audio', return_value='Ahmad 2 oil filters 25 dollars each, labor 30'):
            text = self.c.post('/api/transcribe', data={'audio': (io.BytesIO(b'voice'), 'v.webm')}, content_type='multipart/form-data', headers=self.h).json['transcript']
        draft, _ = self.ask(text, order([part('oil filter', 2, 25)], labor=30))           # voice -> MA -> draft
        self.assertTrue(draft['review']['ready'])
        inv = self.save(dict(draft, client_request_id='req-e2e-1'))
        again = self.c.post('/api/invoices', json=dict(draft, client_request_id='req-e2e-1'), headers=self.h)
        self.assertEqual(again.json['id'], inv['id'])                                     # double click does not duplicate
        self.assertEqual(self.approve(inv).json['status'], 'approved')
        pdf = self.c.get('/api/invoices/%s/pdf' % inv['id']).data
        self.assertTrue(pdf.startswith(b'%PDF'))
        self.assertIn(inv['id'], [x['id'] for x in self.c.get('/api/invoices').json])
        with patch.dict(os.environ, SMTP_ENV), patch('smtplib.SMTP', FakeSMTP):
            r = self.c.post('/api/invoices/%s/email' % inv['id'], json={'to': 'customer@example.com', 'confirm': True, 'request_key': 'e2e-email-1'}, headers=self.h).json
        self.assertEqual(r['status'], 'sent')
        self.assertEqual(len(self.c.get('/api/invoices').json), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)


class EvalFixTests(unittest.TestCase):
    """Rules added after the first live AI evaluation (34/60)."""
    def run_engine(self, message, parts, **extra):
        from unittest.mock import patch
        from invoice_engine import create_invoice
        order = {'customer_name': 'X', 'customer_phone': '', 'plate_number': '', 'parts': parts,
                 'labor_amount': None, 'labor_currency': None, **extra}
        with patch('invoice_engine.understand_message', return_value=order):
            return create_invoice(message)

    def test_price_without_currency_is_usd(self):
        r = self.run_engine('brake disc 160', [dict(name='brake disc', quantity=1, quantity_evidence='1', unit_price=160, price_currency=None)])
        self.assertEqual(r['items'][0]['price_usd'], '160')
        self.assertTrue(any('assumed USD' in w for w in r['warnings']))

    def test_huge_price_without_currency_is_lbp(self):
        r = self.run_engine('oil filter 2,000,000', [dict(name='oil filter', quantity=1, unit_price=2000000, price_currency=None)])
        self.assertEqual(r['items'][0]['price_lbp'], '2000000')

    def test_labor_without_currency_is_usd(self):
        r = self.run_engine('labor 50', [dict(name='oil filter', quantity=1, unit_price=10, price_currency='USD')], labor_amount=50)
        self.assertEqual(r['labor_currency'], 'USD')

    def test_unsaid_oil_size_asks(self):
        r = self.run_engine('changed engine oil, 1 container at 40 USD',
                            [dict(name='Engine Oil 5L', original_name='engine oil', quantity=1, unit_price=40, price_currency='USD')])
        self.assertFalse(r['items'])
        ids = {c['id'] for s in r['suggestions'] for c in s['candidates']}
        self.assertTrue({'P001', 'P002'} <= ids)

    def test_vague_filter_asks(self):
        r = self.run_engine('changed the filter, 1 at 30',
                            [dict(name='Oil Filter', original_name='the filter', quantity=1, unit_price=30, price_currency='USD')])
        self.assertFalse(r['items'])
        self.assertGreater(len(r['suggestions'][0]['candidates']), 1)

    def test_another_counts_as_one(self):
        from ai_agent import has_quantity_evidence
        self.assertTrue(has_quantity_evidence({'quantity': 1, 'quantity_evidence': 'another'}, '1 oil filter 25, and another oil filter 25'))


class CancelTests(unittest.TestCase):
    def test_cancel_draft_needs_no_ai(self):
        import web_api, re
        self.assertTrue(web_api.CANCEL_RE.search('cancel this invoice'))
        self.assertTrue(web_api.CANCEL_RE.search('الغيها'))
        self.assertFalse(web_api.CANCEL_RE.search('customer Rami 1 oil filter 25'))


class PersonaTests(unittest.TestCase):
    def test_ma_identity_in_router_prompt(self):
        import ai_agent
        ROUTER_PROMPT = ' '.join(ai_agent.ROUTER_PROMPT.split())
        self.assertIn("Hi, I'm MA, your AI assistant. I'm here to help you understand, organize, and complete your tasks.", ROUTER_PROMPT)
        self.assertIn('Lebanese Arabic', ROUTER_PROMPT)
        self.assertIn('normal conversation', ROUTER_PROMPT)
        self.assertIn('do not repeat the same opening', ROUTER_PROMPT)


class LiveProgressTests(unittest.TestCase):
    """The invoice screen shows MA's real steps: streamed as NDJSON with ?progress=1."""
    def setUp(self):
        import tempfile
        from app import app
        self.app, self.tmp = app, tempfile.TemporaryDirectory()
        self.old = app.config.get('INVOICE_DB'); app.config['INVOICE_DB'] = self.tmp.name + '/p.db'
        self.c = app.test_client()
        self.c.post('/api/auth/register', json=dict(first_name='Karim', last_name='Haddad', username='karim_p', password='Garage2026', phone='+96171123456', company_name='Cedar'))
        self.h = {'X-CSRF-Token': self.c.get_cookie('if_csrf').value}

    def tearDown(self):
        self.app.config['INVOICE_DB'] = self.old; self.tmp.cleanup()

    def stream(self, text, route, order=None, exc=None):
        import json
        from unittest.mock import patch
        kw = {'side_effect': exc} if exc else {'return_value': order}
        with patch('ai_agent.route_message', return_value=route), patch('invoice_engine.understand_message', **kw):
            r = self.c.post('/api/invoices/generate?progress=1', json={'text': text}, headers=self.h)
            self.assertEqual(r.mimetype, 'application/x-ndjson')
            return [json.loads(l) for l in r.data.decode().splitlines()]

    def test_steps_then_the_same_draft_as_without_progress(self):
        order = dict(customer='Ali', parts=[dict(name='oil filter', quantity=2, quantity_evidence='2', unit_price=25, price_currency='USD')],
                     labor_amount=30, labor_currency='USD', notes='', truck_plate='', truck_model='')
        ev = self.stream('Ali 2 oil filters 25 each labor 30', {'intent': 'invoice'}, order)
        keys = [e['key'] for e in ev if e['type'] == 'step']
        self.assertEqual(keys, ['start', 'intent', 'extract', 'customer', 'item', 'check', 'totals'])
        item = next(e for e in ev if e.get('key') == 'item')['item']
        self.assertEqual((item['d'], item['q'], item['p']), ('Oil Filter', 2, 25.0))
        self.assertEqual(ev[-1]['type'], 'result'); self.assertEqual(ev[-1]['status'], 200)
        self.assertEqual(ev[-1]['body']['totals']['total_usd'], 80)
        self.assertTrue(all(e['ar'] and e['en'] for e in ev if e['type'] == 'step'))

    def test_answers_and_errors_are_streamed_too(self):
        from ai_agent import GeminiUnavailable
        ev = self.stream('hi', {'intent': 'chat', 'reply': 'Hello!'})
        self.assertEqual(ev[-1]['body']['reply'], 'Hello!')
        self.assertEqual([e['key'] for e in ev if e['type'] == 'step'], ['start', 'intent'])
        ev = self.stream('Ali 2 oil filters', {'intent': 'invoice'}, exc=GeminiUnavailable('busy'))
        self.assertEqual(ev[-1]['status'], 503)

    def test_no_csrf_is_refused_before_streaming(self):
        r = self.c.post('/api/invoices/generate?progress=1', json={'text': 'x'})
        self.assertEqual(r.status_code, 403); self.assertNotEqual(r.mimetype, 'application/x-ndjson')
