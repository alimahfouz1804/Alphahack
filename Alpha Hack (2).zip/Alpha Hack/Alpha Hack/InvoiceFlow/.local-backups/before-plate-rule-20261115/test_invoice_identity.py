import sys,json,unittest
sys.path.insert(0,r'C:\Users\aliab\OneDrive\Documents\Alpha Hack\InvoiceFlow')
from unittest.mock import patch
from test_web import WebTests,ORDER
from invoice_engine import create_invoice
import web_api,approval_store
from app import app

class IdentityTests(WebTests):
    def test_identity_alternatives(self):
        for name,plate in [('Demo',''),('','DEMO001'),('Demo','DEMO001')]:
            c=self.client(dict(__import__('test_web').SIGNUP,username='user_'+str(len(name))+str(len(plate))))
            h=self.csrf(c)
            with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer=name,truck_plate=plate)):
                draft=c.post('/api/invoices/generate',json={'text':'test'},headers=h).json
            self.assertIn('items',draft)
            self.assertNotIn('Customer name is missing',draft['warnings'])
            saved=c.post('/api/invoices',json=draft,headers=h).json
            path='/api/invoices/'+saved['id']
            self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,200)
            self.assertEqual(c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h).status_code,200)

    def test_missing_identity_cannot_bypass_server(self):
        c=self.client(); h=self.csrf(c)
        with patch('invoice_engine.understand_message',return_value=dict(ORDER,customer='',truck_plate='')):
            draft=c.post('/api/invoices/generate',json={'text':'غيرنا فلتر زيت'},headers=h).json
            legacy=create_invoice('test')
        self.assertIn('اسم الزبون',draft['question'])
        self.assertTrue(legacy['incomplete'])
        saved=approval_store.save_draft(legacy,app.config['INVOICE_DB'])
        self.assertEqual(approval_store.approve(saved['invoice_id'],saved['review_digest'],'tester',True,app.config['INVOICE_DB']),409)
        for name,plate in [('', ''),('   ','  '),('—','-')]:
            saved=c.post('/api/invoices',json={'cust':{'name':name},'truck':{'plate':plate},'items':[{'d':'Oil Filter','q':1,'p':25}]},headers=h).json
            path='/api/invoices/'+saved['id']
            self.assertEqual(c.post(path+'/submit',json={},headers=h).status_code,409)
            with web_api.connect(app.config['INVOICE_DB']) as db:
                db.execute("UPDATE web_invoices SET status='pending' WHERE id=?",(saved['id'],))
            self.assertEqual(c.post(path+'/approve',json={'confirm':True,'review_digest':saved['review_digest'],'acknowledge_warnings':True},headers=h).status_code,409)
            with web_api.connect(app.config['INVOICE_DB']) as db:
                db.execute("UPDATE web_invoices SET status='approved' WHERE id=?",(saved['id'],))
            self.assertEqual(c.get(path+'/pdf').status_code,409)

if __name__=='__main__': unittest.main()
