import io, os, tempfile, unittest, wave
from unittest.mock import patch, Mock
os.environ.setdefault('GEMINI_API_KEY','test-only')
from app import app
import approval_store as store
from voice_agent import transcribe_audio, Transcript
from ai_agent import client, GeminiUnavailable

ORDER=dict(customer='علي',parts=[dict(name='oil filter',quantity=2,unit_price=25,price_currency='USD'),dict(name='fuel filter',quantity=1,unit_price=30,price_currency='USD')],labor_amount=30,labor_currency='USD',notes='مراجعة بعد أسبوع')

def wav_bytes():
    out=io.BytesIO()
    with wave.open(out,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(b'\0\0'*160)
    return out.getvalue()

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.old=app.config['INVOICE_DB']; app.config['INVOICE_DB']=self.temp.name+'/test.db'
        self.db=app.config['INVOICE_DB']; self.c=app.test_client()
        store.create_employee('tester','a-test-password-only',self.db)
        login=self.c.post('/api/auth/login',json={'username':'tester','password':'a-test-password-only'})
        self.headers={'Authorization':'Bearer '+login.json['token']}
    def tearDown(self):
        app.config['INVOICE_DB']=self.old; self.temp.cleanup()
    def draft(self):
        with patch('invoice_engine.understand_message',return_value=ORDER):
            r=self.c.post('/api/invoice/draft',json={'message':'test','approved':True})
        self.assertEqual(r.status_code,200); return r.json
    def test_complete_approval_pdf(self):
        d=self.draft(); route='/api/invoices/'+d['invoice_id']; self.assertFalse(d['approved'])
        self.assertEqual(self.c.get(route+'/pdf').status_code,401)
        self.assertEqual(self.c.get(route+'/pdf',headers=self.headers).status_code,409)
        preview=self.c.get(route+'/pdf?preview=true',headers=self.headers)
        self.assertEqual(preview.status_code,200); self.assertTrue(preview.data.startswith(b'%PDF'))
        self.assertEqual(self.c.post(route+'/approve',json={'confirm':True,'review_digest':'wrong'},headers=self.headers).status_code,409)
        approved=self.c.post(route+'/approve',json={'confirm':True,'review_digest':d['review_digest'],'subtotal_usd':'0'},headers=self.headers)
        self.assertEqual(approved.status_code,200); self.assertEqual(approved.json['subtotal_usd'],'110.00')
        result=self.c.get(route+'/pdf',headers=self.headers)
        self.assertEqual(result.status_code,200); self.assertTrue(result.data.startswith(b'%PDF'))
        self.assertEqual(store.get_invoice(d['invoice_id'],self.db)['approved_by'],'tester')
        with store.connect(self.db) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM audit').fetchone()[0],2)
    def test_voice_arabic_and_english(self):
        for text in ['غيرنا فلتر زيت عدد اتنين وفلتر مازوت وأجرة 30 دولار','Changed two oil filters and one fuel filter. Labor 30 USD.']:
            with patch('workflow_routes.transcribe_audio',return_value=text),patch('invoice_engine.understand_message',return_value=ORDER):
                r=self.c.post('/api/transcribe',data={'audio':(io.BytesIO(wav_bytes()),'voice.wav'),'generate_invoice':'true'},headers=self.headers)
            self.assertEqual(r.status_code,200); self.assertEqual(r.json['transcript'],text)
            self.assertEqual(r.json['invoice']['subtotal_usd'],'110.00'); self.assertFalse(r.json['invoice']['approved'])
    def test_transcription_only(self):
        with patch('workflow_routes.transcribe_audio',return_value='hello'):
            r=self.c.post('/api/transcribe',data={'audio':(io.BytesIO(wav_bytes()),'voice.wav')},headers=self.headers)
        self.assertEqual(r.json,{'transcript':'hello'})

    def test_unpriced_voice_draft_cannot_be_approved(self):
        order = dict(ORDER, parts=[dict(name='oil filter', quantity=2)], labor_amount=None, labor_currency=None)
        with patch('workflow_routes.transcribe_audio', return_value='Two oil filters'), patch('invoice_engine.understand_message', return_value=order):
            r = self.c.post('/api/transcribe', data={'audio': (io.BytesIO(wav_bytes()), 'voice.wav'), 'generate_invoice': 'true'},headers=self.headers)
        self.assertEqual(r.status_code, 200)
        draft = r.json['invoice']
        self.assertIsNone(draft['items'][0]['price_usd'])
        self.assertIsNone(draft['subtotal_usd'])
        route = '/api/invoices/'+draft['invoice_id']
        self.assertEqual(self.c.post(route+'/approve', json={'confirm':True,'review_digest':draft['review_digest'],'acknowledge_warnings':True}, headers=self.headers).status_code,409)
        preview = self.c.get(route+'/pdf?preview=true', headers=self.headers)
        self.assertEqual(preview.status_code, 200)
        self.assertTrue(preview.data.startswith(b'%PDF'))
    def test_invalid_uploads(self):
        self.assertEqual(self.c.post('/api/transcribe',headers=self.headers).status_code,400)
        for content in [b'',b'not an audio file']:
            self.assertEqual(self.c.post('/api/transcribe',data={'audio':(io.BytesIO(content),'fake.wav')},headers=self.headers).status_code,400)
        from werkzeug.test import EnvironBuilder
        builder=EnvironBuilder(path='/api/transcribe',method='POST',headers=self.headers,data={'audio':(io.BytesIO(b'x'*(10*1024*1024+1)),'large.wav')})
        environ=builder.get_environ()
        try:
            self.assertEqual(self.c.open(environ).status_code,413)
        finally:
            environ['wsgi.input'].close()
            builder.close()
    def test_transcription_failure(self):
        with patch('workflow_routes.transcribe_audio',side_effect=GeminiUnavailable('private details')):
            r=self.c.post('/api/transcribe',data={'audio':(io.BytesIO(wav_bytes()),'voice.wav')},headers=self.headers)
        self.assertEqual(r.status_code,503); self.assertNotIn('private',r.get_data(as_text=True))
    def test_no_speech(self):
        with patch.object(client.models,'generate_content',return_value=Mock(parsed=Transcript(text=''))):
            with self.assertRaises(ValueError): transcribe_audio(wav_bytes())
    def test_warning_acknowledgment(self):
        d=store.save_draft({**self.draft(),'warnings':['Customer name is missing']},self.db)
        route='/api/invoices/'+d['invoice_id']+'/approve'
        self.assertEqual(self.c.post(route,json={'confirm':True,'review_digest':d['review_digest']},headers=self.headers).status_code,409)
        self.assertEqual(self.c.post(route,json={'confirm':True,'review_digest':d['review_digest'],'acknowledge_warnings':True},headers=self.headers).status_code,200)
    def test_logout_and_expiry(self):
        d=self.draft(); route='/api/invoices/'+d['invoice_id']
        self.c.post('/api/auth/logout',headers=self.headers)
        self.assertEqual(self.c.get(route,headers=self.headers).status_code,401)
        session=self.c.post('/api/auth/login',json={'username':'tester','password':'a-test-password-only'})
        self.headers={'Authorization':'Bearer '+session.json['token']}
        with store.connect(self.db) as db: db.execute('UPDATE sessions SET expires=0')
        self.assertEqual(self.c.get(route,headers=self.headers).status_code,401)
    def test_login_throttle(self):
        for _ in range(5): self.assertEqual(self.c.post('/api/auth/login',json={'username':'tester','password':'wrong'}).status_code,401)
        self.assertEqual(self.c.post('/api/auth/login',json={'username':'tester','password':'wrong'}).status_code,429)
    def test_transcription_fallback(self):
        from google.genai import errors
        with patch.object(client.models,'generate_content',side_effect=[errors.APIError(503,{}),Mock(parsed=Transcript(text='hello'))]) as call:
            self.assertEqual(transcribe_audio(wav_bytes()),'hello')
            self.assertEqual(call.call_count,2)

    def test_password_reset_revokes_sessions(self):
        store.create_employee('tester','another-test-password',self.db)
        self.assertEqual(self.c.get('/api/invoices/missing',headers=self.headers).status_code,401)

    def test_missing_invoice_and_confirmation(self):
        self.assertEqual(self.c.get('/api/invoices/missing',headers=self.headers).status_code,404)
        d=self.draft()
        self.assertEqual(self.c.post('/api/invoices/'+d['invoice_id']+'/approve',json={'review_digest':d['review_digest']},headers=self.headers).status_code,400)

if __name__=='__main__': unittest.main()
