"""Business workflow regression tests. Provider calls are mocks, not real sends."""
import copy
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
os.environ.setdefault('GEMINI_API_KEY','test-only')
from app import app
from test_web import SIGNUP
import web_api
import delivery_providers


class MasterTests(unittest.TestCase):
    def setUp(self):
        from test_part_lookup import fixture_lookup
        lookup_mock=patch('part_lookup.lookup_part',side_effect=fixture_lookup);lookup_mock.start();self.addCleanup(lookup_mock.stop)
        self.tmp=tempfile.TemporaryDirectory();self.old=app.config['INVOICE_DB'];app.config['INVOICE_DB']=self.tmp.name+'/test.db'
        self.c=app.test_client();self.c.post('/api/auth/register',json=SIGNUP)
        self.h={'X-CSRF-Token':self.c.get_cookie('if_csrf').value}
        self.data={'cust':{'name':'Elie','email':'elie@example.test','tel':'+96171123456'},'truck':{},
                   'items':[{'d':'Coupling','q':2,'p':8,'is_custom':True}], 'client_request_id':'test-save-123'}
    def tearDown(self):
        app.config['INVOICE_DB']=self.old;self.tmp.cleanup()
    def save(self,data=None):
        r=self.c.post('/api/invoices',json=data or self.data,headers=self.h);self.assertIn(r.status_code,(200,201),r.json);return r.json
    def approve(self,inv):
        path='/api/invoices/'+inv['id']
        self.assertEqual(self.c.post(path+'/submit',json={},headers=self.h).status_code,200)
        return self.c.post(path+'/approve',json={'confirm':True,'review_digest':inv['review_digest'],'acknowledge_warnings':True},headers=self.h)
    def test_immutable_pdf_history_and_customer(self):
        d=self.save();r=self.approve(d);self.assertEqual(r.status_code,200,r.json)
        pdf=self.c.get('/api/invoices/'+d['id']+'/pdf').data
        self.assertTrue(pdf.startswith(b'%PDF'));self.assertEqual(r.json['totals']['total_usd'],16)
        with web_api.connect(app.config['INVOICE_DB']) as db:
            db.execute("UPDATE companies SET name='Changed shop'")
            self.assertEqual(db.execute('SELECT COUNT(*) FROM invoice_files').fetchone()[0],1)
        self.assertEqual(pdf,self.c.get('/api/invoices/'+d['id']+'/pdf').data)
        c=app.test_client();c.post('/api/auth/login',json={'username':SIGNUP['username'],'password':SIGNUP['password']})
        self.assertEqual(c.get('/api/invoices').json[0]['id'],d['id'])
        self.assertEqual(c.get('/api/invoices/'+d['id']+'/pdf').data,pdf)
        self.assertEqual(c.get('/api/customers').json[0]['tel'],'+96171123456')
    def test_duplicate_save_approval(self):
        a=self.save();b=self.save();self.assertEqual(a['id'],b['id']);self.assertEqual(self.approve(a).status_code,200)
        again=self.c.post('/api/invoices/'+a['id']+'/approve',json={'confirm':True,'review_digest':a['review_digest']},headers=self.h)
        self.assertEqual(again.status_code,200)
        with web_api.connect(app.config['INVOICE_DB']) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM audit WHERE action='approved'").fetchone()[0],1)
        changed=copy.deepcopy(self.data);changed['items'][0]['p']=10
        self.assertEqual(self.c.post('/api/invoices',json=changed,headers=self.h).status_code,409)
    def test_missing_invalid_and_empty_items(self):
        for n,items in enumerate([[],[{'d':'','q':1,'p':8}],[{'d':'X','q':0,'p':8}],[{'d':'X','q':None,'p':8}],[{'d':'X','q':1,'p':None}]]):
            d=self.save({**self.data,'items':items,'client_request_id':str(n)})
            self.assertEqual(self.c.post('/api/invoices/'+d['id']+'/submit',json={},headers=self.h).status_code,409)
    def test_contact_validation_and_deduplication(self):
        for cust in ({'name':'A','tel':'hello'},{'name':'A','email':'wrong'}):
            self.assertEqual(self.c.post('/api/customers',json=cust,headers=self.h).status_code,422)
        a=self.c.post('/api/customers',json=self.data['cust'],headers=self.h).json
        b=self.c.post('/api/customers',json=self.data['cust'],headers=self.h).json
        self.assertEqual(a['id'],b['id'])
    def test_pdf_failure_rolls_back_approval(self):
        d=self.save();self.c.post('/api/invoices/'+d['id']+'/submit',json={},headers=self.h)
        with patch('pdf_invoice.web_invoice_pdf',side_effect=RuntimeError('font problem')):
            r=self.c.post('/api/invoices/'+d['id']+'/approve',json={'confirm':True,'review_digest':d['review_digest']},headers=self.h)
        self.assertEqual(r.status_code,500)
        self.assertEqual(self.c.get('/api/invoices/'+d['id']).json['status'],'pending')
        with web_api.connect(app.config['INVOICE_DB']) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM invoice_files').fetchone()[0],0)
    def test_custom_confirmation_and_catalog_unchanged(self):
        path=Path(web_api.BASE)/'products.json';before=hashlib.sha256(path.read_bytes()).hexdigest()
        order={'customer':'Elie','parts':[{'name':'coupling','quantity':2,'unit_price':8,'price_currency':'USD'}]}
        with patch('invoice_engine.understand_message',return_value=order):
            proposal=self.c.post('/api/invoices/generate',json={'text':'two couplings at 8 USD each'},headers=self.h).json
        self.assertNotIn('items',proposal)
        selection={'custom':True,'name':'Coupling','quantity':2,'unit_price':8,'currency':'USD'}
        payload={'confirm':True,'confirmation_token':proposal['confirmation_token'],'selections':{'0':selection}}
        for field in ('quantity','unit_price'):
            bad=copy.deepcopy(payload);bad['selections']['0'][field]=None
            self.assertEqual(self.c.post('/api/invoices/confirm-parts',json=bad,headers=self.h).status_code,422)
        r=self.c.post('/api/invoices/confirm-parts',json=payload,headers=self.h)
        self.assertEqual(r.json['totals']['total_usd'],16);self.assertTrue(r.json['items'][0]['is_custom']);self.assertIsNone(r.json['items'][0]['catalog_id'])
        self.assertEqual(before,hashlib.sha256(path.read_bytes()).hexdigest())
    def test_delivery_failure_retry_same_bytes_and_idempotency(self):
        d=self.save();self.approve(d);path='/api/invoices/'+d['id'];pdf=self.c.get(path+'/pdf').data
        data={'confirm':True,'to':'elie@example.test','request_key':'request-123'}
        with patch('delivery_providers.send_email',side_effect=delivery_providers.DeliveryError('Unavailable')):
            r=self.c.post(path+'/email',json=data,headers=self.h)
        self.assertEqual(r.json['status'],'failed');self.assertEqual(self.c.get(path).json['status'],'approved')
        data['request_key']='request-456'
        with patch('delivery_providers.send_email',return_value='provider-test-id') as send:
            r=self.c.post(path+'/email',json=data,headers=self.h);again=self.c.post(path+'/email',json=data,headers=self.h)
            self.assertEqual(send.call_count,1);self.assertEqual(send.call_args.args[1],pdf)
        self.assertEqual(r.json['status'],'sent');self.assertFalse(r.json['delivery_confirmed']);self.assertEqual(r.json['id'],again.json['id'])
        self.assertEqual(len(self.c.get(path+'/activity').json['deliveries']),2)
    def test_unapproved_delivery_csrf_print_and_company_isolation(self):
        d=self.save();path='/api/invoices/'+d['id'];data={'confirm':True,'request_key':'request-789'}
        self.assertEqual(self.c.post(path+'/email',json=data,headers=self.h).status_code,409)
        self.assertEqual(self.c.post(path+'/print',json={},headers=self.h).status_code,409)
        self.approve(d)
        self.assertEqual(self.c.post(path+'/email',json=data).status_code,403)
        r=self.c.post(path+'/print',json={},headers=self.h);self.assertEqual(r.json['status'],'initiated');self.assertFalse(r.json['physical_print_confirmed'])
        other=app.test_client();other.post('/api/auth/register',json={**SIGNUP,'username':'other_test'})
        self.assertEqual(other.get(path+'/activity').status_code,404);self.assertEqual(other.get(path+'/pdf').status_code,404)
    def test_missing_provider_configuration(self):
        d=self.save();self.approve(d)
        with patch.dict(os.environ,{},clear=True):
            self.assertFalse(self.c.get('/api/delivery/config').json['email']['configured'])
            for method,to in [('email','elie@example.test'),('whatsapp','+96171123456')]:
                r=self.c.post('/api/invoices/'+d['id']+'/'+method,json={'confirm':True,'to':to,'request_key':'no-config-123'},headers=self.h)
                self.assertEqual(r.json['status'],'failed');self.assertIn('configured',r.json['error'])

if __name__=='__main__':unittest.main()

