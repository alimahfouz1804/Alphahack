
import json
from pathlib import Path

BASE = Path(__file__).parent

def load_products():
    with open(BASE / "products.json", "r", encoding="utf-8") as f:
        return json.load(f)["products"]

def search_products(query):
    query = query.strip().casefold()

    if not query:
        return []

    results = []

    for product in load_products():
        names = [
            product["id"],
            product["name_en"],
            product["name_ar"],
            *product["aliases"]
        ]

        if any(query in name.casefold() for name in names):
            results.append(product)

    return results

def get_product_by_id(product_id):
    for product in load_products():
        if product["id"] == product_id:
            return product
    return None

if __name__ == "__main__":
    for query in ["فلتر زيت", "oil filter", "زيت موتور"]:
        print(query, search_products(query))
