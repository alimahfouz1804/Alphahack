"""Run the AI scenarios against the REAL MA agent (real Gemini) and write AI_SCENARIOS.md.

Usage (from the InvoiceFlow folder, with GEMINI_API_KEY in .env):
    python ai_eval/run_eval.py                  # all 60 scenarios
    python ai_eval/run_eval.py --only S13,S40   # some scenarios (e.g. re-test after a fix)
    python ai_eval/run_eval.py --doc-only       # only rebuild AI_SCENARIOS.md from saved results

What is real and what is not:
  * The whole server path is real: intent routing, Gemini extraction, catalog matching,
    server validation, totals, approval, PDF storage. A temporary database is used, never garage.db.
  * Voice: if ai_eval/audio/<ID>.webm (or .wav/.m4a/.mp3/.ogg) exists, it is sent to the real
    /api/transcribe endpoint (real speech-to-text). Otherwise the scenario's transcript text is
    used and the result is labelled "transcript-level" (it tests MA's understanding, NOT the microphone
    or speech-to-text).
  * Nothing here trains or fine-tunes the model. Results measure the current prompts + rules.
"""
import argparse
import datetime
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EVAL = ROOT / 'ai_eval'
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

SIGNUP = dict(first_name='Eval', last_name='Runner', username='ai_eval_runner', password='EvalRunner2026',
              phone='+96171123456', company_name='Eval Garage')


def load():
    return json.loads((EVAL / 'scenarios.json').read_text(encoding='utf-8'))


# ---------------------------------------------------------------- running
def run_scenario(app, sc, delay):
    """Plays one scenario like the browser does. Returns the evidence used for checking."""
    import web_api
    app.config['INVOICE_DB'] = tempfile.mkdtemp() + '/eval.db'
    pass  # login/rate limits are stored in the (fresh) test database
    c = app.test_client()
    r = c.post('/api/auth/register', json=SIGNUP)
    assert r.status_code == 201, r.json
    h = {'X-CSRF-Token': c.get_cookie('if_csrf').value}
    history, steps, last, first_question = [], [], {}, None
    catalog_before = hashlib.sha256((ROOT / 'products.json').read_bytes()).hexdigest()
    ev = dict(confirm_status=None, approve_status=None, invoice=None, preview_pdf=False, voice_mode=None)

    def post_message(text):
        nonlocal last, first_question
        history.append({'role': 'user', 'text': text})
        for wait in (20, 45, 90, None):  # model busy / quota: wait and retry, never count it as an AI answer
            resp = c.post('/api/invoices/generate', json={'text': text, 'history': history}, headers=h)
            if resp.status_code not in (429, 503) or wait is None:
                break
            print('(model busy, retrying in %ds)' % wait, end=' ', flush=True)
            time.sleep(wait)
        data = resp.json if resp.is_json else {'error': resp.status_code}
        if resp.status_code != 200:
            data = {'error': resp.status_code, 'detail': (resp.json or {}).get('detail') if resp.is_json else ''}
        # keep history exactly like the frontend does
        if 'reply' in data:
            history.append({'role': 'assistant', 'text': data['reply'], 'kind': 'answer', 'ask': data.get('ask', '')})
        elif data.get('question'):
            history.append({'role': 'assistant', 'text': data['question'], 'kind': 'question'})
            if first_question is None:
                first_question = data['question']
        last = data
        steps.append({'user': text, 'ma': summarize(data)})
        time.sleep(delay)

    for turn in sc['turns']:
        if 'seed_customer' in turn:
            c.post('/api/customers', json=turn['seed_customer'], headers=h)
        elif 'say' in turn:
            post_message(turn['say'])
        elif 'voice' in turn:
            audio = None
            for ext in ('.webm', '.wav', '.m4a', '.mp3', '.ogg'):
                p = EVAL / 'audio' / (sc['id'] + ext)
                if p.exists():
                    audio = p; break
            if audio:
                with open(audio, 'rb') as f:
                    tr = c.post('/api/transcribe', data={'audio': (f, audio.name)}, content_type='multipart/form-data', headers=h)
                text = (tr.json or {}).get('transcript', '') if tr.is_json else ''
                ev['voice_mode'] = 'real audio -> speech-to-text'
                steps.append({'audio': audio.name, 'transcript': text, 'expected_transcript': turn['voice']})
                time.sleep(delay)
                post_message(text or '(empty transcript)')
            else:
                ev['voice_mode'] = ev['voice_mode'] or 'transcript-level (no audio file)'
                post_message(turn['voice'])
        elif 'confirm' in turn:
            token = last.get('confirmation_token')
            if not token:
                steps.append({'confirm': 'no suggestions to confirm'}); ev['confirm_status'] = 'no-suggestions'; continue
            sel = {}
            for s in last.get('suggestions', []):
                want = turn['confirm']
                sel[str(s['index'])] = ({'custom': True, **want['custom']} if 'custom' in want else want['pick'])
            resp = c.post('/api/invoices/confirm-parts', json={'confirmation_token': token, 'selections': sel, 'confirm': True}, headers=h)
            ev['confirm_status'] = resp.status_code
            if resp.status_code == 200:
                last = resp.json
                if last.get('question'):
                    history.append({'role': 'assistant', 'text': last['question'], 'kind': 'question'})
            steps.append({'confirm': turn['confirm'], 'status': resp.status_code, 'ma': summarize(resp.json if resp.is_json else {})})
        elif turn.get('approve') or turn.get('preview_pdf'):
            if 'items' not in last:
                steps.append({'save': 'no draft to save'}); ev['approve_status'] = 'no-draft'; continue
            saved = c.post('/api/invoices', json=last, headers=h)
            if saved.status_code != 201:
                ev['approve_status'] = saved.status_code; steps.append({'save': saved.status_code}); continue
            inv = saved.json
            if turn.get('preview_pdf'):
                p = c.get('/api/invoices/%s/pdf?preview=1' % inv['id'])
                ev['preview_pdf'] = p.data[:4] == b'%PDF'
                steps.append({'preview_pdf': ev['preview_pdf']})
            if turn.get('approve'):
                fresh = c.get('/api/invoices/' + inv['id']).json
                a = c.post('/api/invoices/%s/approve' % inv['id'], json={'confirm': True, 'review_digest': fresh['review_digest'], 'acknowledge_warnings': True}, headers=h)
                ev['approve_status'] = a.status_code
                steps.append({'approve': a.status_code})
                if a.status_code == 200:
                    ev['invoice'] = a.json
    with app.app_context(), web_api.connect() as db:
        ev['pdf_stored'] = db.execute('SELECT COUNT(*) FROM invoice_files').fetchone()[0] > 0
    ev['history'] = c.get('/api/invoices').json
    ev['catalog_unchanged'] = catalog_before == hashlib.sha256((ROOT / 'products.json').read_bytes()).hexdigest()
    ev['final'] = last
    ev['first_question'] = first_question
    ev['steps'] = steps
    return ev


def summarize(d):
    if not isinstance(d, dict):
        return d
    if 'error' in d:
        return {'error': d['error'], 'detail': d.get('detail')}
    out = {}
    for k in ('reply', 'question', 'understood', 'ask', 'action', 'new_invoice', 'blocked_items'):
        if d.get(k):
            out[k] = d[k]
    if d.get('suggestions'):
        out['suggestions'] = [{'description': s.get('description'), 'candidates': [x['id'] for x in s.get('candidates', [])],
                               'custom_allowed': s.get('custom_allowed')} for s in d['suggestions']]
    if 'items' in d:
        out['customer'] = (d.get('cust') or {}).get('name')
        out['tel'] = (d.get('cust') or {}).get('tel')
        out['plate'] = (d.get('truck') or {}).get('plate')
        out['items'] = [{'name': i.get('d'), 'catalog_id': i.get('catalog_id'), 'q': i.get('q'), 'p': i.get('p'),
                         'line_usd': i.get('total_usd'), 'custom': i.get('is_custom')} for i in d['items']]
        out['total_usd'] = (d.get('totals') or {}).get('total_usd')
        out['review'] = d.get('review')
        out['warnings'] = d.get('warnings')
    return out


# ---------------------------------------------------------------- checking
def num(x):
    return None if x is None else round(float(x), 2)


def check(sc, ev):
    e, d, fails = sc['expect'], ev['final'] or {}, []
    has_items, q = 'items' in d, d.get('question')
    kind = e.get('kind')

    def need(cond, why):
        if not cond: fails.append(why)

    if 'error' in d:
        fails.append('server error %s: %s' % (d.get('error'), d.get('detail')))
    if kind == 'draft': need(has_items, 'expected a draft invoice, got %s' % ('a question' if q else 'no draft'))
    if kind == 'question': need(bool(q) and not has_items, 'expected a clarification question, got %s' % ('a draft' if has_items else 'no question'))
    if kind == 'question_or_suggestions': need((q or d.get('suggestions')) and not has_items, 'expected a question/suggestions, got %s' % ('a draft' if has_items else 'neither'))
    if kind == 'draft_or_question': need(has_items or q, 'expected a draft or a question')
    if kind == 'not_draft': need(not has_items, 'expected no draft after cancelling')
    if kind == 'approved': need(ev['approve_status'] == 200, 'approval expected to succeed (got %s)' % ev['approve_status'])
    if kind == 'approve_blocked': need(ev['approve_status'] == 409, 'approval expected to be blocked with 409 (got %s)' % ev['approve_status'])
    if kind == 'confirm_rejected': need(ev['confirm_status'] == 422, 'an unsuggested part must be rejected with 422 (got %s)' % ev['confirm_status'])

    inv = ev['invoice'] if kind == 'approved' and ev['invoice'] else d
    items = inv.get('items') or []
    cust = (inv.get('cust') or {}).get('name') or ''
    if 'customer' in e and (has_items or inv is ev['invoice']):
        need(cust.strip().casefold() == e['customer'].casefold(), 'customer: expected %r, got %r' % (e['customer'], cust))
    if 'customer_contains' in e and has_items: need(e['customer_contains'] in cust, 'customer should contain %r, got %r' % (e['customer_contains'], cust))
    if 'customer_ci' in e and has_items: need(cust.strip().casefold() == e['customer_ci'], 'customer: got %r' % cust)
    if 'tel' in e and has_items: need((inv.get('cust') or {}).get('tel') == e['tel'], 'phone: expected %s, got %s' % (e['tel'], (inv.get('cust') or {}).get('tel')))
    if 'plate' in e and has_items: need((inv.get('truck') or {}).get('plate') == e['plate'], 'plate: expected %s, got %s' % (e['plate'], (inv.get('truck') or {}).get('plate')))
    for want in e.get('items', []):
        def match(i):
            name = (i.get('d') or '')
            if 'name' in want and name.casefold() != want['name'].casefold(): return False
            if 'name_contains' in want and want['name_contains'].casefold() not in name.casefold(): return False
            if 'catalog_id' in want and i.get('catalog_id') != want['catalog_id']: return False
            if 'q' in want and num(i.get('q')) != num(want['q']): return False
            if 'p' in want and num(i.get('p')) != num(want['p']): return False
            if 'is_custom' in want and bool(i.get('is_custom')) != want['is_custom']: return False
            return True
        need(any(match(i) for i in items), 'missing line %s' % json.dumps(want, ensure_ascii=False))
    for name in e.get('absent', []):
        need(not any(name.casefold() == (i.get('d') or '').casefold() for i in items), '%s should have been removed/replaced' % name)
    tot = num((inv.get('totals') or {}).get('total_usd'))
    if 'total_usd' in e and (has_items or kind == 'approved'): need(tot == num(e['total_usd']), 'total: expected %s, got %s' % (e['total_usd'], tot))
    if 'total_usd_if_draft' in e and has_items: need(tot == num(e['total_usd_if_draft']), 'total must stay %s (no silent discount), got %s' % (e['total_usd_if_draft'], tot))
    if 'item_count' in e and has_items: need(len(items) == e['item_count'], 'expected %d line(s), got %d' % (e['item_count'], len(items)))
    if e.get('no_items'): need(not has_items, 'must not produce an invoice before clarification')
    if e.get('no_invented_price') and has_items:
        need(all(i.get('p') is None for i in items if not str(i.get('d', '')).lower().startswith('labor')), 'a price was filled in that the mechanic never said')
    if e.get('no_negative_lines') and has_items: need(all((i.get('p') or 0) >= 0 for i in items), 'negative (discount) line added')
    if e.get('review_missing') and has_items:
        got = [m['field'] for m in (d.get('review') or {}).get('missing', [])]
        need(all(f in got for f in e['review_missing']), 'review should list missing %s, got %s' % (e['review_missing'], got))
    if e.get('duplicate_ok') and has_items:
        merged = any(num(i.get('q')) == 2 for i in items if i.get('catalog_id') == 'P003')
        need(merged or (d.get('review') or {}).get('duplicates'), 'duplicate oil filter neither merged nor flagged')
    if e.get('total_equals_lines') and has_items:
        need(num(sum(i.get('total_usd') or 0 for i in items)) == tot, 'total differs from the sum of lines')
    if e.get('candidates_any') and not has_items and d.get('suggestions'):
        ids = {x['id'] for s in d['suggestions'] for x in s.get('candidates', [])}
        need(ids & set(e['candidates_any']), 'suggestions should include one of %s, got %s' % (e['candidates_any'], sorted(ids)))
    if e.get('question_contains') and q:
        need(any(w in q.lower() for w in e['question_contains']), 'question should ask about %s, got %r' % (e['question_contains'], q[:120]))
    if e.get('first_question_contains'):
        fq = (ev['first_question'] or '').lower()
        need(any(w in fq for w in e['first_question_contains']), 'MA should ask for the display name, asked %r' % fq[:120])
    if e.get('new_invoice'): need(d.get('new_invoice') is True, 'second invoice not marked as a new invoice')
    if e.get('catalog_unchanged'): need(ev['catalog_unchanged'], 'products.json changed')
    if e.get('pdf_stored'): need(ev['pdf_stored'], 'no stored PDF after approval')
    if e.get('in_history'): need(any(x['status'] == 'approved' for x in ev['history']), 'approved invoice not in history')
    if e.get('preview_pdf'): need(ev['preview_pdf'], 'preview PDF not produced')
    if e.get('no_saved_invoices'): need(not ev['history'], 'an invoice was saved although it was cancelled')
    return fails


# ---------------------------------------------------------------- documentation
def md_escape(x):
    return str(x).replace('|', '\\|').replace('\n', ' ')


def turns_text(sc):
    out = []
    for t in sc['turns']:
        if 'say' in t: out.append('Text: "%s"' % t['say'])
        elif 'voice' in t: out.append('Voice (expected transcript): "%s"' % t['voice'] + (' (audio file: %s)' % t['audio'] if t.get('audio') else ''))
        elif 'confirm' in t: out.append('Employee confirms: %s' % json.dumps(t['confirm'], ensure_ascii=False))
        elif 'approve' in t: out.append('Employee clicks Approve (expected HTTP %s)' % t.get('expect_status', 200))
        elif 'preview_pdf' in t: out.append('Employee downloads the preview PDF')
        elif 'seed_customer' in t: out.append('Existing saved customer: %s' % t['seed_customer']['name'])
    return out


def write_doc(scenarios, results, runs):
    total = len(scenarios)
    done = [s for s in scenarios if s['id'] in results]
    passed = [s for s in done if results[s['id']]['pass']]
    L = ['# AI Scenarios: MA (InvoiceFlow AI) evaluation', '',
         'Generated by `ai_eval/run_eval.py` from `ai_eval/scenarios.json`. Do not edit results by hand.', '',
         '**What these results mean:** each scenario is played against the real MA through the real server '
         '(intent routing, Gemini extraction, catalog matching, validation, totals, approval, PDF). '
         'No model was fine-tuned: improvements are prompt, rule, retrieval and validation changes, measured here.', '',
         '**Voice scenarios:** unless a real recording exists in `ai_eval/audio/`, they are evaluated at '
         '**transcript level** (MA understanding only). That does not prove the microphone or speech-to-text works; '
         'those are covered by TC-01 to TC-04 and the manual checks in TEST_CASES.md.', '']
    if not done:
        L += ['## Status: NOT EXECUTED', '',
              'The scenarios have not been run against the live model yet. On the laptop (with the Gemini key in `.env`):', '',
              '```', 'python ai_eval/run_eval.py', '```', '',
              'Every "Actual" field below says NOT EXECUTED until then. Nothing here is a result.', '']
    else:
        last = runs[-1] if runs else {}
        L += ['## Summary', '',
              '| Scenarios | Executed | Passed | Failed | Not executed | Last run | Model(s) |', '|---|---|---|---|---|---|---|',
              '| %d | %d | %d | %d | %d | %s | %s |' % (total, len(done), len(passed), len(done) - len(passed), total - len(done),
                                                     last.get('at', ''), md_escape(last.get('models', ''))), '']
        cats = {}
        for s in scenarios:
            c = cats.setdefault(s['category'], [0, 0, 0])
            c[0] += 1
            if s['id'] in results:
                c[1] += 1; c[2] += results[s['id']]['pass']
        L += ['| Category | Scenarios | Executed | Passed |', '|---|---|---|---|'] + ['| %s | %d | %d | %d |' % (k, *v) for k, v in cats.items()] + ['']
        L += ['| ID | Title | Result |', '|---|---|---|'] + [
            '| %s | %s | %s |' % (s['id'], md_escape(s['title']), ('PASS' if results[s['id']]['pass'] else 'FAIL') if s['id'] in results else 'NOT EXECUTED') for s in scenarios] + ['']
    for s in scenarios:
        r = results.get(s['id'])
        prev = [x['results'][s['id']] for x in runs[:-1] if s['id'] in x.get('results', {})]
        L += ['---', '', '## %s: %s' % (s['id'], s['title']), '',
              '| Field | Value |', '|---|---|',
              '| Scenario ID | %s |' % s['id'], '| Title | %s |' % md_escape(s['title']), '| Category | %s |' % s['category'],
              '| Input type | %s |' % s['input_type'],
              '| Original mechanic request | %s |' % md_escape(' → '.join(turns_text(s))),
              '| Expected interpretation | %s |' % md_escape(s['expected_interpretation']),
              '| Expected extracted fields | %s |' % md_escape(json.dumps({k: v for k, v in s['expect'].items() if k in ('customer', 'customer_contains', 'tel', 'plate', 'items')}, ensure_ascii=False)),
              '| Expected catalog behavior | %s |' % md_escape(s['expected_catalog_behavior']),
              '| Expected clarification | %s |' % md_escape(s['expected_clarification']),
              '| Expected structured output (checks) | `%s` |' % md_escape(json.dumps(s['expect'], ensure_ascii=False)),
              '| Expected invoice draft | %s |' % md_escape(s['expected_invoice_draft']),
              '| Business rules evaluated | %s |' % md_escape('; '.join(s['business_rules'])),
              '| Actual agent output | %s |' % (md_escape(json.dumps(r['actual'], ensure_ascii=False)[:1500]) if r else 'NOT EXECUTED'),
              '| Voice handling | %s |' % (md_escape(r.get('voice_mode') or 'n/a (text)') if r else 'NOT EXECUTED'),
              '| Pass / Fail | %s |' % (('PASS' if r['pass'] else 'FAIL') if r else 'NOT EXECUTED'),
              '| Error explanation | %s |' % (md_escape('; '.join(r['fails']) or '—') if r else 'NOT EXECUTED'),
              '| Fix applied | %s |' % md_escape('; '.join(s.get('fix_log') or []) or '—'),
              '| Re-test result | %s |' % (md_escape(('earlier: %s → latest: %s' % (', '.join('PASS' if x['pass'] else 'FAIL' for x in prev), 'PASS' if r['pass'] else 'FAIL')) if prev else 'no re-test yet') if r else 'NOT EXECUTED'),
              '']
    (ROOT / 'AI_SCENARIOS.md').write_text('\n'.join(L), encoding='utf-8')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--only', help='comma-separated scenario IDs')
    ap.add_argument('--delay', type=float, default=3.0, help='seconds between model calls (quota)')
    ap.add_argument('--doc-only', action='store_true')
    ap.add_argument('--failed', action='store_true', help='re-run only scenarios whose latest result is FAIL')
    a = ap.parse_args()
    scenarios = load()
    runs_dir = EVAL / 'runs'
    runs = [json.loads(p.read_text(encoding='utf-8')) for p in sorted(runs_dir.glob('*.json'))] if runs_dir.exists() else []
    latest = {}
    for run in runs:
        latest.update(run['results'])
    if not a.doc_only:
        from dotenv import load_dotenv
        load_dotenv(ROOT / '.env')
        if not os.getenv('GEMINI_API_KEY'):
            sys.exit('GEMINI_API_KEY is missing in .env: the evaluation needs the real model.')
        from app import app
        only = set(a.only.split(',')) if a.only else None
        if a.failed:
            only = {k for k, r in latest.items() if not r['pass']}
            print('Re-running %d failed scenarios: %s' % (len(only), ', '.join(sorted(only))))
        run = {'at': datetime.datetime.now().isoformat(timespec='seconds'),
               'models': '%s (backup %s)' % (os.getenv('GEMINI_MODEL', 'gemini-3.5-flash'), os.getenv('GEMINI_BACKUP_MODEL', 'gemini-3.6-flash')),
               'results': {}}
        for sc in scenarios:
            if only and sc['id'] not in only:
                continue
            print('%s %s ...' % (sc['id'], sc['title']), end=' ', flush=True)
            try:
                ev = run_scenario(app, sc, a.delay)
                fails = check(sc, ev)
            except Exception as exc:  # report, never hide
                ev, fails = {'steps': [], 'voice_mode': None}, ['runner error: %s: %s' % (type(exc).__name__, exc)]
            res = {'pass': not fails, 'fails': fails, 'actual': ev.get('steps'), 'voice_mode': ev.get('voice_mode')}
            run['results'][sc['id']] = res
            print('PASS' if res['pass'] else 'FAIL: ' + '; '.join(fails))
        runs_dir.mkdir(exist_ok=True)
        (runs_dir / (run['at'].replace(':', '-') + '.json')).write_text(json.dumps(run, ensure_ascii=False, indent=1), encoding='utf-8')
        runs.append(run)
        latest.update(run['results'])
        print('\n%d run, %d passed' % (len(run['results']), sum(r['pass'] for r in run['results'].values())))
    write_doc(scenarios, latest, runs)
    print('AI_SCENARIOS.md written')


if __name__ == '__main__':
    main()
