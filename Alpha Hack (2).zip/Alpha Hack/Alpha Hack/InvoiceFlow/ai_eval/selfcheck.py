"""Pipeline self-check: NOT an AI evaluation.

Replaces Gemini with a scripted "perfect model" that returns exactly the extraction each scenario
expects, then runs the same runner and checks. If a scenario fails here, the problem is in the
server rules or in the scenario's expectations, not in the AI. Use it before spending model quota.

    python ai_eval/selfcheck.py
"""
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / 'ai_eval'))
os.environ.setdefault('GEMINI_API_KEY', 'selfcheck')
import run_eval  # noqa: E402

# Scenarios whose correct behaviour depends on the model REFUSING to guess (questions) are skipped:
# a scripted model cannot show that; only the live evaluation can.
NEEDS_REAL_MODEL = {'S09', 'S12', 'S18', 'S21', 'S22', 'S27', 'S28', 'S34', 'S35', 'S38', 'S43', 'S46', 'S53', 'S58'}


def scripted(sc):
    e = sc['expect']
    parts, labor = [], None
    for it in e.get('items', []):
        if it.get('name') == 'Labor':
            labor = it['p']; continue
        parts.append(dict(name=it.get('name') or it.get('name_contains'), quantity=int(it['q']), quantity_evidence=str(int(it['q'])),
                          unit_price=it['p'], price_currency='USD'))
    cust = e.get('customer') or e.get('customer_contains') or e.get('customer_ci') or ''
    order = dict(customer=cust, parts=parts, labor_amount=labor, labor_currency='USD' if labor is not None else None,
                 notes='', truck_plate=e.get('plate', ''), truck_model='', customer_phone=e.get('tel', ''), customer_email='')
    confirm = next((t['confirm'] for t in sc['turns'] if 'confirm' in t), None)
    if confirm and 'pick' in confirm:      # functional description -> candidates the employee confirms
        p0 = dict(order['parts'][0]) if order['parts'] else dict(name='part', quantity=1, quantity_evidence='1', unit_price=250, price_currency='USD')
        cands = ['P009'] if sc['expect'].get('kind') == 'confirm_rejected' else [confirm['pick'], 'P008' if confirm['pick'] != 'P008' else 'P010']
        p0.update(match_type='description', description=sc['turns'][0]['say'], candidate_ids=cands)
        if not order['parts']:
            order['parts'] = [p0]
        order['parts'][0] = p0
    if confirm and 'custom' in confirm:    # unknown item -> custom line
        order['parts'] = [dict(name='unknown widget', quantity=confirm['custom']['quantity'], quantity_evidence=str(confirm['custom']['quantity']),
                               unit_price=confirm['custom']['unit_price'], price_currency='USD', scope='automotive')]
    return order


def main():
    from app import app
    ok = bad = 0
    for sc in run_eval.load():
        if sc['id'] in NEEDS_REAL_MODEL:
            print(sc['id'], 'skipped (needs the real model to refuse/ask)'); continue
        order = scripted(sc)
        new = sc['expect'].get('new_invoice')
        route = lambda conv, today, wd: {'intent': 'invoice', 'language': 'en', 'new_invoice': bool(new)}
        with patch('ai_agent.route_message', side_effect=route), patch('invoice_engine.understand_message', return_value=order), \
             patch('part_lookup.lookup_part', return_value={'status': 'unavailable', 'question': '', 'sources': []}), \
             patch('workflow_routes.transcribe_audio', side_effect=lambda *a, **k: ''):
            ev = run_eval.run_scenario(app, sc, 0)
        fails = run_eval.check(sc, ev)
        ok += not fails; bad += bool(fails)
        print(sc['id'], 'OK' if not fails else 'PROBLEM: ' + '; '.join(fails))
    print('\nself-check: %d OK, %d problems (scripted model, NOT an AI result)' % (ok, bad))


if __name__ == '__main__':
    main()
