# Real voice recordings for the AI evaluation

Put real recordings here to test real speech-to-text, not only MA's understanding.
Name each file after its scenario: `S01.webm`, `S03.m4a`, … (.webm .wav .m4a .mp3 .ogg).

Voice scenarios: S01, S03, S08, S09, S10, S39, S51, S60. The expected words are in `ai_eval/scenarios.json`
(the `voice` field). Record them the way a mechanic would really say them, in the garage if possible
(background noise is fine; that is the point).

Then run `python ai_eval/run_eval.py --only S01,S03,S08,S09,S10,S39,S51,S60`.
AI_SCENARIOS.md will show "real audio -> speech-to-text" and the transcript for each one.
Without a file, a voice scenario is evaluated at transcript level only.

Do not record real customer names or phone numbers.
