@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
python start_local.py
if errorlevel 1 pause
