# InvoiceFlow AI: voice, approval and PDF workflow

This extends the existing Flask project. Product records and catalog prices are preserved. New drafts use only prices explicitly supplied in the repair description or entered while editing: an omitted price remains JSON null and displays as a dash. The configured USD/LBP exchange rate is preserved. The existing private .env is reused and must never be shared. No default employee password is installed.

## Start and test

In a VS Code PowerShell terminal:

```powershell
cd "C:\Users\aliab\OneDrive\Documents\Alpha Hack\InvoiceFlow"
python -m pip install -r requirements.txt
python manage_employees.py
python app.py
```

Employee setup asks for a username and a hidden password of at least 12 characters. Run it again to reset that employee's password and revoke their sessions. Keep this local administrative command restricted to the laptop owner. If the backend is already running on port 5000, use it rather than starting a second copy.

In a second terminal, from the same folder:

```powershell
python -m unittest test_backend test_workflow -v
python demo_workflow.py --message "Customer Demo Customer: replaced 2 oil filters at 25 USD each and 1 fuel filter at 30 USD each. Labor 30 USD."
python demo_workflow.py --message "للزبون التجريبي غيرنا فلتر زيت عدد اتنين سعر الواحد 25 دولار وفلتر مازوت واحد سعره 30 دولار وأجرة إيد 30 دولار"
python demo_workflow.py --audio "C:\path\to\recording.wav"
```

The demo prints the transcript and invoice for review, asks for your employee login without echoing the password, writes a draft PDF, and requires typing APPROVE before downloading a final PDF. It also requires acknowledging any invoice warnings. PDFs go to output/pdf. Login tokens are not printed and are revoked when the demo finishes.

Both example repair requests should produce two P003 oil filters and one P004 fuel filter, labor USD 30, total USD 110.00 / LBP 9,900,000 using the current catalog rate. Arabic/English voice results should be reviewed for transcription accuracy before approval.

## API contract

| Method and path | Input / behavior |
|---|---|
| POST /api/invoice/draft | Existing JSON `{ "message": "..." }`; now also saves a draft and returns invoice_id and review_digest. Existing invoice fields remain. |
| POST /api/transcribe | multipart/form-data field audio containing a recording. Optional generate_invoice=true returns `{transcript, invoice}`. Default returns `{transcript}` only. |
| POST /api/auth/login | JSON username and password. Returns a one-hour Bearer token. Five failed attempts per client IP block login for five minutes. |
| POST /api/auth/logout | Bearer token; revokes the session. |
| GET /api/invoices/{id} | Employee Bearer token; loads the exact saved draft for review. |
| POST /api/invoices/{id}/approve | Employee token and JSON `{ "confirm": true, "review_digest": "digest from reviewed draft", "acknowledge_warnings": true }`. Warnings require explicit acknowledgment. |
| GET /api/invoices/{id}/pdf?preview=true | Employee token; draft PDFs are clearly marked NOT APPROVED. |
| GET /api/invoices/{id}/pdf | Employee token; final PDF blocked with 409 until the saved invoice is approved. |

Send employee tokens in `Authorization: Bearer <token>`, never in URLs. No cookies are used. Voice uploads are limited to 10 MB; supported containers are WAV, MP3, M4A/MP4, OGG, FLAC and WebM. Headers are checked rather than trusting filenames; Gemini must still decode the recording. Empty/unintelligible or invalid audio returns 400, oversized uploads 413, AI outages 503. Audio is processed transiently and is not stored by this app; it is sent to Gemini for transcription.

## Approval and sending

Invoice payloads are saved server-side in garage.db. Approval records the employee and time and checks the reviewed snapshot digest. Client-supplied prices, approved flags, or employee names cannot authorize an invoice. Approved snapshots are immutable through the API; corrections require a new draft and new approval. Review warnings must be acknowledged. Passwords use Werkzeug's salted password hashing; only token hashes are stored. Approval and PDF release are recorded in the audit table.

Sending currently means downloading an approved PDF for manual delivery. No email or WhatsApp sender is configured and the app does not claim an invoice has been sent. If an automatic sender is added later, it must load the saved approved snapshot and enforce the same approval gate; never trust a client-supplied invoice body. Preview PDFs remain visibly unapproved.

This is a localhost backend. Before remote deployment, use HTTPS, a production server, access controls for draft creation/transcription, database backups, and restricted filesystem access. Anyone who can edit this laptop's Python files or database is an administrator and outside the API approval boundary.

## Files

- app.py: preserves existing endpoints; saves draft snapshots and registers new routes.
- voice_agent.py: Gemini transcription with existing API key/model fallback, file limits and speech validation. Optional GEMINI_AUDIO_MODEL overrides the primary audio model.
- workflow_routes.py: upload, employee login/logout, review, approval, and PDF endpoints.
- approval_store.py: SQLite employee hashes, sessions, immutable drafts and audit records.
- manage_employees.py: local hidden-password setup/reset.
- pdf_invoice.py: ReportLab PDFs, Arabic shaping and Unicode font. Uses Windows Arial by default; INVOICE_FONT_PATH may point to another Arabic-capable TTF.
- demo_workflow.py: interactive test of text/voice through review and approved PDF download.
- test_backend.py / test_workflow.py: regression and security tests with isolated temporary databases; no live Gemini calls in these unit tests.
- requirements.txt / .gitignore: PDF dependencies and exclusion of private/generated files.

The explicit-price update changes ai_agent.py and invoice_engine.py to extract quoted unit prices instead of filling them from the catalog. Missing prices or labor leave the draft incomplete and block approval, even if warnings are acknowledged. Existing terminal snapshots are immutable: generate a fresh draft with the missing prices included, or use the website's editable draft workflow. products.json and .env are unchanged. Timestamped backups of edited files are kept in .local-backups.

Gemini audio reference: https://ai.google.dev/gemini-api/docs/audio
