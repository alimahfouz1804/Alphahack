@echo off
cd /d "%~dp0"
echo Re-running only the scenarios that failed last time...
python ai_eval\run_eval.py --failed > ai_eval\last_run.log 2>&1
type ai_eval\last_run.log
echo.
echo Done. Results are in AI_SCENARIOS.md
pause
